import {
  protoOf180f3jzyo7rfj as protoOf,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  classMetawt99a3kyl3us as classMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  objectMeta213120oau977m as objectMeta,
  Random24dxadk52mliy as Random,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
setMetadataFor(CryptographyRandom, 'CryptographyRandom', classMeta, Random);
setMetadataFor(AbstractRandom, 'AbstractRandom', classMeta, CryptographyRandom);
setMetadataFor(Default, 'Default', objectMeta, CryptographyRandom);
setMetadataFor(WebCryptoCryptographyRandom, 'WebCryptoCryptographyRandom', objectMeta, AbstractRandom);
//endregion
function AbstractRandom() {
  CryptographyRandom.call(this);
}
protoOf(AbstractRandom).vg = function (bitCount) {
  var numBytes = (bitCount + 7 | 0) / 8 | 0;
  var b = this.yg(numBytes);
  var next = 0;
  var inductionVariable = 0;
  if (inductionVariable < numBytes)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      next = (next << 8) + (b[i] & 255) | 0;
    }
     while (inductionVariable < numBytes);
  return next >>> (imul(numBytes, 8) - bitCount | 0) | 0;
};
protoOf(AbstractRandom).xg = function (array) {
  // Inline function 'kotlin.collections.isNotEmpty' call
  // Inline function 'kotlin.collections.isEmpty' call
  if (!(array.length === 0)) {
    this.l4u(array);
  }
  return array;
};
function Default() {
  Default_instance = this;
  CryptographyRandom.call(this);
  this.m4u_1 = defaultCryptographyRandom();
}
protoOf(Default).vg = function (bitCount) {
  return this.m4u_1.vg(bitCount);
};
protoOf(Default).ye = function () {
  return this.m4u_1.ye();
};
protoOf(Default).wg = function () {
  return this.m4u_1.wg();
};
protoOf(Default).xg = function (array) {
  return this.m4u_1.xg(array);
};
protoOf(Default).yg = function (size) {
  return this.m4u_1.yg(size);
};
protoOf(Default).zg = function (array, fromIndex, toIndex) {
  return this.m4u_1.zg(array, fromIndex, toIndex);
};
var Default_instance;
function Default_getInstance() {
  if (Default_instance == null)
    new Default();
  return Default_instance;
}
function CryptographyRandom() {
  Default_getInstance();
  Random.call(this);
}
function defaultCryptographyRandom() {
  return WebCryptoCryptographyRandom_getInstance();
}
function fillBytes($this, jsArray) {
  var size = jsArray.length;
  if (size <= 65536) {
    $this.o4u_1.getRandomValues(jsArray);
  } else {
    var filled = 0;
    do {
      // Inline function 'kotlin.comparisons.minOf' call
      var b = size - filled | 0;
      var chunkSize = Math.min(65536, b);
      $this.o4u_1.getRandomValues(jsArray.subarray(filled, filled + chunkSize | 0));
      filled = filled + chunkSize | 0;
    }
     while (filled < size);
  }
}
function WebCryptoCryptographyRandom() {
  WebCryptoCryptographyRandom_instance = this;
  AbstractRandom.call(this);
  this.n4u_1 = 65536;
  this.o4u_1 = getCrypto();
}
protoOf(WebCryptoCryptographyRandom).l4u = function (array) {
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  fillBytes(this, array);
};
var WebCryptoCryptographyRandom_instance;
function WebCryptoCryptographyRandom_getInstance() {
  if (WebCryptoCryptographyRandom_instance == null)
    new WebCryptoCryptographyRandom();
  return WebCryptoCryptographyRandom_instance;
}
function getCrypto() {
  // Inline function 'kotlin.js.unsafeCast' call
  return function () {
    var isNodeJs = typeof process !== 'undefined' && process.versions != null && process.versions.node != null;
    if (isNodeJs) {
      return eval('require')('node:crypto').webcrypto;
    } else {
      return window ? window.crypto ? window.crypto : window.msCrypto : self.crypto;
    }
  }();
}
//region block: exports
export {
  Default_getInstance as Default_getInstance3i7clpznr2ox9,
};
//endregion

//# sourceMappingURL=cryptography-kotlin-cryptography-random.mjs.map
