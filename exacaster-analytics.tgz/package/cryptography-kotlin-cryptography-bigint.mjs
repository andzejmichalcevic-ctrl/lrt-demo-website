import {
  STRING_getInstance2ou4lro9xn2qn as STRING_getInstance,
  PrimitiveSerialDescriptor3egfp53lutxj2 as PrimitiveSerialDescriptor,
  KSerializerzf77vz1967fq as KSerializer,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
import {
  protoOf180f3jzyo7rfj as protoOf,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  objectMeta213120oau977m as objectMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  VOID7hggqo3abtya as VOID,
  Number22v9c06q24q04 as Number_0,
  toByte1ihbgyfg5m688 as toByte,
  toShort1i0zdidogv7z as toShort,
  toInt2q8uldh7sc951 as toInt,
  toLongkk4waq8msp1k as toLong,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  Comparable198qfk8pnblz0 as Comparable,
  classMetawt99a3kyl3us as classMeta,
  arrayCopytctsywo3h7gj as arrayCopy,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  Long2qws0ah9gnpki as Long,
  toString1pkumu07cwy4m as toString,
  IllegalArgumentException_init_$Create$310sysrobvll9 as IllegalArgumentException_init_$Create$,
  toHexString5bhtjxqec7ow as toHexString,
  toByte4i43936u611k as toByte_0,
  isBlank1dvkhjjvox3p0 as isBlank,
  IllegalStateException_init_$Create$3ib9qa3pip8n4 as IllegalStateException_init_$Create$,
  hexToByteArrayj26yk4970vc7 as hexToByteArray,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
//endregion
//region block: pre-declaration
setMetadataFor(BigIntAsStringSerializer, 'BigIntAsStringSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(Companion, 'Companion', objectMeta);
setMetadataFor(BigInt_0, 'BigInt', classMeta, Number_0, [Number_0, Comparable], VOID, VOID, {0: BigIntAsStringSerializer_getInstance});
//endregion
function BigIntAsStringSerializer() {
  BigIntAsStringSerializer_instance = this;
  this.e4u_1 = PrimitiveSerialDescriptor('BigInt', STRING_getInstance());
}
protoOf(BigIntAsStringSerializer).z3q = function () {
  return this.e4u_1;
};
protoOf(BigIntAsStringSerializer).f4u = function (encoder, value) {
  encoder.p3v(value.toString());
};
protoOf(BigIntAsStringSerializer).m3r = function (encoder, value) {
  return this.f4u(encoder, value instanceof BigInt_0 ? value : THROW_CCE());
};
protoOf(BigIntAsStringSerializer).n3r = function (decoder) {
  return toBigInt_3(decoder.i3u());
};
var BigIntAsStringSerializer_instance;
function BigIntAsStringSerializer_getInstance() {
  if (BigIntAsStringSerializer_instance == null)
    new BigIntAsStringSerializer();
  return BigIntAsStringSerializer_instance;
}
function Companion() {
  Companion_instance = this;
  this.g4u_1 = new BigInt_0(BigInt(0));
}
protoOf(Companion).u4i = function () {
  return BigIntAsStringSerializer_getInstance();
};
var Companion_instance;
function Companion_getInstance() {
  if (Companion_instance == null)
    new Companion();
  return Companion_instance;
}
function BigInt_0(jsBigInt) {
  Companion_getInstance();
  Number_0.call(this);
  this.h4u_1 = jsBigInt;
}
protoOf(BigInt_0).i4u = function (other) {
  return this.j4u(toBigInt(other));
};
protoOf(BigInt_0).j4u = function (other) {
  return jsBigIntCompareTo(this.h4u_1, other.h4u_1);
};
protoOf(BigInt_0).d = function (other) {
  return this.j4u(other instanceof BigInt_0 ? other : THROW_CCE());
};
protoOf(BigInt_0).zb = function () {
  return toByte(jsBigIntAsInt(this.h4u_1, 8).toString());
};
protoOf(BigInt_0).ac = function () {
  return toShort(jsBigIntAsInt(this.h4u_1, 16).toString());
};
protoOf(BigInt_0).ra = function () {
  return toInt(jsBigIntAsInt(this.h4u_1, 32).toString());
};
protoOf(BigInt_0).k4u = function () {
  return toLong(jsBigIntAsInt(this.h4u_1, 64).toString());
};
protoOf(BigInt_0).toString = function () {
  return this.h4u_1.toString();
};
protoOf(BigInt_0).hashCode = function () {
  return getStringHashCode(this.h4u_1.toString(36));
};
protoOf(BigInt_0).equals = function (other) {
  if (!(other instanceof BigInt_0))
    return false;
  return jsBigIntEquals(this.h4u_1, other.h4u_1);
};
function encodeToByteArray(_this__u8e3s4) {
  var positive = _this__u8e3s4.i4u(0) >= 0;
  var bytes = positive ? encodeToByteArray$decodeFromHex(_this__u8e3s4.h4u_1.toString(16)) : invertTwoComplement(encodeToByteArray$decodeFromHex(jsBigIntNegate(_this__u8e3s4.h4u_1).toString(16)));
  var firstBytePositive = bytes[0] >= 0;
  if (positive === firstBytePositive)
    return bytes;
  // Inline function 'kotlin.also' call
  var this_0 = new Int8Array(bytes.length + 1 | 0);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'dev.whyoleg.cryptography.bigint.encodeToByteArray.<anonymous>' call
  this_0[0] = positive ? 0 : -1;
  // Inline function 'kotlin.collections.copyInto' call
  var endIndex = bytes.length;
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp = bytes;
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  arrayCopy(tmp, this_0, 1, 0, endIndex);
  return this_0;
}
function toBigInt(_this__u8e3s4) {
  return _this__u8e3s4 === 0 ? Companion_getInstance().g4u_1 : new BigInt_0(BigInt(_this__u8e3s4));
}
function toBigInt_0(_this__u8e3s4) {
  return toBigInt(_this__u8e3s4);
}
function toBigInt_1(_this__u8e3s4) {
  return toBigInt(_this__u8e3s4);
}
function toBigInt_2(_this__u8e3s4) {
  return _this__u8e3s4.equals(new Long(0, 0)) ? Companion_getInstance().g4u_1 : new BigInt_0(BigInt(_this__u8e3s4.toString()));
}
function decodeToBigInt(_this__u8e3s4) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.collections.isNotEmpty' call
  // Inline function 'kotlin.collections.isEmpty' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!(_this__u8e3s4.length === 0)) {
    // Inline function 'dev.whyoleg.cryptography.bigint.decodeToBigInt.<anonymous>' call
    var message = 'empty array';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  if (_this__u8e3s4.length === 1 ? _this__u8e3s4[0] === 0 : false)
    return Companion_getInstance().g4u_1;
  var positive = _this__u8e3s4[0] >= 0;
  var tmp;
  if (positive) {
    tmp = BigInt('0x' + toHexString(_this__u8e3s4));
  } else {
    // Inline function 'kotlin.collections.copyOf' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$4 = _this__u8e3s4.slice();
    tmp = jsBigIntNegate(BigInt('0x' + toHexString(invertTwoComplement(tmp$ret$4))));
  }
  var jsBigInt = tmp;
  return new BigInt_0(jsBigInt);
}
function invertTwoComplement(_this__u8e3s4) {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.collections.indexOfLast' call
    var inductionVariable = _this__u8e3s4.length - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        // Inline function 'dev.whyoleg.cryptography.bigint.invertTwoComplement.<anonymous>' call
        if (!(_this__u8e3s4[index] === 0)) {
          tmp$ret$1 = index;
          break $l$block;
        }
      }
       while (0 <= inductionVariable);
    tmp$ret$1 = -1;
  }
  var firstNonZeroFromEnd = tmp$ret$1;
  // Inline function 'kotlin.repeat' call
  var times = _this__u8e3s4.length;
  // Inline function 'kotlin.contracts.contract' call
  var inductionVariable_0 = 0;
  if (inductionVariable_0 < times)
    do {
      var index_0 = inductionVariable_0;
      inductionVariable_0 = inductionVariable_0 + 1 | 0;
      // Inline function 'dev.whyoleg.cryptography.bigint.invertTwoComplement.<anonymous>' call
      var negated = ~_this__u8e3s4[index_0];
      _this__u8e3s4[index_0] = toByte_0(index_0 < firstNonZeroFromEnd ? negated : negated + 1 | 0);
    }
     while (inductionVariable_0 < times);
  return _this__u8e3s4;
}
function toBigInt_3(_this__u8e3s4) {
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.text.isNotBlank' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!isBlank(_this__u8e3s4)) {
    // Inline function 'dev.whyoleg.cryptography.bigint.toBigInt.<anonymous>' call
    var message = 'empty or blank string';
    throw IllegalStateException_init_$Create$(toString(message));
  }
  return new BigInt_0(BigInt(_this__u8e3s4));
}
function encodeToByteArray$decodeFromHex(_this__u8e3s4) {
  return hexToByteArray((_this__u8e3s4.length % 2 | 0) === 0 ? _this__u8e3s4 : '0' + _this__u8e3s4);
}
function jsBigIntCompareTo(a, b) {
  // Inline function 'kotlin.js.unsafeCast' call
  return function () {
    if (a < b)
      return -1;
    if (a > b)
      return 1;
    return 0;
  }();
}
function jsBigIntAsInt(value, bits) {
  // Inline function 'kotlin.js.unsafeCast' call
  return BigInt.asIntN(bits, value);
}
function jsBigIntEquals(a, b) {
  // Inline function 'kotlin.js.unsafeCast' call
  return a === b;
}
function jsBigIntNegate(value) {
  // Inline function 'kotlin.js.unsafeCast' call
  return -value;
}
//region block: exports
export {
  BigInt_0 as BigInt23zwv5kv3od56,
  decodeToBigInt as decodeToBigInt1petkle13vaiv,
  encodeToByteArray as encodeToByteArrayripney4e4aue,
  toBigInt as toBigInt3kphjqnio21gn,
  toBigInt_0 as toBigInt2ed03w99r27qk,
  toBigInt_2 as toBigInt11bczolyoumqk,
  toBigInt_1 as toBigInt29u3xna2n8w21,
  Companion_getInstance as Companion_getInstance1jgozvdka497o,
};
//endregion

//# sourceMappingURL=cryptography-kotlin-cryptography-bigint.mjs.map
