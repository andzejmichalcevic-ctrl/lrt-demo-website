import {
  Unit_instance1fbcbse1fwigr as Unit_instance,
  VOID7hggqo3abtya as VOID,
  protoOf180f3jzyo7rfj as protoOf,
  toIntOrNull3w2d066r9pvwm as toIntOrNull,
  toLongOrNullutqivezb0wx1 as toLongOrNull,
  toDoubleOrNullkxwozihadygj as toDoubleOrNull,
  toBoolean2azvnq2ukl7b3 as toBoolean,
  classMetawt99a3kyl3us as classMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
//endregion
//region block: pre-declaration
setMetadataFor(StorageSettings, 'StorageSettings', classMeta, VOID, VOID, StorageSettings);
//endregion
function StorageSettings(delegate) {
  var tmp;
  if (delegate === VOID) {
    // Inline function 'com.russhwolf.settings.localStorage' call
    tmp = localStorage;
  } else {
    tmp = delegate;
  }
  delegate = tmp;
  this.d55_1 = delegate;
}
protoOf(StorageSettings).x1x = function (key) {
  return this.d55_1.removeItem(key);
};
protoOf(StorageSettings).e55 = function (key) {
  // Inline function 'com.russhwolf.settings.get' call
  return !(this.d55_1.getItem(key) == null);
};
protoOf(StorageSettings).f55 = function (key, value) {
  // Inline function 'com.russhwolf.settings.set' call
  var this_0 = this.d55_1;
  var value_0 = value.toString();
  this_0.setItem(key, value_0);
};
protoOf(StorageSettings).g55 = function (key) {
  // Inline function 'com.russhwolf.settings.get' call
  var tmp0_safe_receiver = this.d55_1.getItem(key);
  return tmp0_safe_receiver == null ? null : toIntOrNull(tmp0_safe_receiver);
};
protoOf(StorageSettings).h55 = function (key, value) {
  // Inline function 'com.russhwolf.settings.set' call
  var this_0 = this.d55_1;
  var value_0 = value.toString();
  this_0.setItem(key, value_0);
};
protoOf(StorageSettings).i55 = function (key) {
  // Inline function 'com.russhwolf.settings.get' call
  var tmp0_safe_receiver = this.d55_1.getItem(key);
  return tmp0_safe_receiver == null ? null : toLongOrNull(tmp0_safe_receiver);
};
protoOf(StorageSettings).j55 = function (key, value) {
  // Inline function 'com.russhwolf.settings.set' call
  this.d55_1.setItem(key, value);
};
protoOf(StorageSettings).k55 = function (key) {
  // Inline function 'com.russhwolf.settings.get' call
  return this.d55_1.getItem(key);
};
protoOf(StorageSettings).l55 = function (key, value) {
  // Inline function 'com.russhwolf.settings.set' call
  var this_0 = this.d55_1;
  var value_0 = value.toString();
  this_0.setItem(key, value_0);
};
protoOf(StorageSettings).m55 = function (key) {
  // Inline function 'com.russhwolf.settings.get' call
  var tmp0_safe_receiver = this.d55_1.getItem(key);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.text.toFloatOrNull' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp = toDoubleOrNull(tmp0_safe_receiver);
  }
  return tmp;
};
protoOf(StorageSettings).n55 = function (key, value) {
  // Inline function 'com.russhwolf.settings.set' call
  var this_0 = this.d55_1;
  var value_0 = value.toString();
  this_0.setItem(key, value_0);
};
protoOf(StorageSettings).o55 = function (key) {
  // Inline function 'com.russhwolf.settings.get' call
  var tmp0_safe_receiver = this.d55_1.getItem(key);
  return tmp0_safe_receiver == null ? null : toDoubleOrNull(tmp0_safe_receiver);
};
protoOf(StorageSettings).p55 = function (key, value) {
  // Inline function 'com.russhwolf.settings.set' call
  var this_0 = this.d55_1;
  var value_0 = value.toString();
  this_0.setItem(key, value_0);
};
protoOf(StorageSettings).q55 = function (key, defaultValue) {
  // Inline function 'com.russhwolf.settings.get' call
  var tmp0_safe_receiver = this.d55_1.getItem(key);
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : toBoolean(tmp0_safe_receiver);
  return tmp1_elvis_lhs == null ? defaultValue : tmp1_elvis_lhs;
};
protoOf(StorageSettings).r55 = function (key) {
  // Inline function 'com.russhwolf.settings.get' call
  var tmp0_safe_receiver = this.d55_1.getItem(key);
  return tmp0_safe_receiver == null ? null : toBoolean(tmp0_safe_receiver);
};
//region block: exports
export {
  StorageSettings as StorageSettings203mesgel706z,
};
//endregion

//# sourceMappingURL=MultiplatformSettings-multiplatform-settings.mjs.map
