import {
  EmptySerializersModule991ju6pz9b79 as EmptySerializersModule,
  Companion_instance2e54edlpusznp as Companion_instance,
  AbstractDecoder35guh02ubh2hm as AbstractDecoder,
  MAP_getInstance3s1t6byguxmp9 as MAP_getInstance,
  LIST_getInstancey7k5h8d5cvxt as LIST_getInstance,
  AbstractEncoder2gxtu3xmy3f8j as AbstractEncoder,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
import {
  VOID7hggqo3abtya as VOID,
  joinToString1cxrrlmo0chqs as joinToString,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  ArrayDeque_init_$Create$h67uqnktr40s as ArrayDeque_init_$Create$,
  protoOf180f3jzyo7rfj as protoOf,
  equals2au1ep9vhcato as equals,
  toByte4i43936u611k as toByte,
  numberToChar93r9buh19yek as numberToChar,
  Char19o2r8palgjof as Char,
  toShort36kaw0zjdq3ex as toShort,
  classMetawt99a3kyl3us as classMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  Char__toInt_impl_vasixd2xlaiz5u3itpv as Char__toInt_impl_vasixd,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  IllegalStateException_init_$Init$ducdfahmu9oa as IllegalStateException_init_$Init$,
  captureStack1fzi4aczwc4hg as captureStack,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
setMetadataFor(SettingsDecoder, 'SettingsDecoder', classMeta, AbstractDecoder);
setMetadataFor(SettingsEncoder, 'SettingsEncoder', classMeta, AbstractEncoder);
setMetadataFor(DeserializationException, 'DeserializationException', classMeta, IllegalStateException, VOID, DeserializationException);
//endregion
function decodeValue(_this__u8e3s4, serializer, key, defaultValue, serializersModule) {
  serializersModule = serializersModule === VOID ? EmptySerializersModule() : serializersModule;
  // Inline function 'com.russhwolf.settings.serialization.deserializeOrElse' call
  var decoder = new SettingsDecoder(_this__u8e3s4, key, serializersModule);
  var tmp;
  try {
    tmp = serializer.n3r(decoder);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof DeserializationException) {
      var _ = $p;
      decoder.x1m();
      tmp_0 = defaultValue;
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  return tmp;
}
function encodeValue(_this__u8e3s4, serializer, key, value, serializersModule) {
  serializersModule = serializersModule === VOID ? EmptySerializersModule() : serializersModule;
  return serializer.m3r(new SettingsEncoder(_this__u8e3s4, key, serializersModule), value);
}
function getKey($this) {
  return joinToString($this.v55_1, '.');
}
function getNextIndex($this, descriptor, size) {
  var $this_0 = $this;
  var descriptor_0 = descriptor;
  var size_0 = size;
  $l$1: do {
    $l$0: do {
      var index = $this_0.w55_1.be();
      $this_0.w55_1.yd(index + 1 | 0);
      var tmp;
      if (index >= size_0) {
        tmp = -1;
      } else {
        // Inline function 'com.russhwolf.settings.serialization.SettingsDecoder.isMissingAndOptional' call
        var this_0 = $this_0;
        var descriptor_1 = descriptor_0;
        var key = getKey(this_0) + '.' + descriptor_1.y3s(index);
        var tmp_0;
        var tmp_1;
        if (descriptor_1.z3s(index)) {
          // Inline function 'com.russhwolf.settings.contains' call
          tmp_1 = !this_0.s55_1.e55(key);
        } else {
          tmp_1 = false;
        }
        if (tmp_1) {
          tmp_0 = !(this_0.s55_1.r55(key + '?') === true);
        } else {
          tmp_0 = false;
        }
        if (tmp_0) {
          $this_0 = $this_0;
          descriptor_0 = descriptor_0;
          size_0 = size_0;
          continue $l$0;
        } else {
          $this_0.v55_1.r(descriptor_0.y3s(index));
          $this_0.w55_1.r(0);
          tmp = index;
        }
      }
      return tmp;
    }
     while (false);
  }
   while (true);
}
function SettingsDecoder(settings, key, serializersModule) {
  AbstractDecoder.call(this);
  this.s55_1 = settings;
  this.t55_1 = key;
  this.u55_1 = serializersModule;
  var tmp = this;
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayDeque_init_$Create$();
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'com.russhwolf.settings.serialization.SettingsDecoder.keyStack.<anonymous>' call
  this_0.r(this.t55_1);
  tmp.v55_1 = this_0;
  var tmp_0 = this;
  // Inline function 'kotlin.apply' call
  var this_1 = ArrayDeque_init_$Create$();
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'com.russhwolf.settings.serialization.SettingsDecoder.indexStack.<anonymous>' call
  this_1.r(0);
  tmp_0.w55_1 = this_1;
  this.x55_1 = 0;
}
protoOf(SettingsDecoder).k3r = function () {
  return this.u55_1;
};
protoOf(SettingsDecoder).c3v = function (descriptor) {
  if (this.v55_1.ud_1 > this.x55_1) {
    this.v55_1.be();
    this.w55_1.be();
  }
  var tmp0_subject = descriptor.u3s();
  var size = equals(tmp0_subject, LIST_getInstance()) ? this.d3v(descriptor) : equals(tmp0_subject, MAP_getInstance()) ? imul(2, this.d3v(descriptor)) : descriptor.s3s();
  return getNextIndex(this, descriptor, size);
};
protoOf(SettingsDecoder).m3u = function (descriptor) {
  this.x55_1 = this.x55_1 + 1 | 0;
  return protoOf(AbstractDecoder).m3u.call(this, descriptor);
};
protoOf(SettingsDecoder).n3u = function (descriptor) {
  this.x55_1 = this.x55_1 - 1 | 0;
  this.v55_1.be();
  this.w55_1.be();
  if (this.v55_1.b1()) {
    this.v55_1.r(this.t55_1);
    this.w55_1.r(0);
  }
};
protoOf(SettingsDecoder).d3v = function (descriptor) {
  var tmp0_elvis_lhs = this.s55_1.g55(getKey(this) + '.size');
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw new DeserializationException();
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
protoOf(SettingsDecoder).y3t = function () {
  var tmp0_elvis_lhs = this.s55_1.r55(getKey(this) + '?');
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw new DeserializationException();
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
protoOf(SettingsDecoder).z3t = function () {
  return null;
};
protoOf(SettingsDecoder).a3u = function () {
  var tmp0_elvis_lhs = this.s55_1.r55(getKey(this));
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw new DeserializationException();
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
protoOf(SettingsDecoder).b3u = function () {
  var tmp0_safe_receiver = this.s55_1.g55(getKey(this));
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : toByte(tmp0_safe_receiver);
  var tmp;
  if (tmp1_elvis_lhs == null) {
    throw new DeserializationException();
  } else {
    tmp = tmp1_elvis_lhs;
  }
  return tmp;
};
protoOf(SettingsDecoder).h3u = function () {
  var tmp0_safe_receiver = this.s55_1.g55(getKey(this));
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : numberToChar(tmp0_safe_receiver);
  var tmp;
  var tmp_0 = tmp1_elvis_lhs;
  if ((tmp_0 == null ? null : new Char(tmp_0)) == null) {
    throw new DeserializationException();
  } else {
    tmp = tmp1_elvis_lhs;
  }
  return tmp;
};
protoOf(SettingsDecoder).g3u = function () {
  var tmp0_elvis_lhs = this.s55_1.o55(getKey(this));
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw new DeserializationException();
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
protoOf(SettingsDecoder).j3u = function (enumDescriptor) {
  var tmp0_elvis_lhs = this.s55_1.g55(getKey(this));
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw new DeserializationException();
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
protoOf(SettingsDecoder).f3u = function () {
  var tmp0_elvis_lhs = this.s55_1.m55(getKey(this));
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw new DeserializationException();
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
protoOf(SettingsDecoder).d3u = function () {
  var tmp0_elvis_lhs = this.s55_1.g55(getKey(this));
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw new DeserializationException();
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
protoOf(SettingsDecoder).e3u = function () {
  var tmp0_elvis_lhs = this.s55_1.i55(getKey(this));
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw new DeserializationException();
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
protoOf(SettingsDecoder).c3u = function () {
  var tmp0_safe_receiver = this.s55_1.g55(getKey(this));
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : toShort(tmp0_safe_receiver);
  var tmp;
  if (tmp1_elvis_lhs == null) {
    throw new DeserializationException();
  } else {
    tmp = tmp1_elvis_lhs;
  }
  return tmp;
};
protoOf(SettingsDecoder).i3u = function () {
  var tmp0_elvis_lhs = this.s55_1.k55(getKey(this));
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw new DeserializationException();
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
protoOf(SettingsDecoder).x1m = function () {
  this.v55_1.x();
  this.w55_1.x();
  this.x55_1 = 0;
  this.v55_1.r(this.t55_1);
  this.w55_1.r(0);
};
function getKey_0($this) {
  return joinToString($this.a56_1, '.');
}
function SettingsEncoder(settings, key, serializersModule) {
  AbstractEncoder.call(this);
  this.y55_1 = settings;
  this.z55_1 = serializersModule;
  var tmp = this;
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayDeque_init_$Create$();
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'com.russhwolf.settings.serialization.SettingsEncoder.keyStack.<anonymous>' call
  this_0.r(key);
  tmp.a56_1 = this_0;
  this.b56_1 = 0;
}
protoOf(SettingsEncoder).k3r = function () {
  return this.z55_1;
};
protoOf(SettingsEncoder).e3v = function (descriptor, index) {
  if (this.a56_1.ud_1 > this.b56_1) {
    this.a56_1.be();
  }
  this.a56_1.r(descriptor.y3s(index));
  return true;
};
protoOf(SettingsEncoder).m3u = function (descriptor) {
  this.b56_1 = this.b56_1 + 1 | 0;
  return protoOf(AbstractEncoder).m3u.call(this, descriptor);
};
protoOf(SettingsEncoder).n3u = function (descriptor) {
  this.b56_1 = this.b56_1 - 1 | 0;
  this.a56_1.be();
};
protoOf(SettingsEncoder).g3w = function (descriptor, collectionSize) {
  this.y55_1.f55(getKey_0(this) + '.size', collectionSize);
  return protoOf(AbstractEncoder).g3w.call(this, descriptor, collectionSize);
};
protoOf(SettingsEncoder).f3w = function () {
  return this.y55_1.p55(getKey_0(this) + '?', true);
};
protoOf(SettingsEncoder).g3v = function () {
  this.y55_1.x1x(getKey_0(this));
  this.y55_1.p55(getKey_0(this) + '?', false);
};
protoOf(SettingsEncoder).h3v = function (value) {
  return this.y55_1.p55(getKey_0(this), value);
};
protoOf(SettingsEncoder).i3v = function (value) {
  return this.y55_1.f55(getKey_0(this), value);
};
protoOf(SettingsEncoder).o3v = function (value) {
  var tmp = getKey_0(this);
  // Inline function 'kotlin.code' call
  var tmp$ret$0 = Char__toInt_impl_vasixd(value);
  return this.y55_1.f55(tmp, tmp$ret$0);
};
protoOf(SettingsEncoder).n3v = function (value) {
  return this.y55_1.n55(getKey_0(this), value);
};
protoOf(SettingsEncoder).q3v = function (enumDescriptor, index) {
  return this.y55_1.f55(getKey_0(this), index);
};
protoOf(SettingsEncoder).m3v = function (value) {
  return this.y55_1.l55(getKey_0(this), value);
};
protoOf(SettingsEncoder).k3v = function (value) {
  return this.y55_1.f55(getKey_0(this), value);
};
protoOf(SettingsEncoder).l3v = function (value) {
  return this.y55_1.h55(getKey_0(this), value);
};
protoOf(SettingsEncoder).j3v = function (value) {
  return this.y55_1.f55(getKey_0(this), value);
};
protoOf(SettingsEncoder).p3v = function (value) {
  return this.y55_1.j55(getKey_0(this), value);
};
function DeserializationException() {
  IllegalStateException_init_$Init$(this);
  captureStack(this, DeserializationException);
}
//region block: exports
export {
  decodeValue as decodeValue1tpu2zv9bx2qw,
  encodeValue as encodeValue242y8vttc9801,
};
//endregion

//# sourceMappingURL=MultiplatformSettings-multiplatform-settings-serialization.mjs.map
