import {
  emptyList1g2z5xcrvp2zy as emptyList,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  asList2ho2pewtsfvv as asList,
  protoOf180f3jzyo7rfj as protoOf,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  classMetawt99a3kyl3us as classMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  VOID7hggqo3abtya as VOID,
  interfaceMeta1u1l5puptm1ve as interfaceMeta,
  StringCompanionObject_instance3alxothmy382k as StringCompanionObject_instance,
  LazyThreadSafetyMode_PUBLICATION_getInstance2wcpeyiugdaea as LazyThreadSafetyMode_PUBLICATION_getInstance,
  lazy1261dae0bgscp as lazy,
  getKClassFromExpression3vpejubogshaw as getKClassFromExpression,
  KProperty1ca4yb4wlo496 as KProperty1,
  getPropertyCallableRef1ajb9in178r5r as getPropertyCallableRef,
  objectCreate1ve4bgxiu4x98 as objectCreate,
  Entry2xmjmyutzoq3p as Entry,
  isInterface3d6p8outrmvmk as isInterface,
  IllegalArgumentException_init_$Create$310sysrobvll9 as IllegalArgumentException_init_$Create$,
  zip2suipyqmdw72q as zip,
  toMap1vec9topfei08 as toMap,
  LinkedHashMap_init_$Create$1p3p95clvi93w as LinkedHashMap_init_$Create$,
  toString1pkumu07cwy4m as toString,
  IllegalStateException_init_$Create$3ib9qa3pip8n4 as IllegalStateException_init_$Create$,
  mapCapacity1h45rc3eh9p2l as mapCapacity,
  LinkedHashMap_init_$Create$7ps311k1ff73 as LinkedHashMap_init_$Create$_0,
  Map140uvy3s5zad8 as Map,
  IllegalArgumentException_init_$Init$1elycfkdq8or6 as IllegalArgumentException_init_$Init$,
  captureStack1fzi4aczwc4hg as captureStack,
  IllegalArgumentException_init_$Init$1ihrezc0xr9m4 as IllegalArgumentException_init_$Init$_0,
  IllegalArgumentException_init_$Init$l84p0lagzo4a as IllegalArgumentException_init_$Init$_1,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  ArrayList_init_$Create$1s1wkrw82c0iw as ArrayList_init_$Create$,
  KClass1cc9rfeybg8hs as KClass,
  Triple1vhi3d0dgpnjb as Triple,
  getKClass1s3j9wy1cofik as getKClass,
  Paire9pteg33gng7 as Pair,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  MutableMap1kqeifoi36kpz as MutableMap,
  HashMap1a0ld5kgwhmhv as HashMap,
  LinkedHashSet2tkztfx86kyx2 as LinkedHashSet,
  MutableSetwuwn7k5m570a as MutableSet,
  Setjrjc7fhfd6b9 as Set,
  HashSet2dzve9y63nf0v as HashSet,
  ArrayList3it5z8td81qkl as ArrayList,
  MutableList1beimitadwkna as MutableList,
  List3hktaavzmj137 as List,
  Collection1k04j3hzsbod0 as Collection,
  copyToArray2j022khrow2yi as copyToArray,
  _Result___get_value__impl__bjfvqgo6z1uu11rodr as _Result___get_value__impl__bjfvqg,
  _Result___get_isFailure__impl__jpirivzehaw445b0cy as _Result___get_isFailure__impl__jpiriv,
  Result3t1vadv16kmzk as Result,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  equals2au1ep9vhcato as equals,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  isBlank1dvkhjjvox3p0 as isBlank,
  toList383f556t1dixk as toList,
  ArrayList_init_$Create$2qnngtk1et9r9 as ArrayList_init_$Create$_0,
  HashSet_init_$Create$1urd5csbv51lq as HashSet_init_$Create$,
  toHashSet1qrcsl3g8ugc8 as toHashSet,
  toBooleanArray2u3qw7fjwsmuh as toBooleanArray,
  withIndex3s8q7w1g0hyfn as withIndex,
  to2cs3ny02qtbcb as to,
  lazy2hsh8ze7j6ikd as lazy_0,
  contentEqualsaf55p28mnw74 as contentEquals,
  until1jbpn0z3f8lbg as until,
  joinToString1cxrrlmo0chqs as joinToString,
  objectMeta213120oau977m as objectMeta,
  Long2qws0ah9gnpki as Long,
  Char19o2r8palgjof as Char,
  Duration__toIsoString_impl_9h6wsm33t9fmb34wprd as Duration__toIsoString_impl_9h6wsm,
  Duration5ynfiptaqcrg as Duration,
  Companion_getInstance3vz87v4c01z2t as Companion_getInstance,
  toIntOrNull3w2d066r9pvwm as toIntOrNull,
  hashCodeq5arwsb9dgti as hashCode,
  ArrayList_init_$Create$44sx2frbo105 as ArrayList_init_$Create$_1,
  HashSet_init_$Create$1205t9rx6gzuw as HashSet_init_$Create$_0,
  LinkedHashSet_init_$Create$3qv13l7kzf0ni as LinkedHashSet_init_$Create$,
  LinkedHashSet_init_$Create$aoic19bt9c3t as LinkedHashSet_init_$Create$_0,
  HashMap_init_$Create$1ria3pjlcm5i3 as HashMap_init_$Create$,
  HashMap_init_$Create$2xkn9k09cz2fd as HashMap_init_$Create$_0,
  LinkedHashMap_init_$Create$1ihgfw4xf4rsr as LinkedHashMap_init_$Create$_1,
  isArray1hxjqtqy632bc as isArray,
  arrayIterator3lgwvgteckzhv as arrayIterator,
  step18s9qzr5xwxat as step,
  getValue48kllevslyh6 as getValue,
  longArray288a0fctlmjmj as longArray,
  Companion_getInstance3gn12jgnf4xoo as Companion_getInstance_0,
  get_lastIndex1y2f6o9u8hnf7 as get_lastIndex,
  countTrailingZeroBits1k55x07cygoff as countTrailingZeroBits,
  indexOf3ic8eacwbbrog as indexOf,
  contentToString3ujacv8hqfipd as contentToString,
  Enum3alwj03lh1n41 as Enum,
  fillArrayVali8eppxapiek4 as fillArrayVal,
  HashSet_init_$Create$7yrdg7emowlg as HashSet_init_$Create$_1,
  KTypeParameter1s8efufd4mbj5 as KTypeParameter,
  booleanArray2jdug9b51huk7 as booleanArray,
  emptyMapr06gerzljqtm as emptyMap,
  contentHashCode2i020q5tbeh2s as contentHashCode,
  Companion_getInstance2e3h8n26rh23 as Companion_getInstance_1,
  isCharArray21auq5hbrg68m as isCharArray,
  charArray2ujmm1qusno00 as charArray,
  DoubleCompanionObject_instance3q51gr7gsd0au as DoubleCompanionObject_instance,
  isDoubleArray1wyh4nyf7pjxn as isDoubleArray,
  FloatCompanionObject_instance367t6x2s4xzmv as FloatCompanionObject_instance,
  isFloatArrayjjscnqphw92j as isFloatArray,
  isLongArray2fdt3z7yu3ef as isLongArray,
  Companion_getInstance1puqqwzccfvrg as Companion_getInstance_2,
  _ULongArray___get_size__impl__ju6dtr1b48sgq5mqufi as _ULongArray___get_size__impl__ju6dtr,
  ULongArray3nd0d80mdwjj8 as ULongArray,
  _ULongArray___init__impl__twm1l3w35zjgwc40e6 as _ULongArray___init__impl__twm1l3,
  _ULong___init__impl__c78o9k2uqxdjm6b0lbg as _ULong___init__impl__c78o9k,
  ULongArray__get_impl_pr71q927jt2k7w7gjei as ULongArray__get_impl_pr71q9,
  _ULong___get_data__impl__fggpzb1jl4xe0gulani as _ULong___get_data__impl__fggpzb,
  IntCompanionObject_instance3tw56cgyd5vup as IntCompanionObject_instance,
  isIntArrayeijsubfngq38 as isIntArray,
  Companion_getInstanceuedpedmz4g65 as Companion_getInstance_3,
  _UIntArray___get_size__impl__r6l8ci9njro21awxk9 as _UIntArray___get_size__impl__r6l8ci,
  UIntArrayrp6cv44n5v4y as UIntArray,
  _UIntArray___init__impl__ghjpc6p9a9ozepj5yp as _UIntArray___init__impl__ghjpc6,
  _UInt___init__impl__l7qpdl1vpobek1e692 as _UInt___init__impl__l7qpdl,
  UIntArray__get_impl_gp5kza3dxey4dpmolyb as UIntArray__get_impl_gp5kza,
  _UInt___get_data__impl__f0vqqw9xdox7iecbly as _UInt___get_data__impl__f0vqqw,
  ShortCompanionObject_instance3vq120mx8545m as ShortCompanionObject_instance,
  isShortArraywz30zxwtqi8h as isShortArray,
  Companion_getInstance2du03jiluw9jj as Companion_getInstance_4,
  _UShortArray___get_size__impl__jqto1bat9kt7h1kexu as _UShortArray___get_size__impl__jqto1b,
  UShortArray11avpmknxdgvv as UShortArray,
  _UShortArray___init__impl__9b26ef20xbmpmmmp8nr as _UShortArray___init__impl__9b26ef,
  _UShort___init__impl__jigrne3h2nm35iaibum as _UShort___init__impl__jigrne,
  UShortArray__get_impl_fnbhmx2rw6mvd6ywjjn as UShortArray__get_impl_fnbhmx,
  _UShort___get_data__impl__g02459z5yfs6z0kj0 as _UShort___get_data__impl__g0245,
  ByteCompanionObject_instance9rvhjp0l184i as ByteCompanionObject_instance,
  isByteArray4nnzfn1x4o3w as isByteArray,
  Companion_getInstance1trnkq9cty7vr as Companion_getInstance_5,
  _UByteArray___get_size__impl__h6pkdv2ztnvvin1oejd as _UByteArray___get_size__impl__h6pkdv,
  UByteArray2qu4d6gwssdf9 as UByteArray,
  _UByteArray___init__impl__ip4y9n2yrhvr539f00i as _UByteArray___init__impl__ip4y9n,
  _UByte___init__impl__g9hnc415bxbmye0j11o as _UByte___init__impl__g9hnc4,
  UByteArray__get_impl_t5f3hv2yxdiuhsa1bkg as UByteArray__get_impl_t5f3hv,
  _UByte___get_data__impl__jof9qrfj1ch8mjizvj as _UByte___get_data__impl__jof9qr,
  BooleanCompanionObject_instance29o5h9ajgjmec as BooleanCompanionObject_instance,
  isBooleanArray35llghle4c6w1 as isBooleanArray,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  copyOf2p23ljc5f5ea3 as copyOf,
  copyOfgossjg6lh6js as copyOf_0,
  copyOfq9pcgcgbldck as copyOf_1,
  copyOf9mbsebmgnw4t as copyOf_2,
  _ULongArray___get_storage__impl__28e64jlq4wjpcpg0xb as _ULongArray___get_storage__impl__28e64j,
  _ULongArray___init__impl__twm1l31njh1yo2fhc3d as _ULongArray___init__impl__twm1l3_0,
  ULongArray__set_impl_z19mvh3jq4upxqlu5i0 as ULongArray__set_impl_z19mvh,
  copyOf3rutauicler23 as copyOf_3,
  _UIntArray___get_storage__impl__92a0v03adro3l9nnqca as _UIntArray___get_storage__impl__92a0v0,
  _UIntArray___init__impl__ghjpc61vagysy0rvf as _UIntArray___init__impl__ghjpc6_0,
  UIntArray__set_impl_7f2zu22xxx79utmdcyl as UIntArray__set_impl_7f2zu2,
  copyOf39s58md6y6rn6 as copyOf_4,
  _UShortArray___get_storage__impl__t2jpv53ishea48wnh3x as _UShortArray___get_storage__impl__t2jpv5,
  _UShortArray___init__impl__9b26ef2p62uevidil7h as _UShortArray___init__impl__9b26ef_0,
  UShortArray__set_impl_6d8whp1v6ijtn8ethum as UShortArray__set_impl_6d8whp,
  copyOfwy6h3t5vzqpl as copyOf_5,
  _UByteArray___get_storage__impl__d4kctt24cpxlf9wdrm1 as _UByteArray___get_storage__impl__d4kctt,
  _UByteArray___init__impl__ip4y9n1d0y5mfc7d2ru as _UByteArray___init__impl__ip4y9n_0,
  UByteArray__set_impl_jvcicn17xhe4228sib8 as UByteArray__set_impl_jvcicn,
  copyOf37mht4mx7mjgh as copyOf_6,
  Unitkvevlwgzwiuc as Unit,
  trimIndent1qytc1wvt8suh as trimIndent,
  equals2v6cggk171b6e as equals_0,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  toString35i91qxh73cps as toString_0,
  titlecase36e9fbud5gg4t as titlecase,
  isLowerCase16nv9n55l9laa as isLowerCase,
  PrimitiveClasses_getInstance2v63zn04dtq03 as PrimitiveClasses_getInstance,
  ULong3f9k7s38t3rfp as ULong,
  UInt1hthisrv6cndi as UInt,
  UShort26xnqty60t7le as UShort,
  UBytep4j7r1t64gz1 as UByte,
  mapOf1xd03cq9cnmy8 as mapOf,
  last1vo29oleiqj36 as last,
  lastOrNull1aq5oz189qoe1 as lastOrNull,
  get_lastIndex1yw0x4k50k51w as get_lastIndex_0,
  get_js1ale1wr4fbvs0 as get_js,
  findAssociatedObject1kb88g16k1goa as findAssociatedObject,
  get_indicesc04v40g017hw as get_indices,
  IndexOutOfBoundsException_init_$Create$jb51qtvf74or as IndexOutOfBoundsException_init_$Create$,
  get_indices377latqcai313 as get_indices_0,
  Companion_instance2oawqq9qiaris as Companion_instance,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
setMetadataFor(SerializationStrategy, 'SerializationStrategy', interfaceMeta);
setMetadataFor(DeserializationStrategy, 'DeserializationStrategy', interfaceMeta);
setMetadataFor(KSerializer, 'KSerializer', interfaceMeta, VOID, [SerializationStrategy, DeserializationStrategy]);
setMetadataFor(ContextualSerializer, 'ContextualSerializer', classMeta, VOID, [KSerializer]);
setMetadataFor(AbstractPolymorphicSerializer, 'AbstractPolymorphicSerializer', classMeta, VOID, [KSerializer]);
setMetadataFor(PolymorphicSerializer, 'PolymorphicSerializer', classMeta, AbstractPolymorphicSerializer);
setMetadataFor(_no_name_provided__qut3iv, VOID, classMeta);
setMetadataFor(SealedClassSerializer, 'SealedClassSerializer', classMeta, AbstractPolymorphicSerializer);
setMetadataFor(StringFormat, 'StringFormat', interfaceMeta);
setMetadataFor(BinaryFormat, 'BinaryFormat', interfaceMeta);
setMetadataFor(SerializationException, 'SerializationException', classMeta, IllegalArgumentException, VOID, SerializationException_init_$Create$);
setMetadataFor(UnknownFieldException, 'UnknownFieldException', classMeta, SerializationException);
setMetadataFor(MissingFieldException, 'MissingFieldException', classMeta, SerializationException);
function get_isNullable() {
  return false;
}
function get_isInline() {
  return false;
}
function get_annotations() {
  return emptyList();
}
setMetadataFor(SerialDescriptor, 'SerialDescriptor', interfaceMeta);
setMetadataFor(ContextDescriptor, 'ContextDescriptor', classMeta, VOID, [SerialDescriptor]);
setMetadataFor(elementDescriptors$1$1, VOID, classMeta);
setMetadataFor(_no_name_provided__qut3iv_0, VOID, classMeta);
setMetadataFor(elementNames$1$1, VOID, classMeta);
setMetadataFor(_no_name_provided__qut3iv_1, VOID, classMeta);
setMetadataFor(ClassSerialDescriptorBuilder, 'ClassSerialDescriptorBuilder', classMeta);
setMetadataFor(CachedNames, 'CachedNames', interfaceMeta);
setMetadataFor(SerialDescriptorImpl, 'SerialDescriptorImpl', classMeta, VOID, [SerialDescriptor, CachedNames]);
setMetadataFor(SerialKind, 'SerialKind', classMeta);
setMetadataFor(ENUM, 'ENUM', objectMeta, SerialKind);
setMetadataFor(CONTEXTUAL, 'CONTEXTUAL', objectMeta, SerialKind);
setMetadataFor(PrimitiveKind, 'PrimitiveKind', classMeta, SerialKind);
setMetadataFor(BOOLEAN, 'BOOLEAN', objectMeta, PrimitiveKind);
setMetadataFor(BYTE, 'BYTE', objectMeta, PrimitiveKind);
setMetadataFor(CHAR, 'CHAR', objectMeta, PrimitiveKind);
setMetadataFor(SHORT, 'SHORT', objectMeta, PrimitiveKind);
setMetadataFor(INT, 'INT', objectMeta, PrimitiveKind);
setMetadataFor(LONG, 'LONG', objectMeta, PrimitiveKind);
setMetadataFor(FLOAT, 'FLOAT', objectMeta, PrimitiveKind);
setMetadataFor(DOUBLE, 'DOUBLE', objectMeta, PrimitiveKind);
setMetadataFor(STRING, 'STRING', objectMeta, PrimitiveKind);
setMetadataFor(StructureKind, 'StructureKind', classMeta, SerialKind);
setMetadataFor(CLASS, 'CLASS', objectMeta, StructureKind);
setMetadataFor(LIST, 'LIST', objectMeta, StructureKind);
setMetadataFor(MAP, 'MAP', objectMeta, StructureKind);
setMetadataFor(OBJECT, 'OBJECT', objectMeta, StructureKind);
setMetadataFor(PolymorphicKind, 'PolymorphicKind', classMeta, SerialKind);
setMetadataFor(SEALED, 'SEALED', objectMeta, PolymorphicKind);
setMetadataFor(OPEN, 'OPEN', objectMeta, PolymorphicKind);
function decodeSerializableValue(deserializer) {
  return deserializer.n3r(this);
}
setMetadataFor(Decoder, 'Decoder', interfaceMeta);
function decodeSequentially() {
  return false;
}
function decodeCollectionSize(descriptor) {
  return -1;
}
function decodeSerializableElement$default(descriptor, index, deserializer, previousValue, $super) {
  previousValue = previousValue === VOID ? null : previousValue;
  return $super === VOID ? this.y3u(descriptor, index, deserializer, previousValue) : $super.y3u.call(this, descriptor, index, deserializer, previousValue);
}
setMetadataFor(CompositeDecoder, 'CompositeDecoder', interfaceMeta);
setMetadataFor(AbstractDecoder, 'AbstractDecoder', classMeta, VOID, [Decoder, CompositeDecoder]);
function encodeNotNullMark() {
}
function beginCollection(descriptor, collectionSize) {
  return this.m3u(descriptor);
}
function encodeSerializableValue(serializer, value) {
  serializer.m3r(this, value);
}
function encodeNullableSerializableValue(serializer, value) {
  var isNullabilitySupported = serializer.z3q().o3s();
  if (isNullabilitySupported) {
    return this.l3r(isInterface(serializer, SerializationStrategy) ? serializer : THROW_CCE(), value);
  }
  if (value == null) {
    this.g3v();
  } else {
    this.f3w();
    this.l3r(serializer, value);
  }
}
setMetadataFor(Encoder, 'Encoder', interfaceMeta);
function shouldEncodeElementDefault(descriptor, index) {
  return true;
}
setMetadataFor(CompositeEncoder, 'CompositeEncoder', interfaceMeta);
setMetadataFor(AbstractEncoder, 'AbstractEncoder', classMeta, VOID, [Encoder, CompositeEncoder]);
setMetadataFor(Companion, 'Companion', objectMeta);
setMetadataFor(NothingSerializer_0, 'NothingSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(DurationSerializer, 'DurationSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(ListLikeDescriptor, 'ListLikeDescriptor', classMeta, VOID, [SerialDescriptor]);
setMetadataFor(ArrayListClassDesc, 'ArrayListClassDesc', classMeta, ListLikeDescriptor);
setMetadataFor(HashSetClassDesc, 'HashSetClassDesc', classMeta, ListLikeDescriptor);
setMetadataFor(LinkedHashSetClassDesc, 'LinkedHashSetClassDesc', classMeta, ListLikeDescriptor);
setMetadataFor(MapLikeDescriptor, 'MapLikeDescriptor', classMeta, VOID, [SerialDescriptor]);
setMetadataFor(HashMapClassDesc, 'HashMapClassDesc', classMeta, MapLikeDescriptor);
setMetadataFor(LinkedHashMapClassDesc, 'LinkedHashMapClassDesc', classMeta, MapLikeDescriptor);
setMetadataFor(ArrayClassDesc, 'ArrayClassDesc', classMeta, ListLikeDescriptor);
setMetadataFor(PrimitiveArrayDescriptor, 'PrimitiveArrayDescriptor', classMeta, ListLikeDescriptor);
setMetadataFor(AbstractCollectionSerializer, 'AbstractCollectionSerializer', classMeta, VOID, [KSerializer]);
setMetadataFor(CollectionLikeSerializer, 'CollectionLikeSerializer', classMeta, AbstractCollectionSerializer);
setMetadataFor(CollectionSerializer, 'CollectionSerializer', classMeta, CollectionLikeSerializer);
setMetadataFor(ArrayListSerializer, 'ArrayListSerializer', classMeta, CollectionSerializer);
setMetadataFor(HashSetSerializer, 'HashSetSerializer', classMeta, CollectionSerializer);
setMetadataFor(LinkedHashSetSerializer, 'LinkedHashSetSerializer', classMeta, CollectionSerializer);
setMetadataFor(MapLikeSerializer, 'MapLikeSerializer', classMeta, AbstractCollectionSerializer);
setMetadataFor(HashMapSerializer, 'HashMapSerializer', classMeta, MapLikeSerializer);
setMetadataFor(LinkedHashMapSerializer, 'LinkedHashMapSerializer', classMeta, MapLikeSerializer);
setMetadataFor(ReferenceArraySerializer, 'ReferenceArraySerializer', classMeta, CollectionLikeSerializer);
setMetadataFor(PrimitiveArraySerializer, 'PrimitiveArraySerializer', classMeta, CollectionLikeSerializer);
setMetadataFor(PrimitiveArrayBuilder, 'PrimitiveArrayBuilder', classMeta);
setMetadataFor(Companion_0, 'Companion', objectMeta);
setMetadataFor(ElementMarker, 'ElementMarker', classMeta);
setMetadataFor(EnumSerializer, 'EnumSerializer', classMeta, VOID, [KSerializer]);
setMetadataFor(PluginGeneratedSerialDescriptor, 'PluginGeneratedSerialDescriptor', classMeta, VOID, [SerialDescriptor, CachedNames]);
setMetadataFor(EnumDescriptor, 'EnumDescriptor', classMeta, PluginGeneratedSerialDescriptor);
setMetadataFor(InlineClassDescriptor, 'InlineClassDescriptor', classMeta, PluginGeneratedSerialDescriptor);
function typeParametersSerializers() {
  return get_EMPTY_SERIALIZER_ARRAY();
}
setMetadataFor(GeneratedSerializer, 'GeneratedSerializer', interfaceMeta, VOID, [KSerializer]);
setMetadataFor(InlinePrimitiveDescriptor$1, VOID, classMeta, VOID, [GeneratedSerializer]);
setMetadataFor(NoOpEncoder, 'NoOpEncoder', objectMeta, AbstractEncoder);
setMetadataFor(NothingSerialDescriptor, 'NothingSerialDescriptor', objectMeta, VOID, [SerialDescriptor]);
setMetadataFor(NullableSerializer, 'NullableSerializer', classMeta, VOID, [KSerializer]);
setMetadataFor(SerialDescriptorForNullable, 'SerialDescriptorForNullable', classMeta, VOID, [SerialDescriptor, CachedNames]);
setMetadataFor(ObjectSerializer, 'ObjectSerializer', classMeta, VOID, [KSerializer]);
setMetadataFor(SerializerFactory, 'SerializerFactory', interfaceMeta);
setMetadataFor(CharArraySerializer_0, 'CharArraySerializer', objectMeta, PrimitiveArraySerializer, [KSerializer, PrimitiveArraySerializer]);
setMetadataFor(DoubleArraySerializer_0, 'DoubleArraySerializer', objectMeta, PrimitiveArraySerializer, [KSerializer, PrimitiveArraySerializer]);
setMetadataFor(FloatArraySerializer_0, 'FloatArraySerializer', objectMeta, PrimitiveArraySerializer, [KSerializer, PrimitiveArraySerializer]);
setMetadataFor(LongArraySerializer_0, 'LongArraySerializer', objectMeta, PrimitiveArraySerializer, [KSerializer, PrimitiveArraySerializer]);
setMetadataFor(ULongArraySerializer_0, 'ULongArraySerializer', objectMeta, PrimitiveArraySerializer, [KSerializer, PrimitiveArraySerializer]);
setMetadataFor(IntArraySerializer_0, 'IntArraySerializer', objectMeta, PrimitiveArraySerializer, [KSerializer, PrimitiveArraySerializer]);
setMetadataFor(UIntArraySerializer_0, 'UIntArraySerializer', objectMeta, PrimitiveArraySerializer, [KSerializer, PrimitiveArraySerializer]);
setMetadataFor(ShortArraySerializer_0, 'ShortArraySerializer', objectMeta, PrimitiveArraySerializer, [KSerializer, PrimitiveArraySerializer]);
setMetadataFor(UShortArraySerializer_0, 'UShortArraySerializer', objectMeta, PrimitiveArraySerializer, [KSerializer, PrimitiveArraySerializer]);
setMetadataFor(ByteArraySerializer_0, 'ByteArraySerializer', objectMeta, PrimitiveArraySerializer, [KSerializer, PrimitiveArraySerializer]);
setMetadataFor(UByteArraySerializer_0, 'UByteArraySerializer', objectMeta, PrimitiveArraySerializer, [KSerializer, PrimitiveArraySerializer]);
setMetadataFor(BooleanArraySerializer_0, 'BooleanArraySerializer', objectMeta, PrimitiveArraySerializer, [KSerializer, PrimitiveArraySerializer]);
setMetadataFor(CharArrayBuilder, 'CharArrayBuilder', classMeta, PrimitiveArrayBuilder);
setMetadataFor(DoubleArrayBuilder, 'DoubleArrayBuilder', classMeta, PrimitiveArrayBuilder);
setMetadataFor(FloatArrayBuilder, 'FloatArrayBuilder', classMeta, PrimitiveArrayBuilder);
setMetadataFor(LongArrayBuilder, 'LongArrayBuilder', classMeta, PrimitiveArrayBuilder);
setMetadataFor(ULongArrayBuilder, 'ULongArrayBuilder', classMeta, PrimitiveArrayBuilder);
setMetadataFor(IntArrayBuilder, 'IntArrayBuilder', classMeta, PrimitiveArrayBuilder);
setMetadataFor(UIntArrayBuilder, 'UIntArrayBuilder', classMeta, PrimitiveArrayBuilder);
setMetadataFor(ShortArrayBuilder, 'ShortArrayBuilder', classMeta, PrimitiveArrayBuilder);
setMetadataFor(UShortArrayBuilder, 'UShortArrayBuilder', classMeta, PrimitiveArrayBuilder);
setMetadataFor(ByteArrayBuilder, 'ByteArrayBuilder', classMeta, PrimitiveArrayBuilder);
setMetadataFor(UByteArrayBuilder, 'UByteArrayBuilder', classMeta, PrimitiveArrayBuilder);
setMetadataFor(BooleanArrayBuilder, 'BooleanArrayBuilder', classMeta, PrimitiveArrayBuilder);
setMetadataFor(StringSerializer, 'StringSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(CharSerializer, 'CharSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(DoubleSerializer, 'DoubleSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(FloatSerializer, 'FloatSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(LongSerializer, 'LongSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(IntSerializer, 'IntSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(ShortSerializer, 'ShortSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(ByteSerializer, 'ByteSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(BooleanSerializer, 'BooleanSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(UnitSerializer, 'UnitSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(PrimitiveSerialDescriptor_0, 'PrimitiveSerialDescriptor', classMeta, VOID, [SerialDescriptor]);
setMetadataFor(TaggedEncoder, 'TaggedEncoder', classMeta, VOID, [Encoder, CompositeEncoder]);
setMetadataFor(NamedValueEncoder, 'NamedValueEncoder', classMeta, TaggedEncoder);
setMetadataFor(TaggedDecoder, 'TaggedDecoder', classMeta, VOID, [Decoder, CompositeDecoder]);
setMetadataFor(NamedValueDecoder, 'NamedValueDecoder', classMeta, TaggedDecoder);
setMetadataFor(MapEntry, 'MapEntry', classMeta, VOID, [Entry]);
setMetadataFor(KeyValueSerializer, 'KeyValueSerializer', classMeta, VOID, [KSerializer]);
setMetadataFor(MapEntrySerializer_0, 'MapEntrySerializer', classMeta, KeyValueSerializer);
setMetadataFor(PairSerializer_0, 'PairSerializer', classMeta, KeyValueSerializer);
setMetadataFor(TripleSerializer_0, 'TripleSerializer', classMeta, VOID, [KSerializer]);
setMetadataFor(ULongSerializer, 'ULongSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(UIntSerializer, 'UIntSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(UShortSerializer, 'UShortSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(UByteSerializer, 'UByteSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(SerializersModule, 'SerializersModule', classMeta);
setMetadataFor(SerialModuleImpl, 'SerialModuleImpl', classMeta, SerializersModule);
setMetadataFor(ContextualProvider, 'ContextualProvider', classMeta);
setMetadataFor(Argless, 'Argless', classMeta, ContextualProvider);
setMetadataFor(WithTypeArguments, 'WithTypeArguments', classMeta, ContextualProvider);
function contextual(kClass, serializer) {
  return this.o4b(kClass, SerializersModuleCollector$contextual$lambda(serializer));
}
setMetadataFor(SerializersModuleCollector, 'SerializersModuleCollector', interfaceMeta);
setMetadataFor(SerializableWith, 'SerializableWith', classMeta, VOID, VOID, VOID, 0);
setMetadataFor(createCache$1, VOID, classMeta);
setMetadataFor(createParametrizedCache$1, VOID, classMeta);
//endregion
function serializer($this, serializersModule) {
  var tmp0_elvis_lhs = serializersModule.y3q($this.u3q_1, $this.w3q_1);
  var tmp1_elvis_lhs = tmp0_elvis_lhs == null ? $this.v3q_1 : tmp0_elvis_lhs;
  var tmp;
  if (tmp1_elvis_lhs == null) {
    serializerNotRegistered($this.u3q_1);
  } else {
    tmp = tmp1_elvis_lhs;
  }
  return tmp;
}
function ContextualSerializer$descriptor$lambda(this$0) {
  return function ($this$buildSerialDescriptor) {
    var tmp = $this$buildSerialDescriptor;
    // Inline function 'kotlin.collections.orEmpty' call
    var tmp0_safe_receiver = this$0.v3q_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.z3q();
    var tmp0_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.a3r();
    tmp.d3r_1 = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
    return Unit_instance;
  };
}
function ContextualSerializer(serializableClass, fallbackSerializer, typeArgumentsSerializers) {
  this.u3q_1 = serializableClass;
  this.v3q_1 = fallbackSerializer;
  this.w3q_1 = asList(typeArgumentsSerializers);
  var tmp = this;
  var tmp_0 = CONTEXTUAL_getInstance();
  tmp.x3q_1 = withContext(buildSerialDescriptor('kotlinx.serialization.ContextualSerializer', tmp_0, [], ContextualSerializer$descriptor$lambda(this)), this.u3q_1);
}
protoOf(ContextualSerializer).z3q = function () {
  return this.x3q_1;
};
protoOf(ContextualSerializer).j3r = function (encoder, value) {
  encoder.l3r(serializer(this, encoder.k3r()), value);
};
protoOf(ContextualSerializer).m3r = function (encoder, value) {
  return this.j3r(encoder, !(value == null) ? value : THROW_CCE());
};
protoOf(ContextualSerializer).n3r = function (decoder) {
  return decoder.o3r(serializer(this, decoder.k3r()));
};
function KSerializer() {
}
function SerializationStrategy() {
}
function DeserializationStrategy() {
}
function PolymorphicSerializer$descriptor$delegate$lambda$lambda(this$0) {
  return function ($this$buildSerialDescriptor) {
    $this$buildSerialDescriptor.p3r('type', serializer_2(StringCompanionObject_instance).z3q());
    $this$buildSerialDescriptor.p3r('value', buildSerialDescriptor('kotlinx.serialization.Polymorphic<' + this$0.q3r_1.s6() + '>', CONTEXTUAL_getInstance(), []));
    $this$buildSerialDescriptor.d3r_1 = this$0.r3r_1;
    return Unit_instance;
  };
}
function PolymorphicSerializer$descriptor$delegate$lambda(this$0) {
  return function () {
    var tmp = OPEN_getInstance();
    return withContext(buildSerialDescriptor('kotlinx.serialization.Polymorphic', tmp, [], PolymorphicSerializer$descriptor$delegate$lambda$lambda(this$0)), this$0.q3r_1);
  };
}
function PolymorphicSerializer(baseClass) {
  AbstractPolymorphicSerializer.call(this);
  this.q3r_1 = baseClass;
  this.r3r_1 = emptyList();
  var tmp = this;
  var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
  tmp.s3r_1 = lazy(tmp_0, PolymorphicSerializer$descriptor$delegate$lambda(this));
}
protoOf(PolymorphicSerializer).t3r = function () {
  return this.q3r_1;
};
protoOf(PolymorphicSerializer).z3q = function () {
  // Inline function 'kotlin.getValue' call
  var this_0 = this.s3r_1;
  descriptor$factory();
  return this_0.l2();
};
protoOf(PolymorphicSerializer).toString = function () {
  return 'kotlinx.serialization.PolymorphicSerializer(baseClass: ' + this.q3r_1 + ')';
};
function findPolymorphicSerializer(_this__u8e3s4, encoder, value) {
  var tmp0_elvis_lhs = _this__u8e3s4.v3r(encoder, value);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throwSubtypeNotRegistered(getKClassFromExpression(value), _this__u8e3s4.t3r());
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function findPolymorphicSerializer_0(_this__u8e3s4, decoder, klassName) {
  var tmp0_elvis_lhs = _this__u8e3s4.u3r(decoder, klassName);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throwSubtypeNotRegistered_0(klassName, _this__u8e3s4.t3r());
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function descriptor$factory() {
  return getPropertyCallableRef('descriptor', 1, KProperty1, function (receiver) {
    return receiver.z3q();
  }, null);
}
function SealedClassSerializer_init_$Init$(serialName, baseClass, subclasses, subclassSerializers, classAnnotations, $this) {
  SealedClassSerializer.call($this, serialName, baseClass, subclasses, subclassSerializers);
  $this.x3r_1 = asList(classAnnotations);
  return $this;
}
function SealedClassSerializer_init_$Create$(serialName, baseClass, subclasses, subclassSerializers, classAnnotations) {
  return SealedClassSerializer_init_$Init$(serialName, baseClass, subclasses, subclassSerializers, classAnnotations, objectCreate(protoOf(SealedClassSerializer)));
}
function SealedClassSerializer$descriptor$delegate$lambda$lambda$lambda(this$0) {
  return function ($this$buildSerialDescriptor) {
    // Inline function 'kotlin.collections.iterator' call
    var tmp0_iterator = this$0.a3s_1.h2().u();
    while (tmp0_iterator.v()) {
      var element = tmp0_iterator.w();
      // Inline function 'kotlinx.serialization.SealedClassSerializer.descriptor$delegate.<anonymous>.<anonymous>.<anonymous>.<anonymous>' call
      // Inline function 'kotlin.collections.component1' call
      var name = element.k2();
      // Inline function 'kotlin.collections.component2' call
      var serializer = element.l2();
      $this$buildSerialDescriptor.p3r(name, serializer.z3q());
    }
    return Unit_instance;
  };
}
function SealedClassSerializer$descriptor$delegate$lambda$lambda(this$0) {
  return function ($this$buildSerialDescriptor) {
    $this$buildSerialDescriptor.p3r('type', serializer_2(StringCompanionObject_instance).z3q());
    var tmp = 'kotlinx.serialization.Sealed<' + this$0.w3r_1.s6() + '>';
    var tmp_0 = CONTEXTUAL_getInstance();
    var elementDescriptor = buildSerialDescriptor(tmp, tmp_0, [], SealedClassSerializer$descriptor$delegate$lambda$lambda$lambda(this$0));
    $this$buildSerialDescriptor.p3r('value', elementDescriptor);
    $this$buildSerialDescriptor.d3r_1 = this$0.x3r_1;
    return Unit_instance;
  };
}
function SealedClassSerializer$descriptor$delegate$lambda($serialName, this$0) {
  return function () {
    var tmp = SEALED_getInstance();
    return buildSerialDescriptor($serialName, tmp, [], SealedClassSerializer$descriptor$delegate$lambda$lambda(this$0));
  };
}
function _no_name_provided__qut3iv($this) {
  this.b3s_1 = $this;
}
protoOf(_no_name_provided__qut3iv).c3s = function () {
  return this.b3s_1.u();
};
protoOf(_no_name_provided__qut3iv).d3s = function (element) {
  // Inline function 'kotlinx.serialization.SealedClassSerializer.<anonymous>' call
  return element.l2().z3q().e3s();
};
protoOf(_no_name_provided__qut3iv).f3s = function (element) {
  return this.d3s((!(element == null) ? isInterface(element, Entry) : false) ? element : THROW_CCE());
};
function SealedClassSerializer(serialName, baseClass, subclasses, subclassSerializers) {
  AbstractPolymorphicSerializer.call(this);
  this.w3r_1 = baseClass;
  this.x3r_1 = emptyList();
  var tmp = this;
  var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
  tmp.y3r_1 = lazy(tmp_0, SealedClassSerializer$descriptor$delegate$lambda(serialName, this));
  if (!(subclasses.length === subclassSerializers.length)) {
    throw IllegalArgumentException_init_$Create$('All subclasses of sealed class ' + this.w3r_1.s6() + ' should be marked @Serializable');
  }
  this.z3r_1 = toMap(zip(subclasses, subclassSerializers));
  var tmp_1 = this;
  // Inline function 'kotlin.collections.mapValues' call
  // Inline function 'kotlin.collections.aggregate' call
  // Inline function 'kotlin.collections.groupingBy' call
  var this_0 = this.z3r_1.h2();
  // Inline function 'kotlin.collections.aggregateTo' call
  var this_1 = new _no_name_provided__qut3iv(this_0);
  // Inline function 'kotlin.collections.mutableMapOf' call
  var destination = LinkedHashMap_init_$Create$();
  // Inline function 'kotlin.collections.iterator' call
  var tmp0_iterator = this_1.c3s();
  while (tmp0_iterator.v()) {
    var e = tmp0_iterator.w();
    var key = this_1.f3s(e);
    var accumulator = destination.s2(key);
    // Inline function 'kotlin.collections.set' call
    // Inline function 'kotlinx.serialization.SealedClassSerializer.<anonymous>' call
    accumulator == null && !destination.p2(key);
    if (!(accumulator == null)) {
      // Inline function 'kotlin.error' call
      var message = "Multiple sealed subclasses of '" + this.w3r_1 + "' have the same serial name '" + key + "':" + (" '" + accumulator.k2() + "', '" + e.k2() + "'");
      throw IllegalStateException_init_$Create$(toString(message));
    }
    destination.i2(key, e);
  }
  // Inline function 'kotlin.collections.mapValuesTo' call
  var destination_0 = LinkedHashMap_init_$Create$_0(mapCapacity(destination.n()));
  // Inline function 'kotlin.collections.associateByTo' call
  var tmp0_iterator_0 = destination.h2().u();
  while (tmp0_iterator_0.v()) {
    var element = tmp0_iterator_0.w();
    // Inline function 'kotlin.collections.mapValuesTo.<anonymous>' call
    var tmp_2 = element.k2();
    // Inline function 'kotlinx.serialization.SealedClassSerializer.<anonymous>' call
    var tmp$ret$7 = element.l2().l2();
    destination_0.i2(tmp_2, tmp$ret$7);
  }
  tmp_1.a3s_1 = destination_0;
}
protoOf(SealedClassSerializer).t3r = function () {
  return this.w3r_1;
};
protoOf(SealedClassSerializer).z3q = function () {
  // Inline function 'kotlin.getValue' call
  var this_0 = this.y3r_1;
  descriptor$factory_0();
  return this_0.l2();
};
protoOf(SealedClassSerializer).u3r = function (decoder, klassName) {
  // Inline function 'kotlin.collections.get' call
  var this_0 = this.a3s_1;
  var tmp0_elvis_lhs = (isInterface(this_0, Map) ? this_0 : THROW_CCE()).s2(klassName);
  return tmp0_elvis_lhs == null ? protoOf(AbstractPolymorphicSerializer).u3r.call(this, decoder, klassName) : tmp0_elvis_lhs;
};
protoOf(SealedClassSerializer).v3r = function (encoder, value) {
  var tmp0_elvis_lhs = this.z3r_1.s2(getKClassFromExpression(value));
  var tmp1_safe_receiver = tmp0_elvis_lhs == null ? protoOf(AbstractPolymorphicSerializer).v3r.call(this, encoder, value) : tmp0_elvis_lhs;
  var tmp;
  if (tmp1_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlinx.serialization.internal.cast' call
    tmp = isInterface(tmp1_safe_receiver, SerializationStrategy) ? tmp1_safe_receiver : THROW_CCE();
  }
  return tmp;
};
function descriptor$factory_0() {
  return getPropertyCallableRef('descriptor', 1, KProperty1, function (receiver) {
    return receiver.z3q();
  }, null);
}
function StringFormat() {
}
function BinaryFormat() {
}
function SerializationException_init_$Init$($this) {
  IllegalArgumentException_init_$Init$($this);
  SerializationException.call($this);
  return $this;
}
function SerializationException_init_$Create$() {
  var tmp = SerializationException_init_$Init$(objectCreate(protoOf(SerializationException)));
  captureStack(tmp, SerializationException_init_$Create$);
  return tmp;
}
function SerializationException_init_$Init$_0(message, $this) {
  IllegalArgumentException_init_$Init$_0(message, $this);
  SerializationException.call($this);
  return $this;
}
function SerializationException_init_$Create$_0(message) {
  var tmp = SerializationException_init_$Init$_0(message, objectCreate(protoOf(SerializationException)));
  captureStack(tmp, SerializationException_init_$Create$_0);
  return tmp;
}
function SerializationException_init_$Init$_1(message, cause, $this) {
  IllegalArgumentException_init_$Init$_1(message, cause, $this);
  SerializationException.call($this);
  return $this;
}
function SerializationException() {
  captureStack(this, SerializationException);
}
function UnknownFieldException_init_$Init$(index, $this) {
  UnknownFieldException.call($this, 'An unknown field for index ' + index);
  return $this;
}
function UnknownFieldException_init_$Create$(index) {
  var tmp = UnknownFieldException_init_$Init$(index, objectCreate(protoOf(UnknownFieldException)));
  captureStack(tmp, UnknownFieldException_init_$Create$);
  return tmp;
}
function UnknownFieldException(message) {
  SerializationException_init_$Init$_0(message, this);
  captureStack(this, UnknownFieldException);
}
function MissingFieldException_init_$Init$(missingFields, serialName, $this) {
  MissingFieldException.call($this, missingFields, missingFields.n() === 1 ? "Field '" + missingFields.f1(0) + "' is required for type with serial name '" + serialName + "', but it was missing" : 'Fields ' + missingFields + " are required for type with serial name '" + serialName + "', but they were missing", null);
  return $this;
}
function MissingFieldException_init_$Create$(missingFields, serialName) {
  var tmp = MissingFieldException_init_$Init$(missingFields, serialName, objectCreate(protoOf(MissingFieldException)));
  captureStack(tmp, MissingFieldException_init_$Create$);
  return tmp;
}
function MissingFieldException(missingFields, message, cause) {
  SerializationException_init_$Init$_1(message, cause, this);
  captureStack(this, MissingFieldException);
  this.k3s_1 = missingFields;
}
function serializerOrNull(_this__u8e3s4) {
  var tmp0_elvis_lhs = compiledSerializerImpl(_this__u8e3s4);
  return tmp0_elvis_lhs == null ? builtinSerializerOrNull(_this__u8e3s4) : tmp0_elvis_lhs;
}
function serializersForParameters(_this__u8e3s4, typeArguments, failOnMissingTypeArgSerializer) {
  var tmp;
  if (failOnMissingTypeArgSerializer) {
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(typeArguments, 10));
    var tmp0_iterator = typeArguments.u();
    while (tmp0_iterator.v()) {
      var item = tmp0_iterator.w();
      // Inline function 'kotlinx.serialization.serializersForParameters.<anonymous>' call
      var tmp$ret$0 = serializer_0(_this__u8e3s4, item);
      destination.r(tmp$ret$0);
    }
    tmp = destination;
  } else {
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList_init_$Create$(collectionSizeOrDefault(typeArguments, 10));
    var tmp0_iterator_0 = typeArguments.u();
    while (tmp0_iterator_0.v()) {
      var item_0 = tmp0_iterator_0.w();
      // Inline function 'kotlinx.serialization.serializersForParameters.<anonymous>' call
      var tmp0_elvis_lhs = serializerOrNull_0(_this__u8e3s4, item_0);
      var tmp_0;
      if (tmp0_elvis_lhs == null) {
        return null;
      } else {
        tmp_0 = tmp0_elvis_lhs;
      }
      var tmp$ret$3 = tmp_0;
      destination_0.r(tmp$ret$3);
    }
    tmp = destination_0;
  }
  var serializers = tmp;
  return serializers;
}
function parametrizedSerializerOrNull(_this__u8e3s4, serializers, elementClassifierIfArray) {
  var tmp0_elvis_lhs = builtinParametrizedSerializer(_this__u8e3s4, serializers, elementClassifierIfArray);
  return tmp0_elvis_lhs == null ? compiledParametrizedSerializer(_this__u8e3s4, serializers) : tmp0_elvis_lhs;
}
function serializer_0(_this__u8e3s4, type) {
  var tmp0_elvis_lhs = serializerByKTypeImpl(_this__u8e3s4, type, true);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    platformSpecificSerializerNotRegistered(kclass(type));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function serializerOrNull_0(_this__u8e3s4, type) {
  return serializerByKTypeImpl(_this__u8e3s4, type, false);
}
function builtinParametrizedSerializer(_this__u8e3s4, serializers, elementClassifierIfArray) {
  var tmp;
  if (((_this__u8e3s4.equals(getKClass(Collection)) ? true : _this__u8e3s4.equals(getKClass(List))) ? true : _this__u8e3s4.equals(getKClass(MutableList))) ? true : _this__u8e3s4.equals(getKClass(ArrayList))) {
    tmp = new ArrayListSerializer(serializers.f1(0));
  } else if (_this__u8e3s4.equals(getKClass(HashSet))) {
    tmp = new HashSetSerializer(serializers.f1(0));
  } else if ((_this__u8e3s4.equals(getKClass(Set)) ? true : _this__u8e3s4.equals(getKClass(MutableSet))) ? true : _this__u8e3s4.equals(getKClass(LinkedHashSet))) {
    tmp = new LinkedHashSetSerializer(serializers.f1(0));
  } else if (_this__u8e3s4.equals(getKClass(HashMap))) {
    tmp = new HashMapSerializer(serializers.f1(0), serializers.f1(1));
  } else if ((_this__u8e3s4.equals(getKClass(Map)) ? true : _this__u8e3s4.equals(getKClass(MutableMap))) ? true : _this__u8e3s4.equals(getKClass(LinkedHashMap))) {
    tmp = new LinkedHashMapSerializer(serializers.f1(0), serializers.f1(1));
  } else if (_this__u8e3s4.equals(getKClass(Entry))) {
    tmp = MapEntrySerializer(serializers.f1(0), serializers.f1(1));
  } else if (_this__u8e3s4.equals(getKClass(Pair))) {
    tmp = PairSerializer(serializers.f1(0), serializers.f1(1));
  } else if (_this__u8e3s4.equals(getKClass(Triple))) {
    tmp = TripleSerializer(serializers.f1(0), serializers.f1(1), serializers.f1(2));
  } else {
    var tmp_0;
    if (isReferenceArray(_this__u8e3s4)) {
      var tmp_1 = elementClassifierIfArray();
      tmp_0 = ArraySerializer((!(tmp_1 == null) ? isInterface(tmp_1, KClass) : false) ? tmp_1 : THROW_CCE(), serializers.f1(0));
    } else {
      tmp_0 = null;
    }
    tmp = tmp_0;
  }
  return tmp;
}
function compiledParametrizedSerializer(_this__u8e3s4, serializers) {
  // Inline function 'kotlin.collections.toTypedArray' call
  var tmp$ret$0 = copyToArray(serializers);
  return constructSerializerForGivenTypeArgs(_this__u8e3s4, tmp$ret$0.slice());
}
function serializerByKTypeImpl(_this__u8e3s4, type, failOnMissingTypeArgSerializer) {
  var rootClass = kclass(type);
  var isNullable = type.i7();
  // Inline function 'kotlin.collections.map' call
  var this_0 = type.h7();
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
  var tmp0_iterator = this_0.u();
  while (tmp0_iterator.v()) {
    var item = tmp0_iterator.w();
    var tmp$ret$0 = typeOrThrow(item);
    destination.r(tmp$ret$0);
  }
  var typeArguments = destination;
  var tmp;
  if (typeArguments.b1()) {
    tmp = findCachedSerializer(rootClass, isNullable);
  } else {
    // Inline function 'kotlin.Result.getOrNull' call
    var this_1 = findParametrizedCachedSerializer(rootClass, typeArguments, isNullable);
    var tmp_0;
    if (_Result___get_isFailure__impl__jpiriv(this_1)) {
      tmp_0 = null;
    } else {
      var tmp_1 = _Result___get_value__impl__bjfvqg(this_1);
      tmp_0 = (tmp_1 == null ? true : !(tmp_1 == null)) ? tmp_1 : THROW_CCE();
    }
    tmp = tmp_0;
  }
  var cachedSerializer = tmp;
  if (cachedSerializer == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    return cachedSerializer;
  }
  var tmp_2;
  if (typeArguments.b1()) {
    tmp_2 = _this__u8e3s4.l3s(rootClass);
  } else {
    var tmp1_elvis_lhs = serializersForParameters(_this__u8e3s4, typeArguments, failOnMissingTypeArgSerializer);
    var tmp_3;
    if (tmp1_elvis_lhs == null) {
      return null;
    } else {
      tmp_3 = tmp1_elvis_lhs;
    }
    var serializers = tmp_3;
    var tmp2_elvis_lhs = parametrizedSerializerOrNull(rootClass, serializers, serializerByKTypeImpl$lambda(typeArguments));
    tmp_2 = tmp2_elvis_lhs == null ? _this__u8e3s4.y3q(rootClass, serializers) : tmp2_elvis_lhs;
  }
  var contextualSerializer = tmp_2;
  var tmp_4;
  if (contextualSerializer == null) {
    tmp_4 = null;
  } else {
    // Inline function 'kotlinx.serialization.internal.cast' call
    tmp_4 = isInterface(contextualSerializer, KSerializer) ? contextualSerializer : THROW_CCE();
  }
  var tmp4_safe_receiver = tmp_4;
  return tmp4_safe_receiver == null ? null : nullable(tmp4_safe_receiver, isNullable);
}
function nullable(_this__u8e3s4, shouldBeNullable) {
  if (shouldBeNullable)
    return get_nullable(_this__u8e3s4);
  return isInterface(_this__u8e3s4, KSerializer) ? _this__u8e3s4 : THROW_CCE();
}
function serializer_1(_this__u8e3s4) {
  var tmp0_elvis_lhs = serializerOrNull(_this__u8e3s4);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    serializerNotRegistered(_this__u8e3s4);
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function serializerByKTypeImpl$lambda($typeArguments) {
  return function () {
    return $typeArguments.f1(0).g7();
  };
}
function get_SERIALIZERS_CACHE() {
  _init_properties_SerializersCache_kt__hgwi2p();
  return SERIALIZERS_CACHE;
}
var SERIALIZERS_CACHE;
function get_SERIALIZERS_CACHE_NULLABLE() {
  _init_properties_SerializersCache_kt__hgwi2p();
  return SERIALIZERS_CACHE_NULLABLE;
}
var SERIALIZERS_CACHE_NULLABLE;
function get_PARAMETRIZED_SERIALIZERS_CACHE() {
  _init_properties_SerializersCache_kt__hgwi2p();
  return PARAMETRIZED_SERIALIZERS_CACHE;
}
var PARAMETRIZED_SERIALIZERS_CACHE;
function get_PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE() {
  _init_properties_SerializersCache_kt__hgwi2p();
  return PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE;
}
var PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE;
function findCachedSerializer(clazz, isNullable) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var tmp;
  if (!isNullable) {
    var tmp0_safe_receiver = get_SERIALIZERS_CACHE().m3s(clazz);
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlinx.serialization.internal.cast' call
      tmp_0 = isInterface(tmp0_safe_receiver, KSerializer) ? tmp0_safe_receiver : THROW_CCE();
    }
    tmp = tmp_0;
  } else {
    tmp = get_SERIALIZERS_CACHE_NULLABLE().m3s(clazz);
  }
  return tmp;
}
function findParametrizedCachedSerializer(clazz, types, isNullable) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var tmp;
  if (!isNullable) {
    var tmp_0 = get_PARAMETRIZED_SERIALIZERS_CACHE().n3s(clazz, types);
    tmp = new Result(tmp_0) instanceof Result ? tmp_0 : THROW_CCE();
  } else {
    tmp = get_PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE().n3s(clazz, types);
  }
  return tmp;
}
function SERIALIZERS_CACHE$lambda(it) {
  _init_properties_SerializersCache_kt__hgwi2p();
  return serializerOrNull(it);
}
function SERIALIZERS_CACHE_NULLABLE$lambda(it) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var tmp0_safe_receiver = serializerOrNull(it);
  var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : get_nullable(tmp0_safe_receiver);
  var tmp;
  if (tmp1_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlinx.serialization.internal.cast' call
    tmp = isInterface(tmp1_safe_receiver, KSerializer) ? tmp1_safe_receiver : THROW_CCE();
  }
  return tmp;
}
function PARAMETRIZED_SERIALIZERS_CACHE$lambda(clazz, types) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var serializers = ensureNotNull(serializersForParameters(EmptySerializersModule_0(), types, true));
  return parametrizedSerializerOrNull(clazz, serializers, PARAMETRIZED_SERIALIZERS_CACHE$lambda$lambda(types));
}
function PARAMETRIZED_SERIALIZERS_CACHE$lambda$lambda($types) {
  return function () {
    return $types.f1(0).g7();
  };
}
function PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE$lambda(clazz, types) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var serializers = ensureNotNull(serializersForParameters(EmptySerializersModule_0(), types, true));
  var tmp0_safe_receiver = parametrizedSerializerOrNull(clazz, serializers, PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE$lambda$lambda(types));
  var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : get_nullable(tmp0_safe_receiver);
  var tmp;
  if (tmp1_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlinx.serialization.internal.cast' call
    tmp = isInterface(tmp1_safe_receiver, KSerializer) ? tmp1_safe_receiver : THROW_CCE();
  }
  return tmp;
}
function PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE$lambda$lambda($types) {
  return function () {
    return $types.f1(0).g7();
  };
}
var properties_initialized_SerializersCache_kt_q8kf25;
function _init_properties_SerializersCache_kt__hgwi2p() {
  if (!properties_initialized_SerializersCache_kt_q8kf25) {
    properties_initialized_SerializersCache_kt_q8kf25 = true;
    SERIALIZERS_CACHE = createCache(SERIALIZERS_CACHE$lambda);
    SERIALIZERS_CACHE_NULLABLE = createCache(SERIALIZERS_CACHE_NULLABLE$lambda);
    PARAMETRIZED_SERIALIZERS_CACHE = createParametrizedCache(PARAMETRIZED_SERIALIZERS_CACHE$lambda);
    PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE = createParametrizedCache(PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE$lambda);
  }
}
function get_nullable(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4.z3q().o3s()) {
    tmp = isInterface(_this__u8e3s4, KSerializer) ? _this__u8e3s4 : THROW_CCE();
  } else {
    tmp = new NullableSerializer(_this__u8e3s4);
  }
  return tmp;
}
function serializer_2(_this__u8e3s4) {
  return StringSerializer_getInstance();
}
function serializer_3(_this__u8e3s4) {
  return CharSerializer_getInstance();
}
function CharArraySerializer() {
  return CharArraySerializer_getInstance();
}
function serializer_4(_this__u8e3s4) {
  return DoubleSerializer_getInstance();
}
function DoubleArraySerializer() {
  return DoubleArraySerializer_getInstance();
}
function serializer_5(_this__u8e3s4) {
  return FloatSerializer_getInstance();
}
function FloatArraySerializer() {
  return FloatArraySerializer_getInstance();
}
function serializer_6(_this__u8e3s4) {
  return LongSerializer_getInstance();
}
function LongArraySerializer() {
  return LongArraySerializer_getInstance();
}
function serializer_7(_this__u8e3s4) {
  return ULongSerializer_getInstance();
}
function ULongArraySerializer() {
  return ULongArraySerializer_getInstance();
}
function serializer_8(_this__u8e3s4) {
  return IntSerializer_getInstance();
}
function IntArraySerializer() {
  return IntArraySerializer_getInstance();
}
function serializer_9(_this__u8e3s4) {
  return UIntSerializer_getInstance();
}
function UIntArraySerializer() {
  return UIntArraySerializer_getInstance();
}
function serializer_10(_this__u8e3s4) {
  return ShortSerializer_getInstance();
}
function ShortArraySerializer() {
  return ShortArraySerializer_getInstance();
}
function serializer_11(_this__u8e3s4) {
  return UShortSerializer_getInstance();
}
function UShortArraySerializer() {
  return UShortArraySerializer_getInstance();
}
function serializer_12(_this__u8e3s4) {
  return ByteSerializer_getInstance();
}
function ByteArraySerializer() {
  return ByteArraySerializer_getInstance();
}
function serializer_13(_this__u8e3s4) {
  return UByteSerializer_getInstance();
}
function UByteArraySerializer() {
  return UByteArraySerializer_getInstance();
}
function serializer_14(_this__u8e3s4) {
  return BooleanSerializer_getInstance();
}
function BooleanArraySerializer() {
  return BooleanArraySerializer_getInstance();
}
function serializer_15(_this__u8e3s4) {
  return UnitSerializer_getInstance();
}
function NothingSerializer() {
  return NothingSerializer_getInstance();
}
function serializer_16(_this__u8e3s4) {
  return DurationSerializer_getInstance();
}
function MapEntrySerializer(keySerializer, valueSerializer) {
  return new MapEntrySerializer_0(keySerializer, valueSerializer);
}
function PairSerializer(keySerializer, valueSerializer) {
  return new PairSerializer_0(keySerializer, valueSerializer);
}
function TripleSerializer(aSerializer, bSerializer, cSerializer) {
  return new TripleSerializer_0(aSerializer, bSerializer, cSerializer);
}
function ArraySerializer(kClass, elementSerializer) {
  return new ReferenceArraySerializer(kClass, elementSerializer);
}
function ListSerializer(elementSerializer) {
  return new ArrayListSerializer(elementSerializer);
}
function MapSerializer(keySerializer, valueSerializer) {
  return new LinkedHashMapSerializer(keySerializer, valueSerializer);
}
function SetSerializer(elementSerializer) {
  return new LinkedHashSetSerializer(elementSerializer);
}
function withContext(_this__u8e3s4, context) {
  return new ContextDescriptor(_this__u8e3s4, context);
}
function ContextDescriptor(original, kClass) {
  this.p3s_1 = original;
  this.q3s_1 = kClass;
  this.r3s_1 = this.p3s_1.e3s() + '<' + this.q3s_1.s6() + '>';
}
protoOf(ContextDescriptor).a3r = function () {
  return this.p3s_1.a3r();
};
protoOf(ContextDescriptor).s3s = function () {
  return this.p3s_1.s3s();
};
protoOf(ContextDescriptor).t3s = function () {
  return this.p3s_1.t3s();
};
protoOf(ContextDescriptor).o3s = function () {
  return this.p3s_1.o3s();
};
protoOf(ContextDescriptor).u3s = function () {
  return this.p3s_1.u3s();
};
protoOf(ContextDescriptor).v3s = function (index) {
  return this.p3s_1.v3s(index);
};
protoOf(ContextDescriptor).w3s = function (index) {
  return this.p3s_1.w3s(index);
};
protoOf(ContextDescriptor).x3s = function (name) {
  return this.p3s_1.x3s(name);
};
protoOf(ContextDescriptor).y3s = function (index) {
  return this.p3s_1.y3s(index);
};
protoOf(ContextDescriptor).z3s = function (index) {
  return this.p3s_1.z3s(index);
};
protoOf(ContextDescriptor).e3s = function () {
  return this.r3s_1;
};
protoOf(ContextDescriptor).equals = function (other) {
  var tmp0_elvis_lhs = other instanceof ContextDescriptor ? other : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return false;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var another = tmp;
  return equals(this.p3s_1, another.p3s_1) ? another.q3s_1.equals(this.q3s_1) : false;
};
protoOf(ContextDescriptor).hashCode = function () {
  var result = this.q3s_1.hashCode();
  result = imul(31, result) + getStringHashCode(this.r3s_1) | 0;
  return result;
};
protoOf(ContextDescriptor).toString = function () {
  return 'ContextDescriptor(kClass: ' + this.q3s_1 + ', original: ' + this.p3s_1 + ')';
};
function getContextualDescriptor(_this__u8e3s4, descriptor) {
  var tmp0_safe_receiver = get_capturedKClass(descriptor);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.serialization.descriptors.getContextualDescriptor.<anonymous>' call
    var tmp0_safe_receiver_0 = _this__u8e3s4.l3s(tmp0_safe_receiver);
    tmp = tmp0_safe_receiver_0 == null ? null : tmp0_safe_receiver_0.z3q();
  }
  return tmp;
}
function get_capturedKClass(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4 instanceof ContextDescriptor) {
    tmp = _this__u8e3s4.q3s_1;
  } else {
    if (_this__u8e3s4 instanceof SerialDescriptorForNullable) {
      tmp = get_capturedKClass(_this__u8e3s4.a3t_1);
    } else {
      tmp = null;
    }
  }
  return tmp;
}
function SerialDescriptor() {
}
function get_elementDescriptors(_this__u8e3s4) {
  // Inline function 'kotlin.collections.Iterable' call
  return new _no_name_provided__qut3iv_0(_this__u8e3s4);
}
function get_elementNames(_this__u8e3s4) {
  // Inline function 'kotlin.collections.Iterable' call
  return new _no_name_provided__qut3iv_1(_this__u8e3s4);
}
function elementDescriptors$1$1($this_elementDescriptors) {
  this.e3t_1 = $this_elementDescriptors;
  this.d3t_1 = $this_elementDescriptors.s3s();
}
protoOf(elementDescriptors$1$1).v = function () {
  return this.d3t_1 > 0;
};
protoOf(elementDescriptors$1$1).w = function () {
  var tmp = this.e3t_1.s3s();
  var tmp1 = this.d3t_1;
  this.d3t_1 = tmp1 - 1 | 0;
  return this.e3t_1.w3s(tmp - tmp1 | 0);
};
function _no_name_provided__qut3iv_0($this_elementDescriptors) {
  this.f3t_1 = $this_elementDescriptors;
}
protoOf(_no_name_provided__qut3iv_0).u = function () {
  // Inline function 'kotlinx.serialization.descriptors.<get-elementDescriptors>.<anonymous>' call
  return new elementDescriptors$1$1(this.f3t_1);
};
function elementNames$1$1($this_elementNames) {
  this.h3t_1 = $this_elementNames;
  this.g3t_1 = $this_elementNames.s3s();
}
protoOf(elementNames$1$1).v = function () {
  return this.g3t_1 > 0;
};
protoOf(elementNames$1$1).w = function () {
  var tmp = this.h3t_1.s3s();
  var tmp1 = this.g3t_1;
  this.g3t_1 = tmp1 - 1 | 0;
  return this.h3t_1.y3s(tmp - tmp1 | 0);
};
function _no_name_provided__qut3iv_1($this_elementNames) {
  this.i3t_1 = $this_elementNames;
}
protoOf(_no_name_provided__qut3iv_1).u = function () {
  // Inline function 'kotlinx.serialization.descriptors.<get-elementNames>.<anonymous>' call
  return new elementNames$1$1(this.i3t_1);
};
function buildSerialDescriptor(serialName, kind, typeParameters, builder) {
  var tmp;
  if (builder === VOID) {
    tmp = buildSerialDescriptor$lambda;
  } else {
    tmp = builder;
  }
  builder = tmp;
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.text.isNotBlank' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!isBlank(serialName)) {
    // Inline function 'kotlinx.serialization.descriptors.buildSerialDescriptor.<anonymous>' call
    var message = 'Blank serial names are prohibited';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!equals(kind, CLASS_getInstance())) {
    // Inline function 'kotlinx.serialization.descriptors.buildSerialDescriptor.<anonymous>' call
    var message_0 = "For StructureKind.CLASS please use 'buildClassSerialDescriptor' instead";
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  var sdBuilder = new ClassSerialDescriptorBuilder(serialName);
  builder(sdBuilder);
  return new SerialDescriptorImpl(serialName, kind, sdBuilder.e3r_1.n(), toList(typeParameters), sdBuilder);
}
function ClassSerialDescriptorBuilder(serialName) {
  this.b3r_1 = serialName;
  this.c3r_1 = false;
  this.d3r_1 = emptyList();
  this.e3r_1 = ArrayList_init_$Create$_0();
  this.f3r_1 = HashSet_init_$Create$();
  this.g3r_1 = ArrayList_init_$Create$_0();
  this.h3r_1 = ArrayList_init_$Create$_0();
  this.i3r_1 = ArrayList_init_$Create$_0();
}
protoOf(ClassSerialDescriptorBuilder).j3t = function (elementName, descriptor, annotations, isOptional) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!this.f3r_1.r(elementName)) {
    // Inline function 'kotlinx.serialization.descriptors.ClassSerialDescriptorBuilder.element.<anonymous>' call
    var message = "Element with name '" + elementName + "' is already registered in " + this.b3r_1;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.collections.plusAssign' call
  this.e3r_1.r(elementName);
  // Inline function 'kotlin.collections.plusAssign' call
  this.g3r_1.r(descriptor);
  // Inline function 'kotlin.collections.plusAssign' call
  this.h3r_1.r(annotations);
  // Inline function 'kotlin.collections.plusAssign' call
  this.i3r_1.r(isOptional);
};
protoOf(ClassSerialDescriptorBuilder).p3r = function (elementName, descriptor, annotations, isOptional, $super) {
  annotations = annotations === VOID ? emptyList() : annotations;
  isOptional = isOptional === VOID ? false : isOptional;
  var tmp;
  if ($super === VOID) {
    this.j3t(elementName, descriptor, annotations, isOptional);
    tmp = Unit_instance;
  } else {
    tmp = $super.j3t.call(this, elementName, descriptor, annotations, isOptional);
  }
  return tmp;
};
function buildClassSerialDescriptor(serialName, typeParameters, builderAction) {
  var tmp;
  if (builderAction === VOID) {
    tmp = buildClassSerialDescriptor$lambda;
  } else {
    tmp = builderAction;
  }
  builderAction = tmp;
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.text.isNotBlank' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!isBlank(serialName)) {
    // Inline function 'kotlinx.serialization.descriptors.buildClassSerialDescriptor.<anonymous>' call
    var message = 'Blank serial names are prohibited';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var sdBuilder = new ClassSerialDescriptorBuilder(serialName);
  builderAction(sdBuilder);
  return new SerialDescriptorImpl(serialName, CLASS_getInstance(), sdBuilder.e3r_1.n(), toList(typeParameters), sdBuilder);
}
function _get__hashCode__tgwhef($this) {
  // Inline function 'kotlin.getValue' call
  var this_0 = $this.v3t_1;
  _hashCode$factory();
  return this_0.l2();
}
function SerialDescriptorImpl$_hashCode$delegate$lambda(this$0) {
  return function () {
    return hashCodeImpl(this$0, this$0.u3t_1);
  };
}
function SerialDescriptorImpl$toString$lambda(this$0) {
  return function (it) {
    return this$0.y3s(it) + ': ' + this$0.w3s(it).e3s();
  };
}
function SerialDescriptorImpl(serialName, kind, elementsCount, typeParameters, builder) {
  this.k3t_1 = serialName;
  this.l3t_1 = kind;
  this.m3t_1 = elementsCount;
  this.n3t_1 = builder.d3r_1;
  this.o3t_1 = toHashSet(builder.e3r_1);
  var tmp = this;
  // Inline function 'kotlin.collections.toTypedArray' call
  var this_0 = builder.e3r_1;
  tmp.p3t_1 = copyToArray(this_0);
  this.q3t_1 = compactArray(builder.g3r_1);
  var tmp_0 = this;
  // Inline function 'kotlin.collections.toTypedArray' call
  var this_1 = builder.h3r_1;
  tmp_0.r3t_1 = copyToArray(this_1);
  this.s3t_1 = toBooleanArray(builder.i3r_1);
  var tmp_1 = this;
  // Inline function 'kotlin.collections.map' call
  var this_2 = withIndex(this.p3t_1);
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_2, 10));
  var tmp0_iterator = this_2.u();
  while (tmp0_iterator.v()) {
    var item = tmp0_iterator.w();
    // Inline function 'kotlinx.serialization.descriptors.SerialDescriptorImpl.name2Index.<anonymous>' call
    var tmp$ret$2 = to(item.me_1, item.le_1);
    destination.r(tmp$ret$2);
  }
  tmp_1.t3t_1 = toMap(destination);
  this.u3t_1 = compactArray(typeParameters);
  var tmp_2 = this;
  tmp_2.v3t_1 = lazy_0(SerialDescriptorImpl$_hashCode$delegate$lambda(this));
}
protoOf(SerialDescriptorImpl).e3s = function () {
  return this.k3t_1;
};
protoOf(SerialDescriptorImpl).u3s = function () {
  return this.l3t_1;
};
protoOf(SerialDescriptorImpl).s3s = function () {
  return this.m3t_1;
};
protoOf(SerialDescriptorImpl).a3r = function () {
  return this.n3t_1;
};
protoOf(SerialDescriptorImpl).w3t = function () {
  return this.o3t_1;
};
protoOf(SerialDescriptorImpl).y3s = function (index) {
  return getChecked(this.p3t_1, index);
};
protoOf(SerialDescriptorImpl).x3s = function (name) {
  var tmp0_elvis_lhs = this.t3t_1.s2(name);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    tmp = -3;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
protoOf(SerialDescriptorImpl).v3s = function (index) {
  return getChecked(this.r3t_1, index);
};
protoOf(SerialDescriptorImpl).w3s = function (index) {
  return getChecked(this.q3t_1, index);
};
protoOf(SerialDescriptorImpl).z3s = function (index) {
  return getChecked_0(this.s3t_1, index);
};
protoOf(SerialDescriptorImpl).equals = function (other) {
  var tmp$ret$0;
  $l$block_5: {
    // Inline function 'kotlinx.serialization.internal.equalsImpl' call
    if (this === other) {
      tmp$ret$0 = true;
      break $l$block_5;
    }
    if (!(other instanceof SerialDescriptorImpl)) {
      tmp$ret$0 = false;
      break $l$block_5;
    }
    if (!(this.e3s() === other.e3s())) {
      tmp$ret$0 = false;
      break $l$block_5;
    }
    // Inline function 'kotlinx.serialization.descriptors.SerialDescriptorImpl.equals.<anonymous>' call
    if (!contentEquals(this.u3t_1, other.u3t_1)) {
      tmp$ret$0 = false;
      break $l$block_5;
    }
    if (!(this.s3s() === other.s3s())) {
      tmp$ret$0 = false;
      break $l$block_5;
    }
    var inductionVariable = 0;
    var last = this.s3s();
    if (inductionVariable < last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!(this.w3s(index).e3s() === other.w3s(index).e3s())) {
          tmp$ret$0 = false;
          break $l$block_5;
        }
        if (!equals(this.w3s(index).u3s(), other.w3s(index).u3s())) {
          tmp$ret$0 = false;
          break $l$block_5;
        }
      }
       while (inductionVariable < last);
    tmp$ret$0 = true;
  }
  return tmp$ret$0;
};
protoOf(SerialDescriptorImpl).hashCode = function () {
  return _get__hashCode__tgwhef(this);
};
protoOf(SerialDescriptorImpl).toString = function () {
  var tmp = until(0, this.m3t_1);
  var tmp_0 = this.k3t_1 + '(';
  return joinToString(tmp, ', ', tmp_0, ')', VOID, VOID, SerialDescriptorImpl$toString$lambda(this));
};
function PrimitiveSerialDescriptor(serialName, kind) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.text.isNotBlank' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!isBlank(serialName)) {
    // Inline function 'kotlinx.serialization.descriptors.PrimitiveSerialDescriptor.<anonymous>' call
    var message = 'Blank serial names are prohibited';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return PrimitiveDescriptorSafe(serialName, kind);
}
function buildSerialDescriptor$lambda($this$null) {
  return Unit_instance;
}
function buildClassSerialDescriptor$lambda($this$null) {
  return Unit_instance;
}
function _hashCode$factory() {
  return getPropertyCallableRef('_hashCode', 1, KProperty1, function (receiver) {
    return _get__hashCode__tgwhef(receiver);
  }, null);
}
function ENUM() {
  ENUM_instance = this;
  SerialKind.call(this);
}
var ENUM_instance;
function ENUM_getInstance() {
  if (ENUM_instance == null)
    new ENUM();
  return ENUM_instance;
}
function CONTEXTUAL() {
  CONTEXTUAL_instance = this;
  SerialKind.call(this);
}
var CONTEXTUAL_instance;
function CONTEXTUAL_getInstance() {
  if (CONTEXTUAL_instance == null)
    new CONTEXTUAL();
  return CONTEXTUAL_instance;
}
function SerialKind() {
}
protoOf(SerialKind).toString = function () {
  return ensureNotNull(getKClassFromExpression(this).s6());
};
protoOf(SerialKind).hashCode = function () {
  return getStringHashCode(this.toString());
};
function BOOLEAN() {
  BOOLEAN_instance = this;
  PrimitiveKind.call(this);
}
var BOOLEAN_instance;
function BOOLEAN_getInstance() {
  if (BOOLEAN_instance == null)
    new BOOLEAN();
  return BOOLEAN_instance;
}
function BYTE() {
  BYTE_instance = this;
  PrimitiveKind.call(this);
}
var BYTE_instance;
function BYTE_getInstance() {
  if (BYTE_instance == null)
    new BYTE();
  return BYTE_instance;
}
function CHAR() {
  CHAR_instance = this;
  PrimitiveKind.call(this);
}
var CHAR_instance;
function CHAR_getInstance() {
  if (CHAR_instance == null)
    new CHAR();
  return CHAR_instance;
}
function SHORT() {
  SHORT_instance = this;
  PrimitiveKind.call(this);
}
var SHORT_instance;
function SHORT_getInstance() {
  if (SHORT_instance == null)
    new SHORT();
  return SHORT_instance;
}
function INT() {
  INT_instance = this;
  PrimitiveKind.call(this);
}
var INT_instance;
function INT_getInstance() {
  if (INT_instance == null)
    new INT();
  return INT_instance;
}
function LONG() {
  LONG_instance = this;
  PrimitiveKind.call(this);
}
var LONG_instance;
function LONG_getInstance() {
  if (LONG_instance == null)
    new LONG();
  return LONG_instance;
}
function FLOAT() {
  FLOAT_instance = this;
  PrimitiveKind.call(this);
}
var FLOAT_instance;
function FLOAT_getInstance() {
  if (FLOAT_instance == null)
    new FLOAT();
  return FLOAT_instance;
}
function DOUBLE() {
  DOUBLE_instance = this;
  PrimitiveKind.call(this);
}
var DOUBLE_instance;
function DOUBLE_getInstance() {
  if (DOUBLE_instance == null)
    new DOUBLE();
  return DOUBLE_instance;
}
function STRING() {
  STRING_instance = this;
  PrimitiveKind.call(this);
}
var STRING_instance;
function STRING_getInstance() {
  if (STRING_instance == null)
    new STRING();
  return STRING_instance;
}
function PrimitiveKind() {
  SerialKind.call(this);
}
function CLASS() {
  CLASS_instance = this;
  StructureKind.call(this);
}
var CLASS_instance;
function CLASS_getInstance() {
  if (CLASS_instance == null)
    new CLASS();
  return CLASS_instance;
}
function LIST() {
  LIST_instance = this;
  StructureKind.call(this);
}
var LIST_instance;
function LIST_getInstance() {
  if (LIST_instance == null)
    new LIST();
  return LIST_instance;
}
function MAP() {
  MAP_instance = this;
  StructureKind.call(this);
}
var MAP_instance;
function MAP_getInstance() {
  if (MAP_instance == null)
    new MAP();
  return MAP_instance;
}
function OBJECT() {
  OBJECT_instance = this;
  StructureKind.call(this);
}
var OBJECT_instance;
function OBJECT_getInstance() {
  if (OBJECT_instance == null)
    new OBJECT();
  return OBJECT_instance;
}
function StructureKind() {
  SerialKind.call(this);
}
function SEALED() {
  SEALED_instance = this;
  PolymorphicKind.call(this);
}
var SEALED_instance;
function SEALED_getInstance() {
  if (SEALED_instance == null)
    new SEALED();
  return SEALED_instance;
}
function OPEN() {
  OPEN_instance = this;
  PolymorphicKind.call(this);
}
var OPEN_instance;
function OPEN_getInstance() {
  if (OPEN_instance == null)
    new OPEN();
  return OPEN_instance;
}
function PolymorphicKind() {
  SerialKind.call(this);
}
function AbstractDecoder() {
}
protoOf(AbstractDecoder).x3t = function () {
  throw SerializationException_init_$Create$_0('' + getKClassFromExpression(this) + " can't retrieve untyped values");
};
protoOf(AbstractDecoder).y3t = function () {
  return true;
};
protoOf(AbstractDecoder).z3t = function () {
  return null;
};
protoOf(AbstractDecoder).a3u = function () {
  var tmp = this.x3t();
  return typeof tmp === 'boolean' ? tmp : THROW_CCE();
};
protoOf(AbstractDecoder).b3u = function () {
  var tmp = this.x3t();
  return typeof tmp === 'number' ? tmp : THROW_CCE();
};
protoOf(AbstractDecoder).c3u = function () {
  var tmp = this.x3t();
  return typeof tmp === 'number' ? tmp : THROW_CCE();
};
protoOf(AbstractDecoder).d3u = function () {
  var tmp = this.x3t();
  return typeof tmp === 'number' ? tmp : THROW_CCE();
};
protoOf(AbstractDecoder).e3u = function () {
  var tmp = this.x3t();
  return tmp instanceof Long ? tmp : THROW_CCE();
};
protoOf(AbstractDecoder).f3u = function () {
  var tmp = this.x3t();
  return typeof tmp === 'number' ? tmp : THROW_CCE();
};
protoOf(AbstractDecoder).g3u = function () {
  var tmp = this.x3t();
  return typeof tmp === 'number' ? tmp : THROW_CCE();
};
protoOf(AbstractDecoder).h3u = function () {
  var tmp = this.x3t();
  return tmp instanceof Char ? tmp.ta_1 : THROW_CCE();
};
protoOf(AbstractDecoder).i3u = function () {
  var tmp = this.x3t();
  return typeof tmp === 'string' ? tmp : THROW_CCE();
};
protoOf(AbstractDecoder).j3u = function (enumDescriptor) {
  var tmp = this.x3t();
  return typeof tmp === 'number' ? tmp : THROW_CCE();
};
protoOf(AbstractDecoder).k3u = function (descriptor) {
  return this;
};
protoOf(AbstractDecoder).l3u = function (deserializer, previousValue) {
  return this.o3r(deserializer);
};
protoOf(AbstractDecoder).m3u = function (descriptor) {
  return this;
};
protoOf(AbstractDecoder).n3u = function (descriptor) {
};
protoOf(AbstractDecoder).o3u = function (descriptor, index) {
  return this.a3u();
};
protoOf(AbstractDecoder).p3u = function (descriptor, index) {
  return this.b3u();
};
protoOf(AbstractDecoder).q3u = function (descriptor, index) {
  return this.c3u();
};
protoOf(AbstractDecoder).r3u = function (descriptor, index) {
  return this.d3u();
};
protoOf(AbstractDecoder).s3u = function (descriptor, index) {
  return this.e3u();
};
protoOf(AbstractDecoder).t3u = function (descriptor, index) {
  return this.f3u();
};
protoOf(AbstractDecoder).u3u = function (descriptor, index) {
  return this.g3u();
};
protoOf(AbstractDecoder).v3u = function (descriptor, index) {
  return this.h3u();
};
protoOf(AbstractDecoder).w3u = function (descriptor, index) {
  return this.i3u();
};
protoOf(AbstractDecoder).x3u = function (descriptor, index) {
  return this.k3u(descriptor.w3s(index));
};
protoOf(AbstractDecoder).y3u = function (descriptor, index, deserializer, previousValue) {
  return this.l3u(deserializer, previousValue);
};
protoOf(AbstractDecoder).a3v = function (descriptor, index, deserializer, previousValue) {
  // Inline function 'kotlinx.serialization.encoding.decodeIfNullable' call
  var isNullabilitySupported = deserializer.z3q().o3s();
  var tmp;
  if (isNullabilitySupported ? true : this.y3t()) {
    // Inline function 'kotlinx.serialization.encoding.AbstractDecoder.decodeNullableSerializableElement.<anonymous>' call
    tmp = this.l3u(deserializer, previousValue);
  } else {
    tmp = this.z3t();
  }
  return tmp;
};
function AbstractEncoder() {
}
protoOf(AbstractEncoder).m3u = function (descriptor) {
  return this;
};
protoOf(AbstractEncoder).n3u = function (descriptor) {
};
protoOf(AbstractEncoder).e3v = function (descriptor, index) {
  return true;
};
protoOf(AbstractEncoder).f3v = function (value) {
  throw SerializationException_init_$Create$_0('Non-serializable ' + getKClassFromExpression(value) + ' is not supported by ' + getKClassFromExpression(this) + ' encoder');
};
protoOf(AbstractEncoder).g3v = function () {
  throw SerializationException_init_$Create$_0("'null' is not supported by default");
};
protoOf(AbstractEncoder).h3v = function (value) {
  return this.f3v(value);
};
protoOf(AbstractEncoder).i3v = function (value) {
  return this.f3v(value);
};
protoOf(AbstractEncoder).j3v = function (value) {
  return this.f3v(value);
};
protoOf(AbstractEncoder).k3v = function (value) {
  return this.f3v(value);
};
protoOf(AbstractEncoder).l3v = function (value) {
  return this.f3v(value);
};
protoOf(AbstractEncoder).m3v = function (value) {
  return this.f3v(value);
};
protoOf(AbstractEncoder).n3v = function (value) {
  return this.f3v(value);
};
protoOf(AbstractEncoder).o3v = function (value) {
  return this.f3v(new Char(value));
};
protoOf(AbstractEncoder).p3v = function (value) {
  return this.f3v(value);
};
protoOf(AbstractEncoder).q3v = function (enumDescriptor, index) {
  return this.f3v(index);
};
protoOf(AbstractEncoder).r3v = function (descriptor) {
  return this;
};
protoOf(AbstractEncoder).s3v = function (descriptor, index, value) {
  if (this.e3v(descriptor, index)) {
    this.h3v(value);
  }
};
protoOf(AbstractEncoder).t3v = function (descriptor, index, value) {
  if (this.e3v(descriptor, index)) {
    this.i3v(value);
  }
};
protoOf(AbstractEncoder).u3v = function (descriptor, index, value) {
  if (this.e3v(descriptor, index)) {
    this.j3v(value);
  }
};
protoOf(AbstractEncoder).v3v = function (descriptor, index, value) {
  if (this.e3v(descriptor, index)) {
    this.k3v(value);
  }
};
protoOf(AbstractEncoder).w3v = function (descriptor, index, value) {
  if (this.e3v(descriptor, index)) {
    this.l3v(value);
  }
};
protoOf(AbstractEncoder).x3v = function (descriptor, index, value) {
  if (this.e3v(descriptor, index)) {
    this.m3v(value);
  }
};
protoOf(AbstractEncoder).y3v = function (descriptor, index, value) {
  if (this.e3v(descriptor, index)) {
    this.n3v(value);
  }
};
protoOf(AbstractEncoder).z3v = function (descriptor, index, value) {
  if (this.e3v(descriptor, index)) {
    this.o3v(value);
  }
};
protoOf(AbstractEncoder).a3w = function (descriptor, index, value) {
  if (this.e3v(descriptor, index)) {
    this.p3v(value);
  }
};
protoOf(AbstractEncoder).b3w = function (descriptor, index) {
  return this.e3v(descriptor, index) ? this.r3v(descriptor.w3s(index)) : NoOpEncoder_getInstance();
};
protoOf(AbstractEncoder).c3w = function (descriptor, index, serializer, value) {
  if (this.e3v(descriptor, index)) {
    this.l3r(serializer, value);
  }
};
protoOf(AbstractEncoder).d3w = function (descriptor, index, serializer, value) {
  if (this.e3v(descriptor, index)) {
    this.e3w(serializer, value);
  }
};
function Decoder() {
}
function Companion() {
  this.i3w_1 = -1;
  this.j3w_1 = -3;
}
var Companion_instance_0;
function Companion_getInstance_6() {
  return Companion_instance_0;
}
function CompositeDecoder() {
}
function Encoder() {
}
function CompositeEncoder() {
}
function decodeSequentially_0($this, compositeDecoder) {
  var klassName = compositeDecoder.w3u($this.z3q(), 0);
  var serializer = findPolymorphicSerializer_0($this, compositeDecoder, klassName);
  return compositeDecoder.z3u($this.z3q(), 1, serializer);
}
function AbstractPolymorphicSerializer() {
}
protoOf(AbstractPolymorphicSerializer).j3r = function (encoder, value) {
  var actualSerializer = findPolymorphicSerializer(this, encoder, value);
  // Inline function 'kotlinx.serialization.encoding.encodeStructure' call
  var descriptor = this.z3q();
  var composite = encoder.m3u(descriptor);
  // Inline function 'kotlinx.serialization.internal.AbstractPolymorphicSerializer.serialize.<anonymous>' call
  composite.a3w(this.z3q(), 0, actualSerializer.z3q().e3s());
  var tmp = this.z3q();
  // Inline function 'kotlinx.serialization.internal.cast' call
  var tmp$ret$0 = isInterface(actualSerializer, SerializationStrategy) ? actualSerializer : THROW_CCE();
  composite.c3w(tmp, 1, tmp$ret$0, value);
  composite.n3u(descriptor);
};
protoOf(AbstractPolymorphicSerializer).m3r = function (encoder, value) {
  return this.j3r(encoder, !(value == null) ? value : THROW_CCE());
};
protoOf(AbstractPolymorphicSerializer).n3r = function (decoder) {
  // Inline function 'kotlinx.serialization.encoding.decodeStructure' call
  var descriptor = this.z3q();
  var composite = decoder.m3u(descriptor);
  var tmp$ret$0;
  $l$block: {
    // Inline function 'kotlinx.serialization.internal.AbstractPolymorphicSerializer.deserialize.<anonymous>' call
    var klassName = null;
    var value = null;
    if (composite.b3v()) {
      tmp$ret$0 = decodeSequentially_0(this, composite);
      break $l$block;
    }
    mainLoop: while (true) {
      var index = composite.c3v(this.z3q());
      if (index === -1) {
        break mainLoop;
      } else {
        if (index === 0) {
          klassName = composite.w3u(this.z3q(), index);
        } else {
          if (index === 1) {
            var tmp$ret$2;
            $l$block_0: {
              // Inline function 'kotlin.requireNotNull' call
              var value_0 = klassName;
              // Inline function 'kotlin.contracts.contract' call
              if (value_0 == null) {
                // Inline function 'kotlinx.serialization.internal.AbstractPolymorphicSerializer.deserialize.<anonymous>.<anonymous>' call
                var message = 'Cannot read polymorphic value before its type token';
                throw IllegalArgumentException_init_$Create$(toString(message));
              } else {
                tmp$ret$2 = value_0;
                break $l$block_0;
              }
            }
            klassName = tmp$ret$2;
            var serializer = findPolymorphicSerializer_0(this, composite, klassName);
            value = composite.z3u(this.z3q(), index, serializer);
          } else {
            var tmp0_elvis_lhs = klassName;
            throw SerializationException_init_$Create$_0('Invalid index in polymorphic deserialization of ' + (tmp0_elvis_lhs == null ? 'unknown class' : tmp0_elvis_lhs) + ('\n Expected 0, 1 or DECODE_DONE(-1), but found ' + index));
          }
        }
      }
    }
    var tmp$ret$4;
    $l$block_1: {
      // Inline function 'kotlin.requireNotNull' call
      var value_1 = value;
      // Inline function 'kotlin.contracts.contract' call
      if (value_1 == null) {
        // Inline function 'kotlinx.serialization.internal.AbstractPolymorphicSerializer.deserialize.<anonymous>.<anonymous>' call
        var message_0 = 'Polymorphic value has not been read for class ' + klassName;
        throw IllegalArgumentException_init_$Create$(toString(message_0));
      } else {
        tmp$ret$4 = value_1;
        break $l$block_1;
      }
    }
    var tmp = tmp$ret$4;
    tmp$ret$0 = !(tmp == null) ? tmp : THROW_CCE();
  }
  var result = tmp$ret$0;
  composite.n3u(descriptor);
  return result;
};
protoOf(AbstractPolymorphicSerializer).u3r = function (decoder, klassName) {
  return decoder.k3r().k3w(this.t3r(), klassName);
};
protoOf(AbstractPolymorphicSerializer).v3r = function (encoder, value) {
  return encoder.k3r().l3w(this.t3r(), value);
};
function throwSubtypeNotRegistered(subClass, baseClass) {
  var tmp0_elvis_lhs = subClass.s6();
  throwSubtypeNotRegistered_0(tmp0_elvis_lhs == null ? '' + subClass : tmp0_elvis_lhs, baseClass);
}
function throwSubtypeNotRegistered_0(subClassName, baseClass) {
  var scope = "in the polymorphic scope of '" + baseClass.s6() + "'";
  throw SerializationException_init_$Create$_0(subClassName == null ? 'Class discriminator was missing and no default serializers were registered ' + scope + '.' : "Serializer for subclass '" + subClassName + "' is not found " + scope + '.\n' + ("Check if class with serial name '" + subClassName + "' exists and serializer is registered in a corresponding SerializersModule.\n") + ("To be registered automatically, class '" + subClassName + "' has to be '@Serializable', and the base class '" + baseClass.s6() + "' has to be sealed and '@Serializable'."));
}
function NothingSerializer_0() {
  NothingSerializer_instance = this;
  this.m3w_1 = NothingSerialDescriptor_getInstance();
}
protoOf(NothingSerializer_0).z3q = function () {
  return this.m3w_1;
};
protoOf(NothingSerializer_0).n3w = function (encoder, value) {
  throw SerializationException_init_$Create$_0("'kotlin.Nothing' cannot be serialized");
};
protoOf(NothingSerializer_0).m3r = function (encoder, value) {
  var tmp;
  if (false) {
    tmp = value;
  } else {
    tmp = THROW_CCE();
  }
  return this.n3w(encoder, tmp);
};
protoOf(NothingSerializer_0).n3r = function (decoder) {
  throw SerializationException_init_$Create$_0("'kotlin.Nothing' does not have instances");
};
var NothingSerializer_instance;
function NothingSerializer_getInstance() {
  if (NothingSerializer_instance == null)
    new NothingSerializer_0();
  return NothingSerializer_instance;
}
function DurationSerializer() {
  DurationSerializer_instance = this;
  this.o3w_1 = new PrimitiveSerialDescriptor_0('kotlin.time.Duration', STRING_getInstance());
}
protoOf(DurationSerializer).z3q = function () {
  return this.o3w_1;
};
protoOf(DurationSerializer).p3w = function (encoder, value) {
  encoder.p3v(Duration__toIsoString_impl_9h6wsm(value));
};
protoOf(DurationSerializer).m3r = function (encoder, value) {
  return this.p3w(encoder, value instanceof Duration ? value.tj_1 : THROW_CCE());
};
protoOf(DurationSerializer).q3w = function (decoder) {
  return Companion_getInstance().sj(decoder.i3u());
};
protoOf(DurationSerializer).n3r = function (decoder) {
  return new Duration(this.q3w(decoder));
};
var DurationSerializer_instance;
function DurationSerializer_getInstance() {
  if (DurationSerializer_instance == null)
    new DurationSerializer();
  return DurationSerializer_instance;
}
function CachedNames() {
}
function ArrayListClassDesc(elementDesc) {
  ListLikeDescriptor.call(this, elementDesc);
}
protoOf(ArrayListClassDesc).e3s = function () {
  return 'kotlin.collections.ArrayList';
};
function HashSetClassDesc(elementDesc) {
  ListLikeDescriptor.call(this, elementDesc);
}
protoOf(HashSetClassDesc).e3s = function () {
  return 'kotlin.collections.HashSet';
};
function LinkedHashSetClassDesc(elementDesc) {
  ListLikeDescriptor.call(this, elementDesc);
}
protoOf(LinkedHashSetClassDesc).e3s = function () {
  return 'kotlin.collections.LinkedHashSet';
};
function HashMapClassDesc(keyDesc, valueDesc) {
  MapLikeDescriptor.call(this, 'kotlin.collections.HashMap', keyDesc, valueDesc);
}
function LinkedHashMapClassDesc(keyDesc, valueDesc) {
  MapLikeDescriptor.call(this, 'kotlin.collections.LinkedHashMap', keyDesc, valueDesc);
}
function ArrayClassDesc(elementDesc) {
  ListLikeDescriptor.call(this, elementDesc);
}
protoOf(ArrayClassDesc).e3s = function () {
  return 'kotlin.Array';
};
function ListLikeDescriptor(elementDescriptor) {
  this.t3w_1 = elementDescriptor;
  this.u3w_1 = 1;
}
protoOf(ListLikeDescriptor).u3s = function () {
  return LIST_getInstance();
};
protoOf(ListLikeDescriptor).s3s = function () {
  return this.u3w_1;
};
protoOf(ListLikeDescriptor).y3s = function (index) {
  return index.toString();
};
protoOf(ListLikeDescriptor).x3s = function (name) {
  var tmp0_elvis_lhs = toIntOrNull(name);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalArgumentException_init_$Create$(name + ' is not a valid list index');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
protoOf(ListLikeDescriptor).z3s = function (index) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(index >= 0)) {
    // Inline function 'kotlinx.serialization.internal.ListLikeDescriptor.isElementOptional.<anonymous>' call
    var message = 'Illegal index ' + index + ', ' + this.e3s() + ' expects only non-negative indices';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return false;
};
protoOf(ListLikeDescriptor).v3s = function (index) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(index >= 0)) {
    // Inline function 'kotlinx.serialization.internal.ListLikeDescriptor.getElementAnnotations.<anonymous>' call
    var message = 'Illegal index ' + index + ', ' + this.e3s() + ' expects only non-negative indices';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return emptyList();
};
protoOf(ListLikeDescriptor).w3s = function (index) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(index >= 0)) {
    // Inline function 'kotlinx.serialization.internal.ListLikeDescriptor.getElementDescriptor.<anonymous>' call
    var message = 'Illegal index ' + index + ', ' + this.e3s() + ' expects only non-negative indices';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return this.t3w_1;
};
protoOf(ListLikeDescriptor).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof ListLikeDescriptor))
    return false;
  if (equals(this.t3w_1, other.t3w_1) ? this.e3s() === other.e3s() : false)
    return true;
  return false;
};
protoOf(ListLikeDescriptor).hashCode = function () {
  return imul(hashCode(this.t3w_1), 31) + getStringHashCode(this.e3s()) | 0;
};
protoOf(ListLikeDescriptor).toString = function () {
  return this.e3s() + '(' + this.t3w_1 + ')';
};
function MapLikeDescriptor(serialName, keyDescriptor, valueDescriptor) {
  this.z3w_1 = serialName;
  this.a3x_1 = keyDescriptor;
  this.b3x_1 = valueDescriptor;
  this.c3x_1 = 2;
}
protoOf(MapLikeDescriptor).e3s = function () {
  return this.z3w_1;
};
protoOf(MapLikeDescriptor).u3s = function () {
  return MAP_getInstance();
};
protoOf(MapLikeDescriptor).s3s = function () {
  return this.c3x_1;
};
protoOf(MapLikeDescriptor).y3s = function (index) {
  return index.toString();
};
protoOf(MapLikeDescriptor).x3s = function (name) {
  var tmp0_elvis_lhs = toIntOrNull(name);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalArgumentException_init_$Create$(name + ' is not a valid map index');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
protoOf(MapLikeDescriptor).z3s = function (index) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(index >= 0)) {
    // Inline function 'kotlinx.serialization.internal.MapLikeDescriptor.isElementOptional.<anonymous>' call
    var message = 'Illegal index ' + index + ', ' + this.e3s() + ' expects only non-negative indices';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return false;
};
protoOf(MapLikeDescriptor).v3s = function (index) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(index >= 0)) {
    // Inline function 'kotlinx.serialization.internal.MapLikeDescriptor.getElementAnnotations.<anonymous>' call
    var message = 'Illegal index ' + index + ', ' + this.e3s() + ' expects only non-negative indices';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return emptyList();
};
protoOf(MapLikeDescriptor).w3s = function (index) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(index >= 0)) {
    // Inline function 'kotlinx.serialization.internal.MapLikeDescriptor.getElementDescriptor.<anonymous>' call
    var message = 'Illegal index ' + index + ', ' + this.e3s() + ' expects only non-negative indices';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var tmp;
  switch (index % 2 | 0) {
    case 0:
      tmp = this.a3x_1;
      break;
    case 1:
      tmp = this.b3x_1;
      break;
    default:
      var message_0 = 'Unreached';
      throw IllegalStateException_init_$Create$(toString(message_0));
  }
  return tmp;
};
protoOf(MapLikeDescriptor).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof MapLikeDescriptor))
    return false;
  if (!(this.e3s() === other.e3s()))
    return false;
  if (!equals(this.a3x_1, other.a3x_1))
    return false;
  if (!equals(this.b3x_1, other.b3x_1))
    return false;
  return true;
};
protoOf(MapLikeDescriptor).hashCode = function () {
  var result = getStringHashCode(this.e3s());
  result = imul(31, result) + hashCode(this.a3x_1) | 0;
  result = imul(31, result) + hashCode(this.b3x_1) | 0;
  return result;
};
protoOf(MapLikeDescriptor).toString = function () {
  return this.e3s() + '(' + this.a3x_1 + ', ' + this.b3x_1 + ')';
};
function PrimitiveArrayDescriptor(primitive) {
  ListLikeDescriptor.call(this, primitive);
  this.h3x_1 = primitive.e3s() + 'Array';
}
protoOf(PrimitiveArrayDescriptor).e3s = function () {
  return this.h3x_1;
};
function ArrayListSerializer(element) {
  CollectionSerializer.call(this, element);
  this.j3x_1 = new ArrayListClassDesc(element.z3q());
}
protoOf(ArrayListSerializer).z3q = function () {
  return this.j3x_1;
};
protoOf(ArrayListSerializer).k3x = function () {
  // Inline function 'kotlin.collections.arrayListOf' call
  return ArrayList_init_$Create$_0();
};
protoOf(ArrayListSerializer).l3x = function (_this__u8e3s4) {
  return _this__u8e3s4.n();
};
protoOf(ArrayListSerializer).m3x = function (_this__u8e3s4) {
  return this.l3x(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE());
};
protoOf(ArrayListSerializer).n3x = function (_this__u8e3s4) {
  return _this__u8e3s4;
};
protoOf(ArrayListSerializer).o3x = function (_this__u8e3s4) {
  return this.n3x(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE());
};
protoOf(ArrayListSerializer).p3x = function (_this__u8e3s4) {
  var tmp0_elvis_lhs = _this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : null;
  return tmp0_elvis_lhs == null ? ArrayList_init_$Create$_1(_this__u8e3s4) : tmp0_elvis_lhs;
};
protoOf(ArrayListSerializer).q3x = function (_this__u8e3s4) {
  return this.p3x((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, List) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(ArrayListSerializer).r3x = function (_this__u8e3s4, size) {
  return _this__u8e3s4.z2(size);
};
protoOf(ArrayListSerializer).s3x = function (_this__u8e3s4, size) {
  return this.r3x(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE(), size);
};
protoOf(ArrayListSerializer).t3x = function (_this__u8e3s4, index, element) {
  _this__u8e3s4.r1(index, element);
};
protoOf(ArrayListSerializer).u3x = function (_this__u8e3s4, index, element) {
  var tmp = _this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE();
  return this.t3x(tmp, index, (element == null ? true : !(element == null)) ? element : THROW_CCE());
};
function HashSetSerializer(eSerializer) {
  CollectionSerializer.call(this, eSerializer);
  this.f3y_1 = new HashSetClassDesc(eSerializer.z3q());
}
protoOf(HashSetSerializer).z3q = function () {
  return this.f3y_1;
};
protoOf(HashSetSerializer).k3x = function () {
  return HashSet_init_$Create$();
};
protoOf(HashSetSerializer).g3y = function (_this__u8e3s4) {
  return _this__u8e3s4.n();
};
protoOf(HashSetSerializer).m3x = function (_this__u8e3s4) {
  return this.g3y(_this__u8e3s4 instanceof HashSet ? _this__u8e3s4 : THROW_CCE());
};
protoOf(HashSetSerializer).h3y = function (_this__u8e3s4) {
  return _this__u8e3s4;
};
protoOf(HashSetSerializer).o3x = function (_this__u8e3s4) {
  return this.h3y(_this__u8e3s4 instanceof HashSet ? _this__u8e3s4 : THROW_CCE());
};
protoOf(HashSetSerializer).i3y = function (_this__u8e3s4) {
  var tmp0_elvis_lhs = _this__u8e3s4 instanceof HashSet ? _this__u8e3s4 : null;
  return tmp0_elvis_lhs == null ? HashSet_init_$Create$_0(_this__u8e3s4) : tmp0_elvis_lhs;
};
protoOf(HashSetSerializer).q3x = function (_this__u8e3s4) {
  return this.i3y((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Set) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(HashSetSerializer).j3y = function (_this__u8e3s4, size) {
};
protoOf(HashSetSerializer).s3x = function (_this__u8e3s4, size) {
  return this.j3y(_this__u8e3s4 instanceof HashSet ? _this__u8e3s4 : THROW_CCE(), size);
};
protoOf(HashSetSerializer).k3y = function (_this__u8e3s4, index, element) {
  _this__u8e3s4.r(element);
};
protoOf(HashSetSerializer).u3x = function (_this__u8e3s4, index, element) {
  var tmp = _this__u8e3s4 instanceof HashSet ? _this__u8e3s4 : THROW_CCE();
  return this.k3y(tmp, index, (element == null ? true : !(element == null)) ? element : THROW_CCE());
};
function LinkedHashSetSerializer(eSerializer) {
  CollectionSerializer.call(this, eSerializer);
  this.m3y_1 = new LinkedHashSetClassDesc(eSerializer.z3q());
}
protoOf(LinkedHashSetSerializer).z3q = function () {
  return this.m3y_1;
};
protoOf(LinkedHashSetSerializer).k3x = function () {
  // Inline function 'kotlin.collections.linkedSetOf' call
  return LinkedHashSet_init_$Create$();
};
protoOf(LinkedHashSetSerializer).n3y = function (_this__u8e3s4) {
  return _this__u8e3s4.n();
};
protoOf(LinkedHashSetSerializer).m3x = function (_this__u8e3s4) {
  return this.n3y(_this__u8e3s4 instanceof LinkedHashSet ? _this__u8e3s4 : THROW_CCE());
};
protoOf(LinkedHashSetSerializer).o3y = function (_this__u8e3s4) {
  return _this__u8e3s4;
};
protoOf(LinkedHashSetSerializer).o3x = function (_this__u8e3s4) {
  return this.o3y(_this__u8e3s4 instanceof LinkedHashSet ? _this__u8e3s4 : THROW_CCE());
};
protoOf(LinkedHashSetSerializer).i3y = function (_this__u8e3s4) {
  var tmp0_elvis_lhs = _this__u8e3s4 instanceof LinkedHashSet ? _this__u8e3s4 : null;
  return tmp0_elvis_lhs == null ? LinkedHashSet_init_$Create$_0(_this__u8e3s4) : tmp0_elvis_lhs;
};
protoOf(LinkedHashSetSerializer).q3x = function (_this__u8e3s4) {
  return this.i3y((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Set) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(LinkedHashSetSerializer).p3y = function (_this__u8e3s4, size) {
};
protoOf(LinkedHashSetSerializer).s3x = function (_this__u8e3s4, size) {
  return this.p3y(_this__u8e3s4 instanceof LinkedHashSet ? _this__u8e3s4 : THROW_CCE(), size);
};
protoOf(LinkedHashSetSerializer).q3y = function (_this__u8e3s4, index, element) {
  _this__u8e3s4.r(element);
};
protoOf(LinkedHashSetSerializer).u3x = function (_this__u8e3s4, index, element) {
  var tmp = _this__u8e3s4 instanceof LinkedHashSet ? _this__u8e3s4 : THROW_CCE();
  return this.q3y(tmp, index, (element == null ? true : !(element == null)) ? element : THROW_CCE());
};
function HashMapSerializer(kSerializer, vSerializer) {
  MapLikeSerializer.call(this, kSerializer, vSerializer);
  this.t3y_1 = new HashMapClassDesc(kSerializer.z3q(), vSerializer.z3q());
}
protoOf(HashMapSerializer).z3q = function () {
  return this.t3y_1;
};
protoOf(HashMapSerializer).u3y = function (_this__u8e3s4) {
  return _this__u8e3s4.n();
};
protoOf(HashMapSerializer).v3y = function (_this__u8e3s4) {
  return this.u3y((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Map) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(HashMapSerializer).w3y = function (_this__u8e3s4) {
  // Inline function 'kotlin.collections.iterator' call
  return _this__u8e3s4.h2().u();
};
protoOf(HashMapSerializer).x3y = function (_this__u8e3s4) {
  return this.w3y((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Map) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(HashMapSerializer).k3x = function () {
  return HashMap_init_$Create$();
};
protoOf(HashMapSerializer).y3y = function (_this__u8e3s4) {
  return imul(_this__u8e3s4.n(), 2);
};
protoOf(HashMapSerializer).m3x = function (_this__u8e3s4) {
  return this.y3y(_this__u8e3s4 instanceof HashMap ? _this__u8e3s4 : THROW_CCE());
};
protoOf(HashMapSerializer).z3y = function (_this__u8e3s4) {
  return _this__u8e3s4;
};
protoOf(HashMapSerializer).o3x = function (_this__u8e3s4) {
  return this.z3y(_this__u8e3s4 instanceof HashMap ? _this__u8e3s4 : THROW_CCE());
};
protoOf(HashMapSerializer).a3z = function (_this__u8e3s4) {
  var tmp0_elvis_lhs = _this__u8e3s4 instanceof HashMap ? _this__u8e3s4 : null;
  return tmp0_elvis_lhs == null ? HashMap_init_$Create$_0(_this__u8e3s4) : tmp0_elvis_lhs;
};
protoOf(HashMapSerializer).q3x = function (_this__u8e3s4) {
  return this.a3z((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Map) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(HashMapSerializer).b3z = function (_this__u8e3s4, size) {
};
protoOf(HashMapSerializer).s3x = function (_this__u8e3s4, size) {
  return this.b3z(_this__u8e3s4 instanceof HashMap ? _this__u8e3s4 : THROW_CCE(), size);
};
function LinkedHashMapSerializer(kSerializer, vSerializer) {
  MapLikeSerializer.call(this, kSerializer, vSerializer);
  this.i3z_1 = new LinkedHashMapClassDesc(kSerializer.z3q(), vSerializer.z3q());
}
protoOf(LinkedHashMapSerializer).z3q = function () {
  return this.i3z_1;
};
protoOf(LinkedHashMapSerializer).u3y = function (_this__u8e3s4) {
  return _this__u8e3s4.n();
};
protoOf(LinkedHashMapSerializer).v3y = function (_this__u8e3s4) {
  return this.u3y((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Map) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(LinkedHashMapSerializer).w3y = function (_this__u8e3s4) {
  // Inline function 'kotlin.collections.iterator' call
  return _this__u8e3s4.h2().u();
};
protoOf(LinkedHashMapSerializer).x3y = function (_this__u8e3s4) {
  return this.w3y((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Map) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(LinkedHashMapSerializer).k3x = function () {
  return LinkedHashMap_init_$Create$();
};
protoOf(LinkedHashMapSerializer).j3z = function (_this__u8e3s4) {
  return imul(_this__u8e3s4.n(), 2);
};
protoOf(LinkedHashMapSerializer).m3x = function (_this__u8e3s4) {
  return this.j3z(_this__u8e3s4 instanceof LinkedHashMap ? _this__u8e3s4 : THROW_CCE());
};
protoOf(LinkedHashMapSerializer).k3z = function (_this__u8e3s4) {
  return _this__u8e3s4;
};
protoOf(LinkedHashMapSerializer).o3x = function (_this__u8e3s4) {
  return this.k3z(_this__u8e3s4 instanceof LinkedHashMap ? _this__u8e3s4 : THROW_CCE());
};
protoOf(LinkedHashMapSerializer).a3z = function (_this__u8e3s4) {
  var tmp0_elvis_lhs = _this__u8e3s4 instanceof LinkedHashMap ? _this__u8e3s4 : null;
  return tmp0_elvis_lhs == null ? LinkedHashMap_init_$Create$_1(_this__u8e3s4) : tmp0_elvis_lhs;
};
protoOf(LinkedHashMapSerializer).q3x = function (_this__u8e3s4) {
  return this.a3z((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Map) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(LinkedHashMapSerializer).l3z = function (_this__u8e3s4, size) {
};
protoOf(LinkedHashMapSerializer).s3x = function (_this__u8e3s4, size) {
  return this.l3z(_this__u8e3s4 instanceof LinkedHashMap ? _this__u8e3s4 : THROW_CCE(), size);
};
function ReferenceArraySerializer(kClass, eSerializer) {
  CollectionLikeSerializer.call(this, eSerializer);
  this.n3z_1 = kClass;
  this.o3z_1 = new ArrayClassDesc(eSerializer.z3q());
}
protoOf(ReferenceArraySerializer).z3q = function () {
  return this.o3z_1;
};
protoOf(ReferenceArraySerializer).p3z = function (_this__u8e3s4) {
  return _this__u8e3s4.length;
};
protoOf(ReferenceArraySerializer).v3y = function (_this__u8e3s4) {
  return this.p3z((!(_this__u8e3s4 == null) ? isArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(ReferenceArraySerializer).q3z = function (_this__u8e3s4) {
  return arrayIterator(_this__u8e3s4);
};
protoOf(ReferenceArraySerializer).x3y = function (_this__u8e3s4) {
  return this.q3z((!(_this__u8e3s4 == null) ? isArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(ReferenceArraySerializer).k3x = function () {
  // Inline function 'kotlin.collections.arrayListOf' call
  return ArrayList_init_$Create$_0();
};
protoOf(ReferenceArraySerializer).r3z = function (_this__u8e3s4) {
  return _this__u8e3s4.n();
};
protoOf(ReferenceArraySerializer).m3x = function (_this__u8e3s4) {
  return this.r3z(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE());
};
protoOf(ReferenceArraySerializer).s3z = function (_this__u8e3s4) {
  return toNativeArrayImpl(_this__u8e3s4, this.n3z_1);
};
protoOf(ReferenceArraySerializer).o3x = function (_this__u8e3s4) {
  return this.s3z(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE());
};
protoOf(ReferenceArraySerializer).t3z = function (_this__u8e3s4) {
  return ArrayList_init_$Create$_1(asList(_this__u8e3s4));
};
protoOf(ReferenceArraySerializer).q3x = function (_this__u8e3s4) {
  return this.t3z((!(_this__u8e3s4 == null) ? isArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(ReferenceArraySerializer).u3z = function (_this__u8e3s4, size) {
  return _this__u8e3s4.z2(size);
};
protoOf(ReferenceArraySerializer).s3x = function (_this__u8e3s4, size) {
  return this.u3z(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE(), size);
};
protoOf(ReferenceArraySerializer).v3z = function (_this__u8e3s4, index, element) {
  _this__u8e3s4.r1(index, element);
};
protoOf(ReferenceArraySerializer).u3x = function (_this__u8e3s4, index, element) {
  var tmp = _this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE();
  return this.v3z(tmp, index, (element == null ? true : !(element == null)) ? element : THROW_CCE());
};
function CollectionSerializer(element) {
  CollectionLikeSerializer.call(this, element);
}
protoOf(CollectionSerializer).w3x = function (_this__u8e3s4) {
  return _this__u8e3s4.n();
};
protoOf(CollectionSerializer).v3y = function (_this__u8e3s4) {
  return this.w3x((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Collection) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(CollectionSerializer).x3x = function (_this__u8e3s4) {
  return _this__u8e3s4.u();
};
protoOf(CollectionSerializer).x3y = function (_this__u8e3s4) {
  return this.x3x((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Collection) : false) ? _this__u8e3s4 : THROW_CCE());
};
function MapLikeSerializer(keySerializer, valueSerializer) {
  AbstractCollectionSerializer.call(this);
  this.c3z_1 = keySerializer;
  this.d3z_1 = valueSerializer;
}
protoOf(MapLikeSerializer).e3z = function (decoder, builder, startIndex, size) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(size >= 0)) {
    // Inline function 'kotlinx.serialization.internal.MapLikeSerializer.readAll.<anonymous>' call
    var message = 'Size must be known in advance when using READ_ALL';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var progression = step(until(0, imul(size, 2)), 2);
  var inductionVariable = progression.ma_1;
  var last = progression.na_1;
  var step_0 = progression.oa_1;
  if ((step_0 > 0 ? inductionVariable <= last : false) ? true : step_0 < 0 ? last <= inductionVariable : false)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + step_0 | 0;
      this.f3z(decoder, startIndex + index | 0, builder, false);
    }
     while (!(index === last));
};
protoOf(MapLikeSerializer).a3y = function (decoder, builder, startIndex, size) {
  return this.e3z(decoder, (!(builder == null) ? isInterface(builder, MutableMap) : false) ? builder : THROW_CCE(), startIndex, size);
};
protoOf(MapLikeSerializer).f3z = function (decoder, index, builder, checkIndex) {
  var key = decoder.z3u(this.z3q(), index, this.c3z_1);
  var tmp;
  if (checkIndex) {
    // Inline function 'kotlin.also' call
    var this_0 = decoder.c3v(this.z3q());
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.serialization.internal.MapLikeSerializer.readElement.<anonymous>' call
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.contracts.contract' call
    if (!(this_0 === (index + 1 | 0))) {
      // Inline function 'kotlinx.serialization.internal.MapLikeSerializer.readElement.<anonymous>.<anonymous>' call
      var message = 'Value must follow key in a map, index for key: ' + index + ', returned index for value: ' + this_0;
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    tmp = this_0;
  } else {
    tmp = index + 1 | 0;
  }
  var vIndex = tmp;
  var tmp_0;
  var tmp_1;
  if (builder.p2(key)) {
    var tmp_2 = this.d3z_1.z3q().u3s();
    tmp_1 = !(tmp_2 instanceof PrimitiveKind);
  } else {
    tmp_1 = false;
  }
  if (tmp_1) {
    tmp_0 = decoder.y3u(this.z3q(), vIndex, this.d3z_1, getValue(builder, key));
  } else {
    tmp_0 = decoder.z3u(this.z3q(), vIndex, this.d3z_1);
  }
  var value = tmp_0;
  // Inline function 'kotlin.collections.set' call
  builder.i2(key, value);
};
protoOf(MapLikeSerializer).b3y = function (decoder, index, builder, checkIndex) {
  return this.f3z(decoder, index, (!(builder == null) ? isInterface(builder, MutableMap) : false) ? builder : THROW_CCE(), checkIndex);
};
protoOf(MapLikeSerializer).z3x = function (encoder, value) {
  var size = this.v3y(value);
  // Inline function 'kotlinx.serialization.encoding.encodeCollection' call
  var descriptor = this.z3q();
  var composite = encoder.g3w(descriptor, size);
  // Inline function 'kotlinx.serialization.internal.MapLikeSerializer.serialize.<anonymous>' call
  var iterator = this.x3y(value);
  var index = 0;
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var tmp0_iterator = iterator;
  while (tmp0_iterator.v()) {
    var element = tmp0_iterator.w();
    // Inline function 'kotlinx.serialization.internal.MapLikeSerializer.serialize.<anonymous>.<anonymous>' call
    // Inline function 'kotlin.collections.component1' call
    var k = element.k2();
    // Inline function 'kotlin.collections.component2' call
    var v = element.l2();
    var tmp = this.z3q();
    var tmp0 = index;
    index = tmp0 + 1 | 0;
    composite.c3w(tmp, tmp0, this.c3z_1, k);
    var tmp_0 = this.z3q();
    var tmp1 = index;
    index = tmp1 + 1 | 0;
    composite.c3w(tmp_0, tmp1, this.d3z_1, v);
  }
  composite.n3u(descriptor);
};
protoOf(MapLikeSerializer).m3r = function (encoder, value) {
  return this.z3x(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
};
function CollectionLikeSerializer(elementSerializer) {
  AbstractCollectionSerializer.call(this);
  this.y3x_1 = elementSerializer;
}
protoOf(CollectionLikeSerializer).z3x = function (encoder, value) {
  var size = this.v3y(value);
  // Inline function 'kotlinx.serialization.encoding.encodeCollection' call
  var descriptor = this.z3q();
  var composite = encoder.g3w(descriptor, size);
  // Inline function 'kotlinx.serialization.internal.CollectionLikeSerializer.serialize.<anonymous>' call
  var iterator = this.x3y(value);
  var inductionVariable = 0;
  if (inductionVariable < size)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      composite.c3w(this.z3q(), index, this.y3x_1, iterator.w());
    }
     while (inductionVariable < size);
  composite.n3u(descriptor);
};
protoOf(CollectionLikeSerializer).m3r = function (encoder, value) {
  return this.z3x(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
};
protoOf(CollectionLikeSerializer).a3y = function (decoder, builder, startIndex, size) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(size >= 0)) {
    // Inline function 'kotlinx.serialization.internal.CollectionLikeSerializer.readAll.<anonymous>' call
    var message = 'Size must be known in advance when using READ_ALL';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var inductionVariable = 0;
  if (inductionVariable < size)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      this.b3y(decoder, startIndex + index | 0, builder, false);
    }
     while (inductionVariable < size);
};
protoOf(CollectionLikeSerializer).b3y = function (decoder, index, builder, checkIndex) {
  this.u3x(builder, index, decoder.z3u(this.z3q(), index, this.y3x_1));
};
function readSize($this, decoder, builder) {
  var size = decoder.d3v($this.z3q());
  $this.s3x(builder, size);
  return size;
}
function AbstractCollectionSerializer() {
}
protoOf(AbstractCollectionSerializer).d3y = function (decoder, previous) {
  var tmp1_elvis_lhs = previous == null ? null : this.q3x(previous);
  var builder = tmp1_elvis_lhs == null ? this.k3x() : tmp1_elvis_lhs;
  var startIndex = this.m3x(builder);
  var compositeDecoder = decoder.m3u(this.z3q());
  if (compositeDecoder.b3v()) {
    this.a3y(compositeDecoder, builder, startIndex, readSize(this, compositeDecoder, builder));
  } else {
    $l$loop: while (true) {
      var index = compositeDecoder.c3v(this.z3q());
      if (index === -1)
        break $l$loop;
      this.c3y(compositeDecoder, startIndex + index | 0, builder);
    }
  }
  compositeDecoder.n3u(this.z3q());
  return this.o3x(builder);
};
protoOf(AbstractCollectionSerializer).n3r = function (decoder) {
  return this.d3y(decoder, null);
};
protoOf(AbstractCollectionSerializer).c3y = function (decoder, index, builder, checkIndex, $super) {
  checkIndex = checkIndex === VOID ? true : checkIndex;
  var tmp;
  if ($super === VOID) {
    this.b3y(decoder, index, builder, checkIndex);
    tmp = Unit_instance;
  } else {
    tmp = $super.b3y.call(this, decoder, index, builder, checkIndex);
  }
  return tmp;
};
function PrimitiveArraySerializer(primitiveSerializer) {
  CollectionLikeSerializer.call(this, primitiveSerializer);
  this.x3z_1 = new PrimitiveArrayDescriptor(primitiveSerializer.z3q());
}
protoOf(PrimitiveArraySerializer).z3q = function () {
  return this.x3z_1;
};
protoOf(PrimitiveArraySerializer).y3z = function (_this__u8e3s4) {
  return _this__u8e3s4.z3z();
};
protoOf(PrimitiveArraySerializer).m3x = function (_this__u8e3s4) {
  return this.y3z(_this__u8e3s4 instanceof PrimitiveArrayBuilder ? _this__u8e3s4 : THROW_CCE());
};
protoOf(PrimitiveArraySerializer).a40 = function (_this__u8e3s4) {
  return _this__u8e3s4.l1i();
};
protoOf(PrimitiveArraySerializer).o3x = function (_this__u8e3s4) {
  return this.a40(_this__u8e3s4 instanceof PrimitiveArrayBuilder ? _this__u8e3s4 : THROW_CCE());
};
protoOf(PrimitiveArraySerializer).b40 = function (_this__u8e3s4, size) {
  return _this__u8e3s4.z2(size);
};
protoOf(PrimitiveArraySerializer).s3x = function (_this__u8e3s4, size) {
  return this.b40(_this__u8e3s4 instanceof PrimitiveArrayBuilder ? _this__u8e3s4 : THROW_CCE(), size);
};
protoOf(PrimitiveArraySerializer).c40 = function (_this__u8e3s4) {
  var message = 'This method lead to boxing and must not be used, use writeContents instead';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(PrimitiveArraySerializer).x3y = function (_this__u8e3s4) {
  return this.c40((_this__u8e3s4 == null ? true : !(_this__u8e3s4 == null)) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(PrimitiveArraySerializer).d40 = function (_this__u8e3s4, index, element) {
  var message = 'This method lead to boxing and must not be used, use Builder.append instead';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(PrimitiveArraySerializer).u3x = function (_this__u8e3s4, index, element) {
  var tmp = _this__u8e3s4 instanceof PrimitiveArrayBuilder ? _this__u8e3s4 : THROW_CCE();
  return this.d40(tmp, index, (element == null ? true : !(element == null)) ? element : THROW_CCE());
};
protoOf(PrimitiveArraySerializer).k3x = function () {
  return this.q3x(this.e40());
};
protoOf(PrimitiveArraySerializer).h40 = function (encoder, value) {
  var size = this.v3y(value);
  // Inline function 'kotlinx.serialization.encoding.encodeCollection' call
  var descriptor = this.x3z_1;
  var composite = encoder.g3w(descriptor, size);
  // Inline function 'kotlinx.serialization.internal.PrimitiveArraySerializer.serialize.<anonymous>' call
  this.g40(composite, value, size);
  composite.n3u(descriptor);
};
protoOf(PrimitiveArraySerializer).m3r = function (encoder, value) {
  return this.h40(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
};
protoOf(PrimitiveArraySerializer).z3x = function (encoder, value) {
  return this.h40(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
};
protoOf(PrimitiveArraySerializer).n3r = function (decoder) {
  return this.d3y(decoder, null);
};
function PrimitiveArrayBuilder() {
}
protoOf(PrimitiveArrayBuilder).i40 = function (requiredCapacity, $super) {
  requiredCapacity = requiredCapacity === VOID ? this.z3z() + 1 | 0 : requiredCapacity;
  var tmp;
  if ($super === VOID) {
    this.z2(requiredCapacity);
    tmp = Unit_instance;
  } else {
    tmp = $super.z2.call(this, requiredCapacity);
  }
  return tmp;
};
function Companion_0() {
  Companion_instance_1 = this;
  this.j40_1 = longArray(0);
}
var Companion_instance_1;
function Companion_getInstance_7() {
  if (Companion_instance_1 == null)
    new Companion_0();
  return Companion_instance_1;
}
function prepareHighMarksArray($this, elementsCount) {
  var slotsCount = (elementsCount - 1 | 0) >>> 6 | 0;
  Companion_getInstance_0();
  var elementsInLastSlot = elementsCount & (64 - 1 | 0);
  var highMarks = longArray(slotsCount);
  if (!(elementsInLastSlot === 0)) {
    highMarks[get_lastIndex(highMarks)] = (new Long(-1, -1)).tb(elementsCount);
  }
  return highMarks;
}
function markHigh($this, index) {
  var slot = (index >>> 6 | 0) - 1 | 0;
  Companion_getInstance_0();
  var offsetInSlot = index & (64 - 1 | 0);
  $this.n40_1[slot] = $this.n40_1[slot].xb((new Long(1, 0)).tb(offsetInSlot));
}
function nextUnmarkedHighIndex($this) {
  var inductionVariable = 0;
  var last = $this.n40_1.length - 1 | 0;
  if (inductionVariable <= last)
    do {
      var slot = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var tmp = slot + 1 | 0;
      Companion_getInstance_0();
      var slotOffset = imul(tmp, 64);
      var slotMarks = $this.n40_1[slot];
      while (!slotMarks.equals(new Long(-1, -1))) {
        var indexInSlot = countTrailingZeroBits(slotMarks.rb());
        slotMarks = slotMarks.xb((new Long(1, 0)).tb(indexInSlot));
        var index = slotOffset + indexInSlot | 0;
        if ($this.l40_1($this.k40_1, index)) {
          $this.n40_1[slot] = slotMarks;
          return index;
        }
      }
      $this.n40_1[slot] = slotMarks;
    }
     while (inductionVariable <= last);
  return -1;
}
function ElementMarker(descriptor, readIfAbsent) {
  Companion_getInstance_7();
  this.k40_1 = descriptor;
  this.l40_1 = readIfAbsent;
  var elementsCount = this.k40_1.s3s();
  Companion_getInstance_0();
  if (elementsCount <= 64) {
    var tmp = this;
    var tmp_0;
    Companion_getInstance_0();
    if (elementsCount === 64) {
      tmp_0 = new Long(0, 0);
    } else {
      tmp_0 = (new Long(-1, -1)).tb(elementsCount);
    }
    tmp.m40_1 = tmp_0;
    this.n40_1 = Companion_getInstance_7().j40_1;
  } else {
    this.m40_1 = new Long(0, 0);
    this.n40_1 = prepareHighMarksArray(this, elementsCount);
  }
}
protoOf(ElementMarker).o40 = function (index) {
  Companion_getInstance_0();
  if (index < 64) {
    this.m40_1 = this.m40_1.xb((new Long(1, 0)).tb(index));
  } else {
    markHigh(this, index);
  }
};
protoOf(ElementMarker).p40 = function () {
  var elementsCount = this.k40_1.s3s();
  while (!this.m40_1.equals(new Long(-1, -1))) {
    var index = countTrailingZeroBits(this.m40_1.rb());
    this.m40_1 = this.m40_1.xb((new Long(1, 0)).tb(index));
    if (this.l40_1(this.k40_1, index)) {
      return index;
    }
  }
  Companion_getInstance_0();
  if (elementsCount > 64) {
    return nextUnmarkedHighIndex(this);
  }
  return -1;
};
function createSimpleEnumSerializer(serialName, values) {
  return new EnumSerializer(serialName, values);
}
function createUnmarkedDescriptor($this, serialName) {
  var d = new EnumDescriptor(serialName, $this.q40_1.length);
  // Inline function 'kotlin.collections.forEach' call
  var indexedObject = $this.q40_1;
  var inductionVariable = 0;
  var last = indexedObject.length;
  while (inductionVariable < last) {
    var element = indexedObject[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    // Inline function 'kotlinx.serialization.internal.EnumSerializer.createUnmarkedDescriptor.<anonymous>' call
    d.f41(element.z9_1);
  }
  return d;
}
function EnumSerializer$descriptor$delegate$lambda(this$0, $serialName) {
  return function () {
    var tmp0_elvis_lhs = this$0.r40_1;
    return tmp0_elvis_lhs == null ? createUnmarkedDescriptor(this$0, $serialName) : tmp0_elvis_lhs;
  };
}
function EnumSerializer(serialName, values) {
  this.q40_1 = values;
  this.r40_1 = null;
  var tmp = this;
  tmp.s40_1 = lazy_0(EnumSerializer$descriptor$delegate$lambda(this, serialName));
}
protoOf(EnumSerializer).z3q = function () {
  // Inline function 'kotlin.getValue' call
  var this_0 = this.s40_1;
  descriptor$factory_1();
  return this_0.l2();
};
protoOf(EnumSerializer).g41 = function (encoder, value) {
  var index = indexOf(this.q40_1, value);
  if (index === -1) {
    throw SerializationException_init_$Create$_0('' + value + ' is not a valid enum ' + this.z3q().e3s() + ', ' + ('must be one of ' + contentToString(this.q40_1)));
  }
  encoder.q3v(this.z3q(), index);
};
protoOf(EnumSerializer).m3r = function (encoder, value) {
  return this.g41(encoder, value instanceof Enum ? value : THROW_CCE());
};
protoOf(EnumSerializer).n3r = function (decoder) {
  var index = decoder.j3u(this.z3q());
  if (!(0 <= index ? index <= (this.q40_1.length - 1 | 0) : false)) {
    throw SerializationException_init_$Create$_0('' + index + ' is not among valid ' + this.z3q().e3s() + ' enum values, ' + ('values size is ' + this.q40_1.length));
  }
  return this.q40_1[index];
};
protoOf(EnumSerializer).toString = function () {
  return 'kotlinx.serialization.internal.EnumSerializer<' + this.z3q().e3s() + '>';
};
function _get_elementDescriptors__y23q9p($this) {
  // Inline function 'kotlin.getValue' call
  var this_0 = $this.u41_1;
  elementDescriptors$factory();
  return this_0.l2();
}
function EnumDescriptor$elementDescriptors$delegate$lambda($elementsCount, $name, this$0) {
  return function () {
    var tmp = 0;
    var tmp_0 = $elementsCount;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = fillArrayVal(Array(tmp_0), null);
    while (tmp < tmp_0) {
      var tmp_2 = tmp;
      tmp_1[tmp_2] = buildSerialDescriptor($name + '.' + this$0.y3s(tmp_2), OBJECT_getInstance(), []);
      tmp = tmp + 1 | 0;
    }
    return tmp_1;
  };
}
function EnumDescriptor(name, elementsCount) {
  PluginGeneratedSerialDescriptor.call(this, name, VOID, elementsCount);
  this.t41_1 = ENUM_getInstance();
  var tmp = this;
  tmp.u41_1 = lazy_0(EnumDescriptor$elementDescriptors$delegate$lambda(elementsCount, name, this));
}
protoOf(EnumDescriptor).u3s = function () {
  return this.t41_1;
};
protoOf(EnumDescriptor).w3s = function (index) {
  return getChecked(_get_elementDescriptors__y23q9p(this), index);
};
protoOf(EnumDescriptor).equals = function (other) {
  if (this === other)
    return true;
  if (other == null)
    return false;
  if (!(!(other == null) ? isInterface(other, SerialDescriptor) : false))
    return false;
  if (!(other.u3s() === ENUM_getInstance()))
    return false;
  if (!(this.e3s() === other.e3s()))
    return false;
  if (!equals(cachedSerialNames(this), cachedSerialNames(other)))
    return false;
  return true;
};
protoOf(EnumDescriptor).toString = function () {
  return joinToString(get_elementNames(this), ', ', this.e3s() + '(', ')');
};
protoOf(EnumDescriptor).hashCode = function () {
  var result = getStringHashCode(this.e3s());
  // Inline function 'kotlinx.serialization.internal.elementsHashCodeBy' call
  // Inline function 'kotlin.collections.fold' call
  var accumulator = 1;
  var tmp0_iterator = get_elementNames(this).u();
  while (tmp0_iterator.v()) {
    var element = tmp0_iterator.w();
    // Inline function 'kotlinx.serialization.internal.elementsHashCodeBy.<anonymous>' call
    var hash = accumulator;
    var tmp = imul(31, hash);
    // Inline function 'kotlin.hashCode' call
    // Inline function 'kotlinx.serialization.internal.EnumDescriptor.hashCode.<anonymous>' call
    var tmp1_elvis_lhs = element == null ? null : hashCode(element);
    accumulator = tmp + (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs) | 0;
  }
  var elementsHashCode = accumulator;
  result = imul(31, result) + elementsHashCode | 0;
  return result;
};
function descriptor$factory_1() {
  return getPropertyCallableRef('descriptor', 1, KProperty1, function (receiver) {
    return receiver.z3q();
  }, null);
}
function elementDescriptors$factory() {
  return getPropertyCallableRef('elementDescriptors', 1, KProperty1, function (receiver) {
    return _get_elementDescriptors__y23q9p(receiver);
  }, null);
}
function InlinePrimitiveDescriptor(name, primitiveSerializer) {
  return new InlineClassDescriptor(name, new InlinePrimitiveDescriptor$1(primitiveSerializer));
}
function InlineClassDescriptor(name, generatedSerializer) {
  PluginGeneratedSerialDescriptor.call(this, name, generatedSerializer, 1);
  this.j42_1 = true;
}
protoOf(InlineClassDescriptor).t3s = function () {
  return this.j42_1;
};
protoOf(InlineClassDescriptor).hashCode = function () {
  return imul(protoOf(PluginGeneratedSerialDescriptor).hashCode.call(this), 31);
};
protoOf(InlineClassDescriptor).equals = function (other) {
  var tmp$ret$0;
  $l$block_5: {
    // Inline function 'kotlinx.serialization.internal.equalsImpl' call
    if (this === other) {
      tmp$ret$0 = true;
      break $l$block_5;
    }
    if (!(other instanceof InlineClassDescriptor)) {
      tmp$ret$0 = false;
      break $l$block_5;
    }
    if (!(this.e3s() === other.e3s())) {
      tmp$ret$0 = false;
      break $l$block_5;
    }
    // Inline function 'kotlinx.serialization.internal.InlineClassDescriptor.equals.<anonymous>' call
    if (!(other.j42_1 ? contentEquals(this.v41(), other.v41()) : false)) {
      tmp$ret$0 = false;
      break $l$block_5;
    }
    if (!(this.s3s() === other.s3s())) {
      tmp$ret$0 = false;
      break $l$block_5;
    }
    var inductionVariable = 0;
    var last = this.s3s();
    if (inductionVariable < last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!(this.w3s(index).e3s() === other.w3s(index).e3s())) {
          tmp$ret$0 = false;
          break $l$block_5;
        }
        if (!equals(this.w3s(index).u3s(), other.w3s(index).u3s())) {
          tmp$ret$0 = false;
          break $l$block_5;
        }
      }
       while (inductionVariable < last);
    tmp$ret$0 = true;
  }
  return tmp$ret$0;
};
function InlinePrimitiveDescriptor$1($primitiveSerializer) {
  this.k42_1 = $primitiveSerializer;
}
protoOf(InlinePrimitiveDescriptor$1).l42 = function () {
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [this.k42_1];
};
protoOf(InlinePrimitiveDescriptor$1).z3q = function () {
  var message = 'unsupported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(InlinePrimitiveDescriptor$1).m3r = function (encoder, value) {
  // Inline function 'kotlin.error' call
  var message = 'unsupported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(InlinePrimitiveDescriptor$1).n3r = function (decoder) {
  // Inline function 'kotlin.error' call
  var message = 'unsupported';
  throw IllegalStateException_init_$Create$(toString(message));
};
function jsonCachedSerialNames(_this__u8e3s4) {
  return cachedSerialNames(_this__u8e3s4);
}
function NoOpEncoder() {
  NoOpEncoder_instance = this;
  AbstractEncoder.call(this);
  this.n42_1 = EmptySerializersModule_0();
}
protoOf(NoOpEncoder).k3r = function () {
  return this.n42_1;
};
protoOf(NoOpEncoder).f3v = function (value) {
  return Unit_instance;
};
protoOf(NoOpEncoder).g3v = function () {
  return Unit_instance;
};
protoOf(NoOpEncoder).h3v = function (value) {
  return Unit_instance;
};
protoOf(NoOpEncoder).i3v = function (value) {
  return Unit_instance;
};
protoOf(NoOpEncoder).j3v = function (value) {
  return Unit_instance;
};
protoOf(NoOpEncoder).k3v = function (value) {
  return Unit_instance;
};
protoOf(NoOpEncoder).l3v = function (value) {
  return Unit_instance;
};
protoOf(NoOpEncoder).m3v = function (value) {
  return Unit_instance;
};
protoOf(NoOpEncoder).n3v = function (value) {
  return Unit_instance;
};
protoOf(NoOpEncoder).o3v = function (value) {
  return Unit_instance;
};
protoOf(NoOpEncoder).p3v = function (value) {
  return Unit_instance;
};
protoOf(NoOpEncoder).q3v = function (enumDescriptor, index) {
  return Unit_instance;
};
var NoOpEncoder_instance;
function NoOpEncoder_getInstance() {
  if (NoOpEncoder_instance == null)
    new NoOpEncoder();
  return NoOpEncoder_instance;
}
function error($this) {
  throw IllegalStateException_init_$Create$('Descriptor for type `kotlin.Nothing` does not have elements');
}
function NothingSerialDescriptor() {
  NothingSerialDescriptor_instance = this;
  this.o42_1 = OBJECT_getInstance();
  this.p42_1 = 'kotlin.Nothing';
}
protoOf(NothingSerialDescriptor).u3s = function () {
  return this.o42_1;
};
protoOf(NothingSerialDescriptor).e3s = function () {
  return this.p42_1;
};
protoOf(NothingSerialDescriptor).s3s = function () {
  return 0;
};
protoOf(NothingSerialDescriptor).y3s = function (index) {
  error(this);
};
protoOf(NothingSerialDescriptor).x3s = function (name) {
  error(this);
};
protoOf(NothingSerialDescriptor).z3s = function (index) {
  error(this);
};
protoOf(NothingSerialDescriptor).w3s = function (index) {
  error(this);
};
protoOf(NothingSerialDescriptor).v3s = function (index) {
  error(this);
};
protoOf(NothingSerialDescriptor).toString = function () {
  return 'NothingSerialDescriptor';
};
protoOf(NothingSerialDescriptor).equals = function (other) {
  return this === other;
};
protoOf(NothingSerialDescriptor).hashCode = function () {
  return getStringHashCode(this.p42_1) + imul(31, this.o42_1.hashCode()) | 0;
};
var NothingSerialDescriptor_instance;
function NothingSerialDescriptor_getInstance() {
  if (NothingSerialDescriptor_instance == null)
    new NothingSerialDescriptor();
  return NothingSerialDescriptor_instance;
}
function NullableSerializer(serializer) {
  this.q42_1 = serializer;
  this.r42_1 = new SerialDescriptorForNullable(this.q42_1.z3q());
}
protoOf(NullableSerializer).z3q = function () {
  return this.r42_1;
};
protoOf(NullableSerializer).s42 = function (encoder, value) {
  if (!(value == null)) {
    encoder.f3w();
    encoder.l3r(this.q42_1, value);
  } else {
    encoder.g3v();
  }
};
protoOf(NullableSerializer).m3r = function (encoder, value) {
  return this.s42(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
};
protoOf(NullableSerializer).n3r = function (decoder) {
  return decoder.y3t() ? decoder.o3r(this.q42_1) : decoder.z3t();
};
protoOf(NullableSerializer).equals = function (other) {
  if (this === other)
    return true;
  if (other == null ? true : !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
    return false;
  if (!(other instanceof NullableSerializer))
    THROW_CCE();
  if (!equals(this.q42_1, other.q42_1))
    return false;
  return true;
};
protoOf(NullableSerializer).hashCode = function () {
  return hashCode(this.q42_1);
};
function SerialDescriptorForNullable(original) {
  this.a3t_1 = original;
  this.b3t_1 = this.a3t_1.e3s() + '?';
  this.c3t_1 = cachedSerialNames(this.a3t_1);
}
protoOf(SerialDescriptorForNullable).a3r = function () {
  return this.a3t_1.a3r();
};
protoOf(SerialDescriptorForNullable).s3s = function () {
  return this.a3t_1.s3s();
};
protoOf(SerialDescriptorForNullable).t3s = function () {
  return this.a3t_1.t3s();
};
protoOf(SerialDescriptorForNullable).u3s = function () {
  return this.a3t_1.u3s();
};
protoOf(SerialDescriptorForNullable).v3s = function (index) {
  return this.a3t_1.v3s(index);
};
protoOf(SerialDescriptorForNullable).w3s = function (index) {
  return this.a3t_1.w3s(index);
};
protoOf(SerialDescriptorForNullable).x3s = function (name) {
  return this.a3t_1.x3s(name);
};
protoOf(SerialDescriptorForNullable).y3s = function (index) {
  return this.a3t_1.y3s(index);
};
protoOf(SerialDescriptorForNullable).z3s = function (index) {
  return this.a3t_1.z3s(index);
};
protoOf(SerialDescriptorForNullable).e3s = function () {
  return this.b3t_1;
};
protoOf(SerialDescriptorForNullable).w3t = function () {
  return this.c3t_1;
};
protoOf(SerialDescriptorForNullable).o3s = function () {
  return true;
};
protoOf(SerialDescriptorForNullable).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof SerialDescriptorForNullable))
    return false;
  if (!equals(this.a3t_1, other.a3t_1))
    return false;
  return true;
};
protoOf(SerialDescriptorForNullable).toString = function () {
  return '' + this.a3t_1 + '?';
};
protoOf(SerialDescriptorForNullable).hashCode = function () {
  return imul(hashCode(this.a3t_1), 31);
};
function ObjectSerializer$descriptor$delegate$lambda$lambda(this$0) {
  return function ($this$buildSerialDescriptor) {
    $this$buildSerialDescriptor.d3r_1 = this$0.u42_1;
    return Unit_instance;
  };
}
function ObjectSerializer$descriptor$delegate$lambda($serialName, this$0) {
  return function () {
    var tmp = OBJECT_getInstance();
    return buildSerialDescriptor($serialName, tmp, [], ObjectSerializer$descriptor$delegate$lambda$lambda(this$0));
  };
}
function ObjectSerializer(serialName, objectInstance) {
  this.t42_1 = objectInstance;
  this.u42_1 = emptyList();
  var tmp = this;
  var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
  tmp.v42_1 = lazy(tmp_0, ObjectSerializer$descriptor$delegate$lambda(serialName, this));
}
protoOf(ObjectSerializer).z3q = function () {
  // Inline function 'kotlin.getValue' call
  var this_0 = this.v42_1;
  descriptor$factory_2();
  return this_0.l2();
};
protoOf(ObjectSerializer).j3r = function (encoder, value) {
  encoder.m3u(this.z3q()).n3u(this.z3q());
};
protoOf(ObjectSerializer).m3r = function (encoder, value) {
  return this.j3r(encoder, !(value == null) ? value : THROW_CCE());
};
protoOf(ObjectSerializer).n3r = function (decoder) {
  // Inline function 'kotlinx.serialization.encoding.decodeStructure' call
  var descriptor = this.z3q();
  var composite = decoder.m3u(descriptor);
  var tmp$ret$0;
  $l$block_0: {
    // Inline function 'kotlinx.serialization.internal.ObjectSerializer.deserialize.<anonymous>' call
    if (composite.b3v()) {
      tmp$ret$0 = Unit_instance;
      break $l$block_0;
    }
    var index = composite.c3v(this.z3q());
    if (index === -1) {
      tmp$ret$0 = Unit_instance;
      break $l$block_0;
    } else {
      throw SerializationException_init_$Create$_0('Unexpected index ' + index);
    }
  }
  var result = tmp$ret$0;
  composite.n3u(descriptor);
  return this.t42_1;
};
function descriptor$factory_2() {
  return getPropertyCallableRef('descriptor', 1, KProperty1, function (receiver) {
    return receiver.z3q();
  }, null);
}
function get_EMPTY_DESCRIPTOR_ARRAY() {
  _init_properties_Platform_common_kt__3qzecs();
  return EMPTY_DESCRIPTOR_ARRAY;
}
var EMPTY_DESCRIPTOR_ARRAY;
function cachedSerialNames(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  if (isInterface(_this__u8e3s4, CachedNames))
    return _this__u8e3s4.w3t();
  var result = HashSet_init_$Create$_1(_this__u8e3s4.s3s());
  var inductionVariable = 0;
  var last = _this__u8e3s4.s3s();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.collections.plusAssign' call
      var element = _this__u8e3s4.y3s(i);
      result.r(element);
    }
     while (inductionVariable < last);
  return result;
}
function kclass(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  var t = _this__u8e3s4.g7();
  var tmp;
  if (!(t == null) ? isInterface(t, KClass) : false) {
    tmp = t;
  } else {
    if (!(t == null) ? isInterface(t, KTypeParameter) : false) {
      throw IllegalArgumentException_init_$Create$('Captured type parameter ' + t + ' from generic non-reified function. ' + ('Such functionality cannot be supported because ' + t + ' is erased, either specify serializer explicitly or make ') + ('calling function inline with reified ' + t + '.'));
    } else {
      throw IllegalArgumentException_init_$Create$('Only KClass supported as classifier, got ' + t);
    }
  }
  var tmp_0 = tmp;
  return isInterface(tmp_0, KClass) ? tmp_0 : THROW_CCE();
}
function typeOrThrow(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.requireNotNull' call
    var value = _this__u8e3s4.ni_1;
    // Inline function 'kotlin.contracts.contract' call
    if (value == null) {
      // Inline function 'kotlinx.serialization.internal.typeOrThrow.<anonymous>' call
      var message = 'Star projections in type arguments are not allowed, but had ' + _this__u8e3s4.ni_1;
      throw IllegalArgumentException_init_$Create$(toString(message));
    } else {
      tmp$ret$1 = value;
      break $l$block;
    }
  }
  return tmp$ret$1;
}
function notRegisteredMessage(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  var tmp0_elvis_lhs = _this__u8e3s4.s6();
  return notRegisteredMessage_0(tmp0_elvis_lhs == null ? '<local class name not available>' : tmp0_elvis_lhs);
}
function notRegisteredMessage_0(className) {
  _init_properties_Platform_common_kt__3qzecs();
  return "Serializer for class '" + className + "' is not found.\n" + "Please ensure that class is marked as '@Serializable' and that the serialization compiler plugin is applied.\n";
}
function compactArray(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  // Inline function 'kotlin.takeUnless' call
  // Inline function 'kotlin.contracts.contract' call
  var tmp;
  // Inline function 'kotlinx.serialization.internal.compactArray.<anonymous>' call
  // Inline function 'kotlin.collections.isNullOrEmpty' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(_this__u8e3s4 == null ? true : _this__u8e3s4.b1())) {
    tmp = _this__u8e3s4;
  } else {
    tmp = null;
  }
  var tmp0_safe_receiver = tmp;
  var tmp_0;
  if (tmp0_safe_receiver == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.collections.toTypedArray' call
    tmp_0 = copyToArray(tmp0_safe_receiver);
  }
  var tmp1_elvis_lhs = tmp_0;
  return tmp1_elvis_lhs == null ? get_EMPTY_DESCRIPTOR_ARRAY() : tmp1_elvis_lhs;
}
function serializerNotRegistered(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  throw SerializationException_init_$Create$_0(notRegisteredMessage(_this__u8e3s4));
}
var properties_initialized_Platform_common_kt_i7q4ty;
function _init_properties_Platform_common_kt__3qzecs() {
  if (!properties_initialized_Platform_common_kt_i7q4ty) {
    properties_initialized_Platform_common_kt_i7q4ty = true;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    EMPTY_DESCRIPTOR_ARRAY = [];
  }
}
function throwMissingFieldException(seen, goldenMask, descriptor) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var missingFields = ArrayList_init_$Create$_0();
  var missingFieldsBits = goldenMask & ~seen;
  var inductionVariable = 0;
  if (inductionVariable < 32)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      if (!((missingFieldsBits & 1) === 0)) {
        // Inline function 'kotlin.collections.plusAssign' call
        var element = descriptor.y3s(i);
        missingFields.r(element);
      }
      missingFieldsBits = missingFieldsBits >>> 1 | 0;
    }
     while (inductionVariable < 32);
  throw MissingFieldException_init_$Create$(missingFields, descriptor.e3s());
}
function _get_childSerializers__7vnyfa($this) {
  // Inline function 'kotlin.getValue' call
  var this_0 = $this.c41_1;
  childSerializers$factory();
  return this_0.l2();
}
function _get__hashCode__tgwhef_0($this) {
  // Inline function 'kotlin.getValue' call
  var this_0 = $this.e41_1;
  _hashCode$factory_0();
  return this_0.l2();
}
function buildIndices($this) {
  var indices = HashMap_init_$Create$();
  var inductionVariable = 0;
  var last = $this.x40_1.length - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.collections.set' call
      var key = $this.x40_1[i];
      indices.i2(key, i);
    }
     while (inductionVariable <= last);
  return indices;
}
function PluginGeneratedSerialDescriptor$childSerializers$delegate$lambda(this$0) {
  return function () {
    var tmp0_safe_receiver = this$0.u40_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.l42();
    return tmp1_elvis_lhs == null ? get_EMPTY_SERIALIZER_ARRAY() : tmp1_elvis_lhs;
  };
}
function PluginGeneratedSerialDescriptor$typeParameterDescriptors$delegate$lambda(this$0) {
  return function () {
    var tmp0_safe_receiver = this$0.u40_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.m42();
    var tmp;
    if (tmp1_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList_init_$Create$(tmp1_safe_receiver.length);
      var inductionVariable = 0;
      var last = tmp1_safe_receiver.length;
      while (inductionVariable < last) {
        var item = tmp1_safe_receiver[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlinx.serialization.internal.PluginGeneratedSerialDescriptor.typeParameterDescriptors$delegate.<anonymous>.<anonymous>' call
        var tmp$ret$0 = item.z3q();
        destination.r(tmp$ret$0);
      }
      tmp = destination;
    }
    return compactArray(tmp);
  };
}
function PluginGeneratedSerialDescriptor$_hashCode$delegate$lambda(this$0) {
  return function () {
    return hashCodeImpl(this$0, this$0.v41());
  };
}
function PluginGeneratedSerialDescriptor$toString$lambda(this$0) {
  return function (i) {
    return this$0.y3s(i) + ': ' + this$0.w3s(i).e3s();
  };
}
function PluginGeneratedSerialDescriptor(serialName, generatedSerializer, elementsCount) {
  generatedSerializer = generatedSerializer === VOID ? null : generatedSerializer;
  this.t40_1 = serialName;
  this.u40_1 = generatedSerializer;
  this.v40_1 = elementsCount;
  this.w40_1 = -1;
  var tmp = this;
  var tmp_0 = 0;
  var tmp_1 = this.v40_1;
  // Inline function 'kotlin.arrayOfNulls' call
  var tmp_2 = fillArrayVal(Array(tmp_1), null);
  while (tmp_0 < tmp_1) {
    tmp_2[tmp_0] = '[UNINITIALIZED]';
    tmp_0 = tmp_0 + 1 | 0;
  }
  tmp.x40_1 = tmp_2;
  var tmp_3 = this;
  // Inline function 'kotlin.arrayOfNulls' call
  var size = this.v40_1;
  tmp_3.y40_1 = fillArrayVal(Array(size), null);
  this.z40_1 = null;
  this.a41_1 = booleanArray(this.v40_1);
  this.b41_1 = emptyMap();
  var tmp_4 = this;
  var tmp_5 = LazyThreadSafetyMode_PUBLICATION_getInstance();
  tmp_4.c41_1 = lazy(tmp_5, PluginGeneratedSerialDescriptor$childSerializers$delegate$lambda(this));
  var tmp_6 = this;
  var tmp_7 = LazyThreadSafetyMode_PUBLICATION_getInstance();
  tmp_6.d41_1 = lazy(tmp_7, PluginGeneratedSerialDescriptor$typeParameterDescriptors$delegate$lambda(this));
  var tmp_8 = this;
  var tmp_9 = LazyThreadSafetyMode_PUBLICATION_getInstance();
  tmp_8.e41_1 = lazy(tmp_9, PluginGeneratedSerialDescriptor$_hashCode$delegate$lambda(this));
}
protoOf(PluginGeneratedSerialDescriptor).e3s = function () {
  return this.t40_1;
};
protoOf(PluginGeneratedSerialDescriptor).s3s = function () {
  return this.v40_1;
};
protoOf(PluginGeneratedSerialDescriptor).u3s = function () {
  return CLASS_getInstance();
};
protoOf(PluginGeneratedSerialDescriptor).a3r = function () {
  var tmp0_elvis_lhs = this.z40_1;
  return tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
};
protoOf(PluginGeneratedSerialDescriptor).w3t = function () {
  return this.b41_1.f2();
};
protoOf(PluginGeneratedSerialDescriptor).v41 = function () {
  // Inline function 'kotlin.getValue' call
  var this_0 = this.d41_1;
  typeParameterDescriptors$factory();
  return this_0.l2();
};
protoOf(PluginGeneratedSerialDescriptor).w41 = function (name, isOptional) {
  this.w40_1 = this.w40_1 + 1 | 0;
  this.x40_1[this.w40_1] = name;
  this.a41_1[this.w40_1] = isOptional;
  this.y40_1[this.w40_1] = null;
  if (this.w40_1 === (this.v40_1 - 1 | 0)) {
    this.b41_1 = buildIndices(this);
  }
};
protoOf(PluginGeneratedSerialDescriptor).f41 = function (name, isOptional, $super) {
  isOptional = isOptional === VOID ? false : isOptional;
  var tmp;
  if ($super === VOID) {
    this.w41(name, isOptional);
    tmp = Unit_instance;
  } else {
    tmp = $super.w41.call(this, name, isOptional);
  }
  return tmp;
};
protoOf(PluginGeneratedSerialDescriptor).w3s = function (index) {
  return getChecked(_get_childSerializers__7vnyfa(this), index).z3q();
};
protoOf(PluginGeneratedSerialDescriptor).z3s = function (index) {
  return getChecked_0(this.a41_1, index);
};
protoOf(PluginGeneratedSerialDescriptor).v3s = function (index) {
  var tmp0_elvis_lhs = getChecked(this.y40_1, index);
  return tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
};
protoOf(PluginGeneratedSerialDescriptor).y3s = function (index) {
  return getChecked(this.x40_1, index);
};
protoOf(PluginGeneratedSerialDescriptor).x3s = function (name) {
  var tmp0_elvis_lhs = this.b41_1.s2(name);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    tmp = -3;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
protoOf(PluginGeneratedSerialDescriptor).equals = function (other) {
  var tmp$ret$0;
  $l$block_5: {
    // Inline function 'kotlinx.serialization.internal.equalsImpl' call
    if (this === other) {
      tmp$ret$0 = true;
      break $l$block_5;
    }
    if (!(other instanceof PluginGeneratedSerialDescriptor)) {
      tmp$ret$0 = false;
      break $l$block_5;
    }
    if (!(this.e3s() === other.e3s())) {
      tmp$ret$0 = false;
      break $l$block_5;
    }
    // Inline function 'kotlinx.serialization.internal.PluginGeneratedSerialDescriptor.equals.<anonymous>' call
    if (!contentEquals(this.v41(), other.v41())) {
      tmp$ret$0 = false;
      break $l$block_5;
    }
    if (!(this.s3s() === other.s3s())) {
      tmp$ret$0 = false;
      break $l$block_5;
    }
    var inductionVariable = 0;
    var last = this.s3s();
    if (inductionVariable < last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!(this.w3s(index).e3s() === other.w3s(index).e3s())) {
          tmp$ret$0 = false;
          break $l$block_5;
        }
        if (!equals(this.w3s(index).u3s(), other.w3s(index).u3s())) {
          tmp$ret$0 = false;
          break $l$block_5;
        }
      }
       while (inductionVariable < last);
    tmp$ret$0 = true;
  }
  return tmp$ret$0;
};
protoOf(PluginGeneratedSerialDescriptor).hashCode = function () {
  return _get__hashCode__tgwhef_0(this);
};
protoOf(PluginGeneratedSerialDescriptor).toString = function () {
  var tmp = until(0, this.v40_1);
  var tmp_0 = this.e3s() + '(';
  return joinToString(tmp, ', ', tmp_0, ')', VOID, VOID, PluginGeneratedSerialDescriptor$toString$lambda(this));
};
function hashCodeImpl(_this__u8e3s4, typeParams) {
  var result = getStringHashCode(_this__u8e3s4.e3s());
  result = imul(31, result) + contentHashCode(typeParams) | 0;
  var elementDescriptors = get_elementDescriptors(_this__u8e3s4);
  // Inline function 'kotlinx.serialization.internal.elementsHashCodeBy' call
  // Inline function 'kotlin.collections.fold' call
  var accumulator = 1;
  var tmp0_iterator = elementDescriptors.u();
  while (tmp0_iterator.v()) {
    var element = tmp0_iterator.w();
    // Inline function 'kotlinx.serialization.internal.elementsHashCodeBy.<anonymous>' call
    var hash = accumulator;
    var tmp = imul(31, hash);
    // Inline function 'kotlin.hashCode' call
    // Inline function 'kotlinx.serialization.internal.hashCodeImpl.<anonymous>' call
    var tmp0_safe_receiver = element.e3s();
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
    accumulator = tmp + (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs) | 0;
  }
  var namesHash = accumulator;
  // Inline function 'kotlinx.serialization.internal.elementsHashCodeBy' call
  // Inline function 'kotlin.collections.fold' call
  var accumulator_0 = 1;
  var tmp0_iterator_0 = elementDescriptors.u();
  while (tmp0_iterator_0.v()) {
    var element_0 = tmp0_iterator_0.w();
    // Inline function 'kotlinx.serialization.internal.elementsHashCodeBy.<anonymous>' call
    var hash_0 = accumulator_0;
    var tmp_0 = imul(31, hash_0);
    // Inline function 'kotlin.hashCode' call
    // Inline function 'kotlinx.serialization.internal.hashCodeImpl.<anonymous>' call
    var tmp0_safe_receiver_0 = element_0.u3s();
    var tmp1_elvis_lhs_0 = tmp0_safe_receiver_0 == null ? null : hashCode(tmp0_safe_receiver_0);
    accumulator_0 = tmp_0 + (tmp1_elvis_lhs_0 == null ? 0 : tmp1_elvis_lhs_0) | 0;
  }
  var kindHash = accumulator_0;
  result = imul(31, result) + namesHash | 0;
  result = imul(31, result) + kindHash | 0;
  return result;
}
function childSerializers$factory() {
  return getPropertyCallableRef('childSerializers', 1, KProperty1, function (receiver) {
    return _get_childSerializers__7vnyfa(receiver);
  }, null);
}
function typeParameterDescriptors$factory() {
  return getPropertyCallableRef('typeParameterDescriptors', 1, KProperty1, function (receiver) {
    return receiver.v41();
  }, null);
}
function _hashCode$factory_0() {
  return getPropertyCallableRef('_hashCode', 1, KProperty1, function (receiver) {
    return _get__hashCode__tgwhef_0(receiver);
  }, null);
}
function get_EMPTY_SERIALIZER_ARRAY() {
  _init_properties_PluginHelperInterfaces_kt__xgvzfp();
  return EMPTY_SERIALIZER_ARRAY;
}
var EMPTY_SERIALIZER_ARRAY;
function SerializerFactory() {
}
function GeneratedSerializer() {
}
var properties_initialized_PluginHelperInterfaces_kt_ap8in1;
function _init_properties_PluginHelperInterfaces_kt__xgvzfp() {
  if (!properties_initialized_PluginHelperInterfaces_kt_ap8in1) {
    properties_initialized_PluginHelperInterfaces_kt_ap8in1 = true;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    EMPTY_SERIALIZER_ARRAY = [];
  }
}
function CharArraySerializer_0() {
  CharArraySerializer_instance = this;
  PrimitiveArraySerializer.call(this, serializer_3(Companion_getInstance_1()));
}
protoOf(CharArraySerializer_0).z42 = function (_this__u8e3s4) {
  return _this__u8e3s4.length;
};
protoOf(CharArraySerializer_0).v3y = function (_this__u8e3s4) {
  return this.z42((!(_this__u8e3s4 == null) ? isCharArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(CharArraySerializer_0).a43 = function (_this__u8e3s4) {
  return new CharArrayBuilder(_this__u8e3s4);
};
protoOf(CharArraySerializer_0).q3x = function (_this__u8e3s4) {
  return this.a43((!(_this__u8e3s4 == null) ? isCharArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(CharArraySerializer_0).e40 = function () {
  return charArray(0);
};
protoOf(CharArraySerializer_0).b43 = function (decoder, index, builder, checkIndex) {
  builder.e43(decoder.v3u(this.x3z_1, index));
};
protoOf(CharArraySerializer_0).b3y = function (decoder, index, builder, checkIndex) {
  return this.b43(decoder, index, builder instanceof CharArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(CharArraySerializer_0).f40 = function (decoder, index, builder, checkIndex) {
  return this.b43(decoder, index, builder instanceof CharArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(CharArraySerializer_0).f43 = function (encoder, content, size) {
  var inductionVariable = 0;
  if (inductionVariable < size)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      encoder.z3v(this.x3z_1, i, content[i]);
    }
     while (inductionVariable < size);
};
protoOf(CharArraySerializer_0).g40 = function (encoder, content, size) {
  return this.f43(encoder, (!(content == null) ? isCharArray(content) : false) ? content : THROW_CCE(), size);
};
var CharArraySerializer_instance;
function CharArraySerializer_getInstance() {
  if (CharArraySerializer_instance == null)
    new CharArraySerializer_0();
  return CharArraySerializer_instance;
}
function DoubleArraySerializer_0() {
  DoubleArraySerializer_instance = this;
  PrimitiveArraySerializer.call(this, serializer_4(DoubleCompanionObject_instance));
}
protoOf(DoubleArraySerializer_0).i43 = function (_this__u8e3s4) {
  return _this__u8e3s4.length;
};
protoOf(DoubleArraySerializer_0).v3y = function (_this__u8e3s4) {
  return this.i43((!(_this__u8e3s4 == null) ? isDoubleArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(DoubleArraySerializer_0).j43 = function (_this__u8e3s4) {
  return new DoubleArrayBuilder(_this__u8e3s4);
};
protoOf(DoubleArraySerializer_0).q3x = function (_this__u8e3s4) {
  return this.j43((!(_this__u8e3s4 == null) ? isDoubleArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(DoubleArraySerializer_0).e40 = function () {
  return new Float64Array(0);
};
protoOf(DoubleArraySerializer_0).k43 = function (decoder, index, builder, checkIndex) {
  builder.n43(decoder.u3u(this.x3z_1, index));
};
protoOf(DoubleArraySerializer_0).b3y = function (decoder, index, builder, checkIndex) {
  return this.k43(decoder, index, builder instanceof DoubleArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(DoubleArraySerializer_0).f40 = function (decoder, index, builder, checkIndex) {
  return this.k43(decoder, index, builder instanceof DoubleArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(DoubleArraySerializer_0).o43 = function (encoder, content, size) {
  var inductionVariable = 0;
  if (inductionVariable < size)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      encoder.y3v(this.x3z_1, i, content[i]);
    }
     while (inductionVariable < size);
};
protoOf(DoubleArraySerializer_0).g40 = function (encoder, content, size) {
  return this.o43(encoder, (!(content == null) ? isDoubleArray(content) : false) ? content : THROW_CCE(), size);
};
var DoubleArraySerializer_instance;
function DoubleArraySerializer_getInstance() {
  if (DoubleArraySerializer_instance == null)
    new DoubleArraySerializer_0();
  return DoubleArraySerializer_instance;
}
function FloatArraySerializer_0() {
  FloatArraySerializer_instance = this;
  PrimitiveArraySerializer.call(this, serializer_5(FloatCompanionObject_instance));
}
protoOf(FloatArraySerializer_0).r43 = function (_this__u8e3s4) {
  return _this__u8e3s4.length;
};
protoOf(FloatArraySerializer_0).v3y = function (_this__u8e3s4) {
  return this.r43((!(_this__u8e3s4 == null) ? isFloatArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(FloatArraySerializer_0).s43 = function (_this__u8e3s4) {
  return new FloatArrayBuilder(_this__u8e3s4);
};
protoOf(FloatArraySerializer_0).q3x = function (_this__u8e3s4) {
  return this.s43((!(_this__u8e3s4 == null) ? isFloatArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(FloatArraySerializer_0).e40 = function () {
  return new Float32Array(0);
};
protoOf(FloatArraySerializer_0).t43 = function (decoder, index, builder, checkIndex) {
  builder.w43(decoder.t3u(this.x3z_1, index));
};
protoOf(FloatArraySerializer_0).b3y = function (decoder, index, builder, checkIndex) {
  return this.t43(decoder, index, builder instanceof FloatArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(FloatArraySerializer_0).f40 = function (decoder, index, builder, checkIndex) {
  return this.t43(decoder, index, builder instanceof FloatArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(FloatArraySerializer_0).x43 = function (encoder, content, size) {
  var inductionVariable = 0;
  if (inductionVariable < size)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      encoder.x3v(this.x3z_1, i, content[i]);
    }
     while (inductionVariable < size);
};
protoOf(FloatArraySerializer_0).g40 = function (encoder, content, size) {
  return this.x43(encoder, (!(content == null) ? isFloatArray(content) : false) ? content : THROW_CCE(), size);
};
var FloatArraySerializer_instance;
function FloatArraySerializer_getInstance() {
  if (FloatArraySerializer_instance == null)
    new FloatArraySerializer_0();
  return FloatArraySerializer_instance;
}
function LongArraySerializer_0() {
  LongArraySerializer_instance = this;
  PrimitiveArraySerializer.call(this, serializer_6(Companion_getInstance_0()));
}
protoOf(LongArraySerializer_0).a44 = function (_this__u8e3s4) {
  return _this__u8e3s4.length;
};
protoOf(LongArraySerializer_0).v3y = function (_this__u8e3s4) {
  return this.a44((!(_this__u8e3s4 == null) ? isLongArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(LongArraySerializer_0).b44 = function (_this__u8e3s4) {
  return new LongArrayBuilder(_this__u8e3s4);
};
protoOf(LongArraySerializer_0).q3x = function (_this__u8e3s4) {
  return this.b44((!(_this__u8e3s4 == null) ? isLongArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(LongArraySerializer_0).e40 = function () {
  return longArray(0);
};
protoOf(LongArraySerializer_0).c44 = function (decoder, index, builder, checkIndex) {
  builder.f44(decoder.s3u(this.x3z_1, index));
};
protoOf(LongArraySerializer_0).b3y = function (decoder, index, builder, checkIndex) {
  return this.c44(decoder, index, builder instanceof LongArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(LongArraySerializer_0).f40 = function (decoder, index, builder, checkIndex) {
  return this.c44(decoder, index, builder instanceof LongArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(LongArraySerializer_0).g44 = function (encoder, content, size) {
  var inductionVariable = 0;
  if (inductionVariable < size)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      encoder.w3v(this.x3z_1, i, content[i]);
    }
     while (inductionVariable < size);
};
protoOf(LongArraySerializer_0).g40 = function (encoder, content, size) {
  return this.g44(encoder, (!(content == null) ? isLongArray(content) : false) ? content : THROW_CCE(), size);
};
var LongArraySerializer_instance;
function LongArraySerializer_getInstance() {
  if (LongArraySerializer_instance == null)
    new LongArraySerializer_0();
  return LongArraySerializer_instance;
}
function ULongArraySerializer_0() {
  ULongArraySerializer_instance = this;
  PrimitiveArraySerializer.call(this, serializer_7(Companion_getInstance_2()));
}
protoOf(ULongArraySerializer_0).j44 = function (_this__u8e3s4) {
  return _ULongArray___get_size__impl__ju6dtr(_this__u8e3s4);
};
protoOf(ULongArraySerializer_0).v3y = function (_this__u8e3s4) {
  return this.j44(_this__u8e3s4 instanceof ULongArray ? _this__u8e3s4.sl_1 : THROW_CCE());
};
protoOf(ULongArraySerializer_0).k44 = function (_this__u8e3s4) {
  return new ULongArrayBuilder(_this__u8e3s4);
};
protoOf(ULongArraySerializer_0).q3x = function (_this__u8e3s4) {
  return this.k44(_this__u8e3s4 instanceof ULongArray ? _this__u8e3s4.sl_1 : THROW_CCE());
};
protoOf(ULongArraySerializer_0).l44 = function () {
  return _ULongArray___init__impl__twm1l3(0);
};
protoOf(ULongArraySerializer_0).e40 = function () {
  return new ULongArray(this.l44());
};
protoOf(ULongArraySerializer_0).m44 = function (decoder, index, builder, checkIndex) {
  // Inline function 'kotlin.toULong' call
  var this_0 = decoder.x3u(this.x3z_1, index).e3u();
  var tmp$ret$0 = _ULong___init__impl__c78o9k(this_0);
  builder.p44(tmp$ret$0);
};
protoOf(ULongArraySerializer_0).b3y = function (decoder, index, builder, checkIndex) {
  return this.m44(decoder, index, builder instanceof ULongArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(ULongArraySerializer_0).f40 = function (decoder, index, builder, checkIndex) {
  return this.m44(decoder, index, builder instanceof ULongArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(ULongArraySerializer_0).q44 = function (encoder, content, size) {
  var inductionVariable = 0;
  if (inductionVariable < size)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var tmp = encoder.b3w(this.x3z_1, i);
      // Inline function 'kotlin.ULong.toLong' call
      var this_0 = ULongArray__get_impl_pr71q9(content, i);
      var tmp$ret$0 = _ULong___get_data__impl__fggpzb(this_0);
      tmp.l3v(tmp$ret$0);
    }
     while (inductionVariable < size);
};
protoOf(ULongArraySerializer_0).g40 = function (encoder, content, size) {
  return this.q44(encoder, content instanceof ULongArray ? content.sl_1 : THROW_CCE(), size);
};
var ULongArraySerializer_instance;
function ULongArraySerializer_getInstance() {
  if (ULongArraySerializer_instance == null)
    new ULongArraySerializer_0();
  return ULongArraySerializer_instance;
}
function IntArraySerializer_0() {
  IntArraySerializer_instance = this;
  PrimitiveArraySerializer.call(this, serializer_8(IntCompanionObject_instance));
}
protoOf(IntArraySerializer_0).t44 = function (_this__u8e3s4) {
  return _this__u8e3s4.length;
};
protoOf(IntArraySerializer_0).v3y = function (_this__u8e3s4) {
  return this.t44((!(_this__u8e3s4 == null) ? isIntArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(IntArraySerializer_0).u44 = function (_this__u8e3s4) {
  return new IntArrayBuilder(_this__u8e3s4);
};
protoOf(IntArraySerializer_0).q3x = function (_this__u8e3s4) {
  return this.u44((!(_this__u8e3s4 == null) ? isIntArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(IntArraySerializer_0).e40 = function () {
  return new Int32Array(0);
};
protoOf(IntArraySerializer_0).v44 = function (decoder, index, builder, checkIndex) {
  builder.y44(decoder.r3u(this.x3z_1, index));
};
protoOf(IntArraySerializer_0).b3y = function (decoder, index, builder, checkIndex) {
  return this.v44(decoder, index, builder instanceof IntArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(IntArraySerializer_0).f40 = function (decoder, index, builder, checkIndex) {
  return this.v44(decoder, index, builder instanceof IntArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(IntArraySerializer_0).z44 = function (encoder, content, size) {
  var inductionVariable = 0;
  if (inductionVariable < size)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      encoder.v3v(this.x3z_1, i, content[i]);
    }
     while (inductionVariable < size);
};
protoOf(IntArraySerializer_0).g40 = function (encoder, content, size) {
  return this.z44(encoder, (!(content == null) ? isIntArray(content) : false) ? content : THROW_CCE(), size);
};
var IntArraySerializer_instance;
function IntArraySerializer_getInstance() {
  if (IntArraySerializer_instance == null)
    new IntArraySerializer_0();
  return IntArraySerializer_instance;
}
function UIntArraySerializer_0() {
  UIntArraySerializer_instance = this;
  PrimitiveArraySerializer.call(this, serializer_9(Companion_getInstance_3()));
}
protoOf(UIntArraySerializer_0).c45 = function (_this__u8e3s4) {
  return _UIntArray___get_size__impl__r6l8ci(_this__u8e3s4);
};
protoOf(UIntArraySerializer_0).v3y = function (_this__u8e3s4) {
  return this.c45(_this__u8e3s4 instanceof UIntArray ? _this__u8e3s4.gl_1 : THROW_CCE());
};
protoOf(UIntArraySerializer_0).d45 = function (_this__u8e3s4) {
  return new UIntArrayBuilder(_this__u8e3s4);
};
protoOf(UIntArraySerializer_0).q3x = function (_this__u8e3s4) {
  return this.d45(_this__u8e3s4 instanceof UIntArray ? _this__u8e3s4.gl_1 : THROW_CCE());
};
protoOf(UIntArraySerializer_0).e45 = function () {
  return _UIntArray___init__impl__ghjpc6(0);
};
protoOf(UIntArraySerializer_0).e40 = function () {
  return new UIntArray(this.e45());
};
protoOf(UIntArraySerializer_0).f45 = function (decoder, index, builder, checkIndex) {
  // Inline function 'kotlin.toUInt' call
  var this_0 = decoder.x3u(this.x3z_1, index).d3u();
  var tmp$ret$0 = _UInt___init__impl__l7qpdl(this_0);
  builder.i45(tmp$ret$0);
};
protoOf(UIntArraySerializer_0).b3y = function (decoder, index, builder, checkIndex) {
  return this.f45(decoder, index, builder instanceof UIntArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(UIntArraySerializer_0).f40 = function (decoder, index, builder, checkIndex) {
  return this.f45(decoder, index, builder instanceof UIntArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(UIntArraySerializer_0).j45 = function (encoder, content, size) {
  var inductionVariable = 0;
  if (inductionVariable < size)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var tmp = encoder.b3w(this.x3z_1, i);
      // Inline function 'kotlin.UInt.toInt' call
      var this_0 = UIntArray__get_impl_gp5kza(content, i);
      var tmp$ret$0 = _UInt___get_data__impl__f0vqqw(this_0);
      tmp.k3v(tmp$ret$0);
    }
     while (inductionVariable < size);
};
protoOf(UIntArraySerializer_0).g40 = function (encoder, content, size) {
  return this.j45(encoder, content instanceof UIntArray ? content.gl_1 : THROW_CCE(), size);
};
var UIntArraySerializer_instance;
function UIntArraySerializer_getInstance() {
  if (UIntArraySerializer_instance == null)
    new UIntArraySerializer_0();
  return UIntArraySerializer_instance;
}
function ShortArraySerializer_0() {
  ShortArraySerializer_instance = this;
  PrimitiveArraySerializer.call(this, serializer_10(ShortCompanionObject_instance));
}
protoOf(ShortArraySerializer_0).m45 = function (_this__u8e3s4) {
  return _this__u8e3s4.length;
};
protoOf(ShortArraySerializer_0).v3y = function (_this__u8e3s4) {
  return this.m45((!(_this__u8e3s4 == null) ? isShortArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(ShortArraySerializer_0).n45 = function (_this__u8e3s4) {
  return new ShortArrayBuilder(_this__u8e3s4);
};
protoOf(ShortArraySerializer_0).q3x = function (_this__u8e3s4) {
  return this.n45((!(_this__u8e3s4 == null) ? isShortArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(ShortArraySerializer_0).e40 = function () {
  return new Int16Array(0);
};
protoOf(ShortArraySerializer_0).o45 = function (decoder, index, builder, checkIndex) {
  builder.r45(decoder.q3u(this.x3z_1, index));
};
protoOf(ShortArraySerializer_0).b3y = function (decoder, index, builder, checkIndex) {
  return this.o45(decoder, index, builder instanceof ShortArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(ShortArraySerializer_0).f40 = function (decoder, index, builder, checkIndex) {
  return this.o45(decoder, index, builder instanceof ShortArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(ShortArraySerializer_0).s45 = function (encoder, content, size) {
  var inductionVariable = 0;
  if (inductionVariable < size)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      encoder.u3v(this.x3z_1, i, content[i]);
    }
     while (inductionVariable < size);
};
protoOf(ShortArraySerializer_0).g40 = function (encoder, content, size) {
  return this.s45(encoder, (!(content == null) ? isShortArray(content) : false) ? content : THROW_CCE(), size);
};
var ShortArraySerializer_instance;
function ShortArraySerializer_getInstance() {
  if (ShortArraySerializer_instance == null)
    new ShortArraySerializer_0();
  return ShortArraySerializer_instance;
}
function UShortArraySerializer_0() {
  UShortArraySerializer_instance = this;
  PrimitiveArraySerializer.call(this, serializer_11(Companion_getInstance_4()));
}
protoOf(UShortArraySerializer_0).v45 = function (_this__u8e3s4) {
  return _UShortArray___get_size__impl__jqto1b(_this__u8e3s4);
};
protoOf(UShortArraySerializer_0).v3y = function (_this__u8e3s4) {
  return this.v45(_this__u8e3s4 instanceof UShortArray ? _this__u8e3s4.em_1 : THROW_CCE());
};
protoOf(UShortArraySerializer_0).w45 = function (_this__u8e3s4) {
  return new UShortArrayBuilder(_this__u8e3s4);
};
protoOf(UShortArraySerializer_0).q3x = function (_this__u8e3s4) {
  return this.w45(_this__u8e3s4 instanceof UShortArray ? _this__u8e3s4.em_1 : THROW_CCE());
};
protoOf(UShortArraySerializer_0).x45 = function () {
  return _UShortArray___init__impl__9b26ef(0);
};
protoOf(UShortArraySerializer_0).e40 = function () {
  return new UShortArray(this.x45());
};
protoOf(UShortArraySerializer_0).y45 = function (decoder, index, builder, checkIndex) {
  // Inline function 'kotlin.toUShort' call
  var this_0 = decoder.x3u(this.x3z_1, index).c3u();
  var tmp$ret$0 = _UShort___init__impl__jigrne(this_0);
  builder.b46(tmp$ret$0);
};
protoOf(UShortArraySerializer_0).b3y = function (decoder, index, builder, checkIndex) {
  return this.y45(decoder, index, builder instanceof UShortArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(UShortArraySerializer_0).f40 = function (decoder, index, builder, checkIndex) {
  return this.y45(decoder, index, builder instanceof UShortArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(UShortArraySerializer_0).c46 = function (encoder, content, size) {
  var inductionVariable = 0;
  if (inductionVariable < size)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var tmp = encoder.b3w(this.x3z_1, i);
      // Inline function 'kotlin.UShort.toShort' call
      var this_0 = UShortArray__get_impl_fnbhmx(content, i);
      var tmp$ret$0 = _UShort___get_data__impl__g0245(this_0);
      tmp.j3v(tmp$ret$0);
    }
     while (inductionVariable < size);
};
protoOf(UShortArraySerializer_0).g40 = function (encoder, content, size) {
  return this.c46(encoder, content instanceof UShortArray ? content.em_1 : THROW_CCE(), size);
};
var UShortArraySerializer_instance;
function UShortArraySerializer_getInstance() {
  if (UShortArraySerializer_instance == null)
    new UShortArraySerializer_0();
  return UShortArraySerializer_instance;
}
function ByteArraySerializer_0() {
  ByteArraySerializer_instance = this;
  PrimitiveArraySerializer.call(this, serializer_12(ByteCompanionObject_instance));
}
protoOf(ByteArraySerializer_0).f46 = function (_this__u8e3s4) {
  return _this__u8e3s4.length;
};
protoOf(ByteArraySerializer_0).v3y = function (_this__u8e3s4) {
  return this.f46((!(_this__u8e3s4 == null) ? isByteArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(ByteArraySerializer_0).g46 = function (_this__u8e3s4) {
  return new ByteArrayBuilder(_this__u8e3s4);
};
protoOf(ByteArraySerializer_0).q3x = function (_this__u8e3s4) {
  return this.g46((!(_this__u8e3s4 == null) ? isByteArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(ByteArraySerializer_0).e40 = function () {
  return new Int8Array(0);
};
protoOf(ByteArraySerializer_0).h46 = function (decoder, index, builder, checkIndex) {
  builder.k46(decoder.p3u(this.x3z_1, index));
};
protoOf(ByteArraySerializer_0).b3y = function (decoder, index, builder, checkIndex) {
  return this.h46(decoder, index, builder instanceof ByteArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(ByteArraySerializer_0).f40 = function (decoder, index, builder, checkIndex) {
  return this.h46(decoder, index, builder instanceof ByteArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(ByteArraySerializer_0).l46 = function (encoder, content, size) {
  var inductionVariable = 0;
  if (inductionVariable < size)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      encoder.t3v(this.x3z_1, i, content[i]);
    }
     while (inductionVariable < size);
};
protoOf(ByteArraySerializer_0).g40 = function (encoder, content, size) {
  return this.l46(encoder, (!(content == null) ? isByteArray(content) : false) ? content : THROW_CCE(), size);
};
var ByteArraySerializer_instance;
function ByteArraySerializer_getInstance() {
  if (ByteArraySerializer_instance == null)
    new ByteArraySerializer_0();
  return ByteArraySerializer_instance;
}
function UByteArraySerializer_0() {
  UByteArraySerializer_instance = this;
  PrimitiveArraySerializer.call(this, serializer_13(Companion_getInstance_5()));
}
protoOf(UByteArraySerializer_0).o46 = function (_this__u8e3s4) {
  return _UByteArray___get_size__impl__h6pkdv(_this__u8e3s4);
};
protoOf(UByteArraySerializer_0).v3y = function (_this__u8e3s4) {
  return this.o46(_this__u8e3s4 instanceof UByteArray ? _this__u8e3s4.uk_1 : THROW_CCE());
};
protoOf(UByteArraySerializer_0).p46 = function (_this__u8e3s4) {
  return new UByteArrayBuilder(_this__u8e3s4);
};
protoOf(UByteArraySerializer_0).q3x = function (_this__u8e3s4) {
  return this.p46(_this__u8e3s4 instanceof UByteArray ? _this__u8e3s4.uk_1 : THROW_CCE());
};
protoOf(UByteArraySerializer_0).q46 = function () {
  return _UByteArray___init__impl__ip4y9n(0);
};
protoOf(UByteArraySerializer_0).e40 = function () {
  return new UByteArray(this.q46());
};
protoOf(UByteArraySerializer_0).r46 = function (decoder, index, builder, checkIndex) {
  // Inline function 'kotlin.toUByte' call
  var this_0 = decoder.x3u(this.x3z_1, index).b3u();
  var tmp$ret$0 = _UByte___init__impl__g9hnc4(this_0);
  builder.u46(tmp$ret$0);
};
protoOf(UByteArraySerializer_0).b3y = function (decoder, index, builder, checkIndex) {
  return this.r46(decoder, index, builder instanceof UByteArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(UByteArraySerializer_0).f40 = function (decoder, index, builder, checkIndex) {
  return this.r46(decoder, index, builder instanceof UByteArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(UByteArraySerializer_0).v46 = function (encoder, content, size) {
  var inductionVariable = 0;
  if (inductionVariable < size)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var tmp = encoder.b3w(this.x3z_1, i);
      // Inline function 'kotlin.UByte.toByte' call
      var this_0 = UByteArray__get_impl_t5f3hv(content, i);
      var tmp$ret$0 = _UByte___get_data__impl__jof9qr(this_0);
      tmp.i3v(tmp$ret$0);
    }
     while (inductionVariable < size);
};
protoOf(UByteArraySerializer_0).g40 = function (encoder, content, size) {
  return this.v46(encoder, content instanceof UByteArray ? content.uk_1 : THROW_CCE(), size);
};
var UByteArraySerializer_instance;
function UByteArraySerializer_getInstance() {
  if (UByteArraySerializer_instance == null)
    new UByteArraySerializer_0();
  return UByteArraySerializer_instance;
}
function BooleanArraySerializer_0() {
  BooleanArraySerializer_instance = this;
  PrimitiveArraySerializer.call(this, serializer_14(BooleanCompanionObject_instance));
}
protoOf(BooleanArraySerializer_0).y46 = function (_this__u8e3s4) {
  return _this__u8e3s4.length;
};
protoOf(BooleanArraySerializer_0).v3y = function (_this__u8e3s4) {
  return this.y46((!(_this__u8e3s4 == null) ? isBooleanArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(BooleanArraySerializer_0).z46 = function (_this__u8e3s4) {
  return new BooleanArrayBuilder(_this__u8e3s4);
};
protoOf(BooleanArraySerializer_0).q3x = function (_this__u8e3s4) {
  return this.z46((!(_this__u8e3s4 == null) ? isBooleanArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(BooleanArraySerializer_0).e40 = function () {
  return booleanArray(0);
};
protoOf(BooleanArraySerializer_0).a47 = function (decoder, index, builder, checkIndex) {
  builder.d47(decoder.o3u(this.x3z_1, index));
};
protoOf(BooleanArraySerializer_0).b3y = function (decoder, index, builder, checkIndex) {
  return this.a47(decoder, index, builder instanceof BooleanArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(BooleanArraySerializer_0).f40 = function (decoder, index, builder, checkIndex) {
  return this.a47(decoder, index, builder instanceof BooleanArrayBuilder ? builder : THROW_CCE(), checkIndex);
};
protoOf(BooleanArraySerializer_0).e47 = function (encoder, content, size) {
  var inductionVariable = 0;
  if (inductionVariable < size)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      encoder.s3v(this.x3z_1, i, content[i]);
    }
     while (inductionVariable < size);
};
protoOf(BooleanArraySerializer_0).g40 = function (encoder, content, size) {
  return this.e47(encoder, (!(content == null) ? isBooleanArray(content) : false) ? content : THROW_CCE(), size);
};
var BooleanArraySerializer_instance;
function BooleanArraySerializer_getInstance() {
  if (BooleanArraySerializer_instance == null)
    new BooleanArraySerializer_0();
  return BooleanArraySerializer_instance;
}
function CharArrayBuilder(bufferWithData) {
  PrimitiveArrayBuilder.call(this);
  this.c43_1 = bufferWithData;
  this.d43_1 = bufferWithData.length;
  this.z2(10);
}
protoOf(CharArrayBuilder).z3z = function () {
  return this.d43_1;
};
protoOf(CharArrayBuilder).z2 = function (requiredCapacity) {
  if (this.c43_1.length < requiredCapacity)
    this.c43_1 = copyOf(this.c43_1, coerceAtLeast(requiredCapacity, imul(this.c43_1.length, 2)));
};
protoOf(CharArrayBuilder).e43 = function (c) {
  this.i40();
  var tmp = this.c43_1;
  var tmp1 = this.d43_1;
  this.d43_1 = tmp1 + 1 | 0;
  tmp[tmp1] = c;
};
protoOf(CharArrayBuilder).l1i = function () {
  return copyOf(this.c43_1, this.d43_1);
};
function DoubleArrayBuilder(bufferWithData) {
  PrimitiveArrayBuilder.call(this);
  this.l43_1 = bufferWithData;
  this.m43_1 = bufferWithData.length;
  this.z2(10);
}
protoOf(DoubleArrayBuilder).z3z = function () {
  return this.m43_1;
};
protoOf(DoubleArrayBuilder).z2 = function (requiredCapacity) {
  if (this.l43_1.length < requiredCapacity)
    this.l43_1 = copyOf_0(this.l43_1, coerceAtLeast(requiredCapacity, imul(this.l43_1.length, 2)));
};
protoOf(DoubleArrayBuilder).n43 = function (c) {
  this.i40();
  var tmp = this.l43_1;
  var tmp1 = this.m43_1;
  this.m43_1 = tmp1 + 1 | 0;
  tmp[tmp1] = c;
};
protoOf(DoubleArrayBuilder).l1i = function () {
  return copyOf_0(this.l43_1, this.m43_1);
};
function FloatArrayBuilder(bufferWithData) {
  PrimitiveArrayBuilder.call(this);
  this.u43_1 = bufferWithData;
  this.v43_1 = bufferWithData.length;
  this.z2(10);
}
protoOf(FloatArrayBuilder).z3z = function () {
  return this.v43_1;
};
protoOf(FloatArrayBuilder).z2 = function (requiredCapacity) {
  if (this.u43_1.length < requiredCapacity)
    this.u43_1 = copyOf_1(this.u43_1, coerceAtLeast(requiredCapacity, imul(this.u43_1.length, 2)));
};
protoOf(FloatArrayBuilder).w43 = function (c) {
  this.i40();
  var tmp = this.u43_1;
  var tmp1 = this.v43_1;
  this.v43_1 = tmp1 + 1 | 0;
  tmp[tmp1] = c;
};
protoOf(FloatArrayBuilder).l1i = function () {
  return copyOf_1(this.u43_1, this.v43_1);
};
function LongArrayBuilder(bufferWithData) {
  PrimitiveArrayBuilder.call(this);
  this.d44_1 = bufferWithData;
  this.e44_1 = bufferWithData.length;
  this.z2(10);
}
protoOf(LongArrayBuilder).z3z = function () {
  return this.e44_1;
};
protoOf(LongArrayBuilder).z2 = function (requiredCapacity) {
  if (this.d44_1.length < requiredCapacity)
    this.d44_1 = copyOf_2(this.d44_1, coerceAtLeast(requiredCapacity, imul(this.d44_1.length, 2)));
};
protoOf(LongArrayBuilder).f44 = function (c) {
  this.i40();
  var tmp = this.d44_1;
  var tmp1 = this.e44_1;
  this.e44_1 = tmp1 + 1 | 0;
  tmp[tmp1] = c;
};
protoOf(LongArrayBuilder).l1i = function () {
  return copyOf_2(this.d44_1, this.e44_1);
};
function ULongArrayBuilder(bufferWithData) {
  PrimitiveArrayBuilder.call(this);
  this.n44_1 = bufferWithData;
  this.o44_1 = _ULongArray___get_size__impl__ju6dtr(bufferWithData);
  this.z2(10);
}
protoOf(ULongArrayBuilder).z3z = function () {
  return this.o44_1;
};
protoOf(ULongArrayBuilder).z2 = function (requiredCapacity) {
  if (_ULongArray___get_size__impl__ju6dtr(this.n44_1) < requiredCapacity) {
    var tmp = this;
    // Inline function 'kotlin.collections.copyOf' call
    var this_0 = this.n44_1;
    var newSize = coerceAtLeast(requiredCapacity, imul(_ULongArray___get_size__impl__ju6dtr(this.n44_1), 2));
    tmp.n44_1 = _ULongArray___init__impl__twm1l3_0(copyOf_2(_ULongArray___get_storage__impl__28e64j(this_0), newSize));
  }
};
protoOf(ULongArrayBuilder).p44 = function (c) {
  this.i40();
  var tmp = this.n44_1;
  var tmp1 = this.o44_1;
  this.o44_1 = tmp1 + 1 | 0;
  ULongArray__set_impl_z19mvh(tmp, tmp1, c);
};
protoOf(ULongArrayBuilder).f47 = function () {
  // Inline function 'kotlin.collections.copyOf' call
  var this_0 = this.n44_1;
  var newSize = this.o44_1;
  return _ULongArray___init__impl__twm1l3_0(copyOf_2(_ULongArray___get_storage__impl__28e64j(this_0), newSize));
};
protoOf(ULongArrayBuilder).l1i = function () {
  return new ULongArray(this.f47());
};
function IntArrayBuilder(bufferWithData) {
  PrimitiveArrayBuilder.call(this);
  this.w44_1 = bufferWithData;
  this.x44_1 = bufferWithData.length;
  this.z2(10);
}
protoOf(IntArrayBuilder).z3z = function () {
  return this.x44_1;
};
protoOf(IntArrayBuilder).z2 = function (requiredCapacity) {
  if (this.w44_1.length < requiredCapacity)
    this.w44_1 = copyOf_3(this.w44_1, coerceAtLeast(requiredCapacity, imul(this.w44_1.length, 2)));
};
protoOf(IntArrayBuilder).y44 = function (c) {
  this.i40();
  var tmp = this.w44_1;
  var tmp1 = this.x44_1;
  this.x44_1 = tmp1 + 1 | 0;
  tmp[tmp1] = c;
};
protoOf(IntArrayBuilder).l1i = function () {
  return copyOf_3(this.w44_1, this.x44_1);
};
function UIntArrayBuilder(bufferWithData) {
  PrimitiveArrayBuilder.call(this);
  this.g45_1 = bufferWithData;
  this.h45_1 = _UIntArray___get_size__impl__r6l8ci(bufferWithData);
  this.z2(10);
}
protoOf(UIntArrayBuilder).z3z = function () {
  return this.h45_1;
};
protoOf(UIntArrayBuilder).z2 = function (requiredCapacity) {
  if (_UIntArray___get_size__impl__r6l8ci(this.g45_1) < requiredCapacity) {
    var tmp = this;
    // Inline function 'kotlin.collections.copyOf' call
    var this_0 = this.g45_1;
    var newSize = coerceAtLeast(requiredCapacity, imul(_UIntArray___get_size__impl__r6l8ci(this.g45_1), 2));
    tmp.g45_1 = _UIntArray___init__impl__ghjpc6_0(copyOf_3(_UIntArray___get_storage__impl__92a0v0(this_0), newSize));
  }
};
protoOf(UIntArrayBuilder).i45 = function (c) {
  this.i40();
  var tmp = this.g45_1;
  var tmp1 = this.h45_1;
  this.h45_1 = tmp1 + 1 | 0;
  UIntArray__set_impl_7f2zu2(tmp, tmp1, c);
};
protoOf(UIntArrayBuilder).g47 = function () {
  // Inline function 'kotlin.collections.copyOf' call
  var this_0 = this.g45_1;
  var newSize = this.h45_1;
  return _UIntArray___init__impl__ghjpc6_0(copyOf_3(_UIntArray___get_storage__impl__92a0v0(this_0), newSize));
};
protoOf(UIntArrayBuilder).l1i = function () {
  return new UIntArray(this.g47());
};
function ShortArrayBuilder(bufferWithData) {
  PrimitiveArrayBuilder.call(this);
  this.p45_1 = bufferWithData;
  this.q45_1 = bufferWithData.length;
  this.z2(10);
}
protoOf(ShortArrayBuilder).z3z = function () {
  return this.q45_1;
};
protoOf(ShortArrayBuilder).z2 = function (requiredCapacity) {
  if (this.p45_1.length < requiredCapacity)
    this.p45_1 = copyOf_4(this.p45_1, coerceAtLeast(requiredCapacity, imul(this.p45_1.length, 2)));
};
protoOf(ShortArrayBuilder).r45 = function (c) {
  this.i40();
  var tmp = this.p45_1;
  var tmp1 = this.q45_1;
  this.q45_1 = tmp1 + 1 | 0;
  tmp[tmp1] = c;
};
protoOf(ShortArrayBuilder).l1i = function () {
  return copyOf_4(this.p45_1, this.q45_1);
};
function UShortArrayBuilder(bufferWithData) {
  PrimitiveArrayBuilder.call(this);
  this.z45_1 = bufferWithData;
  this.a46_1 = _UShortArray___get_size__impl__jqto1b(bufferWithData);
  this.z2(10);
}
protoOf(UShortArrayBuilder).z3z = function () {
  return this.a46_1;
};
protoOf(UShortArrayBuilder).z2 = function (requiredCapacity) {
  if (_UShortArray___get_size__impl__jqto1b(this.z45_1) < requiredCapacity) {
    var tmp = this;
    // Inline function 'kotlin.collections.copyOf' call
    var this_0 = this.z45_1;
    var newSize = coerceAtLeast(requiredCapacity, imul(_UShortArray___get_size__impl__jqto1b(this.z45_1), 2));
    tmp.z45_1 = _UShortArray___init__impl__9b26ef_0(copyOf_4(_UShortArray___get_storage__impl__t2jpv5(this_0), newSize));
  }
};
protoOf(UShortArrayBuilder).b46 = function (c) {
  this.i40();
  var tmp = this.z45_1;
  var tmp1 = this.a46_1;
  this.a46_1 = tmp1 + 1 | 0;
  UShortArray__set_impl_6d8whp(tmp, tmp1, c);
};
protoOf(UShortArrayBuilder).h47 = function () {
  // Inline function 'kotlin.collections.copyOf' call
  var this_0 = this.z45_1;
  var newSize = this.a46_1;
  return _UShortArray___init__impl__9b26ef_0(copyOf_4(_UShortArray___get_storage__impl__t2jpv5(this_0), newSize));
};
protoOf(UShortArrayBuilder).l1i = function () {
  return new UShortArray(this.h47());
};
function ByteArrayBuilder(bufferWithData) {
  PrimitiveArrayBuilder.call(this);
  this.i46_1 = bufferWithData;
  this.j46_1 = bufferWithData.length;
  this.z2(10);
}
protoOf(ByteArrayBuilder).z3z = function () {
  return this.j46_1;
};
protoOf(ByteArrayBuilder).z2 = function (requiredCapacity) {
  if (this.i46_1.length < requiredCapacity)
    this.i46_1 = copyOf_5(this.i46_1, coerceAtLeast(requiredCapacity, imul(this.i46_1.length, 2)));
};
protoOf(ByteArrayBuilder).k46 = function (c) {
  this.i40();
  var tmp = this.i46_1;
  var tmp1 = this.j46_1;
  this.j46_1 = tmp1 + 1 | 0;
  tmp[tmp1] = c;
};
protoOf(ByteArrayBuilder).l1i = function () {
  return copyOf_5(this.i46_1, this.j46_1);
};
function UByteArrayBuilder(bufferWithData) {
  PrimitiveArrayBuilder.call(this);
  this.s46_1 = bufferWithData;
  this.t46_1 = _UByteArray___get_size__impl__h6pkdv(bufferWithData);
  this.z2(10);
}
protoOf(UByteArrayBuilder).z3z = function () {
  return this.t46_1;
};
protoOf(UByteArrayBuilder).z2 = function (requiredCapacity) {
  if (_UByteArray___get_size__impl__h6pkdv(this.s46_1) < requiredCapacity) {
    var tmp = this;
    // Inline function 'kotlin.collections.copyOf' call
    var this_0 = this.s46_1;
    var newSize = coerceAtLeast(requiredCapacity, imul(_UByteArray___get_size__impl__h6pkdv(this.s46_1), 2));
    tmp.s46_1 = _UByteArray___init__impl__ip4y9n_0(copyOf_5(_UByteArray___get_storage__impl__d4kctt(this_0), newSize));
  }
};
protoOf(UByteArrayBuilder).u46 = function (c) {
  this.i40();
  var tmp = this.s46_1;
  var tmp1 = this.t46_1;
  this.t46_1 = tmp1 + 1 | 0;
  UByteArray__set_impl_jvcicn(tmp, tmp1, c);
};
protoOf(UByteArrayBuilder).i47 = function () {
  // Inline function 'kotlin.collections.copyOf' call
  var this_0 = this.s46_1;
  var newSize = this.t46_1;
  return _UByteArray___init__impl__ip4y9n_0(copyOf_5(_UByteArray___get_storage__impl__d4kctt(this_0), newSize));
};
protoOf(UByteArrayBuilder).l1i = function () {
  return new UByteArray(this.i47());
};
function BooleanArrayBuilder(bufferWithData) {
  PrimitiveArrayBuilder.call(this);
  this.b47_1 = bufferWithData;
  this.c47_1 = bufferWithData.length;
  this.z2(10);
}
protoOf(BooleanArrayBuilder).z3z = function () {
  return this.c47_1;
};
protoOf(BooleanArrayBuilder).z2 = function (requiredCapacity) {
  if (this.b47_1.length < requiredCapacity)
    this.b47_1 = copyOf_6(this.b47_1, coerceAtLeast(requiredCapacity, imul(this.b47_1.length, 2)));
};
protoOf(BooleanArrayBuilder).d47 = function (c) {
  this.i40();
  var tmp = this.b47_1;
  var tmp1 = this.c47_1;
  this.c47_1 = tmp1 + 1 | 0;
  tmp[tmp1] = c;
};
protoOf(BooleanArrayBuilder).l1i = function () {
  return copyOf_6(this.b47_1, this.c47_1);
};
function get_BUILTIN_SERIALIZERS() {
  _init_properties_Primitives_kt__k0eto4();
  return BUILTIN_SERIALIZERS;
}
var BUILTIN_SERIALIZERS;
function builtinSerializerOrNull(_this__u8e3s4) {
  _init_properties_Primitives_kt__k0eto4();
  var tmp = get_BUILTIN_SERIALIZERS().s2(_this__u8e3s4);
  return (tmp == null ? true : isInterface(tmp, KSerializer)) ? tmp : THROW_CCE();
}
function StringSerializer() {
  StringSerializer_instance = this;
  this.j47_1 = new PrimitiveSerialDescriptor_0('kotlin.String', STRING_getInstance());
}
protoOf(StringSerializer).z3q = function () {
  return this.j47_1;
};
protoOf(StringSerializer).k47 = function (encoder, value) {
  return encoder.p3v(value);
};
protoOf(StringSerializer).m3r = function (encoder, value) {
  return this.k47(encoder, (!(value == null) ? typeof value === 'string' : false) ? value : THROW_CCE());
};
protoOf(StringSerializer).n3r = function (decoder) {
  return decoder.i3u();
};
var StringSerializer_instance;
function StringSerializer_getInstance() {
  if (StringSerializer_instance == null)
    new StringSerializer();
  return StringSerializer_instance;
}
function CharSerializer() {
  CharSerializer_instance = this;
  this.l47_1 = new PrimitiveSerialDescriptor_0('kotlin.Char', CHAR_getInstance());
}
protoOf(CharSerializer).z3q = function () {
  return this.l47_1;
};
protoOf(CharSerializer).m47 = function (encoder, value) {
  return encoder.o3v(value);
};
protoOf(CharSerializer).m3r = function (encoder, value) {
  return this.m47(encoder, value instanceof Char ? value.ta_1 : THROW_CCE());
};
protoOf(CharSerializer).n47 = function (decoder) {
  return decoder.h3u();
};
protoOf(CharSerializer).n3r = function (decoder) {
  return new Char(this.n47(decoder));
};
var CharSerializer_instance;
function CharSerializer_getInstance() {
  if (CharSerializer_instance == null)
    new CharSerializer();
  return CharSerializer_instance;
}
function DoubleSerializer() {
  DoubleSerializer_instance = this;
  this.o47_1 = new PrimitiveSerialDescriptor_0('kotlin.Double', DOUBLE_getInstance());
}
protoOf(DoubleSerializer).z3q = function () {
  return this.o47_1;
};
protoOf(DoubleSerializer).p47 = function (encoder, value) {
  return encoder.n3v(value);
};
protoOf(DoubleSerializer).m3r = function (encoder, value) {
  return this.p47(encoder, (!(value == null) ? typeof value === 'number' : false) ? value : THROW_CCE());
};
protoOf(DoubleSerializer).n3r = function (decoder) {
  return decoder.g3u();
};
var DoubleSerializer_instance;
function DoubleSerializer_getInstance() {
  if (DoubleSerializer_instance == null)
    new DoubleSerializer();
  return DoubleSerializer_instance;
}
function FloatSerializer() {
  FloatSerializer_instance = this;
  this.q47_1 = new PrimitiveSerialDescriptor_0('kotlin.Float', FLOAT_getInstance());
}
protoOf(FloatSerializer).z3q = function () {
  return this.q47_1;
};
protoOf(FloatSerializer).r47 = function (encoder, value) {
  return encoder.m3v(value);
};
protoOf(FloatSerializer).m3r = function (encoder, value) {
  return this.r47(encoder, (!(value == null) ? typeof value === 'number' : false) ? value : THROW_CCE());
};
protoOf(FloatSerializer).n3r = function (decoder) {
  return decoder.f3u();
};
var FloatSerializer_instance;
function FloatSerializer_getInstance() {
  if (FloatSerializer_instance == null)
    new FloatSerializer();
  return FloatSerializer_instance;
}
function LongSerializer() {
  LongSerializer_instance = this;
  this.s47_1 = new PrimitiveSerialDescriptor_0('kotlin.Long', LONG_getInstance());
}
protoOf(LongSerializer).z3q = function () {
  return this.s47_1;
};
protoOf(LongSerializer).t47 = function (encoder, value) {
  return encoder.l3v(value);
};
protoOf(LongSerializer).m3r = function (encoder, value) {
  return this.t47(encoder, value instanceof Long ? value : THROW_CCE());
};
protoOf(LongSerializer).n3r = function (decoder) {
  return decoder.e3u();
};
var LongSerializer_instance;
function LongSerializer_getInstance() {
  if (LongSerializer_instance == null)
    new LongSerializer();
  return LongSerializer_instance;
}
function IntSerializer() {
  IntSerializer_instance = this;
  this.u47_1 = new PrimitiveSerialDescriptor_0('kotlin.Int', INT_getInstance());
}
protoOf(IntSerializer).z3q = function () {
  return this.u47_1;
};
protoOf(IntSerializer).v47 = function (encoder, value) {
  return encoder.k3v(value);
};
protoOf(IntSerializer).m3r = function (encoder, value) {
  return this.v47(encoder, (!(value == null) ? typeof value === 'number' : false) ? value : THROW_CCE());
};
protoOf(IntSerializer).n3r = function (decoder) {
  return decoder.d3u();
};
var IntSerializer_instance;
function IntSerializer_getInstance() {
  if (IntSerializer_instance == null)
    new IntSerializer();
  return IntSerializer_instance;
}
function ShortSerializer() {
  ShortSerializer_instance = this;
  this.w47_1 = new PrimitiveSerialDescriptor_0('kotlin.Short', SHORT_getInstance());
}
protoOf(ShortSerializer).z3q = function () {
  return this.w47_1;
};
protoOf(ShortSerializer).x47 = function (encoder, value) {
  return encoder.j3v(value);
};
protoOf(ShortSerializer).m3r = function (encoder, value) {
  return this.x47(encoder, (!(value == null) ? typeof value === 'number' : false) ? value : THROW_CCE());
};
protoOf(ShortSerializer).n3r = function (decoder) {
  return decoder.c3u();
};
var ShortSerializer_instance;
function ShortSerializer_getInstance() {
  if (ShortSerializer_instance == null)
    new ShortSerializer();
  return ShortSerializer_instance;
}
function ByteSerializer() {
  ByteSerializer_instance = this;
  this.y47_1 = new PrimitiveSerialDescriptor_0('kotlin.Byte', BYTE_getInstance());
}
protoOf(ByteSerializer).z3q = function () {
  return this.y47_1;
};
protoOf(ByteSerializer).z47 = function (encoder, value) {
  return encoder.i3v(value);
};
protoOf(ByteSerializer).m3r = function (encoder, value) {
  return this.z47(encoder, (!(value == null) ? typeof value === 'number' : false) ? value : THROW_CCE());
};
protoOf(ByteSerializer).n3r = function (decoder) {
  return decoder.b3u();
};
var ByteSerializer_instance;
function ByteSerializer_getInstance() {
  if (ByteSerializer_instance == null)
    new ByteSerializer();
  return ByteSerializer_instance;
}
function BooleanSerializer() {
  BooleanSerializer_instance = this;
  this.a48_1 = new PrimitiveSerialDescriptor_0('kotlin.Boolean', BOOLEAN_getInstance());
}
protoOf(BooleanSerializer).z3q = function () {
  return this.a48_1;
};
protoOf(BooleanSerializer).b48 = function (encoder, value) {
  return encoder.h3v(value);
};
protoOf(BooleanSerializer).m3r = function (encoder, value) {
  return this.b48(encoder, (!(value == null) ? typeof value === 'boolean' : false) ? value : THROW_CCE());
};
protoOf(BooleanSerializer).n3r = function (decoder) {
  return decoder.a3u();
};
var BooleanSerializer_instance;
function BooleanSerializer_getInstance() {
  if (BooleanSerializer_instance == null)
    new BooleanSerializer();
  return BooleanSerializer_instance;
}
function UnitSerializer() {
  UnitSerializer_instance = this;
  this.c48_1 = new ObjectSerializer('kotlin.Unit', Unit_instance);
}
protoOf(UnitSerializer).z3q = function () {
  return this.c48_1.z3q();
};
protoOf(UnitSerializer).d48 = function (decoder) {
  this.c48_1.n3r(decoder);
};
protoOf(UnitSerializer).n3r = function (decoder) {
  this.d48(decoder);
  return Unit_instance;
};
protoOf(UnitSerializer).e48 = function (encoder, value) {
  this.c48_1.j3r(encoder, Unit_instance);
};
protoOf(UnitSerializer).m3r = function (encoder, value) {
  return this.e48(encoder, value instanceof Unit ? value : THROW_CCE());
};
var UnitSerializer_instance;
function UnitSerializer_getInstance() {
  if (UnitSerializer_instance == null)
    new UnitSerializer();
  return UnitSerializer_instance;
}
function error_0($this) {
  throw IllegalStateException_init_$Create$('Primitive descriptor does not have elements');
}
function PrimitiveSerialDescriptor_0(serialName, kind) {
  this.f48_1 = serialName;
  this.g48_1 = kind;
}
protoOf(PrimitiveSerialDescriptor_0).e3s = function () {
  return this.f48_1;
};
protoOf(PrimitiveSerialDescriptor_0).u3s = function () {
  return this.g48_1;
};
protoOf(PrimitiveSerialDescriptor_0).s3s = function () {
  return 0;
};
protoOf(PrimitiveSerialDescriptor_0).y3s = function (index) {
  error_0(this);
};
protoOf(PrimitiveSerialDescriptor_0).x3s = function (name) {
  error_0(this);
};
protoOf(PrimitiveSerialDescriptor_0).z3s = function (index) {
  error_0(this);
};
protoOf(PrimitiveSerialDescriptor_0).w3s = function (index) {
  error_0(this);
};
protoOf(PrimitiveSerialDescriptor_0).v3s = function (index) {
  error_0(this);
};
protoOf(PrimitiveSerialDescriptor_0).toString = function () {
  return 'PrimitiveDescriptor(' + this.f48_1 + ')';
};
protoOf(PrimitiveSerialDescriptor_0).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof PrimitiveSerialDescriptor_0))
    return false;
  if (this.f48_1 === other.f48_1 ? equals(this.g48_1, other.g48_1) : false)
    return true;
  return false;
};
protoOf(PrimitiveSerialDescriptor_0).hashCode = function () {
  return getStringHashCode(this.f48_1) + imul(31, this.g48_1.hashCode()) | 0;
};
function PrimitiveDescriptorSafe(serialName, kind) {
  _init_properties_Primitives_kt__k0eto4();
  checkName(serialName);
  return new PrimitiveSerialDescriptor_0(serialName, kind);
}
function checkName(serialName) {
  _init_properties_Primitives_kt__k0eto4();
  var keys = get_BUILTIN_SERIALIZERS().f2();
  var tmp0_iterator = keys.u();
  while (tmp0_iterator.v()) {
    var primitive = tmp0_iterator.w();
    var simpleName = capitalize(ensureNotNull(primitive.s6()));
    var qualifiedName = 'kotlin.' + simpleName;
    if (equals_0(serialName, qualifiedName, true) ? true : equals_0(serialName, simpleName, true)) {
      throw IllegalArgumentException_init_$Create$(trimIndent('\n                The name of serial descriptor should uniquely identify associated serializer.\n                For serial name ' + serialName + ' there already exist ' + capitalize(simpleName) + 'Serializer.\n                Please refer to SerialDescriptor documentation for additional information.\n            '));
    }
  }
}
function capitalize(_this__u8e3s4) {
  _init_properties_Primitives_kt__k0eto4();
  // Inline function 'kotlin.text.replaceFirstChar' call
  var tmp;
  // Inline function 'kotlin.text.isNotEmpty' call
  if (charSequenceLength(_this__u8e3s4) > 0) {
    // Inline function 'kotlinx.serialization.internal.capitalize.<anonymous>' call
    var it = charSequenceGet(_this__u8e3s4, 0);
    var tmp$ret$1 = isLowerCase(it) ? titlecase(it) : toString_0(it);
    var tmp_0 = toString(tmp$ret$1);
    // Inline function 'kotlin.text.substring' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp = tmp_0 + _this__u8e3s4.substring(1);
  } else {
    tmp = _this__u8e3s4;
  }
  return tmp;
}
var properties_initialized_Primitives_kt_6dpii6;
function _init_properties_Primitives_kt__k0eto4() {
  if (!properties_initialized_Primitives_kt_6dpii6) {
    properties_initialized_Primitives_kt_6dpii6 = true;
    BUILTIN_SERIALIZERS = mapOf([to(PrimitiveClasses_getInstance().t7(), serializer_2(StringCompanionObject_instance)), to(getKClass(Char), serializer_3(Companion_getInstance_1())), to(PrimitiveClasses_getInstance().w7(), CharArraySerializer()), to(PrimitiveClasses_getInstance().r7(), serializer_4(DoubleCompanionObject_instance)), to(PrimitiveClasses_getInstance().c8(), DoubleArraySerializer()), to(PrimitiveClasses_getInstance().q7(), serializer_5(FloatCompanionObject_instance)), to(PrimitiveClasses_getInstance().b8(), FloatArraySerializer()), to(getKClass(Long), serializer_6(Companion_getInstance_0())), to(PrimitiveClasses_getInstance().a8(), LongArraySerializer()), to(getKClass(ULong), serializer_7(Companion_getInstance_2())), to(getKClass(ULongArray), ULongArraySerializer()), to(PrimitiveClasses_getInstance().p7(), serializer_8(IntCompanionObject_instance)), to(PrimitiveClasses_getInstance().z7(), IntArraySerializer()), to(getKClass(UInt), serializer_9(Companion_getInstance_3())), to(getKClass(UIntArray), UIntArraySerializer()), to(PrimitiveClasses_getInstance().o7(), serializer_10(ShortCompanionObject_instance)), to(PrimitiveClasses_getInstance().y7(), ShortArraySerializer()), to(getKClass(UShort), serializer_11(Companion_getInstance_4())), to(getKClass(UShortArray), UShortArraySerializer()), to(PrimitiveClasses_getInstance().n7(), serializer_12(ByteCompanionObject_instance)), to(PrimitiveClasses_getInstance().x7(), ByteArraySerializer()), to(getKClass(UByte), serializer_13(Companion_getInstance_5())), to(getKClass(UByteArray), UByteArraySerializer()), to(PrimitiveClasses_getInstance().m7(), serializer_14(BooleanCompanionObject_instance)), to(PrimitiveClasses_getInstance().v7(), BooleanArraySerializer()), to(getKClass(Unit), serializer_15(Unit_instance)), to(PrimitiveClasses_getInstance().l7(), NothingSerializer()), to(getKClass(Duration), serializer_16(Companion_getInstance()))]);
  }
}
function NamedValueEncoder() {
  TaggedEncoder.call(this);
}
protoOf(NamedValueEncoder).i48 = function (_this__u8e3s4, index) {
  return this.k48(this.j48(_this__u8e3s4, index));
};
protoOf(NamedValueEncoder).k48 = function (nestedName) {
  var tmp0_elvis_lhs = this.m48();
  return this.n48(tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs, nestedName);
};
protoOf(NamedValueEncoder).j48 = function (descriptor, index) {
  return descriptor.y3s(index);
};
protoOf(NamedValueEncoder).n48 = function (parentName, childName) {
  var tmp;
  // Inline function 'kotlin.text.isEmpty' call
  if (charSequenceLength(parentName) === 0) {
    tmp = childName;
  } else {
    tmp = parentName + '.' + childName;
  }
  return tmp;
};
function NamedValueDecoder() {
  TaggedDecoder.call(this);
}
protoOf(NamedValueDecoder).i48 = function (_this__u8e3s4, index) {
  return this.k48(this.j48(_this__u8e3s4, index));
};
protoOf(NamedValueDecoder).k48 = function (nestedName) {
  var tmp0_elvis_lhs = this.m48();
  return this.n48(tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs, nestedName);
};
protoOf(NamedValueDecoder).j48 = function (descriptor, index) {
  return descriptor.y3s(index);
};
protoOf(NamedValueDecoder).n48 = function (parentName, childName) {
  var tmp;
  // Inline function 'kotlin.text.isEmpty' call
  if (charSequenceLength(parentName) === 0) {
    tmp = childName;
  } else {
    tmp = parentName + '.' + childName;
  }
  return tmp;
};
function encodeElement($this, desc, index) {
  var tag = $this.i48(desc, index);
  $this.e49(tag);
  return true;
}
function TaggedEncoder() {
  var tmp = this;
  // Inline function 'kotlin.collections.arrayListOf' call
  tmp.l48_1 = ArrayList_init_$Create$_0();
}
protoOf(TaggedEncoder).k3r = function () {
  return EmptySerializersModule_0();
};
protoOf(TaggedEncoder).o48 = function (tag, value) {
  throw SerializationException_init_$Create$_0('Non-serializable ' + getKClassFromExpression(value) + ' is not supported by ' + getKClassFromExpression(this) + ' encoder');
};
protoOf(TaggedEncoder).p48 = function (tag) {
};
protoOf(TaggedEncoder).q48 = function (tag) {
  throw SerializationException_init_$Create$_0('null is not supported');
};
protoOf(TaggedEncoder).r48 = function (tag, value) {
  return this.o48(tag, value);
};
protoOf(TaggedEncoder).s48 = function (tag, value) {
  return this.o48(tag, value);
};
protoOf(TaggedEncoder).t48 = function (tag, value) {
  return this.o48(tag, value);
};
protoOf(TaggedEncoder).u48 = function (tag, value) {
  return this.o48(tag, value);
};
protoOf(TaggedEncoder).v48 = function (tag, value) {
  return this.o48(tag, value);
};
protoOf(TaggedEncoder).w48 = function (tag, value) {
  return this.o48(tag, value);
};
protoOf(TaggedEncoder).x48 = function (tag, value) {
  return this.o48(tag, value);
};
protoOf(TaggedEncoder).y48 = function (tag, value) {
  return this.o48(tag, new Char(value));
};
protoOf(TaggedEncoder).z48 = function (tag, value) {
  return this.o48(tag, value);
};
protoOf(TaggedEncoder).a49 = function (tag, enumDescriptor, ordinal) {
  return this.o48(tag, ordinal);
};
protoOf(TaggedEncoder).b49 = function (tag, inlineDescriptor) {
  // Inline function 'kotlin.apply' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.serialization.internal.TaggedEncoder.encodeTaggedInline.<anonymous>' call
  this.e49(tag);
  return this;
};
protoOf(TaggedEncoder).r3v = function (descriptor) {
  return this.b49(this.f49(), descriptor);
};
protoOf(TaggedEncoder).f3w = function () {
  return this.p48(this.d49());
};
protoOf(TaggedEncoder).g3v = function () {
  return this.q48(this.f49());
};
protoOf(TaggedEncoder).h3v = function (value) {
  return this.x48(this.f49(), value);
};
protoOf(TaggedEncoder).i3v = function (value) {
  return this.s48(this.f49(), value);
};
protoOf(TaggedEncoder).j3v = function (value) {
  return this.t48(this.f49(), value);
};
protoOf(TaggedEncoder).k3v = function (value) {
  return this.r48(this.f49(), value);
};
protoOf(TaggedEncoder).l3v = function (value) {
  return this.u48(this.f49(), value);
};
protoOf(TaggedEncoder).m3v = function (value) {
  return this.v48(this.f49(), value);
};
protoOf(TaggedEncoder).n3v = function (value) {
  return this.w48(this.f49(), value);
};
protoOf(TaggedEncoder).o3v = function (value) {
  return this.y48(this.f49(), value);
};
protoOf(TaggedEncoder).p3v = function (value) {
  return this.z48(this.f49(), value);
};
protoOf(TaggedEncoder).q3v = function (enumDescriptor, index) {
  return this.a49(this.f49(), enumDescriptor, index);
};
protoOf(TaggedEncoder).m3u = function (descriptor) {
  return this;
};
protoOf(TaggedEncoder).n3u = function (descriptor) {
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!this.l48_1.b1()) {
    this.f49();
  }
  this.c49(descriptor);
};
protoOf(TaggedEncoder).c49 = function (descriptor) {
};
protoOf(TaggedEncoder).s3v = function (descriptor, index, value) {
  return this.x48(this.i48(descriptor, index), value);
};
protoOf(TaggedEncoder).t3v = function (descriptor, index, value) {
  return this.s48(this.i48(descriptor, index), value);
};
protoOf(TaggedEncoder).u3v = function (descriptor, index, value) {
  return this.t48(this.i48(descriptor, index), value);
};
protoOf(TaggedEncoder).v3v = function (descriptor, index, value) {
  return this.r48(this.i48(descriptor, index), value);
};
protoOf(TaggedEncoder).w3v = function (descriptor, index, value) {
  return this.u48(this.i48(descriptor, index), value);
};
protoOf(TaggedEncoder).x3v = function (descriptor, index, value) {
  return this.v48(this.i48(descriptor, index), value);
};
protoOf(TaggedEncoder).y3v = function (descriptor, index, value) {
  return this.w48(this.i48(descriptor, index), value);
};
protoOf(TaggedEncoder).z3v = function (descriptor, index, value) {
  return this.y48(this.i48(descriptor, index), value);
};
protoOf(TaggedEncoder).a3w = function (descriptor, index, value) {
  return this.z48(this.i48(descriptor, index), value);
};
protoOf(TaggedEncoder).b3w = function (descriptor, index) {
  return this.b49(this.i48(descriptor, index), descriptor.w3s(index));
};
protoOf(TaggedEncoder).c3w = function (descriptor, index, serializer, value) {
  if (encodeElement(this, descriptor, index)) {
    this.l3r(serializer, value);
  }
};
protoOf(TaggedEncoder).d3w = function (descriptor, index, serializer, value) {
  if (encodeElement(this, descriptor, index)) {
    this.e3w(serializer, value);
  }
};
protoOf(TaggedEncoder).d49 = function () {
  return last(this.l48_1);
};
protoOf(TaggedEncoder).m48 = function () {
  return lastOrNull(this.l48_1);
};
protoOf(TaggedEncoder).e49 = function (name) {
  this.l48_1.r(name);
};
protoOf(TaggedEncoder).f49 = function () {
  var tmp;
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!this.l48_1.b1()) {
    tmp = this.l48_1.h1(get_lastIndex_0(this.l48_1));
  } else {
    throw SerializationException_init_$Create$_0('No tag in stack for requested element');
  }
  return tmp;
};
function tagBlock($this, tag, block) {
  $this.e49(tag);
  var r = block();
  if (!$this.j49_1) {
    $this.f49();
  }
  $this.j49_1 = false;
  return r;
}
function TaggedDecoder$decodeSerializableElement$lambda(this$0, $deserializer, $previousValue) {
  return function () {
    return this$0.l3u($deserializer, $previousValue);
  };
}
function TaggedDecoder$decodeNullableSerializableElement$lambda(this$0, $deserializer, $previousValue) {
  return function () {
    // Inline function 'kotlinx.serialization.encoding.decodeIfNullable' call
    var this_0 = this$0;
    var isNullabilitySupported = $deserializer.z3q().o3s();
    var tmp;
    if (isNullabilitySupported ? true : this_0.y3t()) {
      // Inline function 'kotlinx.serialization.internal.TaggedDecoder.decodeNullableSerializableElement.<anonymous>.<anonymous>' call
      tmp = this$0.l3u($deserializer, $previousValue);
    } else {
      tmp = this_0.z3t();
    }
    return tmp;
  };
}
function TaggedDecoder() {
  var tmp = this;
  // Inline function 'kotlin.collections.arrayListOf' call
  tmp.i49_1 = ArrayList_init_$Create$_0();
  this.j49_1 = false;
}
protoOf(TaggedDecoder).k3r = function () {
  return EmptySerializersModule_0();
};
protoOf(TaggedDecoder).k49 = function (tag) {
  throw SerializationException_init_$Create$_0('' + getKClassFromExpression(this) + " can't retrieve untyped values");
};
protoOf(TaggedDecoder).l49 = function (tag) {
  return true;
};
protoOf(TaggedDecoder).m49 = function (tag) {
  var tmp = this.k49(tag);
  return typeof tmp === 'boolean' ? tmp : THROW_CCE();
};
protoOf(TaggedDecoder).n49 = function (tag) {
  var tmp = this.k49(tag);
  return typeof tmp === 'number' ? tmp : THROW_CCE();
};
protoOf(TaggedDecoder).o49 = function (tag) {
  var tmp = this.k49(tag);
  return typeof tmp === 'number' ? tmp : THROW_CCE();
};
protoOf(TaggedDecoder).p49 = function (tag) {
  var tmp = this.k49(tag);
  return typeof tmp === 'number' ? tmp : THROW_CCE();
};
protoOf(TaggedDecoder).q49 = function (tag) {
  var tmp = this.k49(tag);
  return tmp instanceof Long ? tmp : THROW_CCE();
};
protoOf(TaggedDecoder).r49 = function (tag) {
  var tmp = this.k49(tag);
  return typeof tmp === 'number' ? tmp : THROW_CCE();
};
protoOf(TaggedDecoder).s49 = function (tag) {
  var tmp = this.k49(tag);
  return typeof tmp === 'number' ? tmp : THROW_CCE();
};
protoOf(TaggedDecoder).t49 = function (tag) {
  var tmp = this.k49(tag);
  return tmp instanceof Char ? tmp.ta_1 : THROW_CCE();
};
protoOf(TaggedDecoder).u49 = function (tag) {
  var tmp = this.k49(tag);
  return typeof tmp === 'string' ? tmp : THROW_CCE();
};
protoOf(TaggedDecoder).v49 = function (tag, enumDescriptor) {
  var tmp = this.k49(tag);
  return typeof tmp === 'number' ? tmp : THROW_CCE();
};
protoOf(TaggedDecoder).w49 = function (tag, inlineDescriptor) {
  // Inline function 'kotlin.apply' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.serialization.internal.TaggedDecoder.decodeTaggedInline.<anonymous>' call
  this.e49(tag);
  return this;
};
protoOf(TaggedDecoder).l3u = function (deserializer, previousValue) {
  return this.o3r(deserializer);
};
protoOf(TaggedDecoder).k3u = function (descriptor) {
  return this.w49(this.f49(), descriptor);
};
protoOf(TaggedDecoder).y3t = function () {
  var tmp0_elvis_lhs = this.m48();
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return false;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var currentTag = tmp;
  return this.l49(currentTag);
};
protoOf(TaggedDecoder).z3t = function () {
  return null;
};
protoOf(TaggedDecoder).a3u = function () {
  return this.m49(this.f49());
};
protoOf(TaggedDecoder).b3u = function () {
  return this.n49(this.f49());
};
protoOf(TaggedDecoder).c3u = function () {
  return this.o49(this.f49());
};
protoOf(TaggedDecoder).d3u = function () {
  return this.p49(this.f49());
};
protoOf(TaggedDecoder).e3u = function () {
  return this.q49(this.f49());
};
protoOf(TaggedDecoder).f3u = function () {
  return this.r49(this.f49());
};
protoOf(TaggedDecoder).g3u = function () {
  return this.s49(this.f49());
};
protoOf(TaggedDecoder).h3u = function () {
  return this.t49(this.f49());
};
protoOf(TaggedDecoder).i3u = function () {
  return this.u49(this.f49());
};
protoOf(TaggedDecoder).j3u = function (enumDescriptor) {
  return this.v49(this.f49(), enumDescriptor);
};
protoOf(TaggedDecoder).m3u = function (descriptor) {
  return this;
};
protoOf(TaggedDecoder).n3u = function (descriptor) {
};
protoOf(TaggedDecoder).o3u = function (descriptor, index) {
  return this.m49(this.i48(descriptor, index));
};
protoOf(TaggedDecoder).p3u = function (descriptor, index) {
  return this.n49(this.i48(descriptor, index));
};
protoOf(TaggedDecoder).q3u = function (descriptor, index) {
  return this.o49(this.i48(descriptor, index));
};
protoOf(TaggedDecoder).r3u = function (descriptor, index) {
  return this.p49(this.i48(descriptor, index));
};
protoOf(TaggedDecoder).s3u = function (descriptor, index) {
  return this.q49(this.i48(descriptor, index));
};
protoOf(TaggedDecoder).t3u = function (descriptor, index) {
  return this.r49(this.i48(descriptor, index));
};
protoOf(TaggedDecoder).u3u = function (descriptor, index) {
  return this.s49(this.i48(descriptor, index));
};
protoOf(TaggedDecoder).v3u = function (descriptor, index) {
  return this.t49(this.i48(descriptor, index));
};
protoOf(TaggedDecoder).w3u = function (descriptor, index) {
  return this.u49(this.i48(descriptor, index));
};
protoOf(TaggedDecoder).x3u = function (descriptor, index) {
  return this.w49(this.i48(descriptor, index), descriptor.w3s(index));
};
protoOf(TaggedDecoder).y3u = function (descriptor, index, deserializer, previousValue) {
  var tmp = this.i48(descriptor, index);
  return tagBlock(this, tmp, TaggedDecoder$decodeSerializableElement$lambda(this, deserializer, previousValue));
};
protoOf(TaggedDecoder).a3v = function (descriptor, index, deserializer, previousValue) {
  var tmp = this.i48(descriptor, index);
  return tagBlock(this, tmp, TaggedDecoder$decodeNullableSerializableElement$lambda(this, deserializer, previousValue));
};
protoOf(TaggedDecoder).m48 = function () {
  return lastOrNull(this.i49_1);
};
protoOf(TaggedDecoder).e49 = function (name) {
  this.i49_1.r(name);
};
protoOf(TaggedDecoder).f49 = function () {
  var r = this.i49_1.h1(get_lastIndex_0(this.i49_1));
  this.j49_1 = true;
  return r;
};
function get_NULL() {
  _init_properties_Tuples_kt__dz0qyd();
  return NULL;
}
var NULL;
function MapEntry(key, value) {
  this.x49_1 = key;
  this.y49_1 = value;
}
protoOf(MapEntry).k2 = function () {
  return this.x49_1;
};
protoOf(MapEntry).l2 = function () {
  return this.y49_1;
};
protoOf(MapEntry).toString = function () {
  return 'MapEntry(key=' + this.x49_1 + ', value=' + this.y49_1 + ')';
};
protoOf(MapEntry).hashCode = function () {
  var result = this.x49_1 == null ? 0 : hashCode(this.x49_1);
  result = imul(result, 31) + (this.y49_1 == null ? 0 : hashCode(this.y49_1)) | 0;
  return result;
};
protoOf(MapEntry).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof MapEntry))
    return false;
  var tmp0_other_with_cast = other instanceof MapEntry ? other : THROW_CCE();
  if (!equals(this.x49_1, tmp0_other_with_cast.x49_1))
    return false;
  if (!equals(this.y49_1, tmp0_other_with_cast.y49_1))
    return false;
  return true;
};
function MapEntrySerializer$descriptor$lambda($keySerializer, $valueSerializer) {
  return function ($this$buildSerialDescriptor) {
    $this$buildSerialDescriptor.p3r('key', $keySerializer.z3q());
    $this$buildSerialDescriptor.p3r('value', $valueSerializer.z3q());
    return Unit_instance;
  };
}
function MapEntrySerializer_0(keySerializer, valueSerializer) {
  KeyValueSerializer.call(this, keySerializer, valueSerializer);
  var tmp = this;
  var tmp_0 = MAP_getInstance();
  tmp.b4a_1 = buildSerialDescriptor('kotlin.collections.Map.Entry', tmp_0, [], MapEntrySerializer$descriptor$lambda(keySerializer, valueSerializer));
}
protoOf(MapEntrySerializer_0).z3q = function () {
  return this.b4a_1;
};
protoOf(MapEntrySerializer_0).c4a = function (_this__u8e3s4) {
  return _this__u8e3s4.k2();
};
protoOf(MapEntrySerializer_0).d4a = function (_this__u8e3s4) {
  return this.c4a((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Entry) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(MapEntrySerializer_0).e4a = function (_this__u8e3s4) {
  return _this__u8e3s4.l2();
};
protoOf(MapEntrySerializer_0).f4a = function (_this__u8e3s4) {
  return this.e4a((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Entry) : false) ? _this__u8e3s4 : THROW_CCE());
};
protoOf(MapEntrySerializer_0).g4a = function (key, value) {
  return new MapEntry(key, value);
};
function PairSerializer$descriptor$lambda($keySerializer, $valueSerializer) {
  return function ($this$buildClassSerialDescriptor) {
    $this$buildClassSerialDescriptor.p3r('first', $keySerializer.z3q());
    $this$buildClassSerialDescriptor.p3r('second', $valueSerializer.z3q());
    return Unit_instance;
  };
}
function PairSerializer_0(keySerializer, valueSerializer) {
  KeyValueSerializer.call(this, keySerializer, valueSerializer);
  var tmp = this;
  tmp.m4a_1 = buildClassSerialDescriptor('kotlin.Pair', [], PairSerializer$descriptor$lambda(keySerializer, valueSerializer));
}
protoOf(PairSerializer_0).z3q = function () {
  return this.m4a_1;
};
protoOf(PairSerializer_0).n4a = function (_this__u8e3s4) {
  return _this__u8e3s4.ue_1;
};
protoOf(PairSerializer_0).d4a = function (_this__u8e3s4) {
  return this.n4a(_this__u8e3s4 instanceof Pair ? _this__u8e3s4 : THROW_CCE());
};
protoOf(PairSerializer_0).o4a = function (_this__u8e3s4) {
  return _this__u8e3s4.ve_1;
};
protoOf(PairSerializer_0).f4a = function (_this__u8e3s4) {
  return this.o4a(_this__u8e3s4 instanceof Pair ? _this__u8e3s4 : THROW_CCE());
};
protoOf(PairSerializer_0).g4a = function (key, value) {
  return to(key, value);
};
function decodeSequentially_1($this, composite) {
  var a = composite.z3u($this.s4a_1, 0, $this.p4a_1);
  var b = composite.z3u($this.s4a_1, 1, $this.q4a_1);
  var c = composite.z3u($this.s4a_1, 2, $this.r4a_1);
  composite.n3u($this.s4a_1);
  return new Triple(a, b, c);
}
function decodeStructure($this, composite) {
  var a = get_NULL();
  var b = get_NULL();
  var c = get_NULL();
  mainLoop: while (true) {
    var index = composite.c3v($this.s4a_1);
    if (index === -1) {
      break mainLoop;
    } else {
      if (index === 0) {
        a = composite.z3u($this.s4a_1, 0, $this.p4a_1);
      } else {
        if (index === 1) {
          b = composite.z3u($this.s4a_1, 1, $this.q4a_1);
        } else {
          if (index === 2) {
            c = composite.z3u($this.s4a_1, 2, $this.r4a_1);
          } else {
            throw SerializationException_init_$Create$_0('Unexpected index ' + index);
          }
        }
      }
    }
  }
  composite.n3u($this.s4a_1);
  if (a === get_NULL())
    throw SerializationException_init_$Create$_0("Element 'first' is missing");
  if (b === get_NULL())
    throw SerializationException_init_$Create$_0("Element 'second' is missing");
  if (c === get_NULL())
    throw SerializationException_init_$Create$_0("Element 'third' is missing");
  var tmp = (a == null ? true : !(a == null)) ? a : THROW_CCE();
  var tmp_0 = (b == null ? true : !(b == null)) ? b : THROW_CCE();
  return new Triple(tmp, tmp_0, (c == null ? true : !(c == null)) ? c : THROW_CCE());
}
function TripleSerializer$descriptor$lambda(this$0) {
  return function ($this$buildClassSerialDescriptor) {
    $this$buildClassSerialDescriptor.p3r('first', this$0.p4a_1.z3q());
    $this$buildClassSerialDescriptor.p3r('second', this$0.q4a_1.z3q());
    $this$buildClassSerialDescriptor.p3r('third', this$0.r4a_1.z3q());
    return Unit_instance;
  };
}
function TripleSerializer_0(aSerializer, bSerializer, cSerializer) {
  this.p4a_1 = aSerializer;
  this.q4a_1 = bSerializer;
  this.r4a_1 = cSerializer;
  var tmp = this;
  tmp.s4a_1 = buildClassSerialDescriptor('kotlin.Triple', [], TripleSerializer$descriptor$lambda(this));
}
protoOf(TripleSerializer_0).z3q = function () {
  return this.s4a_1;
};
protoOf(TripleSerializer_0).t4a = function (encoder, value) {
  var structuredEncoder = encoder.m3u(this.s4a_1);
  structuredEncoder.c3w(this.s4a_1, 0, this.p4a_1, value.ik_1);
  structuredEncoder.c3w(this.s4a_1, 1, this.q4a_1, value.jk_1);
  structuredEncoder.c3w(this.s4a_1, 2, this.r4a_1, value.kk_1);
  structuredEncoder.n3u(this.s4a_1);
};
protoOf(TripleSerializer_0).m3r = function (encoder, value) {
  return this.t4a(encoder, value instanceof Triple ? value : THROW_CCE());
};
protoOf(TripleSerializer_0).n3r = function (decoder) {
  var composite = decoder.m3u(this.s4a_1);
  if (composite.b3v()) {
    return decodeSequentially_1(this, composite);
  }
  return decodeStructure(this, composite);
};
function KeyValueSerializer(keySerializer, valueSerializer) {
  this.h4a_1 = keySerializer;
  this.i4a_1 = valueSerializer;
}
protoOf(KeyValueSerializer).j4a = function (encoder, value) {
  var structuredEncoder = encoder.m3u(this.z3q());
  structuredEncoder.c3w(this.z3q(), 0, this.h4a_1, this.d4a(value));
  structuredEncoder.c3w(this.z3q(), 1, this.i4a_1, this.f4a(value));
  structuredEncoder.n3u(this.z3q());
};
protoOf(KeyValueSerializer).m3r = function (encoder, value) {
  return this.j4a(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
};
protoOf(KeyValueSerializer).n3r = function (decoder) {
  // Inline function 'kotlinx.serialization.encoding.decodeStructure' call
  var descriptor = this.z3q();
  var composite = decoder.m3u(descriptor);
  var tmp$ret$0;
  $l$block: {
    // Inline function 'kotlinx.serialization.internal.KeyValueSerializer.deserialize.<anonymous>' call
    if (composite.b3v()) {
      var key = composite.z3u(this.z3q(), 0, this.h4a_1);
      var value = composite.z3u(this.z3q(), 1, this.i4a_1);
      tmp$ret$0 = this.g4a(key, value);
      break $l$block;
    }
    var key_0 = get_NULL();
    var value_0 = get_NULL();
    mainLoop: while (true) {
      var idx = composite.c3v(this.z3q());
      if (idx === -1) {
        break mainLoop;
      } else {
        if (idx === 0) {
          key_0 = composite.z3u(this.z3q(), 0, this.h4a_1);
        } else {
          if (idx === 1) {
            value_0 = composite.z3u(this.z3q(), 1, this.i4a_1);
          } else {
            throw SerializationException_init_$Create$_0('Invalid index: ' + idx);
          }
        }
      }
    }
    if (key_0 === get_NULL())
      throw SerializationException_init_$Create$_0("Element 'key' is missing");
    if (value_0 === get_NULL())
      throw SerializationException_init_$Create$_0("Element 'value' is missing");
    var tmp = (key_0 == null ? true : !(key_0 == null)) ? key_0 : THROW_CCE();
    tmp$ret$0 = this.g4a(tmp, (value_0 == null ? true : !(value_0 == null)) ? value_0 : THROW_CCE());
  }
  var result = tmp$ret$0;
  composite.n3u(descriptor);
  return result;
};
var properties_initialized_Tuples_kt_3vs7ar;
function _init_properties_Tuples_kt__dz0qyd() {
  if (!properties_initialized_Tuples_kt_3vs7ar) {
    properties_initialized_Tuples_kt_3vs7ar = true;
    NULL = new Object();
  }
}
function ULongSerializer() {
  ULongSerializer_instance = this;
  this.u4a_1 = InlinePrimitiveDescriptor('kotlin.ULong', serializer_6(Companion_getInstance_0()));
}
protoOf(ULongSerializer).z3q = function () {
  return this.u4a_1;
};
protoOf(ULongSerializer).v4a = function (encoder, value) {
  var tmp = encoder.r3v(this.u4a_1);
  // Inline function 'kotlin.ULong.toLong' call
  var tmp$ret$0 = _ULong___get_data__impl__fggpzb(value);
  tmp.l3v(tmp$ret$0);
};
protoOf(ULongSerializer).m3r = function (encoder, value) {
  return this.v4a(encoder, value instanceof ULong ? value.nl_1 : THROW_CCE());
};
protoOf(ULongSerializer).w4a = function (decoder) {
  // Inline function 'kotlin.toULong' call
  var this_0 = decoder.k3u(this.u4a_1).e3u();
  return _ULong___init__impl__c78o9k(this_0);
};
protoOf(ULongSerializer).n3r = function (decoder) {
  return new ULong(this.w4a(decoder));
};
var ULongSerializer_instance;
function ULongSerializer_getInstance() {
  if (ULongSerializer_instance == null)
    new ULongSerializer();
  return ULongSerializer_instance;
}
function UIntSerializer() {
  UIntSerializer_instance = this;
  this.x4a_1 = InlinePrimitiveDescriptor('kotlin.UInt', serializer_8(IntCompanionObject_instance));
}
protoOf(UIntSerializer).z3q = function () {
  return this.x4a_1;
};
protoOf(UIntSerializer).y4a = function (encoder, value) {
  var tmp = encoder.r3v(this.x4a_1);
  // Inline function 'kotlin.UInt.toInt' call
  var tmp$ret$0 = _UInt___get_data__impl__f0vqqw(value);
  tmp.k3v(tmp$ret$0);
};
protoOf(UIntSerializer).m3r = function (encoder, value) {
  return this.y4a(encoder, value instanceof UInt ? value.bl_1 : THROW_CCE());
};
protoOf(UIntSerializer).z4a = function (decoder) {
  // Inline function 'kotlin.toUInt' call
  var this_0 = decoder.k3u(this.x4a_1).d3u();
  return _UInt___init__impl__l7qpdl(this_0);
};
protoOf(UIntSerializer).n3r = function (decoder) {
  return new UInt(this.z4a(decoder));
};
var UIntSerializer_instance;
function UIntSerializer_getInstance() {
  if (UIntSerializer_instance == null)
    new UIntSerializer();
  return UIntSerializer_instance;
}
function UShortSerializer() {
  UShortSerializer_instance = this;
  this.a4b_1 = InlinePrimitiveDescriptor('kotlin.UShort', serializer_10(ShortCompanionObject_instance));
}
protoOf(UShortSerializer).z3q = function () {
  return this.a4b_1;
};
protoOf(UShortSerializer).b4b = function (encoder, value) {
  var tmp = encoder.r3v(this.a4b_1);
  // Inline function 'kotlin.UShort.toShort' call
  var tmp$ret$0 = _UShort___get_data__impl__g0245(value);
  tmp.j3v(tmp$ret$0);
};
protoOf(UShortSerializer).m3r = function (encoder, value) {
  return this.b4b(encoder, value instanceof UShort ? value.zl_1 : THROW_CCE());
};
protoOf(UShortSerializer).c4b = function (decoder) {
  // Inline function 'kotlin.toUShort' call
  var this_0 = decoder.k3u(this.a4b_1).c3u();
  return _UShort___init__impl__jigrne(this_0);
};
protoOf(UShortSerializer).n3r = function (decoder) {
  return new UShort(this.c4b(decoder));
};
var UShortSerializer_instance;
function UShortSerializer_getInstance() {
  if (UShortSerializer_instance == null)
    new UShortSerializer();
  return UShortSerializer_instance;
}
function UByteSerializer() {
  UByteSerializer_instance = this;
  this.d4b_1 = InlinePrimitiveDescriptor('kotlin.UByte', serializer_12(ByteCompanionObject_instance));
}
protoOf(UByteSerializer).z3q = function () {
  return this.d4b_1;
};
protoOf(UByteSerializer).e4b = function (encoder, value) {
  var tmp = encoder.r3v(this.d4b_1);
  // Inline function 'kotlin.UByte.toByte' call
  var tmp$ret$0 = _UByte___get_data__impl__jof9qr(value);
  tmp.i3v(tmp$ret$0);
};
protoOf(UByteSerializer).m3r = function (encoder, value) {
  return this.e4b(encoder, value instanceof UByte ? value.pk_1 : THROW_CCE());
};
protoOf(UByteSerializer).f4b = function (decoder) {
  // Inline function 'kotlin.toUByte' call
  var this_0 = decoder.k3u(this.d4b_1).b3u();
  return _UByte___init__impl__g9hnc4(this_0);
};
protoOf(UByteSerializer).n3r = function (decoder) {
  return new UByte(this.f4b(decoder));
};
var UByteSerializer_instance;
function UByteSerializer_getInstance() {
  if (UByteSerializer_instance == null)
    new UByteSerializer();
  return UByteSerializer_instance;
}
function get_EmptySerializersModuleLegacyJs() {
  _init_properties_SerializersModule_kt__u78ha3();
  return EmptySerializersModule;
}
var EmptySerializersModule;
function SerializersModule() {
}
protoOf(SerializersModule).l3s = function (kClass, typeArgumentsSerializers, $super) {
  typeArgumentsSerializers = typeArgumentsSerializers === VOID ? emptyList() : typeArgumentsSerializers;
  return $super === VOID ? this.y3q(kClass, typeArgumentsSerializers) : $super.y3q.call(this, kClass, typeArgumentsSerializers);
};
function SerialModuleImpl(class2ContextualFactory, polyBase2Serializers, polyBase2DefaultSerializerProvider, polyBase2NamedSerializers, polyBase2DefaultDeserializerProvider) {
  SerializersModule.call(this);
  this.h4b_1 = class2ContextualFactory;
  this.i4b_1 = polyBase2Serializers;
  this.j4b_1 = polyBase2DefaultSerializerProvider;
  this.k4b_1 = polyBase2NamedSerializers;
  this.l4b_1 = polyBase2DefaultDeserializerProvider;
}
protoOf(SerialModuleImpl).l3w = function (baseClass, value) {
  if (!baseClass.t6(value))
    return null;
  var tmp0_safe_receiver = this.i4b_1.s2(baseClass);
  var tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.s2(getKClassFromExpression(value));
  var registered = (!(tmp == null) ? isInterface(tmp, SerializationStrategy) : false) ? tmp : null;
  if (!(registered == null))
    return registered;
  var tmp_0 = this.j4b_1.s2(baseClass);
  var tmp1_safe_receiver = (!(tmp_0 == null) ? typeof tmp_0 === 'function' : false) ? tmp_0 : null;
  return tmp1_safe_receiver == null ? null : tmp1_safe_receiver(value);
};
protoOf(SerialModuleImpl).k3w = function (baseClass, serializedClassName) {
  var tmp0_safe_receiver = this.k4b_1.s2(baseClass);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.collections.get' call
    tmp = (isInterface(tmp0_safe_receiver, Map) ? tmp0_safe_receiver : THROW_CCE()).s2(serializedClassName);
  }
  var tmp_0 = tmp;
  var registered = (!(tmp_0 == null) ? isInterface(tmp_0, KSerializer) : false) ? tmp_0 : null;
  if (!(registered == null))
    return registered;
  var tmp_1 = this.l4b_1.s2(baseClass);
  var tmp1_safe_receiver = (!(tmp_1 == null) ? typeof tmp_1 === 'function' : false) ? tmp_1 : null;
  return tmp1_safe_receiver == null ? null : tmp1_safe_receiver(serializedClassName);
};
protoOf(SerialModuleImpl).y3q = function (kClass, typeArgumentsSerializers) {
  var tmp0_safe_receiver = this.h4b_1.s2(kClass);
  var tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.m4b(typeArgumentsSerializers);
  return (tmp == null ? true : isInterface(tmp, KSerializer)) ? tmp : null;
};
protoOf(SerialModuleImpl).g4b = function (collector) {
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var tmp0_iterator = this.h4b_1.h2().u();
  while (tmp0_iterator.v()) {
    var element = tmp0_iterator.w();
    // Inline function 'kotlinx.serialization.modules.SerialModuleImpl.dumpTo.<anonymous>' call
    // Inline function 'kotlin.collections.component1' call
    var kclass = element.k2();
    // Inline function 'kotlin.collections.component2' call
    var serial = element.l2();
    if (serial instanceof Argless) {
      var tmp = isInterface(kclass, KClass) ? kclass : THROW_CCE();
      var tmp_0 = serial.p4b_1;
      collector.q4b(tmp, isInterface(tmp_0, KSerializer) ? tmp_0 : THROW_CCE());
    } else {
      if (serial instanceof WithTypeArguments) {
        collector.o4b(kclass, serial.n4b_1);
      }
    }
  }
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var tmp0_iterator_0 = this.i4b_1.h2().u();
  while (tmp0_iterator_0.v()) {
    var element_0 = tmp0_iterator_0.w();
    // Inline function 'kotlinx.serialization.modules.SerialModuleImpl.dumpTo.<anonymous>' call
    // Inline function 'kotlin.collections.component1' call
    var baseClass = element_0.k2();
    // Inline function 'kotlin.collections.component2' call
    var classMap = element_0.l2();
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var tmp0_iterator_1 = classMap.h2().u();
    while (tmp0_iterator_1.v()) {
      var element_1 = tmp0_iterator_1.w();
      // Inline function 'kotlinx.serialization.modules.SerialModuleImpl.dumpTo.<anonymous>.<anonymous>' call
      // Inline function 'kotlin.collections.component1' call
      var actualClass = element_1.k2();
      // Inline function 'kotlin.collections.component2' call
      var serializer = element_1.l2();
      var tmp_1 = isInterface(baseClass, KClass) ? baseClass : THROW_CCE();
      var tmp_2 = isInterface(actualClass, KClass) ? actualClass : THROW_CCE();
      // Inline function 'kotlinx.serialization.internal.cast' call
      var tmp$ret$9 = isInterface(serializer, KSerializer) ? serializer : THROW_CCE();
      collector.r4b(tmp_1, tmp_2, tmp$ret$9);
    }
  }
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var tmp0_iterator_2 = this.j4b_1.h2().u();
  while (tmp0_iterator_2.v()) {
    var element_2 = tmp0_iterator_2.w();
    // Inline function 'kotlinx.serialization.modules.SerialModuleImpl.dumpTo.<anonymous>' call
    // Inline function 'kotlin.collections.component1' call
    var baseClass_0 = element_2.k2();
    // Inline function 'kotlin.collections.component2' call
    var provider = element_2.l2();
    var tmp_3 = isInterface(baseClass_0, KClass) ? baseClass_0 : THROW_CCE();
    collector.s4b(tmp_3, typeof provider === 'function' ? provider : THROW_CCE());
  }
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var tmp0_iterator_3 = this.l4b_1.h2().u();
  while (tmp0_iterator_3.v()) {
    var element_3 = tmp0_iterator_3.w();
    // Inline function 'kotlinx.serialization.modules.SerialModuleImpl.dumpTo.<anonymous>' call
    // Inline function 'kotlin.collections.component1' call
    var baseClass_1 = element_3.k2();
    // Inline function 'kotlin.collections.component2' call
    var provider_0 = element_3.l2();
    var tmp_4 = isInterface(baseClass_1, KClass) ? baseClass_1 : THROW_CCE();
    collector.t4b(tmp_4, typeof provider_0 === 'function' ? provider_0 : THROW_CCE());
  }
};
function Argless() {
}
function WithTypeArguments() {
}
function ContextualProvider() {
}
var properties_initialized_SerializersModule_kt_fjigjn;
function _init_properties_SerializersModule_kt__u78ha3() {
  if (!properties_initialized_SerializersModule_kt_fjigjn) {
    properties_initialized_SerializersModule_kt_fjigjn = true;
    EmptySerializersModule = new SerialModuleImpl(emptyMap(), emptyMap(), emptyMap(), emptyMap(), emptyMap());
  }
}
function EmptySerializersModule_0() {
  return get_EmptySerializersModuleLegacyJs();
}
function SerializersModuleCollector$contextual$lambda($serializer) {
  return function (it) {
    return $serializer;
  };
}
function SerializersModuleCollector() {
}
function SerializableWith(serializer) {
  this.u4b_1 = serializer;
}
protoOf(SerializableWith).equals = function (other) {
  if (!(other instanceof SerializableWith))
    return false;
  var tmp0_other_with_cast = other instanceof SerializableWith ? other : THROW_CCE();
  if (!this.u4b_1.equals(tmp0_other_with_cast.u4b_1))
    return false;
  return true;
};
protoOf(SerializableWith).hashCode = function () {
  return imul(getStringHashCode('serializer'), 127) ^ this.u4b_1.hashCode();
};
protoOf(SerializableWith).toString = function () {
  return '@kotlinx.serialization.SerializableWith(serializer=' + this.u4b_1 + ')';
};
function createCache(factory) {
  return new createCache$1(factory);
}
function createParametrizedCache(factory) {
  return new createParametrizedCache$1(factory);
}
function compiledSerializerImpl(_this__u8e3s4) {
  var tmp1_elvis_lhs = constructSerializerForGivenTypeArgs(_this__u8e3s4, []);
  var tmp;
  if (tmp1_elvis_lhs == null) {
    var tmp_0;
    if (_this__u8e3s4 === PrimitiveClasses_getInstance().l7()) {
      tmp_0 = NothingSerializer_getInstance();
    } else {
      // Inline function 'kotlin.js.asDynamic' call
      var tmp0_safe_receiver = get_js(_this__u8e3s4).Companion;
      tmp_0 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.serializer();
    }
    var tmp_1 = tmp_0;
    tmp = (!(tmp_1 == null) ? isInterface(tmp_1, KSerializer) : false) ? tmp_1 : null;
  } else {
    tmp = tmp1_elvis_lhs;
  }
  return tmp;
}
function platformSpecificSerializerNotRegistered(_this__u8e3s4) {
  throw SerializationException_init_$Create$_0(notRegisteredMessage(_this__u8e3s4) + 'To get enum serializer on Kotlin/JS, it should be annotated with @Serializable annotation.');
}
function isReferenceArray(rootClass) {
  return rootClass.equals(PrimitiveClasses_getInstance().s7());
}
function constructSerializerForGivenTypeArgs(_this__u8e3s4, args) {
  var tmp;
  try {
    // Inline function 'kotlin.reflect.findAssociatedObject' call
    var assocObject = findAssociatedObject(_this__u8e3s4, getKClass(SerializableWith));
    var tmp_0;
    if (!(assocObject == null) ? isInterface(assocObject, KSerializer) : false) {
      tmp_0 = (!(assocObject == null) ? isInterface(assocObject, KSerializer) : false) ? assocObject : THROW_CCE();
    } else {
      if (!(assocObject == null) ? isInterface(assocObject, SerializerFactory) : false) {
        var tmp_1 = assocObject.w42(args.slice());
        tmp_0 = isInterface(tmp_1, KSerializer) ? tmp_1 : THROW_CCE();
      } else {
        if (get_isInterface(_this__u8e3s4)) {
          tmp_0 = new PolymorphicSerializer(_this__u8e3s4);
        } else {
          tmp_0 = null;
        }
      }
    }
    tmp = tmp_0;
  } catch ($p) {
    var tmp_2;
    var e = $p;
    tmp_2 = null;
    tmp = tmp_2;
  }
  return tmp;
}
function get_isInterface(_this__u8e3s4) {
  // Inline function 'kotlin.js.asDynamic' call
  var tmp0_safe_receiver = get_js(_this__u8e3s4).$metadata$;
  return (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.kind) == 'interface';
}
function toNativeArrayImpl(_this__u8e3s4, eClass) {
  // Inline function 'kotlin.collections.toTypedArray' call
  return copyToArray(_this__u8e3s4);
}
function getChecked(_this__u8e3s4, index) {
  if (!(0 <= index ? index <= (_this__u8e3s4.length - 1 | 0) : false))
    throw IndexOutOfBoundsException_init_$Create$('Index ' + index + ' out of bounds ' + get_indices(_this__u8e3s4));
  return _this__u8e3s4[index];
}
function getChecked_0(_this__u8e3s4, index) {
  if (!(0 <= index ? index <= (_this__u8e3s4.length - 1 | 0) : false))
    throw IndexOutOfBoundsException_init_$Create$('Index ' + index + ' out of bounds ' + get_indices_0(_this__u8e3s4));
  return _this__u8e3s4[index];
}
function createCache$1($factory) {
  this.v4b_1 = $factory;
}
protoOf(createCache$1).m3s = function (key) {
  return this.v4b_1(key);
};
function createParametrizedCache$1($factory) {
  this.w4b_1 = $factory;
}
protoOf(createParametrizedCache$1).n3s = function (key, types) {
  // Inline function 'kotlin.runCatching' call
  var tmp;
  try {
    // Inline function 'kotlin.Companion.success' call
    // Inline function 'kotlinx.serialization.internal.<no name provided>.get.<anonymous>' call
    var value = this.w4b_1(key, types);
    tmp = _Result___init__impl__xyqfz8(value);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Error) {
      var e = $p;
      // Inline function 'kotlin.Companion.failure' call
      tmp_0 = _Result___init__impl__xyqfz8(createFailure(e));
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  return tmp;
};
//region block: post-declaration
protoOf(SerialDescriptorImpl).o3s = get_isNullable;
protoOf(SerialDescriptorImpl).t3s = get_isInline;
protoOf(AbstractDecoder).z3u = decodeSerializableElement$default;
protoOf(AbstractDecoder).o3r = decodeSerializableValue;
protoOf(AbstractDecoder).b3v = decodeSequentially;
protoOf(AbstractDecoder).d3v = decodeCollectionSize;
protoOf(AbstractEncoder).f3w = encodeNotNullMark;
protoOf(AbstractEncoder).g3w = beginCollection;
protoOf(AbstractEncoder).l3r = encodeSerializableValue;
protoOf(AbstractEncoder).e3w = encodeNullableSerializableValue;
protoOf(AbstractEncoder).h3w = shouldEncodeElementDefault;
protoOf(ListLikeDescriptor).o3s = get_isNullable;
protoOf(ListLikeDescriptor).t3s = get_isInline;
protoOf(ListLikeDescriptor).a3r = get_annotations;
protoOf(MapLikeDescriptor).o3s = get_isNullable;
protoOf(MapLikeDescriptor).t3s = get_isInline;
protoOf(MapLikeDescriptor).a3r = get_annotations;
protoOf(PluginGeneratedSerialDescriptor).o3s = get_isNullable;
protoOf(PluginGeneratedSerialDescriptor).t3s = get_isInline;
protoOf(InlinePrimitiveDescriptor$1).m42 = typeParametersSerializers;
protoOf(NothingSerialDescriptor).o3s = get_isNullable;
protoOf(NothingSerialDescriptor).t3s = get_isInline;
protoOf(NothingSerialDescriptor).a3r = get_annotations;
protoOf(PrimitiveSerialDescriptor_0).o3s = get_isNullable;
protoOf(PrimitiveSerialDescriptor_0).t3s = get_isInline;
protoOf(PrimitiveSerialDescriptor_0).a3r = get_annotations;
protoOf(TaggedEncoder).g3w = beginCollection;
protoOf(TaggedEncoder).l3r = encodeSerializableValue;
protoOf(TaggedEncoder).e3w = encodeNullableSerializableValue;
protoOf(TaggedEncoder).h3w = shouldEncodeElementDefault;
protoOf(TaggedDecoder).z3u = decodeSerializableElement$default;
protoOf(TaggedDecoder).o3r = decodeSerializableValue;
protoOf(TaggedDecoder).b3v = decodeSequentially;
protoOf(TaggedDecoder).d3v = decodeCollectionSize;
//endregion
//region block: init
Companion_instance_0 = new Companion();
//endregion
//region block: exports
export {
  SealedClassSerializer_init_$Create$ as SealedClassSerializer_init_$Create$36ciaynfdyjkr,
  SerializationException_init_$Init$_0 as SerializationException_init_$Init$2mbwpyyvgkydo,
  SerializationException_init_$Create$_0 as SerializationException_init_$Create$1byppqmdb64jn,
  UnknownFieldException_init_$Create$ as UnknownFieldException_init_$Create$1mnsp66c6fnup,
  OPEN_getInstance as OPEN_getInstance3ec6az8uwus55,
  SEALED_getInstance as SEALED_getInstance3nsev85ow9059,
  STRING_getInstance as STRING_getInstance2ou4lro9xn2qn,
  CONTEXTUAL_getInstance as CONTEXTUAL_getInstance1845118lbzky0,
  ENUM_getInstance as ENUM_getInstance22lfbrqor0c0a,
  CLASS_getInstance as CLASS_getInstance14ex35co4jkrb,
  LIST_getInstance as LIST_getInstancey7k5h8d5cvxt,
  MAP_getInstance as MAP_getInstance3s1t6byguxmp9,
  OBJECT_getInstance as OBJECT_getInstance26229tfe4t547,
  Companion_instance_0 as Companion_instance2e54edlpusznp,
  BooleanSerializer_getInstance as BooleanSerializer_getInstance1t8habeqgiyq1,
  ByteArraySerializer_getInstance as ByteArraySerializer_getInstance1p0ix35e82iv6,
  DoubleSerializer_getInstance as DoubleSerializer_getInstance3da4hv5ndgjlx,
  FloatSerializer_getInstance as FloatSerializer_getInstance2fspe61zbqree,
  IntSerializer_getInstance as IntSerializer_getInstance2q7s8kvk1il5u,
  LongSerializer_getInstance as LongSerializer_getInstance194e4t3ow5wjs,
  StringSerializer_getInstance as StringSerializer_getInstance2wffkbpdux3h9,
  ByteArraySerializer as ByteArraySerializersn06x87bo7h0,
  ListSerializer as ListSerializer1hxuk9dx5n9du,
  MapSerializer as MapSerializer11kmegt3g5c1g,
  NothingSerializer as NothingSerializer3oixyyf77l4xt,
  SetSerializer as SetSerializert3lb0yy9iftr,
  get_nullable as get_nullable197rfua9r7fsz,
  serializer_2 as serializer1x79l67jvwntn,
  serializer_11 as serializer1q7c5q67ysppr,
  serializer_9 as serializer3ikrxnm8b29d6,
  serializer_13 as serializer36584sjyg5661,
  serializer_7 as serializer2lw83vwvpnyms,
  PolymorphicKind as PolymorphicKindla9gurooefwb,
  PrimitiveKind as PrimitiveKindndgbuh6is7ze,
  PrimitiveSerialDescriptor as PrimitiveSerialDescriptor3egfp53lutxj2,
  get_annotations as get_annotationshjxdbdcl8kmv,
  get_isInline as get_isInline5x26qrhi9qs6,
  get_isNullable as get_isNullable36pbikm8xb7bz,
  SerialDescriptor as SerialDescriptor2pelqekb5ic3a,
  ENUM as ENUMlmq49cvwy4ow,
  buildClassSerialDescriptor as buildClassSerialDescriptors2a6xdp6mrtw,
  buildSerialDescriptor as buildSerialDescriptor2873qmkp8r2ib,
  getContextualDescriptor as getContextualDescriptor2n1gf3b895yb8,
  AbstractDecoder as AbstractDecoder35guh02ubh2hm,
  AbstractEncoder as AbstractEncoder2gxtu3xmy3f8j,
  CompositeDecoder as CompositeDecoder2tzm7wpwkr0og,
  CompositeEncoder as CompositeEncoderknecpkexzn3v,
  Decoder as Decoder23nde051s631g,
  Encoder as Encoderqvmrpqtq8hnu,
  AbstractPolymorphicSerializer as AbstractPolymorphicSerializer1ccxwp48nfy58,
  ArrayListSerializer as ArrayListSerializer7k5wnrulb3y6,
  ElementMarker as ElementMarker33ojvsajwmzts,
  typeParametersSerializers as typeParametersSerializers2likxjr48tr7y,
  GeneratedSerializer as GeneratedSerializer1f7t7hssdd2ws,
  InlineClassDescriptor as InlineClassDescriptor2odlvyasjrmr0,
  InlinePrimitiveDescriptor as InlinePrimitiveDescriptor3i6ccn1a4fw94,
  LinkedHashMapSerializer as LinkedHashMapSerializermaoj2nyji7op,
  NamedValueDecoder as NamedValueDecoderzk26ztf92xbq,
  NamedValueEncoder as NamedValueEncoder1lca9edk1lf89,
  PluginGeneratedSerialDescriptor as PluginGeneratedSerialDescriptorqdzeg5asqhfg,
  SerializerFactory as SerializerFactory1qv9hivitncuv,
  createSimpleEnumSerializer as createSimpleEnumSerializer2guioz11kk1m0,
  jsonCachedSerialNames as jsonCachedSerialNameslxufy2gu43jt,
  throwMissingFieldException as throwMissingFieldException2cmke0v3ynf14,
  EmptySerializersModule_0 as EmptySerializersModule991ju6pz9b79,
  contextual as contextual3hpp1gupsu4al,
  SerializersModuleCollector as SerializersModuleCollector3dddz14wd7brg,
  BinaryFormat as BinaryFormat3f3aelhmz0ro1,
  ContextualSerializer as ContextualSerializer1uidivg94sh5v,
  DeserializationStrategy as DeserializationStrategy1z3z5pj9f7zc8,
  KSerializer as KSerializerzf77vz1967fq,
  MissingFieldException as MissingFieldException24tqif29emcmi,
  SealedClassSerializer as SealedClassSerializeriwipiibk55zc,
  SerializationException as SerializationExceptioneqrdve3ts2n9,
  SerializationStrategy as SerializationStrategyh6ouydnm6hci,
  StringFormat as StringFormat2r2ka8mzcb3mi,
  findPolymorphicSerializer_0 as findPolymorphicSerializer1nm87hvemahcj,
  findPolymorphicSerializer as findPolymorphicSerializerk638ixyjovk5,
  serializerOrNull_0 as serializerOrNull31x2b6nu6gruj,
  serializer_1 as serializer1rka18p0rjk4x,
  serializer_0 as serializer1i4e9ym37oxmo,
};
//endregion

//# sourceMappingURL=kotlinx-serialization-kotlinx-serialization-core.mjs.map
