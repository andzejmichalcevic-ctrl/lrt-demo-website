import {
  Unit_instance1fbcbse1fwigr as Unit_instance,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  toString1pkumu07cwy4m as toString,
  IllegalArgumentException_init_$Create$310sysrobvll9 as IllegalArgumentException_init_$Create$,
  toLongw1zpgk99d84b as toLong,
  IllegalStateException_init_$Create$3ib9qa3pip8n4 as IllegalStateException_init_$Create$,
  CoroutineImpl2sn3kjnwmfr10 as CoroutineImpl,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  protoOf180f3jzyo7rfj as protoOf,
  classMetawt99a3kyl3us as classMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  Long2qws0ah9gnpki as Long,
  VOID7hggqo3abtya as VOID,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  CancellationException_init_$Create$tastk7hwpe6q as CancellationException_init_$Create$,
  KMutableProperty11e8g1gb0ecb9j as KMutableProperty1,
  getPropertyCallableRef1ajb9in178r5r as getPropertyCallableRef,
  Companion_getInstance3gn12jgnf4xoo as Companion_getInstance,
  CancellationException3b36o9qz53rgr as CancellationException,
  CancellationException_init_$Init$n55z32xt5rdh as CancellationException_init_$Init$,
  captureStack1fzi4aczwc4hg as captureStack,
  EmptyCoroutineContext_getInstance31fow51ayy30t as EmptyCoroutineContext_getInstance,
  interfaceMeta1u1l5puptm1ve as interfaceMeta,
  isInterface3d6p8outrmvmk as isInterface,
  equals2au1ep9vhcato as equals,
  IntCompanionObject_instance3tw56cgyd5vup as IntCompanionObject_instance,
  StringBuilder_init_$Create$23o1ixl6cos5l as StringBuilder_init_$Create$,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  objectMeta213120oau977m as objectMeta,
  hashCodeq5arwsb9dgti as hashCode,
  toString1h6jjoch8cjt8 as toString_0,
  objectCreate1ve4bgxiu4x98 as objectCreate,
  Exceptiondt2hlxn7j7vw as Exception,
  Exception_init_$Init$32vb8wlewqrmh as Exception_init_$Init$,
  numberToChar93r9buh19yek as numberToChar,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  coerceAtMost322komnqp70ag as coerceAtMost,
  Char__toInt_impl_vasixd2xlaiz5u3itpv as Char__toInt_impl_vasixd,
  toByte4i43936u611k as toByte,
  _UShort___get_data__impl__g02459z5yfs6z0kj0 as _UShort___get_data__impl__g0245,
  UnsupportedOperationException_init_$Create$1j11kynu3hen2 as UnsupportedOperationException_init_$Create$,
  toShort36kaw0zjdq3ex as toShort,
  _UShort___init__impl__jigrne3h2nm35iaibum as _UShort___init__impl__jigrne,
  Companion_getInstance2du03jiluw9jj as Companion_getInstance_0,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  isLowSurrogateujxcv7hjn4ma as isLowSurrogate,
  isHighSurrogate11jfjw70ar0zf as isHighSurrogate,
  coerceAtMostmgknbongtqt as coerceAtMost_0,
  lazy2hsh8ze7j6ikd as lazy,
  KProperty1ca4yb4wlo496 as KProperty1,
  IndexOutOfBoundsException_init_$Create$jb51qtvf74or as IndexOutOfBoundsException_init_$Create$,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  replaceqbix900hl8kl as replace,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  extendThrowable112s72v177bbq as extendThrowable,
  charSequenceSubSequence1iwpdba8s3jc7 as charSequenceSubSequence,
  IndexOutOfBoundsException_init_$Create$2g34kn9hzyp4u as IndexOutOfBoundsException_init_$Create$_0,
  Exception_init_$Init$2fx1sms2m4tu1 as Exception_init_$Init$_0,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  trim11nh7r46at6sx as trim,
  decodeToString1x4faah2liw2p as decodeToString,
  setOf45ia9pnfhe90 as setOf,
  fillArrayVali8eppxapiek4 as fillArrayVal,
} from './kotlin-kotlin-stdlib.mjs';
import {
  atomic$ref$130aurmcwdfdf1 as atomic$ref$1,
  atomic$long$129k9zwo6n9ogd as atomic$long$1,
  atomic$int$11d5swdyn6j0pu as atomic$int$1,
} from './kotlinx-atomicfu.mjs';
import {
  CoroutineScopefcb5f5dwqcas as CoroutineScope,
  cancel$default2y9qiqa2pd5sh as cancel$default,
  invokeOnCompletion$default32r7l1ykbkzvm as invokeOnCompletion$default,
  Job29shfjfygy86k as Job,
  Key_getInstance2js7sv2agqob1 as Key_getInstance,
  launch1c91vkjzdi9sd as launch,
  Key_instance2tirv2rj82ml4 as Key_instance,
  Dispatchers_getInstanceitgtkvqfcnx3 as Dispatchers_getInstance,
  Job13y4jkazwjho0 as Job_0,
} from './kotlinx-coroutines-core.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
setMetadataFor($awaitAtLeastNBytesAvailableForWriteCOROUTINE$0, '$awaitAtLeastNBytesAvailableForWriteCOROUTINE$0', classMeta, CoroutineImpl);
setMetadataFor($awaitAtLeastNBytesAvailableForReadCOROUTINE$1, '$awaitAtLeastNBytesAvailableForReadCOROUTINE$1', classMeta, CoroutineImpl);
setMetadataFor($writePacketCOROUTINE$8, '$writePacketCOROUTINE$8', classMeta, CoroutineImpl);
setMetadataFor($writeFullyCOROUTINE$9, '$writeFullyCOROUTINE$9', classMeta, CoroutineImpl);
setMetadataFor($writeFullyCOROUTINE$10, '$writeFullyCOROUTINE$10', classMeta, CoroutineImpl);
setMetadataFor($readRemainingCOROUTINE$26, '$readRemainingCOROUTINE$26', classMeta, CoroutineImpl);
setMetadataFor($readRemainingSuspendCOROUTINE$27, '$readRemainingSuspendCOROUTINE$27', classMeta, CoroutineImpl);
setMetadataFor($readAvailableCOROUTINE$30, '$readAvailableCOROUTINE$30', classMeta, CoroutineImpl);
setMetadataFor($readAvailableCOROUTINE$33, '$readAvailableCOROUTINE$33', classMeta, CoroutineImpl);
setMetadataFor($awaitInternalAtLeast1COROUTINE$38, '$awaitInternalAtLeast1COROUTINE$38', classMeta, CoroutineImpl);
setMetadataFor($awaitSuspendCOROUTINE$39, '$awaitSuspendCOROUTINE$39', classMeta, CoroutineImpl);
setMetadataFor($discardCOROUTINE$40, '$discardCOROUTINE$40', classMeta, CoroutineImpl);
setMetadataFor($discardSuspendCOROUTINE$41, '$discardSuspendCOROUTINE$41', classMeta, CoroutineImpl);
function readRemaining$default(limit, $completion, $super) {
  var tmp;
  if (limit === VOID) {
    Companion_getInstance();
    tmp = new Long(-1, 2147483647);
  } else {
    tmp = limit;
  }
  limit = tmp;
  return $super === VOID ? this.b1l(limit, $completion) : $super.b1l.call(this, limit, $completion);
}
setMetadataFor(ByteReadChannel_1, 'ByteReadChannel', interfaceMeta, VOID, VOID, VOID, VOID, VOID, [3, 1, 2, 0, 5]);
setMetadataFor(ByteChannelSequentialBase, 'ByteChannelSequentialBase', classMeta, VOID, [ByteReadChannel_1], VOID, VOID, VOID, [1, 3, 0, 2, 5]);
setMetadataFor(ClosedWriteChannelException, 'ClosedWriteChannelException', classMeta, CancellationException);
setMetadataFor(CloseElement, 'CloseElement', classMeta);
setMetadataFor(WriterScope, 'WriterScope', interfaceMeta, VOID, [CoroutineScope]);
setMetadataFor(ChannelJob, 'ChannelJob', classMeta, VOID, [Job], VOID, VOID, VOID, [0]);
setMetadataFor(ChannelScope, 'ChannelScope', classMeta, VOID, [CoroutineScope, WriterScope]);
setMetadataFor(launchChannel$slambda, 'launchChannel$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(Companion, 'Companion', objectMeta);
setMetadataFor(Buffer, 'Buffer', classMeta);
setMetadataFor(InsufficientSpaceException, 'InsufficientSpaceException', classMeta, Exception, VOID, InsufficientSpaceException);
setMetadataFor(Closeable, 'Closeable', interfaceMeta);
function close() {
  this.mp();
}
setMetadataFor(ObjectPool, 'ObjectPool', interfaceMeta, VOID, [Closeable]);
setMetadataFor(DefaultPool, 'DefaultPool', classMeta, VOID, [ObjectPool]);
setMetadataFor(DefaultBufferPool, 'DefaultBufferPool', classMeta, DefaultPool, VOID, DefaultBufferPool);
setMetadataFor(Output, 'Output', classMeta, VOID, [Closeable]);
setMetadataFor(BytePacketBuilder, 'BytePacketBuilder', classMeta, Output, VOID, BytePacketBuilder);
setMetadataFor(Companion_0, 'Companion', objectMeta);
setMetadataFor(Input, 'Input', classMeta, VOID, [Closeable]);
setMetadataFor(ByteReadPacket, 'ByteReadPacket', classMeta, Input);
setMetadataFor(Companion_1, 'Companion', objectMeta);
setMetadataFor(ChunkBuffer$Companion$EmptyPool$1, VOID, classMeta, VOID, [ObjectPool]);
setMetadataFor(NoPoolImpl, 'NoPoolImpl', classMeta, VOID, [ObjectPool]);
setMetadataFor(ChunkBuffer$Companion$NoPool$1, VOID, classMeta, NoPoolImpl);
setMetadataFor(ChunkBuffer$Companion$NoPoolManuallyManaged$1, VOID, classMeta, NoPoolImpl);
setMetadataFor(Companion_2, 'Companion', objectMeta);
setMetadataFor(ChunkBuffer, 'ChunkBuffer', classMeta, Buffer);
setMetadataFor(MalformedUTF8InputException, 'MalformedUTF8InputException', classMeta, Exception);
setMetadataFor($sleepCOROUTINE$52, '$sleepCOROUTINE$52', classMeta, CoroutineImpl);
setMetadataFor($trySuspendCOROUTINE$53, '$trySuspendCOROUTINE$53', classMeta, CoroutineImpl);
setMetadataFor(AwaitingSlot, 'AwaitingSlot', classMeta, VOID, VOID, AwaitingSlot, VOID, VOID, [1]);
setMetadataFor($copyToSequentialImplCOROUTINE$54, '$copyToSequentialImplCOROUTINE$54', classMeta, CoroutineImpl);
setMetadataFor($copyToTailCOROUTINE$55, '$copyToTailCOROUTINE$55', classMeta, CoroutineImpl);
setMetadataFor(ByteArrayPool$1, VOID, classMeta, DefaultPool);
setMetadataFor(ByteChannelJS, 'ByteChannelJS', classMeta, ByteChannelSequentialBase, VOID, VOID, VOID, VOID, [3, 1, 0, 2, 5]);
setMetadataFor(Companion_3, 'Companion', objectMeta);
setMetadataFor(DefaultAllocator, 'DefaultAllocator', objectMeta);
setMetadataFor(Companion_4, 'Companion', objectMeta);
setMetadataFor(Memory, 'Memory', classMeta);
setMetadataFor(Companion_5, 'Companion', objectMeta);
setMetadataFor(Charset, 'Charset', classMeta);
setMetadataFor(Charsets, 'Charsets', objectMeta);
setMetadataFor(MalformedInputException, 'MalformedInputException', classMeta, Error);
setMetadataFor(CharsetDecoder, 'CharsetDecoder', classMeta);
setMetadataFor(CharsetEncoder, 'CharsetEncoder', classMeta);
setMetadataFor(CharsetImpl, 'CharsetImpl', classMeta, Charset);
setMetadataFor(CharsetEncoderImpl, 'CharsetEncoderImpl', classMeta, CharsetEncoder);
setMetadataFor(CharsetDecoderImpl, 'CharsetDecoderImpl', classMeta, CharsetDecoder);
setMetadataFor(DecodeBufferResult, 'DecodeBufferResult', classMeta);
setMetadataFor(IOException, 'IOException', classMeta, Exception);
setMetadataFor(EOFException, 'EOFException', classMeta, IOException);
setMetadataFor(toKtor$1, VOID, classMeta);
setMetadataFor(TextDecoderFallback, 'TextDecoderFallback', classMeta);
//endregion
function ByteReadChannel(content) {
  return ByteReadChannel_0(content, 0, content.length);
}
function _get_isCancelled__nhbn6y($this) {
  var tmp0_safe_receiver = $this.o1c_1.kotlinx$atomicfu$value;
  return !((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.w1c_1) == null);
}
function _set_lastReadAvailable__98ukjs($this, _set____db54di) {
  var this_0 = $this.r1c_1;
  lastReadAvailable$factory();
  this_0.kotlinx$atomicfu$value = _set____db54di;
  return Unit_instance;
}
function _get_lastReadAvailable__cgybqk($this) {
  // Inline function 'kotlinx.atomicfu.AtomicInt.getValue' call
  var this_0 = $this.r1c_1;
  lastReadAvailable$factory_0();
  return this_0.kotlinx$atomicfu$value;
}
function _set_lastReadView__2y3peu($this, _set____db54di) {
  var this_0 = $this.s1c_1;
  lastReadView$factory();
  this_0.kotlinx$atomicfu$value = _set____db54di;
  return Unit_instance;
}
function _get_lastReadView__ihufyy($this) {
  // Inline function 'kotlinx.atomicfu.AtomicRef.getValue' call
  var this_0 = $this.s1c_1;
  lastReadView$factory_0();
  return this_0.kotlinx$atomicfu$value;
}
function flushImpl($this) {
  if ($this.p1c_1.h1d()) {
    $this.t1c_1.y1c();
    return false;
  }
  flushWrittenBytes($this);
  $this.t1c_1.y1c();
  return true;
}
function flushWrittenBytes($this) {
  // Inline function 'kotlinx.atomicfu.locks.synchronized' call
  $this.u1c_1;
  // Inline function 'io.ktor.utils.io.ByteChannelSequentialBase.flushWrittenBytes.<anonymous>' call
  var size = $this.p1c_1.n();
  var buffer = ensureNotNull($this.p1c_1.q1d());
  $this.v1c_1.r1d(buffer);
  $this.m1c_1.atomicfu$addAndGet(size);
}
function ensureNotClosed($this) {
  if ($this.t1d()) {
    var tmp0_elvis_lhs = $this.s1d();
    throw tmp0_elvis_lhs == null ? new ClosedWriteChannelException('Channel ' + $this + ' is already closed') : tmp0_elvis_lhs;
  }
}
function ensureNotFailed($this) {
  var tmp0_safe_receiver = $this.s1d();
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    throw tmp0_safe_receiver;
  }
}
function ensureNotFailed_0($this, closeable) {
  var tmp0_safe_receiver = $this.s1d();
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    closeable.mu();
    throw tmp0_safe_receiver;
  }
}
function readRemainingSuspend($this, builder, limit, $completion) {
  var tmp = new $readRemainingSuspendCOROUTINE$27($this, builder, limit, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function completeReading($this) {
  // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
  var this_0 = _get_lastReadView__ihufyy($this);
  var remaining = this_0.i1e_1 - this_0.h1e_1 | 0;
  var delta = _get_lastReadAvailable__cgybqk($this) - remaining | 0;
  if (!(_get_lastReadView__ihufyy($this) === Companion_instance.n1e())) {
    completeReadHead($this.q1c_1, _get_lastReadView__ihufyy($this));
  }
  if (delta > 0) {
    $this.o1e(delta);
  }
  _set_lastReadAvailable__98ukjs($this, 0);
  _set_lastReadView__2y3peu($this, Companion_getInstance_4().q1e_1);
}
function discardSuspend($this, max, discarded0, $completion) {
  var tmp = new $discardSuspendCOROUTINE$41($this, max, discarded0, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function addBytesRead($this, count) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(count >= 0)) {
    // Inline function 'io.ktor.utils.io.ByteChannelSequentialBase.addBytesRead.<anonymous>' call
    var message = "Can't read negative amount of bytes: " + count;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlinx.atomicfu.AtomicInt.minusAssign' call
  $this.n1c_1.atomicfu$getAndAdd(-count | 0);
  $this.k1c_1.atomicfu$addAndGet$long(toLong(count));
  // Inline function 'kotlinx.atomicfu.AtomicInt.minusAssign' call
  $this.m1c_1.atomicfu$getAndAdd(-count | 0);
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!($this.n1c_1.kotlinx$atomicfu$value >= 0)) {
    // Inline function 'io.ktor.utils.io.ByteChannelSequentialBase.addBytesRead.<anonymous>' call
    var message_0 = 'Readable bytes count is negative: ' + $this.f1f() + ', ' + count + ' in ' + $this;
    throw IllegalStateException_init_$Create$(toString(message_0));
  }
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!($this.f1f() >= 0)) {
    // Inline function 'io.ktor.utils.io.ByteChannelSequentialBase.addBytesRead.<anonymous>' call
    var message_1 = 'Readable bytes count is negative: ' + $this.f1f() + ', ' + count + ' in ' + $this;
    throw IllegalStateException_init_$Create$(toString(message_1));
  }
}
function addBytesWritten($this, count) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(count >= 0)) {
    // Inline function 'io.ktor.utils.io.ByteChannelSequentialBase.addBytesWritten.<anonymous>' call
    var message = "Can't write negative amount of bytes: " + count;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlinx.atomicfu.AtomicInt.plusAssign' call
  $this.n1c_1.atomicfu$getAndAdd(count);
  $this.l1c_1.atomicfu$addAndGet$long(toLong(count));
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!($this.n1c_1.kotlinx$atomicfu$value >= 0)) {
    // Inline function 'io.ktor.utils.io.ByteChannelSequentialBase.addBytesWritten.<anonymous>' call
    var message_0 = 'Readable bytes count is negative: ' + $this.n1c_1.kotlinx$atomicfu$value + ', ' + count + ' in ' + $this;
    throw IllegalStateException_init_$Create$(toString(message_0));
  }
}
function ByteChannelSequentialBase$awaitAtLeastNBytesAvailableForWrite$lambda(this$0, $count) {
  return function () {
    return this$0.g1f() < $count ? !this$0.t1d() : false;
  };
}
function ByteChannelSequentialBase$awaitAtLeastNBytesAvailableForRead$lambda(this$0, $count) {
  return function () {
    return this$0.f1f() < $count ? !this$0.h1f() : false;
  };
}
function $awaitAtLeastNBytesAvailableForWriteCOROUTINE$0(_this__u8e3s4, count, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.q1f_1 = _this__u8e3s4;
  this.r1f_1 = count;
}
protoOf($awaitAtLeastNBytesAvailableForWriteCOROUTINE$0).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 4;
          this.ic_1 = 1;
          continue $sm;
        case 1:
          if (!(this.q1f_1.g1f() < this.r1f_1 ? !this.q1f_1.t1d() : false)) {
            this.ic_1 = 5;
            continue $sm;
          }

          if (!flushImpl(this.q1f_1)) {
            this.ic_1 = 2;
            suspendResult = this.q1f_1.t1c_1.s1f(ByteChannelSequentialBase$awaitAtLeastNBytesAvailableForWrite$lambda(this.q1f_1, this.r1f_1), this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 3;
            continue $sm;
          }

        case 2:
          this.ic_1 = 3;
          continue $sm;
        case 3:
          this.ic_1 = 1;
          continue $sm;
        case 4:
          throw this.lc_1;
        case 5:
          return Unit_instance;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 4) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $awaitAtLeastNBytesAvailableForReadCOROUTINE$1(_this__u8e3s4, count, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.b1g_1 = _this__u8e3s4;
  this.c1g_1 = count;
}
protoOf($awaitAtLeastNBytesAvailableForReadCOROUTINE$1).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          this.ic_1 = 1;
          continue $sm;
        case 1:
          if (!(this.b1g_1.f1f() < this.c1g_1 ? !this.b1g_1.h1f() : false)) {
            this.ic_1 = 4;
            continue $sm;
          }

          this.ic_1 = 2;
          suspendResult = this.b1g_1.t1c_1.s1f(ByteChannelSequentialBase$awaitAtLeastNBytesAvailableForRead$lambda(this.b1g_1, this.c1g_1), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          this.ic_1 = 1;
          continue $sm;
        case 3:
          throw this.lc_1;
        case 4:
          return Unit_instance;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $writePacketCOROUTINE$8(_this__u8e3s4, packet, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.l1g_1 = _this__u8e3s4;
  this.m1g_1 = packet;
}
protoOf($writePacketCOROUTINE$8).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.l1g_1.n1g(1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var size = this.m1g_1.v1g().ra();
          this.l1g_1.p1c_1.w1g(this.m1g_1);
          this.l1g_1.x1g(size);
          return Unit_instance;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $writeFullyCOROUTINE$9(_this__u8e3s4, src, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.g1h_1 = _this__u8e3s4;
  this.h1h_1 = src;
}
protoOf($writeFullyCOROUTINE$9).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.g1h_1.n1g(1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var this_0 = this.h1h_1;
          var count = this_0.i1e_1 - this_0.h1e_1 | 0;
          writeFully_2(this.g1h_1.p1c_1, this.h1h_1);
          this.g1h_1.x1g(count);
          return Unit_instance;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $writeFullyCOROUTINE$10(_this__u8e3s4, src, offset, length, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.q1h_1 = _this__u8e3s4;
  this.r1h_1 = src;
  this.s1h_1 = offset;
  this.t1h_1 = length;
}
protoOf($writeFullyCOROUTINE$10).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 4;
          this.u1h_1 = this.s1h_1;
          this.v1h_1 = this.s1h_1 + this.t1h_1 | 0;
          this.ic_1 = 1;
          continue $sm;
        case 1:
          if (!(this.u1h_1 < this.v1h_1)) {
            this.ic_1 = 3;
            continue $sm;
          }

          this.ic_1 = 2;
          suspendResult = this.q1h_1.n1g(1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          var a = this.q1h_1.g1f();
          var b = this.v1h_1 - this.u1h_1 | 0;
          var bytesCount = Math.min(a, b);
          writeFully_3(this.q1h_1.p1c_1, this.r1h_1, this.u1h_1, bytesCount);
          this.u1h_1 = this.u1h_1 + bytesCount | 0;
          this.q1h_1.x1g(bytesCount);
          this.ic_1 = 1;
          continue $sm;
        case 3:
          return Unit_instance;
        case 4:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 4) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $readRemainingCOROUTINE$26(_this__u8e3s4, limit, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.e1i_1 = _this__u8e3s4;
  this.f1i_1 = limit;
}
protoOf($readRemainingCOROUTINE$26).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          ensureNotFailed(this.e1i_1);
          this.g1i_1 = new BytePacketBuilder();
          var tmp_0 = this;
          var a = this.f1i_1;
          var b = this.e1i_1.q1c_1.v1g();
          tmp_0.h1i_1 = a.o6(b) <= 0 ? a : b;
          this.g1i_1.k1i(this.e1i_1.q1c_1, this.h1i_1);
          this.e1i_1.o1e(this.h1i_1.ra());
          var tmp_1 = this;
          var this_0 = this.f1i_1;
          var other = this.g1i_1.n();
          tmp_1.i1i_1 = this_0.mb(toLong(other));
          if (this.i1i_1.equals(new Long(0, 0)) ? true : this.e1i_1.h1f()) {
            var tmp_2 = this;
            ensureNotFailed_0(this.e1i_1, this.g1i_1);
            tmp_2.j1i_1 = this.g1i_1.l1i();
            this.ic_1 = 2;
            continue $sm;
          } else {
            this.ic_1 = 1;
            suspendResult = readRemainingSuspend(this.e1i_1, this.g1i_1, this.f1i_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          }

        case 1:
          this.j1i_1 = suspendResult;
          this.ic_1 = 2;
          continue $sm;
        case 2:
          return this.j1i_1;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $readRemainingSuspendCOROUTINE$27(_this__u8e3s4, builder, limit, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.c1e_1 = _this__u8e3s4;
  this.d1e_1 = builder;
  this.e1e_1 = limit;
}
protoOf($readRemainingSuspendCOROUTINE$27).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 5;
          this.ic_1 = 1;
          continue $sm;
        case 1:
          if (!(toLong(this.d1e_1.n()).o6(this.e1e_1) < 0)) {
            this.ic_1 = 4;
            continue $sm;
          }

          var tmp_0 = this;
          var this_0 = this.e1e_1;
          var other = this.d1e_1.n();
          var a = this_0.mb(toLong(other));
          var b = this.c1e_1.q1c_1.v1g();
          tmp_0.f1e_1 = a.o6(b) <= 0 ? a : b;
          this.d1e_1.k1i(this.c1e_1.q1c_1, this.f1e_1);
          this.c1e_1.o1e(this.f1e_1.ra());
          ensureNotFailed_0(this.c1e_1, this.d1e_1);
          if (this.c1e_1.h1f() ? true : this.d1e_1.n() === this.e1e_1.ra()) {
            this.ic_1 = 4;
            continue $sm;
          } else {
            this.ic_1 = 2;
            continue $sm;
          }

        case 2:
          this.ic_1 = 3;
          suspendResult = this.c1e_1.m1i(1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 3:
          this.ic_1 = 1;
          continue $sm;
        case 4:
          ensureNotFailed_0(this.c1e_1, this.d1e_1);
          return this.d1e_1.l1i();
        case 5:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 5) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $readAvailableCOROUTINE$30(_this__u8e3s4, dst, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.v1i_1 = _this__u8e3s4;
  this.w1i_1 = dst;
}
protoOf($readAvailableCOROUTINE$30).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          var tmp0_safe_receiver = this.v1i_1.s1d();
          if (tmp0_safe_receiver == null)
            null;
          else {
            throw tmp0_safe_receiver;
          }

          if (this.v1i_1.t1d() ? this.v1i_1.f1f() === 0 : false)
            return -1;
          var this_0 = this.w1i_1;
          if ((this_0.k1e_1 - this_0.i1e_1 | 0) === 0)
            return 0;
          if (this.v1i_1.f1f() === 0) {
            this.ic_1 = 1;
            suspendResult = this.v1i_1.m1i(1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 2;
            continue $sm;
          }

        case 1:
          this.ic_1 = 2;
          continue $sm;
        case 2:
          if (!this.v1i_1.q1c_1.y1i()) {
            this.v1i_1.x1i();
          }

          var this_1 = this.w1i_1;
          var a = toLong(this_1.k1e_1 - this_1.i1e_1 | 0);
          var b = this.v1i_1.q1c_1.v1g();
          var size = (a.o6(b) <= 0 ? a : b).ra();
          readFully_2(this.v1i_1.q1c_1, this.w1i_1, size);
          this.v1i_1.o1e(size);
          return size;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $readAvailableCOROUTINE$33(_this__u8e3s4, dst, offset, length, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.h1j_1 = _this__u8e3s4;
  this.i1j_1 = dst;
  this.j1j_1 = offset;
  this.k1j_1 = length;
}
protoOf($readAvailableCOROUTINE$33).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          var tmp0_safe_receiver = this.h1j_1.s1d();
          if (tmp0_safe_receiver == null)
            null;
          else {
            throw tmp0_safe_receiver;
          }

          if (this.h1j_1.t1d() ? this.h1j_1.f1f() === 0 : false)
            return -1;
          if (this.k1j_1 === 0)
            return 0;
          if (this.h1j_1.f1f() === 0) {
            this.ic_1 = 1;
            suspendResult = this.h1j_1.m1i(1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 2;
            continue $sm;
          }

        case 1:
          this.ic_1 = 2;
          continue $sm;
        case 2:
          if (!this.h1j_1.q1c_1.y1i()) {
            this.h1j_1.x1i();
          }

          var a = toLong(this.k1j_1);
          var b = this.h1j_1.q1c_1.v1g();
          var size = (a.o6(b) <= 0 ? a : b).ra();
          readFully_1(this.h1j_1.q1c_1, this.i1j_1, this.j1j_1, size);
          this.h1j_1.o1e(size);
          return size;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $awaitInternalAtLeast1COROUTINE$38(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.t1j_1 = _this__u8e3s4;
}
protoOf($awaitInternalAtLeast1COROUTINE$38).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          if (!this.t1j_1.q1c_1.v1j()) {
            var tmp_0 = this;
            tmp_0.u1j_1 = true;
            this.ic_1 = 3;
            continue $sm;
          } else {
            this.ic_1 = 1;
            suspendResult = this.t1j_1.m1i(1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          }

        case 1:
          this.u1j_1 = suspendResult;
          this.ic_1 = 3;
          continue $sm;
        case 2:
          throw this.lc_1;
        case 3:
          return this.u1j_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $awaitSuspendCOROUTINE$39(_this__u8e3s4, atLeast, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.e1k_1 = _this__u8e3s4;
  this.f1k_1 = atLeast;
}
protoOf($awaitSuspendCOROUTINE$39).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          if (!(this.f1k_1 >= 0)) {
            var message = 'Failed requirement.';
            throw IllegalArgumentException_init_$Create$(toString(message));
          }

          this.ic_1 = 1;
          suspendResult = this.e1k_1.g1k(this.f1k_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.e1k_1.x1i();
          var tmp0_safe_receiver = this.e1k_1.s1d();
          if (tmp0_safe_receiver == null)
            null;
          else {
            throw tmp0_safe_receiver;
          }

          return !this.e1k_1.h1f() ? this.e1k_1.f1f() >= this.f1k_1 : false;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $discardCOROUTINE$40(_this__u8e3s4, max, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.p1k_1 = _this__u8e3s4;
  this.q1k_1 = max;
}
protoOf($discardCOROUTINE$40).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          this.r1k_1 = this.p1k_1.q1c_1.t1k(this.q1k_1);
          this.p1k_1.o1e(this.r1k_1.ra());
          if (this.r1k_1.equals(this.q1k_1) ? true : this.p1k_1.h1f()) {
            var tmp_0 = this;
            ensureNotFailed(this.p1k_1);
            return this.r1k_1;
          } else {
            this.ic_1 = 1;
            suspendResult = discardSuspend(this.p1k_1, this.q1k_1, this.r1k_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          }

        case 1:
          this.s1k_1 = suspendResult;
          this.ic_1 = 2;
          continue $sm;
        case 2:
          return this.s1k_1;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $discardSuspendCOROUTINE$41(_this__u8e3s4, max, discarded0, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.b1f_1 = _this__u8e3s4;
  this.c1f_1 = max;
  this.d1f_1 = discarded0;
}
protoOf($discardSuspendCOROUTINE$41).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 5;
          this.e1f_1 = this.d1f_1;
          this.ic_1 = 1;
          continue $sm;
        case 1:
          this.ic_1 = 2;
          suspendResult = this.b1f_1.u1k(1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          var ARGUMENT = suspendResult;
          if (!ARGUMENT) {
            this.ic_1 = 4;
            continue $sm;
          } else {
            this.ic_1 = 3;
            continue $sm;
          }

        case 3:
          var count = this.b1f_1.q1c_1.t1k(this.c1f_1.mb(this.e1f_1));
          this.b1f_1.o1e(count.ra());
          this.e1f_1 = this.e1f_1.lb(count);
          if (this.e1f_1.o6(this.c1f_1) < 0 ? !this.b1f_1.h1f() : false) {
            this.ic_1 = 1;
            continue $sm;
          }

          this.ic_1 = 4;
          continue $sm;
        case 4:
          ensureNotFailed(this.b1f_1);
          return this.e1f_1;
        case 5:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 5) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function ByteChannelSequentialBase(initial, autoFlush, pool) {
  pool = pool === VOID ? Companion_getInstance_4().v1k() : pool;
  this.i1c_1 = autoFlush;
  this.j1c_1 = atomic$ref$1(Companion_getInstance_4().q1e_1);
  this.k1c_1 = atomic$long$1(new Long(0, 0));
  this.l1c_1 = atomic$long$1(new Long(0, 0));
  this.m1c_1 = atomic$int$1(0);
  this.n1c_1 = atomic$int$1(0);
  this.o1c_1 = atomic$ref$1(null);
  this.p1c_1 = new BytePacketBuilder(pool);
  this.q1c_1 = ByteReadPacket_init_$Create$(initial, pool);
  this.r1c_1 = atomic$int$1(0);
  this.s1c_1 = atomic$ref$1(Companion_getInstance_4().q1e_1);
  this.t1c_1 = new AwaitingSlot();
  this.u1c_1 = new Object();
  this.v1c_1 = new BytePacketBuilder();
  var count = remainingAll(initial).ra();
  this.x1g(count);
  this.m1c_1.atomicfu$addAndGet(count);
}
protoOf(ByteChannelSequentialBase).w1k = function () {
  return this.i1c_1;
};
protoOf(ByteChannelSequentialBase).t1d = function () {
  return !(this.o1c_1.kotlinx$atomicfu$value == null);
};
protoOf(ByteChannelSequentialBase).f1f = function () {
  return this.m1c_1.kotlinx$atomicfu$value;
};
protoOf(ByteChannelSequentialBase).g1f = function () {
  // Inline function 'kotlin.comparisons.maxOf' call
  var b = 4088 - this.n1c_1.kotlinx$atomicfu$value | 0;
  return Math.max(0, b);
};
protoOf(ByteChannelSequentialBase).h1f = function () {
  return _get_isCancelled__nhbn6y(this) ? true : this.t1d() ? this.n1c_1.kotlinx$atomicfu$value === 0 : false;
};
protoOf(ByteChannelSequentialBase).x1k = function () {
  return this.t1d();
};
protoOf(ByteChannelSequentialBase).s1d = function () {
  var tmp0_safe_receiver = this.o1c_1.kotlinx$atomicfu$value;
  return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.w1c_1;
};
protoOf(ByteChannelSequentialBase).n1g = function (count, $completion) {
  var tmp = new $awaitAtLeastNBytesAvailableForWriteCOROUTINE$0(this, count, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ByteChannelSequentialBase).g1k = function (count, $completion) {
  var tmp = new $awaitAtLeastNBytesAvailableForReadCOROUTINE$1(this, count, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ByteChannelSequentialBase).f6 = function () {
  flushImpl(this);
};
protoOf(ByteChannelSequentialBase).x1i = function () {
  // Inline function 'kotlinx.atomicfu.locks.synchronized' call
  this.u1c_1;
  // Inline function 'io.ktor.utils.io.ByteChannelSequentialBase.prepareFlushedBytes.<anonymous>' call
  unsafeAppend(this.q1c_1, this.v1c_1);
};
protoOf(ByteChannelSequentialBase).y1k = function (packet, $completion) {
  var tmp = new $writePacketCOROUTINE$8(this, packet, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ByteChannelSequentialBase).z1k = function (src, $completion) {
  var tmp = new $writeFullyCOROUTINE$9(this, src, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ByteChannelSequentialBase).a1l = function (src, offset, length, $completion) {
  var tmp = new $writeFullyCOROUTINE$10(this, src, offset, length, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ByteChannelSequentialBase).o1e = function (count) {
  addBytesRead(this, count);
  this.t1c_1.y1c();
};
protoOf(ByteChannelSequentialBase).b1l = function (limit, $completion) {
  var tmp = new $readRemainingCOROUTINE$26(this, limit, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ByteChannelSequentialBase).d1l = function (dst, $completion) {
  return this.e1l(dst instanceof Buffer ? dst : THROW_CCE(), $completion);
};
protoOf(ByteChannelSequentialBase).e1l = function (dst, $completion) {
  var tmp = new $readAvailableCOROUTINE$30(this, dst, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ByteChannelSequentialBase).f1l = function (dst, offset, length, $completion) {
  var tmp = new $readAvailableCOROUTINE$33(this, dst, offset, length, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ByteChannelSequentialBase).u1k = function (atLeast, $completion) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(atLeast >= 0)) {
    // Inline function 'io.ktor.utils.io.ByteChannelSequentialBase.await.<anonymous>' call
    var message = "atLeast parameter shouldn't be negative: " + atLeast;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(toLong(atLeast).o6(new Long(4088, 0)) <= 0)) {
    // Inline function 'io.ktor.utils.io.ByteChannelSequentialBase.await.<anonymous>' call
    var message_0 = "atLeast parameter shouldn't be larger than max buffer size of 4088: " + atLeast;
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  completeReading(this);
  if (atLeast === 0)
    return !this.h1f();
  if (this.q1c_1.v1g().o6(toLong(atLeast)) >= 0)
    return true;
  return this.m1i(atLeast, $completion);
};
protoOf(ByteChannelSequentialBase).g1l = function ($completion) {
  var tmp = new $awaitInternalAtLeast1COROUTINE$38(this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ByteChannelSequentialBase).m1i = function (atLeast, $completion) {
  var tmp = new $awaitSuspendCOROUTINE$39(this, atLeast, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ByteChannelSequentialBase).h1l = function (max, $completion) {
  var tmp = new $discardCOROUTINE$40(this, max, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ByteChannelSequentialBase).ft = function (cause) {
  if (!(this.s1d() == null) ? true : this.t1d()) {
    return false;
  }
  return this.i12(cause == null ? CancellationException_init_$Create$('Channel cancelled') : cause);
};
protoOf(ByteChannelSequentialBase).i12 = function (cause) {
  var closeElement = cause == null ? get_CLOSED_SUCCESS() : new CloseElement(cause);
  if (!this.o1c_1.atomicfu$compareAndSet(null, closeElement))
    return false;
  if (!(cause == null)) {
    this.q1c_1.mu();
    this.p1c_1.mu();
    this.v1c_1.mu();
  } else {
    this.f6();
    this.p1c_1.mu();
  }
  this.t1c_1.i1l(cause);
  return true;
};
protoOf(ByteChannelSequentialBase).j1l = function (dst, limit) {
  var size = this.q1c_1.v1g();
  var tmp;
  if (size.o6(limit) <= 0) {
    dst.p1c_1.w1g(this.q1c_1);
    dst.x1g(size.ra());
    this.o1e(size.ra());
    tmp = size;
  } else {
    tmp = new Long(0, 0);
  }
  return tmp;
};
protoOf(ByteChannelSequentialBase).x1g = function (count) {
  addBytesWritten(this, count);
  if (this.t1d()) {
    this.p1c_1.mu();
    ensureNotClosed(this);
  }
  if (this.w1k() ? true : this.g1f() === 0) {
    this.f6();
  }
};
function lastReadAvailable$factory() {
  return getPropertyCallableRef('lastReadAvailable', 1, KMutableProperty1, function (receiver) {
    return _get_lastReadAvailable__cgybqk(receiver);
  }, function (receiver, value) {
    return _set_lastReadAvailable__98ukjs(receiver, value);
  });
}
function lastReadAvailable$factory_0() {
  return getPropertyCallableRef('lastReadAvailable', 1, KMutableProperty1, function (receiver) {
    return _get_lastReadAvailable__cgybqk(receiver);
  }, function (receiver, value) {
    return _set_lastReadAvailable__98ukjs(receiver, value);
  });
}
function lastReadView$factory() {
  return getPropertyCallableRef('lastReadView', 1, KMutableProperty1, function (receiver) {
    return _get_lastReadView__ihufyy(receiver);
  }, function (receiver, value) {
    return _set_lastReadView__2y3peu(receiver, value);
  });
}
function lastReadView$factory_0() {
  return getPropertyCallableRef('lastReadView', 1, KMutableProperty1, function (receiver) {
    return _get_lastReadView__ihufyy(receiver);
  }, function (receiver, value) {
    return _set_lastReadView__2y3peu(receiver, value);
  });
}
function cancel(_this__u8e3s4) {
  return _this__u8e3s4.ft(null);
}
function readAvailable(_this__u8e3s4, dst, $completion) {
  return _this__u8e3s4.f1l(dst, 0, dst.length, $completion);
}
function discard(_this__u8e3s4, $completion) {
  Companion_getInstance();
  return _this__u8e3s4.h1l(new Long(-1, 2147483647), $completion);
}
function close_0(_this__u8e3s4) {
  return _this__u8e3s4.i12(null);
}
function ClosedWriteChannelException(message) {
  CancellationException_init_$Init$(message, this);
  captureStack(this, ClosedWriteChannelException);
}
function writeFully(_this__u8e3s4, src, $completion) {
  return _this__u8e3s4.a1l(src, 0, src.length, $completion);
}
function get_CLOSED_SUCCESS() {
  _init_properties_CloseElement_kt__5e72ik();
  return CLOSED_SUCCESS;
}
var CLOSED_SUCCESS;
function CloseElement(cause) {
  this.w1c_1 = cause;
}
var properties_initialized_CloseElement_kt_clkism;
function _init_properties_CloseElement_kt__5e72ik() {
  if (!properties_initialized_CloseElement_kt_clkism) {
    properties_initialized_CloseElement_kt_clkism = true;
    CLOSED_SUCCESS = new CloseElement(null);
  }
}
function writer(_this__u8e3s4, coroutineContext, autoFlush, block) {
  coroutineContext = coroutineContext === VOID ? EmptyCoroutineContext_getInstance() : coroutineContext;
  autoFlush = autoFlush === VOID ? false : autoFlush;
  return launchChannel(_this__u8e3s4, coroutineContext, ByteChannel(autoFlush), true, block);
}
function WriterScope() {
}
function ChannelJob(delegate, channel) {
  this.l1l_1 = delegate;
  this.m1l_1 = channel;
}
protoOf(ChannelJob).vy = function () {
  return this.m1l_1;
};
protoOf(ChannelJob).vm = function () {
  return this.l1l_1.vm();
};
protoOf(ChannelJob).k2 = function () {
  return this.l1l_1.k2();
};
protoOf(ChannelJob).on = function () {
  return this.l1l_1.on();
};
protoOf(ChannelJob).io = function (child) {
  return this.l1l_1.io(child);
};
protoOf(ChannelJob).bo = function (cause) {
  this.l1l_1.bo(cause);
};
protoOf(ChannelJob).mf = function (initial, operation) {
  return this.l1l_1.mf(initial, operation);
};
protoOf(ChannelJob).pc = function (key) {
  return this.l1l_1.pc(key);
};
protoOf(ChannelJob).tn = function () {
  return this.l1l_1.tn();
};
protoOf(ChannelJob).xn = function (onCancelling, invokeImmediately, handler) {
  return this.l1l_1.xn(onCancelling, invokeImmediately, handler);
};
protoOf(ChannelJob).wn = function (handler) {
  return this.l1l_1.wn(handler);
};
protoOf(ChannelJob).lf = function (key) {
  return this.l1l_1.lf(key);
};
protoOf(ChannelJob).nf = function (context) {
  return this.l1l_1.nf(context);
};
protoOf(ChannelJob).rn = function () {
  return this.l1l_1.rn();
};
protoOf(ChannelJob).toString = function () {
  return 'ChannelJob[' + this.l1l_1 + ']';
};
function launchChannel(_this__u8e3s4, context, channel, attachJob, block) {
  var dispatcher = _this__u8e3s4.um().pc(Key_getInstance());
  var job = launch(_this__u8e3s4, context, VOID, launchChannel$slambda_0(attachJob, channel, block, dispatcher, null));
  job.wn(launchChannel$lambda(channel));
  return new ChannelJob(job, channel);
}
function ChannelScope(delegate, channel) {
  this.n1l_1 = channel;
  this.o1l_1 = delegate;
}
protoOf(ChannelScope).vy = function () {
  return this.n1l_1;
};
protoOf(ChannelScope).um = function () {
  return this.o1l_1.um();
};
function launchChannel$slambda($attachJob, $channel, $block, $dispatcher, resultContinuation) {
  this.x1l_1 = $attachJob;
  this.y1l_1 = $channel;
  this.z1l_1 = $block;
  this.a1m_1 = $dispatcher;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(launchChannel$slambda).d1m = function ($this$launch, $completion) {
  var tmp = this.e1m($this$launch, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(launchChannel$slambda).gd = function (p1, $completion) {
  return this.d1m((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(launchChannel$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          if (this.x1l_1) {
            this.y1l_1.k1l(ensureNotNull(this.b1m_1.um().pc(Key_instance)));
          }

          var tmp_0 = this;
          var tmp_1 = new ChannelScope(this.b1m_1, this.y1l_1);
          tmp_0.c1m_1 = isInterface(tmp_1, CoroutineScope) ? tmp_1 : THROW_CCE();
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.z1l_1(this.c1m_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.jc_1 = 3;
          this.ic_1 = 4;
          continue $sm;
        case 2:
          this.jc_1 = 3;
          var tmp_2 = this.lc_1;
          if (tmp_2 instanceof Error) {
            var cause = this.lc_1;
            if (!equals(this.a1m_1, Dispatchers_getInstance().fy_1) ? !(this.a1m_1 == null) : false) {
              throw cause;
            }
            this.y1l_1.ft(cause);
            this.ic_1 = 4;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 3:
          throw this.lc_1;
        case 4:
          this.jc_1 = 3;
          return Unit_instance;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
protoOf(launchChannel$slambda).e1m = function ($this$launch, completion) {
  var i = new launchChannel$slambda(this.x1l_1, this.y1l_1, this.z1l_1, this.a1m_1, completion);
  i.b1m_1 = $this$launch;
  return i;
};
function launchChannel$slambda_0($attachJob, $channel, $block, $dispatcher, resultContinuation) {
  var i = new launchChannel$slambda($attachJob, $channel, $block, $dispatcher, resultContinuation);
  var l = function ($this$launch, $completion) {
    return i.d1m($this$launch, $completion);
  };
  l.$arity = 1;
  return l;
}
function launchChannel$lambda($channel) {
  return function (cause) {
    $channel.i12(cause);
    return Unit_instance;
  };
}
function unwrapCancellationException(_this__u8e3s4) {
  var exception = _this__u8e3s4;
  $l$loop: while (exception instanceof CancellationException) {
    if (equals(exception, exception.cause)) {
      return _this__u8e3s4;
    }
    var tmp0_elvis_lhs = exception.cause;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return exception;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    exception = tmp;
  }
  return exception;
}
function decode(_this__u8e3s4, input, max) {
  max = max === VOID ? IntCompanionObject_instance.MAX_VALUE : max;
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.comparisons.minOf' call
  var a = toLong(max);
  var b = sizeEstimate(input);
  var capacity = (a.o6(b) <= 0 ? a : b).ra();
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder_init_$Create$(capacity);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.charsets.decode.<anonymous>' call
  decode_0(_this__u8e3s4, input, this_0, max);
  return this_0.toString();
}
function encodeToImpl(_this__u8e3s4, destination, input, fromIndex, toIndex) {
  var start = fromIndex;
  if (start >= toIndex)
    return 0;
  var bytesWritten = 0;
  // Inline function 'io.ktor.utils.io.core.writeWhileSize' call
  var tail = prepareWriteHead(destination, 1, null);
  try {
    var size;
    $l$loop: while (true) {
      // Inline function 'io.ktor.utils.io.charsets.encodeToImpl.<anonymous>' call
      var view = tail;
      // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
      var before = view.k1e_1 - view.i1e_1 | 0;
      var rc = encodeImpl(_this__u8e3s4, input, start, toIndex, view);
      // Inline function 'kotlin.check' call
      // Inline function 'kotlin.contracts.contract' call
      // Inline function 'kotlin.check' call
      // Inline function 'kotlin.contracts.contract' call
      if (!(rc >= 0)) {
        // Inline function 'kotlin.check.<anonymous>' call
        var message = 'Check failed.';
        throw IllegalStateException_init_$Create$(toString(message));
      }
      start = start + rc | 0;
      var tmp = bytesWritten;
      // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
      bytesWritten = tmp + (before - (view.k1e_1 - view.i1e_1 | 0) | 0) | 0;
      size = start >= toIndex ? 0 : rc === 0 ? 8 : 1;
      if (size <= 0)
        break $l$loop;
      tail = prepareWriteHead(destination, size, tail);
    }
  }finally {
    destination.f1m();
  }
  bytesWritten = bytesWritten + encodeCompleteImpl(_this__u8e3s4, destination) | 0;
  return bytesWritten;
}
function sizeEstimate(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4 instanceof ByteReadPacket) {
    tmp = _this__u8e3s4.v1g();
  } else {
    // Inline function 'kotlin.comparisons.maxOf' call
    var a = _this__u8e3s4.v1g();
    var b = new Long(16, 0);
    tmp = a.o6(b) >= 0 ? a : b;
  }
  return tmp;
}
function encodeCompleteImpl(_this__u8e3s4, dst) {
  var size = 1;
  var bytesWritten = 0;
  // Inline function 'io.ktor.utils.io.core.writeWhile' call
  var tail = prepareWriteHead(dst, 1, null);
  try {
    $l$loop: while (true) {
      // Inline function 'io.ktor.utils.io.charsets.encodeCompleteImpl.<anonymous>' call
      var view = tail;
      // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
      var before = view.k1e_1 - view.i1e_1 | 0;
      if (encodeComplete(_this__u8e3s4, view)) {
        size = 0;
      } else {
        size = size + 1 | 0;
      }
      var tmp = bytesWritten;
      // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
      bytesWritten = tmp + (before - (view.k1e_1 - view.i1e_1 | 0) | 0) | 0;
      if (!(size > 0))
        break $l$loop;
      tail = prepareWriteHead(dst, 1, tail);
    }
  }finally {
    dst.f1m();
  }
  return bytesWritten;
}
function encode(_this__u8e3s4, input, fromIndex, toIndex) {
  fromIndex = fromIndex === VOID ? 0 : fromIndex;
  toIndex = toIndex === VOID ? charSequenceLength(input) : toIndex;
  var tmp$ret$0;
  $l$block: {
    // Inline function 'io.ktor.utils.io.core.buildPacket' call
    // Inline function 'kotlin.contracts.contract' call
    var builder = new BytePacketBuilder();
    try {
      // Inline function 'io.ktor.utils.io.charsets.encode.<anonymous>' call
      encodeToImpl(_this__u8e3s4, builder, input, fromIndex, toIndex);
      tmp$ret$0 = builder.l1i();
      break $l$block;
    } catch ($p) {
      if ($p instanceof Error) {
        var t = $p;
        builder.mu();
        throw t;
      } else {
        throw $p;
      }
    }
  }
  return tmp$ret$0;
}
function Companion() {
  this.m1e_1 = 8;
}
protoOf(Companion).n1e = function () {
  return Companion_getInstance_4().q1e_1;
};
var Companion_instance;
function Companion_getInstance_1() {
  return Companion_instance;
}
function Buffer(memory) {
  this.g1e_1 = memory;
  this.h1e_1 = 0;
  this.i1e_1 = 0;
  this.j1e_1 = 0;
  var tmp = this;
  // Inline function 'io.ktor.utils.io.bits.Memory.size32' call
  tmp.k1e_1 = this.g1e_1.g1m_1.byteLength;
  var tmp_0 = this;
  // Inline function 'io.ktor.utils.io.bits.Memory.size32' call
  tmp_0.l1e_1 = this.g1e_1.g1m_1.byteLength;
}
protoOf(Buffer).h1m = function (count) {
  if (count === 0)
    return Unit_instance;
  var newReadPosition = this.h1e_1 + count | 0;
  if (count < 0 ? true : newReadPosition > this.i1e_1) {
    // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
    var tmp$ret$1 = this.i1e_1 - this.h1e_1 | 0;
    discardFailed(count, tmp$ret$1);
  }
  this.h1e_1 = newReadPosition;
};
protoOf(Buffer).i1m = function (count) {
  var newWritePosition = this.i1e_1 + count | 0;
  if (count < 0 ? true : newWritePosition > this.k1e_1) {
    // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
    var tmp$ret$0 = this.k1e_1 - this.i1e_1 | 0;
    commitWrittenFailed(count, tmp$ret$0);
  }
  this.i1e_1 = newWritePosition;
};
protoOf(Buffer).j1m = function (position) {
  var limit = this.k1e_1;
  if (position < this.i1e_1) {
    var tmp = position - this.i1e_1 | 0;
    // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
    var tmp$ret$0 = this.k1e_1 - this.i1e_1 | 0;
    commitWrittenFailed(tmp, tmp$ret$0);
  }
  if (position >= limit) {
    if (position === limit) {
      this.i1e_1 = position;
      return false;
    }
    var tmp_0 = position - this.i1e_1 | 0;
    // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
    var tmp$ret$1 = this.k1e_1 - this.i1e_1 | 0;
    commitWrittenFailed(tmp_0, tmp$ret$1);
  }
  this.i1e_1 = position;
  return true;
};
protoOf(Buffer).k1m = function (position) {
  if (position < 0 ? true : position > this.i1e_1) {
    var tmp = position - this.h1e_1 | 0;
    // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
    var tmp$ret$0 = this.i1e_1 - this.h1e_1 | 0;
    discardFailed(tmp, tmp$ret$0);
  }
  if (!(this.h1e_1 === position)) {
    this.h1e_1 = position;
  }
};
protoOf(Buffer).l1m = function (count) {
  var newReadPosition = this.h1e_1 - count | 0;
  if (newReadPosition < this.j1e_1) {
    rewindFailed(count, this.h1e_1 - this.j1e_1 | 0);
  }
  this.h1e_1 = newReadPosition;
};
protoOf(Buffer).m1m = function (startGap) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(startGap >= 0)) {
    // Inline function 'io.ktor.utils.io.core.Buffer.reserveStartGap.<anonymous>' call
    var message = "startGap shouldn't be negative: " + startGap;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  if (this.h1e_1 >= startGap) {
    this.j1e_1 = startGap;
    return Unit_instance;
  }
  if (this.h1e_1 === this.i1e_1) {
    if (startGap > this.k1e_1) {
      startGapReservationFailedDueToLimit(this, startGap);
    }
    this.i1e_1 = startGap;
    this.h1e_1 = startGap;
    this.j1e_1 = startGap;
    return Unit_instance;
  }
  startGapReservationFailed(this, startGap);
};
protoOf(Buffer).n1m = function (endGap) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(endGap >= 0)) {
    // Inline function 'io.ktor.utils.io.core.Buffer.reserveEndGap.<anonymous>' call
    var message = "endGap shouldn't be negative: " + endGap;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  var newLimit = this.l1e_1 - endGap | 0;
  if (newLimit >= this.i1e_1) {
    this.k1e_1 = newLimit;
    return Unit_instance;
  }
  if (newLimit < 0) {
    endGapReservationFailedDueToCapacity(this, endGap);
  }
  if (newLimit < this.j1e_1) {
    endGapReservationFailedDueToStartGap(this, endGap);
  }
  if (this.h1e_1 === this.i1e_1) {
    this.k1e_1 = newLimit;
    this.h1e_1 = newLimit;
    this.i1e_1 = newLimit;
    return Unit_instance;
  }
  endGapReservationFailedDueToContent(this, endGap);
};
protoOf(Buffer).o1m = function () {
  this.j1e_1 = 0;
  this.h1e_1 = 0;
  var capacity = this.l1e_1;
  this.i1e_1 = capacity;
};
protoOf(Buffer).p1m = function () {
  this.q1m(this.l1e_1 - this.j1e_1 | 0);
};
protoOf(Buffer).q1m = function (limit) {
  var startGap = this.j1e_1;
  this.h1e_1 = startGap;
  this.i1e_1 = startGap;
  this.k1e_1 = limit;
};
protoOf(Buffer).r1m = function () {
  this.s1m(0);
  this.t1m();
};
protoOf(Buffer).t1m = function () {
  this.k1e_1 = this.l1e_1;
};
protoOf(Buffer).s1m = function (newReadPosition) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(newReadPosition >= 0)) {
    // Inline function 'io.ktor.utils.io.core.Buffer.releaseStartGap.<anonymous>' call
    var message = "newReadPosition shouldn't be negative: " + newReadPosition;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(newReadPosition <= this.h1e_1)) {
    // Inline function 'io.ktor.utils.io.core.Buffer.releaseStartGap.<anonymous>' call
    var message_0 = "newReadPosition shouldn't be ahead of the read position: " + newReadPosition + ' > ' + this.h1e_1;
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  this.h1e_1 = newReadPosition;
  if (this.j1e_1 > newReadPosition) {
    this.j1e_1 = newReadPosition;
  }
};
protoOf(Buffer).u1m = function (copy) {
  copy.k1e_1 = this.k1e_1;
  copy.j1e_1 = this.j1e_1;
  copy.h1e_1 = this.h1e_1;
  copy.i1e_1 = this.i1e_1;
};
protoOf(Buffer).v1m = function () {
  var readPosition = this.h1e_1;
  if (readPosition === this.i1e_1) {
    throw new EOFException('No readable bytes available.');
  }
  this.h1e_1 = readPosition + 1 | 0;
  // Inline function 'io.ktor.utils.io.bits.get' call
  // Inline function 'io.ktor.utils.io.bits.Memory.loadAt' call
  return this.g1e_1.g1m_1.getInt8(readPosition);
};
protoOf(Buffer).w1m = function (value) {
  var writePosition = this.i1e_1;
  if (writePosition === this.k1e_1) {
    throw new InsufficientSpaceException('No free space in the buffer to write a byte');
  }
  // Inline function 'io.ktor.utils.io.bits.set' call
  this.g1e_1.g1m_1.setInt8(writePosition, value);
  this.i1e_1 = writePosition + 1 | 0;
};
protoOf(Buffer).x1m = function () {
  this.r1m();
  this.p1m();
};
protoOf(Buffer).toString = function () {
  var tmp = 'Buffer[0x' + toString_0(hashCode(this), 16) + ']';
  // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
  var tmp_0 = this.i1e_1 - this.h1e_1 | 0;
  // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
  var tmp_1 = this.k1e_1 - this.i1e_1 | 0;
  var tmp_2 = this.j1e_1;
  // Inline function 'io.ktor.utils.io.core.Buffer.endGap' call
  return tmp + ('(' + tmp_0 + ' used, ' + tmp_1 + ' free, ' + (tmp_2 + (this.l1e_1 - this.k1e_1 | 0) | 0) + ' reserved of ' + this.l1e_1 + ')');
};
function discardFailed(count, readRemaining) {
  throw new EOFException('Unable to discard ' + count + ' bytes: only ' + readRemaining + ' available for reading');
}
function commitWrittenFailed(count, writeRemaining) {
  throw new EOFException('Unable to discard ' + count + ' bytes: only ' + writeRemaining + ' available for writing');
}
function rewindFailed(count, rewindRemaining) {
  throw IllegalArgumentException_init_$Create$('Unable to rewind ' + count + ' bytes: only ' + rewindRemaining + ' could be rewinded');
}
function startGapReservationFailedDueToLimit(_this__u8e3s4, startGap) {
  if (startGap > _this__u8e3s4.l1e_1) {
    throw IllegalArgumentException_init_$Create$('Start gap ' + startGap + ' is bigger than the capacity ' + _this__u8e3s4.l1e_1);
  }
  // Inline function 'io.ktor.utils.io.core.Buffer.endGap' call
  var tmp$ret$0 = _this__u8e3s4.l1e_1 - _this__u8e3s4.k1e_1 | 0;
  throw IllegalStateException_init_$Create$('Unable to reserve ' + startGap + ' start gap: there are already ' + tmp$ret$0 + ' bytes reserved in the end');
}
function startGapReservationFailed(_this__u8e3s4, startGap) {
  var tmp = 'Unable to reserve ' + startGap + ' start gap: ';
  // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
  var tmp$ret$0 = _this__u8e3s4.i1e_1 - _this__u8e3s4.h1e_1 | 0;
  throw IllegalStateException_init_$Create$(tmp + ('there are already ' + tmp$ret$0 + ' content bytes starting at offset ' + _this__u8e3s4.h1e_1));
}
function endGapReservationFailedDueToCapacity(_this__u8e3s4, endGap) {
  throw IllegalArgumentException_init_$Create$('End gap ' + endGap + ' is too big: capacity is ' + _this__u8e3s4.l1e_1);
}
function endGapReservationFailedDueToStartGap(_this__u8e3s4, endGap) {
  throw IllegalArgumentException_init_$Create$('End gap ' + endGap + ' is too big: there are already ' + _this__u8e3s4.j1e_1 + ' bytes reserved in the beginning');
}
function endGapReservationFailedDueToContent(_this__u8e3s4, endGap) {
  var tmp = 'Unable to reserve end gap ' + endGap + ':';
  // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
  var tmp$ret$0 = _this__u8e3s4.i1e_1 - _this__u8e3s4.h1e_1 | 0;
  throw IllegalArgumentException_init_$Create$(tmp + (' there are already ' + tmp$ret$0 + ' content bytes at offset ' + _this__u8e3s4.h1e_1));
}
function InsufficientSpaceException_init_$Init$(name, size, availableSpace, $this) {
  InsufficientSpaceException.call($this, 'Not enough free space to write ' + name + ' of ' + size + ' bytes, available ' + availableSpace + ' bytes.');
  return $this;
}
function InsufficientSpaceException_init_$Create$(name, size, availableSpace) {
  var tmp = InsufficientSpaceException_init_$Init$(name, size, availableSpace, objectCreate(protoOf(InsufficientSpaceException)));
  captureStack(tmp, InsufficientSpaceException_init_$Create$);
  return tmp;
}
function InsufficientSpaceException(message) {
  message = message === VOID ? 'Not enough free space' : message;
  Exception_init_$Init$(message, this);
  captureStack(this, InsufficientSpaceException);
}
function restoreStartGap(_this__u8e3s4, size) {
  _this__u8e3s4.s1m(_this__u8e3s4.h1e_1 - size | 0);
}
function writeBufferAppend(_this__u8e3s4, other, maxSize) {
  // Inline function 'kotlin.comparisons.minOf' call
  // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
  var a = other.i1e_1 - other.h1e_1 | 0;
  var size = Math.min(a, maxSize);
  // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
  if ((_this__u8e3s4.k1e_1 - _this__u8e3s4.i1e_1 | 0) <= size) {
    writeBufferAppendUnreserve(_this__u8e3s4, size);
  }
  // Inline function 'io.ktor.utils.io.core.write' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.writeBufferAppend.<anonymous>' call
  var dst = _this__u8e3s4.g1e_1;
  var dstOffset = _this__u8e3s4.i1e_1;
  _this__u8e3s4.k1e_1;
  // Inline function 'io.ktor.utils.io.core.read' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.writeBufferAppend.<anonymous>.<anonymous>' call
  var src = other.g1e_1;
  var srcOffset = other.h1e_1;
  other.i1e_1;
  src.y1m(dst, srcOffset, size, dstOffset);
  var rc = size;
  other.h1m(rc);
  var rc_0 = rc;
  _this__u8e3s4.i1m(rc_0);
  return rc_0;
}
function writeBufferAppendUnreserve(_this__u8e3s4, writeSize) {
  // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
  var tmp = _this__u8e3s4.k1e_1 - _this__u8e3s4.i1e_1 | 0;
  // Inline function 'io.ktor.utils.io.core.Buffer.endGap' call
  if ((tmp + (_this__u8e3s4.l1e_1 - _this__u8e3s4.k1e_1 | 0) | 0) < writeSize) {
    throw IllegalArgumentException_init_$Create$("Can't append buffer: not enough free space at the end");
  }
  var newWritePosition = _this__u8e3s4.i1e_1 + writeSize | 0;
  var overrunSize = newWritePosition - _this__u8e3s4.k1e_1 | 0;
  if (overrunSize > 0) {
    _this__u8e3s4.t1m();
  }
}
function writeBufferPrepend(_this__u8e3s4, other) {
  // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
  var size = other.i1e_1 - other.h1e_1 | 0;
  var readPosition = _this__u8e3s4.h1e_1;
  if (readPosition < size) {
    throw IllegalArgumentException_init_$Create$('Not enough space in the beginning to prepend bytes');
  }
  var newReadPosition = readPosition - size | 0;
  other.g1e_1.y1m(_this__u8e3s4.g1e_1, other.h1e_1, size, newReadPosition);
  other.h1m(size);
  _this__u8e3s4.s1m(newReadPosition);
  return size;
}
function get_DefaultChunkedBufferPool() {
  _init_properties_BufferFactory_kt__uj6b48();
  return DefaultChunkedBufferPool;
}
var DefaultChunkedBufferPool;
function DefaultBufferPool(bufferSize, capacity, allocator) {
  bufferSize = bufferSize === VOID ? 4096 : bufferSize;
  capacity = capacity === VOID ? 1000 : capacity;
  allocator = allocator === VOID ? DefaultAllocator_instance : allocator;
  DefaultPool.call(this, capacity);
  this.c1n_1 = bufferSize;
  this.d1n_1 = allocator;
}
protoOf(DefaultBufferPool).e1n = function () {
  return new ChunkBuffer(this.d1n_1.f1n(this.c1n_1), null, this);
};
protoOf(DefaultBufferPool).g1n = function (instance) {
  this.d1n_1.h1n(instance.g1e_1);
  protoOf(DefaultPool).l1n.call(this, instance);
  instance.w1n();
};
protoOf(DefaultBufferPool).l1n = function (instance) {
  return this.g1n(instance instanceof ChunkBuffer ? instance : THROW_CCE());
};
protoOf(DefaultBufferPool).x1n = function (instance) {
  protoOf(DefaultPool).y1n.call(this, instance);
  // Inline function 'kotlin.check' call
  // Inline function 'io.ktor.utils.io.bits.Memory.size' call
  var this_0 = instance.g1e_1;
  // Inline function 'kotlin.contracts.contract' call
  if (!toLong(this_0.g1m_1.byteLength).equals(toLong(this.c1n_1))) {
    // Inline function 'io.ktor.utils.io.core.DefaultBufferPool.validateInstance.<anonymous>' call
    // Inline function 'io.ktor.utils.io.bits.Memory.size' call
    var this_1 = instance.g1e_1;
    var tmp$ret$1 = toLong(this_1.g1m_1.byteLength);
    var message = 'Buffer size mismatch. Expected: ' + this.c1n_1 + ', actual: ' + tmp$ret$1.toString();
    throw IllegalStateException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!(instance === Companion_getInstance_4().q1e_1)) {
    // Inline function 'io.ktor.utils.io.core.DefaultBufferPool.validateInstance.<anonymous>' call
    var message_0 = "ChunkBuffer.Empty couldn't be recycled";
    throw IllegalStateException_init_$Create$(toString(message_0));
  }
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!(instance === Companion_instance.n1e())) {
    // Inline function 'io.ktor.utils.io.core.DefaultBufferPool.validateInstance.<anonymous>' call
    var message_1 = "Empty instance couldn't be recycled";
    throw IllegalStateException_init_$Create$(toString(message_1));
  }
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(instance.z1n() === 0)) {
    // Inline function 'io.ktor.utils.io.core.DefaultBufferPool.validateInstance.<anonymous>' call
    var message_2 = 'Unable to clear buffer: it is still in use.';
    throw IllegalStateException_init_$Create$(toString(message_2));
  }
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(instance.zz() == null)) {
    // Inline function 'io.ktor.utils.io.core.DefaultBufferPool.validateInstance.<anonymous>' call
    var message_3 = "Recycled instance shouldn't be a part of a chain.";
    throw IllegalStateException_init_$Create$(toString(message_3));
  }
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(instance.v1n_1 == null)) {
    // Inline function 'io.ktor.utils.io.core.DefaultBufferPool.validateInstance.<anonymous>' call
    var message_4 = "Recycled instance shouldn't be a view or another buffer.";
    throw IllegalStateException_init_$Create$(toString(message_4));
  }
};
protoOf(DefaultBufferPool).y1n = function (instance) {
  return this.x1n(instance instanceof ChunkBuffer ? instance : THROW_CCE());
};
protoOf(DefaultBufferPool).a1o = function (instance) {
  // Inline function 'kotlin.apply' call
  var this_0 = protoOf(DefaultPool).b1o.call(this, instance);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.DefaultBufferPool.clearInstance.<anonymous>' call
  this_0.c1o();
  this_0.x1m();
  return this_0;
};
protoOf(DefaultBufferPool).b1o = function (instance) {
  return this.a1o(instance instanceof ChunkBuffer ? instance : THROW_CCE());
};
function get_DEFAULT_BUFFER_SIZE() {
  return DEFAULT_BUFFER_SIZE;
}
var DEFAULT_BUFFER_SIZE;
var properties_initialized_BufferFactory_kt_q9tgbq;
function _init_properties_BufferFactory_kt__uj6b48() {
  if (!properties_initialized_BufferFactory_kt_q9tgbq) {
    properties_initialized_BufferFactory_kt_q9tgbq = true;
    DefaultChunkedBufferPool = new DefaultBufferPool();
  }
}
function writeFully_0(_this__u8e3s4, source, offset, length) {
  offset = offset === VOID ? 0 : offset;
  length = length === VOID ? source.length - offset | 0 : length;
  // Inline function 'io.ktor.utils.io.core.writeExact' call
  var name = 'byte array';
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.write' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.writeExact.<anonymous>' call
  var memory = _this__u8e3s4.g1e_1;
  var start = _this__u8e3s4.i1e_1;
  var writeRemaining = _this__u8e3s4.k1e_1 - start | 0;
  if (writeRemaining < length) {
    throw InsufficientSpaceException_init_$Create$(name, length, writeRemaining);
  }
  // Inline function 'io.ktor.utils.io.core.writeFully.<anonymous>' call
  // Inline function 'io.ktor.utils.io.bits.storeByteArray' call
  // Inline function 'io.ktor.utils.io.bits.useMemory' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlin.let' call
  // Inline function 'kotlin.contracts.contract' call
  of(Companion_getInstance_6(), source, offset, length).y1m(memory, 0, length, start);
  var rc = length;
  _this__u8e3s4.i1m(rc);
}
function writeFully_1(_this__u8e3s4, src, length) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(length >= 0)) {
    // Inline function 'io.ktor.utils.io.core.writeFully.<anonymous>' call
    var message = "length shouldn't be negative: " + length;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(length <= (src.i1e_1 - src.h1e_1 | 0))) {
    // Inline function 'io.ktor.utils.io.core.writeFully.<anonymous>' call
    // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
    var message_0 = "length shouldn't be greater than the source read remaining: " + length + ' > ' + (src.i1e_1 - src.h1e_1 | 0);
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(length <= (_this__u8e3s4.k1e_1 - _this__u8e3s4.i1e_1 | 0))) {
    // Inline function 'io.ktor.utils.io.core.writeFully.<anonymous>' call
    // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
    var message_1 = "length shouldn't be greater than the destination write remaining space: " + length + ' > ' + (_this__u8e3s4.k1e_1 - _this__u8e3s4.i1e_1 | 0);
    throw IllegalArgumentException_init_$Create$(toString(message_1));
  }
  // Inline function 'io.ktor.utils.io.core.writeExact' call
  var name = 'buffer readable content';
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.write' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.writeExact.<anonymous>' call
  var memory = _this__u8e3s4.g1e_1;
  var start = _this__u8e3s4.i1e_1;
  var writeRemaining = _this__u8e3s4.k1e_1 - start | 0;
  if (writeRemaining < length) {
    throw InsufficientSpaceException_init_$Create$(name, length, writeRemaining);
  }
  // Inline function 'io.ktor.utils.io.core.writeFully.<anonymous>' call
  src.g1e_1.y1m(memory, src.h1e_1, length, start);
  src.h1m(length);
  var rc = length;
  _this__u8e3s4.i1m(rc);
}
function readFully(_this__u8e3s4, destination, offset, length) {
  offset = offset === VOID ? 0 : offset;
  length = length === VOID ? destination.length - offset | 0 : length;
  // Inline function 'io.ktor.utils.io.core.readExact' call
  var name = 'byte array';
  // Inline function 'kotlin.contracts.contract' call
  var value;
  // Inline function 'io.ktor.utils.io.core.read' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.readExact.<anonymous>' call
  var memory = _this__u8e3s4.g1e_1;
  var start = _this__u8e3s4.h1e_1;
  if ((_this__u8e3s4.i1e_1 - start | 0) < length) {
    throw new EOFException('Not enough bytes to read a ' + name + ' of size ' + length + '.');
  }
  copyTo_1(memory, destination, start, length, offset);
  value = Unit_instance;
  var rc = length;
  _this__u8e3s4.h1m(rc);
}
function readFully_0(_this__u8e3s4, dst, length) {
  var tmp;
  if (length === VOID) {
    // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
    tmp = dst.k1e_1 - dst.i1e_1 | 0;
  } else {
    tmp = length;
  }
  length = tmp;
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(length >= 0)) {
    // Inline function 'kotlin.require.<anonymous>' call
    var message = 'Failed requirement.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(length <= (dst.k1e_1 - dst.i1e_1 | 0))) {
    // Inline function 'kotlin.require.<anonymous>' call
    var message_0 = 'Failed requirement.';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  // Inline function 'io.ktor.utils.io.core.readExact' call
  var name = 'buffer content';
  // Inline function 'kotlin.contracts.contract' call
  var value;
  // Inline function 'io.ktor.utils.io.core.read' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.readExact.<anonymous>' call
  var memory = _this__u8e3s4.g1e_1;
  var start = _this__u8e3s4.h1e_1;
  if ((_this__u8e3s4.i1e_1 - start | 0) < length) {
    throw new EOFException('Not enough bytes to read a ' + name + ' of size ' + length + '.');
  }
  memory.y1m(dst.g1e_1, start, length, dst.i1e_1);
  dst.i1m(length);
  value = Unit_instance;
  var rc = length;
  _this__u8e3s4.h1m(rc);
  return length;
}
function writeShort(_this__u8e3s4, value) {
  var name = 'short integer';
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.write' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.writeExact.<anonymous>' call
  var memory = _this__u8e3s4.g1e_1;
  var start = _this__u8e3s4.i1e_1;
  var writeRemaining = _this__u8e3s4.k1e_1 - start | 0;
  if (writeRemaining < 2) {
    throw InsufficientSpaceException_init_$Create$(name, 2, writeRemaining);
  }
  // Inline function 'io.ktor.utils.io.core.writeShort.<anonymous>' call
  // Inline function 'io.ktor.utils.io.bits.storeShortAt' call
  memory.g1m_1.setInt16(start, value, false);
  var rc = 2;
  _this__u8e3s4.i1m(rc);
  return Unit_instance;
}
function readShort(_this__u8e3s4) {
  // Inline function 'io.ktor.utils.io.core.readExact' call
  var name = 'short integer';
  // Inline function 'kotlin.contracts.contract' call
  var value;
  // Inline function 'io.ktor.utils.io.core.read' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.readExact.<anonymous>' call
  var memory = _this__u8e3s4.g1e_1;
  var start = _this__u8e3s4.h1e_1;
  if ((_this__u8e3s4.i1e_1 - start | 0) < 2) {
    throw new EOFException('Not enough bytes to read a ' + name + ' of size ' + 2 + '.');
  }
  // Inline function 'io.ktor.utils.io.core.readShort.<anonymous>' call
  // Inline function 'io.ktor.utils.io.bits.loadShortAt' call
  value = memory.g1m_1.getInt16(start, false);
  var rc = 2;
  _this__u8e3s4.h1m(rc);
  return value;
}
function remainingAll(_this__u8e3s4) {
  return remainingAll_0(_this__u8e3s4, new Long(0, 0));
}
function copyAll(_this__u8e3s4) {
  var copied = _this__u8e3s4.g1o();
  var tmp0_elvis_lhs = _this__u8e3s4.zz();
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return copied;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var next = tmp;
  return copyAll_0(next, copied, copied);
}
function findTail(_this__u8e3s4) {
  var $this = _this__u8e3s4;
  $l$1: do {
    $l$0: do {
      var tmp0_elvis_lhs = $this.zz();
      var tmp;
      if (tmp0_elvis_lhs == null) {
        return $this;
      } else {
        tmp = tmp0_elvis_lhs;
      }
      var next = tmp;
      $this = next;
      continue $l$0;
    }
     while (false);
  }
   while (true);
}
function releaseAll(_this__u8e3s4, pool) {
  var current = _this__u8e3s4;
  while (!(current == null)) {
    var next = current.h1o();
    current.i1o(pool);
    current = next;
  }
}
function remainingAll_0(_this__u8e3s4, n) {
  var $this = _this__u8e3s4;
  var n_0 = n;
  $l$1: do {
    $l$0: do {
      // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
      var this_0 = $this;
      var tmp$ret$0 = this_0.i1e_1 - this_0.h1e_1 | 0;
      var rem = toLong(tmp$ret$0).lb(n_0);
      var tmp0_elvis_lhs = $this.zz();
      var tmp;
      if (tmp0_elvis_lhs == null) {
        return rem;
      } else {
        tmp = tmp0_elvis_lhs;
      }
      var next = tmp;
      $this = next;
      n_0 = rem;
      continue $l$0;
    }
     while (false);
  }
   while (true);
}
function copyAll_0(_this__u8e3s4, head, prev) {
  var $this = _this__u8e3s4;
  var head_0 = head;
  var prev_0 = prev;
  $l$1: do {
    $l$0: do {
      var copied = $this.g1o();
      prev_0.j1o(copied);
      var tmp0_elvis_lhs = $this.zz();
      var tmp;
      if (tmp0_elvis_lhs == null) {
        return head_0;
      } else {
        tmp = tmp0_elvis_lhs;
      }
      var next = tmp;
      $this = next;
      head_0 = head_0;
      prev_0 = copied;
      continue $l$0;
    }
     while (false);
  }
   while (true);
}
function BytePacketBuilder(pool) {
  pool = pool === VOID ? Companion_getInstance_4().v1k() : pool;
  Output.call(this, pool);
}
protoOf(BytePacketBuilder).n = function () {
  return this.k1o();
};
protoOf(BytePacketBuilder).h1d = function () {
  return this.k1o() === 0;
};
protoOf(BytePacketBuilder).l1o = function () {
};
protoOf(BytePacketBuilder).m1o = function (source, offset, length) {
};
protoOf(BytePacketBuilder).o5 = function (value) {
  var tmp = protoOf(Output).o5.call(this, value);
  return tmp instanceof BytePacketBuilder ? tmp : THROW_CCE();
};
protoOf(BytePacketBuilder).d8 = function (value) {
  var tmp = protoOf(Output).d8.call(this, value);
  return tmp instanceof BytePacketBuilder ? tmp : THROW_CCE();
};
protoOf(BytePacketBuilder).e8 = function (value, startIndex, endIndex) {
  var tmp = protoOf(Output).e8.call(this, value, startIndex, endIndex);
  return tmp instanceof BytePacketBuilder ? tmp : THROW_CCE();
};
protoOf(BytePacketBuilder).l1i = function () {
  var size = this.n();
  var head = this.q1d();
  return head == null ? Companion_getInstance_2().n1o_1 : new ByteReadPacket(head, toLong(size), this.i1d_1);
};
protoOf(BytePacketBuilder).toString = function () {
  return 'BytePacketBuilder[0x' + hashCode(this) + ']';
};
function ByteReadPacket_init_$Init$(head, pool, $this) {
  ByteReadPacket.call($this, head, remainingAll(head), pool);
  return $this;
}
function ByteReadPacket_init_$Create$(head, pool) {
  return ByteReadPacket_init_$Init$(head, pool, objectCreate(protoOf(ByteReadPacket)));
}
function Companion_0() {
  Companion_instance_0 = this;
  this.n1o_1 = new ByteReadPacket(Companion_getInstance_4().q1e_1, new Long(0, 0), Companion_getInstance_4().p1e_1);
}
var Companion_instance_0;
function Companion_getInstance_2() {
  if (Companion_instance_0 == null)
    new Companion_0();
  return Companion_instance_0;
}
function ByteReadPacket(head, remaining, pool) {
  Companion_getInstance_2();
  Input.call(this, head, remaining, pool);
  this.t1o();
}
protoOf(ByteReadPacket).b1p = function () {
  return new ByteReadPacket(copyAll(this.o1o()), this.v1g(), this.o1g_1);
};
protoOf(ByteReadPacket).c1p = function () {
  return null;
};
protoOf(ByteReadPacket).d1p = function (destination, offset, length) {
  return 0;
};
protoOf(ByteReadPacket).e1p = function () {
};
protoOf(ByteReadPacket).toString = function () {
  return 'ByteReadPacket[' + hashCode(this) + ']';
};
function _set__head__b4pap2($this, newHead) {
  $this.p1g_1 = newHead;
  $this.q1g_1 = newHead.g1e_1;
  $this.r1g_1 = newHead.h1e_1;
  $this.s1g_1 = newHead.i1e_1;
}
function readASCII($this, out, min, max) {
  if (max === 0 ? min === 0 : false)
    return 0;
  else if ($this.v1j())
    if (min === 0)
      return 0;
    else {
      atLeastMinCharactersRequire($this, min);
    }
   else if (max < min) {
    minShouldBeLess($this, min, max);
  }
  var copied = 0;
  var utf8 = false;
  $l$block: {
    // Inline function 'io.ktor.utils.io.core.takeWhile' call
    var release = true;
    var tmp0_elvis_lhs = prepareReadFirstHead($this, 1);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      break $l$block;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var current = tmp;
    try {
      $l$loop_0: do {
        // Inline function 'io.ktor.utils.io.core.Input.readASCII.<anonymous>' call
        var buffer = current;
        var tmp$ret$4;
        $l$block_0: {
          // Inline function 'io.ktor.utils.io.core.internal.decodeASCII' call
          // Inline function 'io.ktor.utils.io.core.read' call
          // Inline function 'kotlin.contracts.contract' call
          // Inline function 'io.ktor.utils.io.core.internal.decodeASCII.<anonymous>' call
          var memory = buffer.g1e_1;
          var start = buffer.h1e_1;
          var endExclusive = buffer.i1e_1;
          var inductionVariable = start;
          if (inductionVariable < endExclusive)
            do {
              var index = inductionVariable;
              inductionVariable = inductionVariable + 1 | 0;
              // Inline function 'io.ktor.utils.io.bits.get' call
              // Inline function 'io.ktor.utils.io.bits.Memory.loadAt' call
              var codepoint = memory.g1m_1.getInt8(index) & 255;
              var tmp_0;
              if ((codepoint & 128) === 128) {
                tmp_0 = true;
              } else {
                // Inline function 'io.ktor.utils.io.core.Input.readASCII.<anonymous>.<anonymous>' call
                var it = numberToChar(codepoint);
                var tmp_1;
                if (copied === max) {
                  tmp_1 = false;
                } else {
                  out.o5(it);
                  copied = copied + 1 | 0;
                  tmp_1 = true;
                }
                tmp_0 = !tmp_1;
              }
              if (tmp_0) {
                buffer.h1m(index - start | 0);
                tmp$ret$4 = false;
                break $l$block_0;
              }
            }
             while (inductionVariable < endExclusive);
          var rc = endExclusive - start | 0;
          buffer.h1m(rc);
          tmp$ret$4 = true;
        }
        var rc_0 = tmp$ret$4;
        var tmp_2;
        if (rc_0) {
          tmp_2 = true;
        } else if (copied === max) {
          tmp_2 = false;
        } else {
          utf8 = true;
          tmp_2 = false;
        }
        if (!tmp_2) {
          break $l$loop_0;
        }
        release = false;
        var tmp1_elvis_lhs = prepareReadNextHead($this, current);
        var tmp_3;
        if (tmp1_elvis_lhs == null) {
          break $l$loop_0;
        } else {
          tmp_3 = tmp1_elvis_lhs;
        }
        var next = tmp_3;
        current = next;
        release = true;
      }
       while (true);
    }finally {
      if (release) {
        completeReadHead($this, current);
      }
    }
  }
  if (utf8) {
    return copied + readUtf8($this, out, min - copied | 0, max - copied | 0) | 0;
  }
  if (copied < min) {
    prematureEndOfStreamChars($this, min, copied);
  }
  return copied;
}
function atLeastMinCharactersRequire($this, min) {
  throw new EOFException('at least ' + min + ' characters required but no bytes available');
}
function minShouldBeLess($this, min, max) {
  throw IllegalArgumentException_init_$Create$('min should be less or equal to max but min = ' + min + ', max = ' + max);
}
function prematureEndOfStreamChars($this, min, copied) {
  throw new MalformedUTF8InputException('Premature end of stream: expected at least ' + min + ' chars but had only ' + copied);
}
function readUtf8($this, out, min, max) {
  var copied = 0;
  $l$block: {
    // Inline function 'io.ktor.utils.io.core.takeWhileSize' call
    var release = true;
    var tmp0_elvis_lhs = prepareReadFirstHead($this, 1);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      break $l$block;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var current = tmp;
    var size = 1;
    try {
      $l$loop_0: do {
        // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
        var this_0 = current;
        var before = this_0.i1e_1 - this_0.h1e_1 | 0;
        var after;
        if (before >= size) {
          try {
            // Inline function 'io.ktor.utils.io.core.Input.readUtf8.<anonymous>' call
            var buffer = current;
            var tmp$ret$5;
            $l$block_3: {
              // Inline function 'io.ktor.utils.io.core.internal.decodeUTF8' call
              var byteCount = 0;
              var value = 0;
              var lastByteCount = 0;
              // Inline function 'io.ktor.utils.io.core.read' call
              // Inline function 'kotlin.contracts.contract' call
              // Inline function 'io.ktor.utils.io.core.internal.decodeUTF8.<anonymous>' call
              var memory = buffer.g1e_1;
              var start = buffer.h1e_1;
              var endExclusive = buffer.i1e_1;
              var inductionVariable = start;
              if (inductionVariable < endExclusive)
                do {
                  var index = inductionVariable;
                  inductionVariable = inductionVariable + 1 | 0;
                  // Inline function 'io.ktor.utils.io.bits.get' call
                  // Inline function 'io.ktor.utils.io.bits.Memory.loadAt' call
                  var v = memory.g1m_1.getInt8(index) & 255;
                  if ((v & 128) === 0) {
                    if (!(byteCount === 0)) {
                      malformedByteCount(byteCount);
                    }
                    // Inline function 'io.ktor.utils.io.core.Input.readUtf8.<anonymous>.<anonymous>' call
                    var it = numberToChar(v);
                    var tmp_0;
                    if (copied === max) {
                      tmp_0 = false;
                    } else {
                      out.o5(it);
                      copied = copied + 1 | 0;
                      tmp_0 = true;
                    }
                    if (!tmp_0) {
                      buffer.h1m(index - start | 0);
                      tmp$ret$5 = -1;
                      break $l$block_3;
                    }
                  } else if (byteCount === 0) {
                    var mask = 128;
                    value = v;
                    var inductionVariable_0 = 1;
                    if (inductionVariable_0 <= 6)
                      $l$loop: do {
                        var i = inductionVariable_0;
                        inductionVariable_0 = inductionVariable_0 + 1 | 0;
                        if (!((value & mask) === 0)) {
                          value = value & ~mask;
                          mask = mask >> 1;
                          byteCount = byteCount + 1 | 0;
                        } else {
                          break $l$loop;
                        }
                      }
                       while (inductionVariable_0 <= 6);
                    lastByteCount = byteCount;
                    byteCount = byteCount - 1 | 0;
                    if (lastByteCount > (endExclusive - index | 0)) {
                      buffer.h1m(index - start | 0);
                      tmp$ret$5 = lastByteCount;
                      break $l$block_3;
                    }
                  } else {
                    value = value << 6 | v & 127;
                    byteCount = byteCount - 1 | 0;
                    if (byteCount === 0) {
                      if (isBmpCodePoint(value)) {
                        // Inline function 'io.ktor.utils.io.core.Input.readUtf8.<anonymous>.<anonymous>' call
                        var it_0 = numberToChar(value);
                        var tmp_1;
                        if (copied === max) {
                          tmp_1 = false;
                        } else {
                          out.o5(it_0);
                          copied = copied + 1 | 0;
                          tmp_1 = true;
                        }
                        if (!tmp_1) {
                          buffer.h1m(((index - start | 0) - lastByteCount | 0) + 1 | 0);
                          tmp$ret$5 = -1;
                          break $l$block_3;
                        }
                      } else if (!isValidCodePoint(value)) {
                        malformedCodePoint(value);
                      } else {
                        var tmp_2;
                        // Inline function 'io.ktor.utils.io.core.Input.readUtf8.<anonymous>.<anonymous>' call
                        var it_1 = numberToChar(highSurrogate(value));
                        var tmp_3;
                        if (copied === max) {
                          tmp_3 = false;
                        } else {
                          out.o5(it_1);
                          copied = copied + 1 | 0;
                          tmp_3 = true;
                        }
                        if (!tmp_3) {
                          tmp_2 = true;
                        } else {
                          // Inline function 'io.ktor.utils.io.core.Input.readUtf8.<anonymous>.<anonymous>' call
                          var it_2 = numberToChar(lowSurrogate(value));
                          var tmp_4;
                          if (copied === max) {
                            tmp_4 = false;
                          } else {
                            out.o5(it_2);
                            copied = copied + 1 | 0;
                            tmp_4 = true;
                          }
                          tmp_2 = !tmp_4;
                        }
                        if (tmp_2) {
                          buffer.h1m(((index - start | 0) - lastByteCount | 0) + 1 | 0);
                          tmp$ret$5 = -1;
                          break $l$block_3;
                        }
                      }
                      value = 0;
                    }
                  }
                }
                 while (inductionVariable < endExclusive);
              var rc = endExclusive - start | 0;
              buffer.h1m(rc);
              tmp$ret$5 = 0;
            }
            var size_0 = tmp$ret$5;
            size = size_0 === 0 ? 1 : size_0 > 0 ? size_0 : 0;
          }finally {
            // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
            var this_1 = current;
            after = this_1.i1e_1 - this_1.h1e_1 | 0;
          }
        } else {
          after = before;
        }
        release = false;
        var tmp_5;
        if (after === 0) {
          tmp_5 = prepareReadNextHead($this, current);
        } else {
          var tmp_6;
          if (after < size) {
            tmp_6 = true;
          } else {
            // Inline function 'io.ktor.utils.io.core.Buffer.endGap' call
            var this_2 = current;
            var tmp_7 = this_2.l1e_1 - this_2.k1e_1 | 0;
            tmp_6 = tmp_7 < 8;
          }
          if (tmp_6) {
            completeReadHead($this, current);
            tmp_5 = prepareReadFirstHead($this, size);
          } else {
            tmp_5 = current;
          }
        }
        var tmp1_elvis_lhs = tmp_5;
        var tmp_8;
        if (tmp1_elvis_lhs == null) {
          break $l$loop_0;
        } else {
          tmp_8 = tmp1_elvis_lhs;
        }
        var next = tmp_8;
        current = next;
        release = true;
      }
       while (size > 0);
    }finally {
      if (release) {
        completeReadHead($this, current);
      }
    }
  }
  if (copied < min) {
    prematureEndOfStreamChars($this, min, copied);
  }
  return copied;
}
function discardAsMuchAsPossible($this, n, skipped) {
  var $this_0 = $this;
  var n_0 = n;
  var skipped_0 = skipped;
  $l$1: do {
    $l$0: do {
      if (n_0.equals(new Long(0, 0)))
        return skipped_0;
      var tmp0_elvis_lhs = $this_0.q1p(1);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        return skipped_0;
      } else {
        tmp = tmp0_elvis_lhs;
      }
      var current = tmp;
      // Inline function 'kotlin.comparisons.minOf' call
      // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
      var tmp$ret$0 = current.i1e_1 - current.h1e_1 | 0;
      var a = toLong(tmp$ret$0);
      var b = n_0;
      var size = (a.o6(b) <= 0 ? a : b).ra();
      current.h1m(size);
      var tmp1_this = $this_0;
      tmp1_this.r1g_1 = tmp1_this.r1g_1 + size | 0;
      afterRead($this_0, current);
      // Inline function 'kotlin.Long.minus' call
      // Inline function 'kotlin.Long.plus' call
      $this_0 = $this_0;
      n_0 = n_0.mb(toLong(size));
      skipped_0 = skipped_0.lb(toLong(size));
      continue $l$0;
    }
     while (false);
  }
   while (true);
}
function discardAsMuchAsPossible_0($this, n, skipped) {
  var currentCount = n;
  var currentSkipped = skipped;
  while (true) {
    if (currentCount === 0) {
      return currentSkipped;
    }
    var tmp0_elvis_lhs = $this.q1p(1);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return currentSkipped;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var current = tmp;
    // Inline function 'kotlin.comparisons.minOf' call
    // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
    var a = current.i1e_1 - current.h1e_1 | 0;
    var b = currentCount;
    var size = Math.min(a, b);
    current.h1m(size);
    $this.r1g_1 = $this.r1g_1 + size | 0;
    afterRead($this, current);
    currentCount = currentCount - size | 0;
    currentSkipped = currentSkipped + size | 0;
  }
}
function fixGapAfterReadFallback($this, current) {
  if ($this.u1g_1 ? current.zz() == null : false) {
    $this.r1g_1 = current.h1e_1;
    $this.s1g_1 = current.i1e_1;
    $this.f1p(new Long(0, 0));
    return Unit_instance;
  }
  // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
  var size = current.i1e_1 - current.h1e_1 | 0;
  // Inline function 'kotlin.comparisons.minOf' call
  // Inline function 'io.ktor.utils.io.core.Buffer.endGap' call
  var b = 8 - (current.l1e_1 - current.k1e_1 | 0) | 0;
  var overrun = Math.min(size, b);
  if (size > overrun) {
    fixGapAfterReadFallbackUnreserved($this, current, size, overrun);
  } else {
    var new_0 = $this.o1g_1.d1o();
    new_0.n1m(8);
    new_0.j1o(current.h1o());
    writeBufferAppend(new_0, current, size);
    _set__head__b4pap2($this, new_0);
  }
  current.i1o($this.o1g_1);
}
function fixGapAfterReadFallbackUnreserved($this, current, size, overrun) {
  var chunk1 = $this.o1g_1.d1o();
  var chunk2 = $this.o1g_1.d1o();
  chunk1.n1m(8);
  chunk2.n1m(8);
  chunk1.j1o(chunk2);
  chunk2.j1o(current.h1o());
  writeBufferAppend(chunk1, current, size - overrun | 0);
  writeBufferAppend(chunk2, current, overrun);
  _set__head__b4pap2($this, chunk1);
  $this.f1p(remainingAll(chunk2));
}
function ensureNext($this, current, empty) {
  var $this_0 = $this;
  var current_0 = current;
  var empty_0 = empty;
  $l$1: do {
    $l$0: do {
      if (current_0 === empty_0) {
        return doFill($this_0);
      }
      var next = current_0.h1o();
      current_0.i1o($this_0.o1g_1);
      var tmp;
      if (next == null) {
        _set__head__b4pap2($this_0, empty_0);
        $this_0.f1p(new Long(0, 0));
        $this_0 = $this_0;
        current_0 = empty_0;
        empty_0 = empty_0;
        continue $l$0;
      } else {
        // Inline function 'io.ktor.utils.io.core.canRead' call
        if (next.i1e_1 > next.h1e_1) {
          _set__head__b4pap2($this_0, next);
          var tmp0_this = $this_0;
          // Inline function 'kotlin.Long.minus' call
          var this_0 = tmp0_this.t1g_1;
          // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
          var other = next.i1e_1 - next.h1e_1 | 0;
          var tmp$ret$2 = this_0.mb(toLong(other));
          tmp0_this.f1p(tmp$ret$2);
          tmp = next;
        } else {
          $this_0 = $this_0;
          current_0 = next;
          empty_0 = empty_0;
          continue $l$0;
        }
      }
      return tmp;
    }
     while (false);
  }
   while (true);
}
function doFill($this) {
  if ($this.u1g_1)
    return null;
  var chunk = $this.c1p();
  if (chunk == null) {
    $this.u1g_1 = true;
    return null;
  }
  appendView($this, chunk);
  return chunk;
}
function appendView($this, chunk) {
  var tail = findTail($this.p1g_1);
  if (tail === Companion_getInstance_4().q1e_1) {
    _set__head__b4pap2($this, chunk);
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.contracts.contract' call
    if (!$this.t1g_1.equals(new Long(0, 0))) {
      throw IllegalStateException_init_$Create$('It should be no tail remaining bytes if current tail is EmptyBuffer');
    }
    var tmp0_safe_receiver = chunk.zz();
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : remainingAll(tmp0_safe_receiver);
    $this.f1p(tmp1_elvis_lhs == null ? new Long(0, 0) : tmp1_elvis_lhs);
  } else {
    tail.j1o(chunk);
    $this.f1p($this.t1g_1.lb(remainingAll(chunk)));
  }
}
function prepareReadLoop($this, minSize, head) {
  var $this_0 = $this;
  var minSize_0 = minSize;
  var head_0 = head;
  $l$1: do {
    $l$0: do {
      // Inline function 'io.ktor.utils.io.core.Input.headRemaining' call
      var this_0 = $this_0;
      var headSize = this_0.s1g_1 - this_0.r1g_1 | 0;
      if (headSize >= minSize_0)
        return head_0;
      var tmp0_elvis_lhs = head_0.zz();
      var tmp1_elvis_lhs = tmp0_elvis_lhs == null ? doFill($this_0) : tmp0_elvis_lhs;
      var tmp;
      if (tmp1_elvis_lhs == null) {
        return null;
      } else {
        tmp = tmp1_elvis_lhs;
      }
      var next = tmp;
      if (headSize === 0) {
        if (!(head_0 === Companion_getInstance_4().q1e_1)) {
          $this_0.r1p(head_0);
        }
        $this_0 = $this_0;
        minSize_0 = minSize_0;
        head_0 = next;
        continue $l$0;
      } else {
        var desiredExtraBytes = minSize_0 - headSize | 0;
        var copied = writeBufferAppend(head_0, next, desiredExtraBytes);
        $this_0.s1g_1 = head_0.i1e_1;
        var tmp2_this = $this_0;
        // Inline function 'kotlin.Long.minus' call
        var tmp$ret$1 = tmp2_this.t1g_1.mb(toLong(copied));
        tmp2_this.f1p(tmp$ret$1);
        // Inline function 'io.ktor.utils.io.core.canRead' call
        if (!(next.i1e_1 > next.h1e_1)) {
          head_0.j1o(null);
          head_0.j1o(next.h1o());
          next.i1o($this_0.o1g_1);
        } else {
          next.m1m(copied);
        }
      }
      // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
      var this_1 = head_0;
      if ((this_1.i1e_1 - this_1.h1e_1 | 0) >= minSize_0)
        return head_0;
      var tmp_0 = minSize_0;
      if (tmp_0 > 8) {
        minSizeIsTooBig($this_0, minSize_0);
      }
      $this_0 = $this_0;
      minSize_0 = minSize_0;
      head_0 = head_0;
      continue $l$0;
    }
     while (false);
  }
   while (true);
}
function minSizeIsTooBig($this, minSize) {
  throw IllegalStateException_init_$Create$('minSize of ' + minSize + ' is too big (should be less than ' + 8 + ')');
}
function afterRead($this, head) {
  // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
  if ((head.i1e_1 - head.h1e_1 | 0) === 0) {
    $this.r1p(head);
  }
}
function Companion_1() {
}
var Companion_instance_1;
function Companion_getInstance_3() {
  return Companion_instance_1;
}
function Input(head, remaining, pool) {
  head = head === VOID ? Companion_getInstance_4().q1e_1 : head;
  remaining = remaining === VOID ? remainingAll(head) : remaining;
  pool = pool === VOID ? Companion_getInstance_4().v1k() : pool;
  this.o1g_1 = pool;
  this.p1g_1 = head;
  this.q1g_1 = head.g1e_1;
  this.r1g_1 = head.h1e_1;
  this.s1g_1 = head.i1e_1;
  var tmp = this;
  // Inline function 'kotlin.Long.minus' call
  var other = this.s1g_1 - this.r1g_1 | 0;
  tmp.t1g_1 = remaining.mb(toLong(other));
  this.u1g_1 = false;
}
protoOf(Input).v1j = function () {
  var tmp;
  var tmp_0;
  // Inline function 'io.ktor.utils.io.core.Input.headRemaining' call
  if ((this.s1g_1 - this.r1g_1 | 0) === 0) {
    tmp_0 = this.t1g_1.equals(new Long(0, 0));
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = this.u1g_1 ? true : doFill(this) == null;
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(Input).o1o = function () {
  // Inline function 'kotlin.also' call
  var this_0 = this.p1g_1;
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.Input.<get-head>.<anonymous>' call
  this_0.k1m(this.r1g_1);
  return this_0;
};
protoOf(Input).f1p = function (newValue) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(newValue.o6(new Long(0, 0)) >= 0)) {
    // Inline function 'io.ktor.utils.io.core.Input.<set-tailRemaining>.<anonymous>' call
    var message = "tailRemaining shouldn't be negative: " + newValue.toString();
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  this.t1g_1 = newValue;
};
protoOf(Input).v1g = function () {
  // Inline function 'io.ktor.utils.io.core.Input.headRemaining' call
  var tmp$ret$0 = this.s1g_1 - this.r1g_1 | 0;
  return toLong(tmp$ret$0).lb(this.t1g_1);
};
protoOf(Input).y1i = function () {
  return !(this.r1g_1 === this.s1g_1) ? true : !this.t1g_1.equals(new Long(0, 0));
};
protoOf(Input).mu = function () {
  var head = this.o1o();
  var empty = Companion_getInstance_4().q1e_1;
  if (!(head === empty)) {
    _set__head__b4pap2(this, empty);
    this.f1p(new Long(0, 0));
    releaseAll(head, this.o1g_1);
  }
};
protoOf(Input).f1o = function () {
  this.mu();
  if (!this.u1g_1) {
    this.u1g_1 = true;
  }
  this.e1p();
};
protoOf(Input).q1d = function () {
  var head = this.o1o();
  var empty = Companion_getInstance_4().q1e_1;
  if (head === empty)
    return null;
  _set__head__b4pap2(this, empty);
  this.f1p(new Long(0, 0));
  return head;
};
protoOf(Input).g1p = function () {
  var head = this.o1o();
  var next = head.zz();
  var empty = Companion_getInstance_4().q1e_1;
  if (head === empty)
    return null;
  if (next == null) {
    _set__head__b4pap2(this, empty);
    this.f1p(new Long(0, 0));
  } else {
    _set__head__b4pap2(this, next);
    // Inline function 'kotlin.Long.minus' call
    var this_0 = this.t1g_1;
    // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
    var other = next.i1e_1 - next.h1e_1 | 0;
    var tmp$ret$1 = this_0.mb(toLong(other));
    this.f1p(tmp$ret$1);
  }
  head.j1o(null);
  return head;
};
protoOf(Input).h1p = function (chain) {
  if (chain === Companion_getInstance_4().q1e_1)
    return Unit_instance;
  var size = remainingAll(chain);
  if (this.p1g_1 === Companion_getInstance_4().q1e_1) {
    _set__head__b4pap2(this, chain);
    // Inline function 'kotlin.Long.minus' call
    // Inline function 'io.ktor.utils.io.core.Input.headRemaining' call
    var other = this.s1g_1 - this.r1g_1 | 0;
    var tmp$ret$1 = size.mb(toLong(other));
    this.f1p(tmp$ret$1);
  } else {
    findTail(this.p1g_1).j1o(chain);
    this.f1p(this.t1g_1.lb(size));
  }
};
protoOf(Input).i1p = function (chain) {
  var tail = findTail(this.o1o());
  // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
  var size = chain.i1e_1 - chain.h1e_1 | 0;
  var tmp;
  if (size === 0) {
    tmp = true;
  } else {
    // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
    tmp = (tail.k1e_1 - tail.i1e_1 | 0) < size;
  }
  if (tmp)
    return false;
  writeBufferAppend(tail, chain, size);
  if (this.o1o() === tail) {
    this.s1g_1 = tail.i1e_1;
  } else {
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$2 = this.t1g_1.lb(toLong(size));
    this.f1p(tmp$ret$2);
  }
  return true;
};
protoOf(Input).j1p = function (n) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(n >= 0)) {
    // Inline function 'io.ktor.utils.io.core.Input.discard.<anonymous>' call
    var message = 'Negative discard is not allowed: ' + n;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return discardAsMuchAsPossible_0(this, n, 0);
};
protoOf(Input).h1m = function (n) {
  if (!(this.j1p(n) === n))
    throw new EOFException('Unable to discard ' + n + ' bytes due to end of packet');
};
protoOf(Input).t1k = function (n) {
  if (n.o6(new Long(0, 0)) <= 0)
    return new Long(0, 0);
  return discardAsMuchAsPossible(this, n, new Long(0, 0));
};
protoOf(Input).k1p = function (min, max) {
  if (min === 0 ? max === 0 ? true : this.v1j() : false)
    return '';
  var remaining = this.v1g();
  if (remaining.o6(new Long(0, 0)) > 0 ? toLong(max).o6(remaining) >= 0 : false)
    return readTextExactBytes(this, remaining.ra());
  // Inline function 'kotlin.text.buildString' call
  var capacity = coerceAtMost(coerceAtLeast(min, 16), max);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder_init_$Create$(capacity);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.Input.readText.<anonymous>' call
  readASCII(this, this_0, min, max);
  return this_0.toString();
};
protoOf(Input).l1p = function (min, max, $super) {
  min = min === VOID ? 0 : min;
  max = max === VOID ? IntCompanionObject_instance.MAX_VALUE : max;
  return $super === VOID ? this.k1p(min, max) : $super.k1p.call(this, min, max);
};
protoOf(Input).m1p = function (minSize) {
  return prepareReadLoop(this, minSize, this.o1o());
};
protoOf(Input).n1p = function (current) {
  return this.o1p(current);
};
protoOf(Input).o1p = function (current) {
  return ensureNext(this, current, Companion_getInstance_4().q1e_1);
};
protoOf(Input).p1p = function (current) {
  var tmp0_elvis_lhs = current.zz();
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return fixGapAfterReadFallback(this, current);
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var next = tmp;
  // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
  var remaining = current.i1e_1 - current.h1e_1 | 0;
  // Inline function 'kotlin.comparisons.minOf' call
  // Inline function 'io.ktor.utils.io.core.Buffer.endGap' call
  var b = 8 - (current.l1e_1 - current.k1e_1 | 0) | 0;
  var overrunSize = Math.min(remaining, b);
  if (next.j1e_1 < overrunSize) {
    return fixGapAfterReadFallback(this, current);
  }
  restoreStartGap(next, overrunSize);
  if (remaining > overrunSize) {
    current.t1m();
    this.s1g_1 = current.i1e_1;
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$3 = this.t1g_1.lb(toLong(overrunSize));
    this.f1p(tmp$ret$3);
  } else {
    _set__head__b4pap2(this, next);
    // Inline function 'kotlin.Long.minus' call
    var this_0 = this.t1g_1;
    // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
    var other = (next.i1e_1 - next.h1e_1 | 0) - overrunSize | 0;
    var tmp$ret$5 = this_0.mb(toLong(other));
    this.f1p(tmp$ret$5);
    current.h1o();
    current.i1o(this.o1g_1);
  }
};
protoOf(Input).c1p = function () {
  var buffer = this.o1g_1.d1o();
  try {
    buffer.n1m(8);
    var tmp = buffer.i1e_1;
    // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
    var tmp$ret$0 = buffer.k1e_1 - buffer.i1e_1 | 0;
    var copied = this.d1p(buffer.g1e_1, tmp, tmp$ret$0);
    if (copied === 0) {
      this.u1g_1 = true;
      // Inline function 'io.ktor.utils.io.core.canRead' call
      if (!(buffer.i1e_1 > buffer.h1e_1)) {
        buffer.i1o(this.o1g_1);
        return null;
      }
    }
    buffer.i1m(copied);
    return buffer;
  } catch ($p) {
    if ($p instanceof Error) {
      var t = $p;
      buffer.i1o(this.o1g_1);
      throw t;
    } else {
      throw $p;
    }
  }
};
protoOf(Input).t1o = function () {
  if (!this.u1g_1) {
    this.u1g_1 = true;
  }
};
protoOf(Input).q1p = function (minSize) {
  var head = this.o1o();
  if ((this.s1g_1 - this.r1g_1 | 0) >= minSize)
    return head;
  return prepareReadLoop(this, minSize, head);
};
protoOf(Input).r1p = function (head) {
  var tmp0_elvis_lhs = head.h1o();
  var next = tmp0_elvis_lhs == null ? Companion_getInstance_4().q1e_1 : tmp0_elvis_lhs;
  _set__head__b4pap2(this, next);
  // Inline function 'kotlin.Long.minus' call
  var this_0 = this.t1g_1;
  // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
  var other = next.i1e_1 - next.h1e_1 | 0;
  var tmp$ret$1 = this_0.mb(toLong(other));
  this.f1p(tmp$ret$1);
  head.i1o(this.o1g_1);
  return next;
};
function discard_0(_this__u8e3s4) {
  Companion_getInstance();
  return _this__u8e3s4.t1k(new Long(-1, 2147483647));
}
function readFully_1(_this__u8e3s4, dst, offset, length) {
  offset = offset === VOID ? 0 : offset;
  length = length === VOID ? dst.length - offset | 0 : length;
  // Inline function 'io.ktor.utils.io.core.requireNoRemaining' call
  // Inline function 'io.ktor.utils.io.core.readFullyBytesTemplate' call
  var remaining = length;
  var dstOffset = offset;
  $l$block: {
    // Inline function 'io.ktor.utils.io.core.takeWhile' call
    var release = true;
    var tmp0_elvis_lhs = prepareReadFirstHead(_this__u8e3s4, 1);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      break $l$block;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var current = tmp;
    try {
      $l$loop_0: do {
        // Inline function 'io.ktor.utils.io.core.readFullyBytesTemplate.<anonymous>' call
        var buffer = current;
        // Inline function 'kotlin.comparisons.minOf' call
        var a = remaining;
        // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
        var b = buffer.i1e_1 - buffer.h1e_1 | 0;
        var count = Math.min(a, b);
        // Inline function 'io.ktor.utils.io.core.readFully.<anonymous>' call
        var dstOffset_0 = dstOffset;
        readFully(buffer, dst, dstOffset_0, count);
        remaining = remaining - count | 0;
        dstOffset = dstOffset + count | 0;
        if (!(remaining > 0)) {
          break $l$loop_0;
        }
        release = false;
        var tmp1_elvis_lhs = prepareReadNextHead(_this__u8e3s4, current);
        var tmp_0;
        if (tmp1_elvis_lhs == null) {
          break $l$loop_0;
        } else {
          tmp_0 = tmp1_elvis_lhs;
        }
        var next = tmp_0;
        current = next;
        release = true;
      }
       while (true);
    }finally {
      if (release) {
        completeReadHead(_this__u8e3s4, current);
      }
    }
  }
  var this_0 = remaining;
  if (this_0 > 0) {
    prematureEndOfStream(this_0);
  }
}
function readFully_2(_this__u8e3s4, dst, length) {
  var tmp;
  if (length === VOID) {
    // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
    tmp = dst.k1e_1 - dst.i1e_1 | 0;
  } else {
    tmp = length;
  }
  length = tmp;
  // Inline function 'io.ktor.utils.io.core.requireNoRemaining' call
  // Inline function 'io.ktor.utils.io.core.readFullyBytesTemplate' call
  var remaining = length;
  var dstOffset = 0;
  $l$block: {
    // Inline function 'io.ktor.utils.io.core.takeWhile' call
    var release = true;
    var tmp0_elvis_lhs = prepareReadFirstHead(_this__u8e3s4, 1);
    var tmp_0;
    if (tmp0_elvis_lhs == null) {
      break $l$block;
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    var current = tmp_0;
    try {
      $l$loop_0: do {
        // Inline function 'io.ktor.utils.io.core.readFullyBytesTemplate.<anonymous>' call
        var buffer = current;
        // Inline function 'kotlin.comparisons.minOf' call
        var a = remaining;
        // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
        var b = buffer.i1e_1 - buffer.h1e_1 | 0;
        var count = Math.min(a, b);
        // Inline function 'io.ktor.utils.io.core.readFully.<anonymous>' call
        readFully_0(buffer, dst, count);
        remaining = remaining - count | 0;
        dstOffset = dstOffset + count | 0;
        if (!(remaining > 0)) {
          break $l$loop_0;
        }
        release = false;
        var tmp1_elvis_lhs = prepareReadNextHead(_this__u8e3s4, current);
        var tmp_1;
        if (tmp1_elvis_lhs == null) {
          break $l$loop_0;
        } else {
          tmp_1 = tmp1_elvis_lhs;
        }
        var next = tmp_1;
        current = next;
        release = true;
      }
       while (true);
    }finally {
      if (release) {
        completeReadHead(_this__u8e3s4, current);
      }
    }
  }
  var this_0 = remaining;
  if (this_0 > 0) {
    prematureEndOfStream(this_0);
  }
}
function readShort_0(_this__u8e3s4) {
  var tmp$ret$3;
  $l$block: {
    // Inline function 'io.ktor.utils.io.core.readPrimitive' call
    // Inline function 'io.ktor.utils.io.core.Input.headRemaining' call
    if ((_this__u8e3s4.s1g_1 - _this__u8e3s4.r1g_1 | 0) > 2) {
      var index = _this__u8e3s4.r1g_1;
      _this__u8e3s4.r1g_1 = index + 2 | 0;
      // Inline function 'io.ktor.utils.io.core.readShort.<anonymous>' call
      // Inline function 'io.ktor.utils.io.bits.loadShortAt' call
      tmp$ret$3 = _this__u8e3s4.q1g_1.g1m_1.getInt16(index, false);
      break $l$block;
    }
    // Inline function 'io.ktor.utils.io.core.readShort.<anonymous>' call
    tmp$ret$3 = readShortFallback(_this__u8e3s4);
  }
  return tmp$ret$3;
}
function readShortFallback(_this__u8e3s4) {
  // Inline function 'io.ktor.utils.io.core.readPrimitiveFallback' call
  var tmp0_elvis_lhs = prepareReadFirstHead(_this__u8e3s4, 2);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    prematureEndOfStream(2);
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var head = tmp;
  // Inline function 'io.ktor.utils.io.core.readShortFallback.<anonymous>' call
  var value = readShort(head);
  completeReadHead(_this__u8e3s4, head);
  return value;
}
function flushChain($this) {
  var tmp0_elvis_lhs = $this.q1d();
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return Unit_instance;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var oldTail = tmp;
  try {
    // Inline function 'io.ktor.utils.io.core.forEachChunk' call
    // Inline function 'kotlin.contracts.contract' call
    var current = oldTail;
    $l$loop: do {
      // Inline function 'io.ktor.utils.io.core.Output.flushChain.<anonymous>' call
      var chunk = current;
      var tmp_0 = chunk.h1e_1;
      // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
      var tmp$ret$0 = chunk.i1e_1 - chunk.h1e_1 | 0;
      $this.m1o(chunk.g1e_1, tmp_0, tmp$ret$0);
      var tmp0_elvis_lhs_0 = current.zz();
      var tmp_1;
      if (tmp0_elvis_lhs_0 == null) {
        break $l$loop;
      } else {
        tmp_1 = tmp0_elvis_lhs_0;
      }
      current = tmp_1;
    }
     while (true);
  }finally {
    releaseAll(oldTail, $this.i1d_1);
  }
}
function appendNewChunk($this) {
  var new_0 = $this.i1d_1.d1o();
  new_0.n1m(8);
  $this.p1o(new_0);
  return new_0;
}
function appendChainImpl($this, head, newTail, chainedSizeDelta) {
  var _tail = $this.k1d_1;
  if (_tail == null) {
    $this.j1d_1 = head;
    $this.p1d_1 = 0;
  } else {
    _tail.j1o(head);
    var tailPosition = $this.m1d_1;
    _tail.j1m(tailPosition);
    $this.p1d_1 = $this.p1d_1 + (tailPosition - $this.o1d_1 | 0) | 0;
  }
  $this.k1d_1 = newTail;
  $this.p1d_1 = $this.p1d_1 + chainedSizeDelta | 0;
  $this.l1d_1 = newTail.g1e_1;
  $this.m1d_1 = newTail.i1e_1;
  $this.o1d_1 = newTail.h1e_1;
  $this.n1d_1 = newTail.k1e_1;
}
function writeByteFallback($this, v) {
  appendNewChunk($this).w1m(v);
  $this.m1d_1 = $this.m1d_1 + 1 | 0;
}
function appendCharFallback($this, c) {
  $l$block: {
    // Inline function 'io.ktor.utils.io.core.Output.write' call
    var buffer = $this.r1o(3);
    try {
      // Inline function 'io.ktor.utils.io.core.Output.appendCharFallback.<anonymous>' call
      // Inline function 'io.ktor.utils.io.core.internal.putUtf8Char' call
      var this_0 = buffer.g1e_1;
      var offset = buffer.i1e_1;
      // Inline function 'kotlin.code' call
      var v = Char__toInt_impl_vasixd(c);
      var tmp;
      if (0 <= v ? v <= 127 : false) {
        // Inline function 'io.ktor.utils.io.bits.Memory.storeAt' call
        var value = toByte(v);
        this_0.g1m_1.setInt8(offset, value);
        tmp = 1;
      } else if (128 <= v ? v <= 2047 : false) {
        // Inline function 'io.ktor.utils.io.bits.set' call
        var value_0 = toByte(192 | v >> 6 & 31);
        this_0.g1m_1.setInt8(offset, value_0);
        // Inline function 'io.ktor.utils.io.bits.set' call
        var index = offset + 1 | 0;
        var value_1 = toByte(128 | v & 63);
        this_0.g1m_1.setInt8(index, value_1);
        tmp = 2;
      } else if (2048 <= v ? v <= 65535 : false) {
        // Inline function 'io.ktor.utils.io.bits.set' call
        var value_2 = toByte(224 | v >> 12 & 15);
        this_0.g1m_1.setInt8(offset, value_2);
        // Inline function 'io.ktor.utils.io.bits.set' call
        var index_0 = offset + 1 | 0;
        var value_3 = toByte(128 | v >> 6 & 63);
        this_0.g1m_1.setInt8(index_0, value_3);
        // Inline function 'io.ktor.utils.io.bits.set' call
        var index_1 = offset + 2 | 0;
        var value_4 = toByte(128 | v & 63);
        this_0.g1m_1.setInt8(index_1, value_4);
        tmp = 3;
      } else if (65536 <= v ? v <= 1114111 : false) {
        // Inline function 'io.ktor.utils.io.bits.set' call
        var value_5 = toByte(240 | v >> 18 & 7);
        this_0.g1m_1.setInt8(offset, value_5);
        // Inline function 'io.ktor.utils.io.bits.set' call
        var index_2 = offset + 1 | 0;
        var value_6 = toByte(128 | v >> 12 & 63);
        this_0.g1m_1.setInt8(index_2, value_6);
        // Inline function 'io.ktor.utils.io.bits.set' call
        var index_3 = offset + 2 | 0;
        var value_7 = toByte(128 | v >> 6 & 63);
        this_0.g1m_1.setInt8(index_3, value_7);
        // Inline function 'io.ktor.utils.io.bits.set' call
        var index_4 = offset + 3 | 0;
        var value_8 = toByte(128 | v & 63);
        this_0.g1m_1.setInt8(index_4, value_8);
        tmp = 4;
      } else {
        malformedCodePoint(v);
      }
      var size = tmp;
      buffer.i1m(size);
      var result = size;
      // Inline function 'kotlin.check' call
      // Inline function 'kotlin.contracts.contract' call
      if (!(result >= 0)) {
        // Inline function 'io.ktor.utils.io.core.Output.write.<anonymous>' call
        var message = "The returned value shouldn't be negative";
        throw IllegalStateException_init_$Create$(toString(message));
      }
      break $l$block;
    }finally {
      $this.f1m();
    }
  }
}
function writePacketMerging($this, tail, foreignStolen, pool) {
  tail.j1m($this.m1d_1);
  // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
  var lastSize = tail.i1e_1 - tail.h1e_1 | 0;
  // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
  var nextSize = foreignStolen.i1e_1 - foreignStolen.h1e_1 | 0;
  var maxCopySize = get_PACKET_MAX_COPY_SIZE();
  var tmp;
  var tmp_0;
  if (nextSize < maxCopySize) {
    // Inline function 'io.ktor.utils.io.core.Buffer.endGap' call
    var tmp_1 = tail.l1e_1 - tail.k1e_1 | 0;
    // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
    tmp_0 = nextSize <= (tmp_1 + (tail.k1e_1 - tail.i1e_1 | 0) | 0);
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = nextSize;
  } else {
    tmp = -1;
  }
  var appendSize = tmp;
  var tmp_2;
  if ((lastSize < maxCopySize ? lastSize <= foreignStolen.j1e_1 : false) ? isExclusivelyOwned(foreignStolen) : false) {
    tmp_2 = lastSize;
  } else {
    tmp_2 = -1;
  }
  var prependSize = tmp_2;
  if (appendSize === -1 ? prependSize === -1 : false) {
    $this.q1o(foreignStolen);
  } else if (prependSize === -1 ? true : appendSize <= prependSize) {
    // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
    var tmp_3 = tail.k1e_1 - tail.i1e_1 | 0;
    // Inline function 'io.ktor.utils.io.core.Buffer.endGap' call
    var tmp$ret$5 = tail.l1e_1 - tail.k1e_1 | 0;
    writeBufferAppend(tail, foreignStolen, tmp_3 + tmp$ret$5 | 0);
    $this.f1m();
    var tmp0_safe_receiver = foreignStolen.h1o();
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.contracts.contract' call
      $this.q1o(tmp0_safe_receiver);
    }
    foreignStolen.i1o(pool);
  } else if (appendSize === -1 ? true : prependSize < appendSize) {
    writePacketSlowPrepend($this, foreignStolen, tail);
  } else {
    throw IllegalStateException_init_$Create$('prep = ' + prependSize + ', app = ' + appendSize);
  }
}
function writePacketSlowPrepend($this, foreignStolen, tail) {
  writeBufferPrepend(foreignStolen, tail);
  var tmp0_elvis_lhs = $this.j1d_1;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var message = "head should't be null since it is already handled in the fast-path";
    throw IllegalStateException_init_$Create$(toString(message));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var _head = tmp;
  if (_head === tail) {
    $this.j1d_1 = foreignStolen;
  } else {
    var pre = _head;
    $l$loop: while (true) {
      var next = ensureNotNull(pre.zz());
      if (next === tail)
        break $l$loop;
      pre = next;
    }
    pre.j1o(foreignStolen);
  }
  tail.i1o($this.i1d_1);
  $this.k1d_1 = findTail(foreignStolen);
}
function Output(pool) {
  this.i1d_1 = pool;
  this.j1d_1 = null;
  this.k1d_1 = null;
  this.l1d_1 = Companion_getInstance_6().s1p_1;
  this.m1d_1 = 0;
  this.n1d_1 = 0;
  this.o1d_1 = 0;
  this.p1d_1 = 0;
}
protoOf(Output).k1o = function () {
  return this.p1d_1 + (this.m1d_1 - this.o1d_1 | 0) | 0;
};
protoOf(Output).o1o = function () {
  var tmp0_elvis_lhs = this.j1d_1;
  return tmp0_elvis_lhs == null ? Companion_getInstance_4().q1e_1 : tmp0_elvis_lhs;
};
protoOf(Output).f6 = function () {
  flushChain(this);
};
protoOf(Output).q1d = function () {
  var tmp0_elvis_lhs = this.j1d_1;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var head = tmp;
  var tmp1_safe_receiver = this.k1d_1;
  if (tmp1_safe_receiver == null)
    null;
  else
    tmp1_safe_receiver.j1m(this.m1d_1);
  this.j1d_1 = null;
  this.k1d_1 = null;
  this.m1d_1 = 0;
  this.n1d_1 = 0;
  this.o1d_1 = 0;
  this.p1d_1 = 0;
  this.l1d_1 = Companion_getInstance_6().s1p_1;
  return head;
};
protoOf(Output).p1o = function (buffer) {
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(buffer.zz() == null)) {
    // Inline function 'io.ktor.utils.io.core.Output.appendSingleChunk.<anonymous>' call
    var message = 'It should be a single buffer chunk.';
    throw IllegalStateException_init_$Create$(toString(message));
  }
  appendChainImpl(this, buffer, buffer, 0);
};
protoOf(Output).q1o = function (head) {
  var tail = findTail(head);
  // Inline function 'io.ktor.utils.io.core.internal.toIntOrFail' call
  // Inline function 'kotlin.Long.minus' call
  var this_0 = remainingAll(head);
  // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
  var other = tail.i1e_1 - tail.h1e_1 | 0;
  var this_1 = this_0.mb(toLong(other));
  var name = 'total size increase';
  if (this_1.o6(toLong(IntCompanionObject_instance.MAX_VALUE)) >= 0) {
    failLongToIntConversion(this_1, name);
  }
  var chainedSizeDelta = this_1.ra();
  appendChainImpl(this, head, tail, chainedSizeDelta);
};
protoOf(Output).w1m = function (v) {
  var index = this.m1d_1;
  if (index < this.n1d_1) {
    this.m1d_1 = index + 1 | 0;
    // Inline function 'io.ktor.utils.io.bits.set' call
    this.l1d_1.g1m_1.setInt8(index, v);
    return Unit_instance;
  }
  return writeByteFallback(this, v);
};
protoOf(Output).f1o = function () {
  try {
    this.f6();
  }finally {
    this.l1o();
  }
};
protoOf(Output).o5 = function (value) {
  var tailPosition = this.m1d_1;
  if ((this.n1d_1 - tailPosition | 0) >= 3) {
    // Inline function 'io.ktor.utils.io.core.internal.putUtf8Char' call
    var this_0 = this.l1d_1;
    // Inline function 'kotlin.code' call
    var v = Char__toInt_impl_vasixd(value);
    var tmp;
    if (0 <= v ? v <= 127 : false) {
      // Inline function 'io.ktor.utils.io.bits.Memory.storeAt' call
      var value_0 = toByte(v);
      this_0.g1m_1.setInt8(tailPosition, value_0);
      tmp = 1;
    } else if (128 <= v ? v <= 2047 : false) {
      // Inline function 'io.ktor.utils.io.bits.set' call
      var value_1 = toByte(192 | v >> 6 & 31);
      this_0.g1m_1.setInt8(tailPosition, value_1);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index = tailPosition + 1 | 0;
      var value_2 = toByte(128 | v & 63);
      this_0.g1m_1.setInt8(index, value_2);
      tmp = 2;
    } else if (2048 <= v ? v <= 65535 : false) {
      // Inline function 'io.ktor.utils.io.bits.set' call
      var value_3 = toByte(224 | v >> 12 & 15);
      this_0.g1m_1.setInt8(tailPosition, value_3);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_0 = tailPosition + 1 | 0;
      var value_4 = toByte(128 | v >> 6 & 63);
      this_0.g1m_1.setInt8(index_0, value_4);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_1 = tailPosition + 2 | 0;
      var value_5 = toByte(128 | v & 63);
      this_0.g1m_1.setInt8(index_1, value_5);
      tmp = 3;
    } else if (65536 <= v ? v <= 1114111 : false) {
      // Inline function 'io.ktor.utils.io.bits.set' call
      var value_6 = toByte(240 | v >> 18 & 7);
      this_0.g1m_1.setInt8(tailPosition, value_6);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_2 = tailPosition + 1 | 0;
      var value_7 = toByte(128 | v >> 12 & 63);
      this_0.g1m_1.setInt8(index_2, value_7);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_3 = tailPosition + 2 | 0;
      var value_8 = toByte(128 | v >> 6 & 63);
      this_0.g1m_1.setInt8(index_3, value_8);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_4 = tailPosition + 3 | 0;
      var value_9 = toByte(128 | v & 63);
      this_0.g1m_1.setInt8(index_4, value_9);
      tmp = 4;
    } else {
      malformedCodePoint(v);
    }
    var size = tmp;
    this.m1d_1 = tailPosition + size | 0;
    return this;
  }
  appendCharFallback(this, value);
  return this;
};
protoOf(Output).d8 = function (value) {
  if (value == null) {
    this.e8('null', 0, 4);
  } else {
    this.e8(value, 0, charSequenceLength(value));
  }
  return this;
};
protoOf(Output).e8 = function (value, startIndex, endIndex) {
  if (value == null) {
    return this.e8('null', startIndex, endIndex);
  }
  writeText(this, value, startIndex, endIndex, Charsets_getInstance().t1p_1);
  return this;
};
protoOf(Output).w1g = function (packet) {
  var foreignStolen = packet.q1d();
  if (foreignStolen == null) {
    packet.mu();
    return Unit_instance;
  }
  var tail = this.k1d_1;
  if (tail == null) {
    this.q1o(foreignStolen);
    return Unit_instance;
  }
  writePacketMerging(this, tail, foreignStolen, packet.o1g_1);
};
protoOf(Output).r1d = function (chunkBuffer) {
  var _tail = this.k1d_1;
  if (_tail == null) {
    this.q1o(chunkBuffer);
    return Unit_instance;
  }
  writePacketMerging(this, _tail, chunkBuffer, this.i1d_1);
};
protoOf(Output).k1i = function (p, n) {
  var remaining = n;
  $l$loop: while (remaining.o6(new Long(0, 0)) > 0) {
    // Inline function 'io.ktor.utils.io.core.Input.headRemaining' call
    var tmp$ret$0 = p.s1g_1 - p.r1g_1 | 0;
    var headRemaining = toLong(tmp$ret$0);
    if (headRemaining.o6(remaining) <= 0) {
      remaining = remaining.mb(headRemaining);
      var tmp0_elvis_lhs = p.g1p();
      var tmp;
      if (tmp0_elvis_lhs == null) {
        throw new EOFException('Unexpected end of packet');
      } else {
        tmp = tmp0_elvis_lhs;
      }
      this.p1o(tmp);
    } else {
      // Inline function 'io.ktor.utils.io.core.read' call
      // Inline function 'kotlin.contracts.contract' call
      var tmp0_elvis_lhs_0 = p.q1p(1);
      var tmp_0;
      if (tmp0_elvis_lhs_0 == null) {
        prematureEndOfStream(1);
      } else {
        tmp_0 = tmp0_elvis_lhs_0;
      }
      var buffer = tmp_0;
      var positionBefore = buffer.h1e_1;
      try {
        // Inline function 'io.ktor.utils.io.core.Output.writePacket.<anonymous>' call
        writeFully_2(this, buffer, remaining.ra());
      }finally {
        var positionAfter = buffer.h1e_1;
        if (positionAfter < positionBefore) {
          throw IllegalStateException_init_$Create$("Buffer's position shouldn't be rewinded");
        }
        if (positionAfter === buffer.i1e_1) {
          p.o1p(buffer);
        } else {
          p.r1g_1 = positionAfter;
        }
      }
      break $l$loop;
    }
  }
};
protoOf(Output).mu = function () {
  this.f1o();
};
protoOf(Output).r1o = function (n) {
  // Inline function 'io.ktor.utils.io.core.Output.tailRemaining' call
  if ((this.n1d_1 - this.m1d_1 | 0) >= n) {
    var tmp0_safe_receiver = this.k1d_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.contracts.contract' call
      tmp0_safe_receiver.j1m(this.m1d_1);
      return tmp0_safe_receiver;
    }
  }
  return appendNewChunk(this);
};
protoOf(Output).f1m = function () {
  var tmp0_safe_receiver = this.k1d_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    this.m1d_1 = tmp0_safe_receiver.i1e_1;
  }
};
protoOf(Output).s1o = function () {
  var head = this.o1o();
  if (!(head === Companion_getInstance_4().q1e_1)) {
    // Inline function 'kotlin.check' call
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlin.check' call
    // Inline function 'kotlin.contracts.contract' call
    if (!(head.zz() == null)) {
      // Inline function 'kotlin.check.<anonymous>' call
      var message = 'Check failed.';
      throw IllegalStateException_init_$Create$(toString(message));
    }
    head.p1m();
    head.n1m(8);
    this.m1d_1 = head.i1e_1;
    this.o1d_1 = this.m1d_1;
    this.n1d_1 = head.k1e_1;
  }
};
function writeFully_2(_this__u8e3s4, src, length) {
  var tmp;
  if (length === VOID) {
    // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
    tmp = src.i1e_1 - src.h1e_1 | 0;
  } else {
    tmp = length;
  }
  length = tmp;
  // Inline function 'io.ktor.utils.io.core.writeFullyBytesTemplate' call
  var currentOffset = 0;
  var remaining = length;
  // Inline function 'io.ktor.utils.io.core.writeWhile' call
  var tail = prepareWriteHead(_this__u8e3s4, 1, null);
  try {
    $l$loop: while (true) {
      // Inline function 'io.ktor.utils.io.core.writeFullyBytesTemplate.<anonymous>' call
      var buffer = tail;
      // Inline function 'kotlin.comparisons.minOf' call
      var a = remaining;
      // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
      var b = buffer.k1e_1 - buffer.i1e_1 | 0;
      var size = Math.min(a, b);
      // Inline function 'io.ktor.utils.io.core.writeFully.<anonymous>' call
      writeFully_1(buffer, src, size);
      currentOffset = currentOffset + size | 0;
      remaining = remaining - size | 0;
      if (!(remaining > 0))
        break $l$loop;
      tail = prepareWriteHead(_this__u8e3s4, 1, tail);
    }
  }finally {
    _this__u8e3s4.f1m();
  }
}
function writeFully_3(_this__u8e3s4, src, offset, length) {
  offset = offset === VOID ? 0 : offset;
  length = length === VOID ? src.length - offset | 0 : length;
  // Inline function 'io.ktor.utils.io.core.writeFullyBytesTemplate' call
  var currentOffset = offset;
  var remaining = length;
  // Inline function 'io.ktor.utils.io.core.writeWhile' call
  var tail = prepareWriteHead(_this__u8e3s4, 1, null);
  try {
    $l$loop: while (true) {
      // Inline function 'io.ktor.utils.io.core.writeFullyBytesTemplate.<anonymous>' call
      var buffer = tail;
      // Inline function 'kotlin.comparisons.minOf' call
      var a = remaining;
      // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
      var b = buffer.k1e_1 - buffer.i1e_1 | 0;
      var size = Math.min(a, b);
      // Inline function 'io.ktor.utils.io.core.writeFully.<anonymous>' call
      var currentOffset_0 = currentOffset;
      writeFully_0(buffer, src, currentOffset_0, size);
      currentOffset = currentOffset + size | 0;
      remaining = remaining - size | 0;
      if (!(remaining > 0))
        break $l$loop;
      tail = prepareWriteHead(_this__u8e3s4, 1, tail);
    }
  }finally {
    _this__u8e3s4.f1m();
  }
}
function writeShort_0(_this__u8e3s4, value) {
  var tmp$ret$0;
  $l$block: {
    // Inline function 'io.ktor.utils.io.core.writePrimitiveTemplate' call
    var index = _this__u8e3s4.m1d_1;
    if ((_this__u8e3s4.n1d_1 - index | 0) > 2) {
      _this__u8e3s4.m1d_1 = index + 2 | 0;
      // Inline function 'io.ktor.utils.io.core.writeShort.<anonymous>' call
      // Inline function 'io.ktor.utils.io.bits.storeShortAt' call
      _this__u8e3s4.l1d_1.g1m_1.setInt16(index, value, false);
      tmp$ret$0 = true;
      break $l$block;
    }
    tmp$ret$0 = false;
  }
  if (!tmp$ret$0) {
    writeShortFallback(_this__u8e3s4, value);
  }
}
function writeShortFallback(_this__u8e3s4, value) {
  // Inline function 'io.ktor.utils.io.core.writePrimitiveFallbackTemplate' call
  var tail = _this__u8e3s4.r1o(2);
  // Inline function 'io.ktor.utils.io.core.writeShortFallback.<anonymous>' call
  writeShort(tail, value);
  _this__u8e3s4.f1m();
  if (!true) {
    // Inline function 'io.ktor.utils.io.bits.highByte' call
    var tmp$ret$1 = toByte(value >>> 8 | 0);
    _this__u8e3s4.w1m(tmp$ret$1);
    // Inline function 'io.ktor.utils.io.bits.lowByte' call
    var tmp$ret$2 = toByte(value & 255);
    _this__u8e3s4.w1m(tmp$ret$2);
  }
}
function readText(_this__u8e3s4, charset, max) {
  charset = charset === VOID ? Charsets_getInstance().t1p_1 : charset;
  max = max === VOID ? IntCompanionObject_instance.MAX_VALUE : max;
  return decode(charset.w1p(), _this__u8e3s4, max);
}
function readBytes(_this__u8e3s4, n) {
  var tmp;
  if (n === VOID) {
    // Inline function 'io.ktor.utils.io.core.coerceAtMostMaxIntOrFail' call
    var this_0 = _this__u8e3s4.v1g();
    var message = 'Unable to convert to a ByteArray: packet is too big';
    if (this_0.o6(toLong(IntCompanionObject_instance.MAX_VALUE)) > 0)
      throw IllegalArgumentException_init_$Create$(message);
    tmp = this_0.ra();
  } else {
    tmp = n;
  }
  n = tmp;
  var tmp_0;
  if (!(n === 0)) {
    // Inline function 'kotlin.also' call
    var this_1 = new Int8Array(n);
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'io.ktor.utils.io.core.readBytes.<anonymous>' call
    readFully_1(_this__u8e3s4, this_1, 0, n);
    tmp_0 = this_1;
  } else {
    tmp_0 = get_EmptyByteArray();
  }
  return tmp_0;
}
function prematureEndOfStream(size) {
  throw new EOFException('Premature end of stream: expected ' + size + ' bytes');
}
function readTextExactBytes(_this__u8e3s4, bytesCount, charset) {
  charset = charset === VOID ? Charsets_getInstance().t1p_1 : charset;
  return decodeExactBytes(charset.w1p(), _this__u8e3s4, bytesCount);
}
function writeText(_this__u8e3s4, text, fromIndex, toIndex, charset) {
  fromIndex = fromIndex === VOID ? 0 : fromIndex;
  toIndex = toIndex === VOID ? charSequenceLength(text) : toIndex;
  charset = charset === VOID ? Charsets_getInstance().t1p_1 : charset;
  if (charset === Charsets_getInstance().t1p_1) {
    return writeTextUtf8(_this__u8e3s4, text, fromIndex, toIndex);
  }
  encodeToImpl(charset.x1p(), _this__u8e3s4, text, fromIndex, toIndex);
}
function writeTextUtf8(_this__u8e3s4, text, fromIndex, toIndex) {
  var index = fromIndex;
  // Inline function 'io.ktor.utils.io.core.writeWhileSize' call
  var tail = prepareWriteHead(_this__u8e3s4, 1, null);
  try {
    var size;
    $l$loop: while (true) {
      // Inline function 'io.ktor.utils.io.core.writeTextUtf8.<anonymous>' call
      var buffer = tail;
      var memory = buffer.g1e_1;
      var dstOffset = buffer.i1e_1;
      var dstLimit = buffer.k1e_1;
      var tmp0_container = encodeUTF8(memory, text, index, toIndex, dstOffset, dstLimit);
      var characters = EncodeResult__component1_impl_36tlhi(tmp0_container);
      var bytes = EncodeResult__component2_impl_3nv7vp(tmp0_container);
      var tmp = index;
      // Inline function 'kotlin.UShort.toInt' call
      index = tmp + (_UShort___get_data__impl__g0245(characters) & 65535) | 0;
      // Inline function 'kotlin.UShort.toInt' call
      var tmp$ret$1 = _UShort___get_data__impl__g0245(bytes) & 65535;
      buffer.i1m(tmp$ret$1);
      var tmp_0;
      var tmp_1;
      // Inline function 'kotlin.UShort.toInt' call
      if ((_UShort___get_data__impl__g0245(characters) & 65535) === 0) {
        tmp_1 = index < toIndex;
      } else {
        tmp_1 = false;
      }
      if (tmp_1) {
        tmp_0 = 8;
      } else {
        if (index < toIndex) {
          tmp_0 = 1;
        } else {
          tmp_0 = 0;
        }
      }
      size = tmp_0;
      if (size <= 0)
        break $l$loop;
      tail = prepareWriteHead(_this__u8e3s4, size, tail);
    }
  }finally {
    _this__u8e3s4.f1m();
  }
}
function ChunkBuffer$Companion$EmptyPool$1() {
}
protoOf(ChunkBuffer$Companion$EmptyPool$1).d1o = function () {
  return Companion_getInstance_4().q1e_1;
};
protoOf(ChunkBuffer$Companion$EmptyPool$1).y1p = function (instance) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(instance === Companion_getInstance_4().q1e_1)) {
    // Inline function 'io.ktor.utils.io.core.internal.<no name provided>.recycle.<anonymous>' call
    var message = 'Only ChunkBuffer.Empty instance could be recycled.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
};
protoOf(ChunkBuffer$Companion$EmptyPool$1).e1o = function (instance) {
  return this.y1p(instance instanceof ChunkBuffer ? instance : THROW_CCE());
};
protoOf(ChunkBuffer$Companion$EmptyPool$1).mp = function () {
};
function ChunkBuffer$Companion$NoPool$1() {
  NoPoolImpl.call(this);
}
protoOf(ChunkBuffer$Companion$NoPool$1).d1o = function () {
  return new ChunkBuffer(DefaultAllocator_instance.f1n(get_DEFAULT_BUFFER_SIZE()), null, this);
};
protoOf(ChunkBuffer$Companion$NoPool$1).y1p = function (instance) {
  DefaultAllocator_instance.h1n(instance.g1e_1);
};
protoOf(ChunkBuffer$Companion$NoPool$1).e1o = function (instance) {
  return this.y1p(instance instanceof ChunkBuffer ? instance : THROW_CCE());
};
function ChunkBuffer$Companion$NoPoolManuallyManaged$1() {
  NoPoolImpl.call(this);
}
protoOf(ChunkBuffer$Companion$NoPoolManuallyManaged$1).d1o = function () {
  throw UnsupportedOperationException_init_$Create$("This pool doesn't support borrow");
};
protoOf(ChunkBuffer$Companion$NoPoolManuallyManaged$1).y1p = function (instance) {
};
protoOf(ChunkBuffer$Companion$NoPoolManuallyManaged$1).e1o = function (instance) {
  return this.y1p(instance instanceof ChunkBuffer ? instance : THROW_CCE());
};
function appendNext($this, chunk) {
  if (!$this.t1n_1.atomicfu$compareAndSet(null, chunk)) {
    throw IllegalStateException_init_$Create$('This chunk has already a next chunk.');
  }
}
function Companion_2() {
  Companion_instance_2 = this;
  var tmp = this;
  tmp.p1e_1 = new ChunkBuffer$Companion$EmptyPool$1();
  this.q1e_1 = new ChunkBuffer(Companion_getInstance_6().s1p_1, null, this.p1e_1);
  var tmp_0 = this;
  tmp_0.r1e_1 = new ChunkBuffer$Companion$NoPool$1();
  var tmp_1 = this;
  tmp_1.s1e_1 = new ChunkBuffer$Companion$NoPoolManuallyManaged$1();
}
protoOf(Companion_2).v1k = function () {
  return get_DefaultChunkedBufferPool();
};
var Companion_instance_2;
function Companion_getInstance_4() {
  if (Companion_instance_2 == null)
    new Companion_2();
  return Companion_instance_2;
}
function ChunkBuffer(memory, origin, parentPool) {
  Companion_getInstance_4();
  Buffer.call(this, memory);
  this.s1n_1 = parentPool;
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!(origin === this)) {
    // Inline function 'io.ktor.utils.io.core.internal.ChunkBuffer.<anonymous>' call
    var message = "A chunk couldn't be a view of itself.";
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  this.t1n_1 = atomic$ref$1(null);
  this.u1n_1 = atomic$int$1(1);
  this.v1n_1 = origin;
}
protoOf(ChunkBuffer).j1o = function (newValue) {
  if (newValue == null) {
    this.h1o();
  } else {
    appendNext(this, newValue);
  }
};
protoOf(ChunkBuffer).zz = function () {
  return this.t1n_1.kotlinx$atomicfu$value;
};
protoOf(ChunkBuffer).z1n = function () {
  return this.u1n_1.kotlinx$atomicfu$value;
};
protoOf(ChunkBuffer).h1o = function () {
  return this.t1n_1.atomicfu$getAndSet(null);
};
protoOf(ChunkBuffer).g1o = function () {
  // Inline function 'kotlin.let' call
  var tmp0_elvis_lhs = this.v1n_1;
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.internal.ChunkBuffer.duplicate.<anonymous>' call
  var newOrigin = tmp0_elvis_lhs == null ? this : tmp0_elvis_lhs;
  newOrigin.z1p();
  // Inline function 'kotlin.also' call
  var this_0 = new ChunkBuffer(this.g1e_1, newOrigin, this.s1n_1);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.internal.ChunkBuffer.duplicate.<anonymous>.<anonymous>' call
  this.u1m(this_0);
  return this_0;
};
protoOf(ChunkBuffer).i1o = function (pool) {
  if (this.a1q()) {
    var origin = this.v1n_1;
    if (!(origin == null)) {
      this.w1n();
      origin.i1o(pool);
    } else {
      var tmp0_elvis_lhs = this.s1n_1;
      var poolToUse = tmp0_elvis_lhs == null ? pool : tmp0_elvis_lhs;
      poolToUse.e1o(this);
    }
  }
};
protoOf(ChunkBuffer).w1n = function () {
  if (!this.u1n_1.atomicfu$compareAndSet(0, -1)) {
    throw IllegalStateException_init_$Create$('Unable to unlink: buffer is in use.');
  }
  this.h1o();
  this.v1n_1 = null;
};
protoOf(ChunkBuffer).z1p = function () {
  $l$block: {
    // Inline function 'kotlinx.atomicfu.update' call
    var this_0 = this.u1n_1;
    while (true) {
      var cur = this_0.kotlinx$atomicfu$value;
      // Inline function 'io.ktor.utils.io.core.internal.ChunkBuffer.acquire.<anonymous>' call
      if (cur <= 0)
        throw IllegalStateException_init_$Create$('Unable to acquire chunk: it is already released.');
      var upd = cur + 1 | 0;
      if (this_0.atomicfu$compareAndSet(cur, upd)) {
        break $l$block;
      }
    }
  }
};
protoOf(ChunkBuffer).c1o = function () {
  $l$block: {
    // Inline function 'kotlinx.atomicfu.update' call
    var this_0 = this.u1n_1;
    while (true) {
      var cur = this_0.kotlinx$atomicfu$value;
      // Inline function 'io.ktor.utils.io.core.internal.ChunkBuffer.unpark.<anonymous>' call
      if (cur < 0) {
        throw IllegalStateException_init_$Create$("This instance is already disposed and couldn't be borrowed.");
      }
      if (cur > 0) {
        throw IllegalStateException_init_$Create$('This instance is already in use but somehow appeared in the pool.');
      }
      var upd = 1;
      if (this_0.atomicfu$compareAndSet(cur, upd)) {
        break $l$block;
      }
    }
  }
};
protoOf(ChunkBuffer).a1q = function () {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlinx.atomicfu.updateAndGet' call
    var this_0 = this.u1n_1;
    while (true) {
      var cur = this_0.kotlinx$atomicfu$value;
      // Inline function 'io.ktor.utils.io.core.internal.ChunkBuffer.release.<anonymous>' call
      if (cur <= 0)
        throw IllegalStateException_init_$Create$('Unable to release: it is already released.');
      var upd = cur - 1 | 0;
      if (this_0.atomicfu$compareAndSet(cur, upd)) {
        tmp$ret$1 = upd;
        break $l$block;
      }
    }
  }
  return tmp$ret$1 === 0;
};
protoOf(ChunkBuffer).x1m = function () {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(this.v1n_1 == null)) {
    // Inline function 'io.ktor.utils.io.core.internal.ChunkBuffer.reset.<anonymous>' call
    var message = 'Unable to reset buffer with origin';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  protoOf(Buffer).x1m.call(this);
  this.t1n_1.kotlinx$atomicfu$value = null;
};
function isExclusivelyOwned(_this__u8e3s4) {
  return _this__u8e3s4.z1n() === 1;
}
function _EncodeResult___init__impl__vkc0cy(value) {
  return value;
}
function _EncodeResult___get_value__impl__h0r466($this) {
  return $this;
}
function _EncodeResult___init__impl__vkc0cy_0(characters, bytes) {
  // Inline function 'kotlin.UShort.toInt' call
  var tmp = (_UShort___get_data__impl__g0245(characters) & 65535) << 16;
  // Inline function 'kotlin.UShort.toInt' call
  var tmp$ret$1 = _UShort___get_data__impl__g0245(bytes) & 65535;
  return _EncodeResult___init__impl__vkc0cy(tmp | tmp$ret$1);
}
function _EncodeResult___get_characters__impl__rrxzcv($this) {
  // Inline function 'kotlin.toUShort' call
  // Inline function 'io.ktor.utils.io.bits.highShort' call
  var this_0 = _EncodeResult___get_value__impl__h0r466($this);
  var this_1 = toShort(this_0 >>> 16 | 0);
  return _UShort___init__impl__jigrne(this_1);
}
function _EncodeResult___get_bytes__impl__bt0kq0($this) {
  // Inline function 'kotlin.toUShort' call
  // Inline function 'io.ktor.utils.io.bits.lowShort' call
  var this_0 = _EncodeResult___get_value__impl__h0r466($this);
  var this_1 = toShort(this_0 & 65535);
  return _UShort___init__impl__jigrne(this_1);
}
function EncodeResult__component1_impl_36tlhi($this) {
  return _EncodeResult___get_characters__impl__rrxzcv($this);
}
function EncodeResult__component2_impl_3nv7vp($this) {
  return _EncodeResult___get_bytes__impl__bt0kq0($this);
}
function failLongToIntConversion(value, name) {
  throw IllegalArgumentException_init_$Create$('Long value ' + value.toString() + ' of ' + name + " doesn't fit into 32-bit integer");
}
function MalformedUTF8InputException(message) {
  Exception_init_$Init$(message, this);
  captureStack(this, MalformedUTF8InputException);
}
function malformedByteCount(byteCount) {
  throw new MalformedUTF8InputException('Expected ' + byteCount + ' more character bytes');
}
function isBmpCodePoint(cp) {
  return (cp >>> 16 | 0) === 0;
}
function isValidCodePoint(codePoint) {
  return codePoint <= 1114111;
}
function malformedCodePoint(value) {
  throw IllegalArgumentException_init_$Create$('Malformed code-point ' + value + ' found');
}
function highSurrogate(cp) {
  return (cp >>> 10 | 0) + 55232 | 0;
}
function lowSurrogate(cp) {
  return (cp & 1023) + 56320 | 0;
}
function encodeUTF8(_this__u8e3s4, text, from, to, dstOffset, dstLimit) {
  // Inline function 'kotlin.comparisons.minOf' call
  // Inline function 'kotlin.UShort.toInt' call
  Companion_getInstance_0();
  var this_0 = _UShort___init__impl__jigrne(-1);
  var b = from + (_UShort___get_data__impl__g0245(this_0) & 65535) | 0;
  var lastCharIndex = Math.min(to, b);
  // Inline function 'kotlin.UShort.toInt' call
  Companion_getInstance_0();
  var this_1 = _UShort___init__impl__jigrne(-1);
  var tmp$ret$2 = _UShort___get_data__impl__g0245(this_1) & 65535;
  var resultLimit = coerceAtMost(dstLimit, tmp$ret$2);
  var resultPosition = dstOffset;
  var index = from;
  $l$loop: do {
    if (resultPosition >= resultLimit ? true : index >= lastCharIndex) {
      // Inline function 'kotlin.toUShort' call
      var this_2 = index - from | 0;
      var tmp = _UShort___init__impl__jigrne(toShort(this_2));
      // Inline function 'kotlin.toUShort' call
      var this_3 = resultPosition - dstOffset | 0;
      var tmp$ret$4 = _UShort___init__impl__jigrne(toShort(this_3));
      return _EncodeResult___init__impl__vkc0cy_0(tmp, tmp$ret$4);
    }
    // Inline function 'kotlin.code' call
    var tmp0 = index;
    index = tmp0 + 1 | 0;
    var this_4 = charSequenceGet(text, tmp0);
    var character = Char__toInt_impl_vasixd(this_4) & 65535;
    if ((character & 65408) === 0) {
      // Inline function 'io.ktor.utils.io.bits.Memory.storeAt' call
      var tmp1 = resultPosition;
      resultPosition = tmp1 + 1 | 0;
      var value = toByte(character);
      _this__u8e3s4.g1m_1.setInt8(tmp1, value);
    } else {
      break $l$loop;
    }
  }
   while (true);
  index = index - 1 | 0;
  return encodeUTF8Stage1(_this__u8e3s4, text, index, lastCharIndex, from, resultPosition, resultLimit, dstOffset);
}
function encodeUTF8Stage1(_this__u8e3s4, text, index1, lastCharIndex, from, resultPosition1, resultLimit, dstOffset) {
  var index = index1;
  var resultPosition = resultPosition1;
  var stage1Limit = resultLimit - 3 | 0;
  $l$loop: do {
    var freeSpace = stage1Limit - resultPosition | 0;
    if (freeSpace <= 0 ? true : index >= lastCharIndex) {
      break $l$loop;
    }
    var tmp0 = index;
    index = tmp0 + 1 | 0;
    var character = charSequenceGet(text, tmp0);
    var tmp;
    if (isHighSurrogate(character)) {
      var tmp_0;
      if (index === lastCharIndex ? true : !isLowSurrogate(charSequenceGet(text, index))) {
        tmp_0 = 63;
      } else {
        var tmp1 = index;
        index = tmp1 + 1 | 0;
        tmp_0 = codePoint(character, charSequenceGet(text, tmp1));
      }
      tmp = tmp_0;
    } else {
      // Inline function 'kotlin.code' call
      tmp = Char__toInt_impl_vasixd(character);
    }
    var codepoint = tmp;
    // Inline function 'io.ktor.utils.io.core.internal.putUtf8Char' call
    var offset = resultPosition;
    var tmp_1;
    if (0 <= codepoint ? codepoint <= 127 : false) {
      // Inline function 'io.ktor.utils.io.bits.Memory.storeAt' call
      var value = toByte(codepoint);
      _this__u8e3s4.g1m_1.setInt8(offset, value);
      tmp_1 = 1;
    } else if (128 <= codepoint ? codepoint <= 2047 : false) {
      // Inline function 'io.ktor.utils.io.bits.set' call
      var value_0 = toByte(192 | codepoint >> 6 & 31);
      _this__u8e3s4.g1m_1.setInt8(offset, value_0);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_0 = offset + 1 | 0;
      var value_1 = toByte(128 | codepoint & 63);
      _this__u8e3s4.g1m_1.setInt8(index_0, value_1);
      tmp_1 = 2;
    } else if (2048 <= codepoint ? codepoint <= 65535 : false) {
      // Inline function 'io.ktor.utils.io.bits.set' call
      var value_2 = toByte(224 | codepoint >> 12 & 15);
      _this__u8e3s4.g1m_1.setInt8(offset, value_2);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_1 = offset + 1 | 0;
      var value_3 = toByte(128 | codepoint >> 6 & 63);
      _this__u8e3s4.g1m_1.setInt8(index_1, value_3);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_2 = offset + 2 | 0;
      var value_4 = toByte(128 | codepoint & 63);
      _this__u8e3s4.g1m_1.setInt8(index_2, value_4);
      tmp_1 = 3;
    } else if (65536 <= codepoint ? codepoint <= 1114111 : false) {
      // Inline function 'io.ktor.utils.io.bits.set' call
      var value_5 = toByte(240 | codepoint >> 18 & 7);
      _this__u8e3s4.g1m_1.setInt8(offset, value_5);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_3 = offset + 1 | 0;
      var value_6 = toByte(128 | codepoint >> 12 & 63);
      _this__u8e3s4.g1m_1.setInt8(index_3, value_6);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_4 = offset + 2 | 0;
      var value_7 = toByte(128 | codepoint >> 6 & 63);
      _this__u8e3s4.g1m_1.setInt8(index_4, value_7);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_5 = offset + 3 | 0;
      var value_8 = toByte(128 | codepoint & 63);
      _this__u8e3s4.g1m_1.setInt8(index_5, value_8);
      tmp_1 = 4;
    } else {
      malformedCodePoint(codepoint);
    }
    var size = tmp_1;
    resultPosition = resultPosition + size | 0;
  }
   while (true);
  if (resultPosition === stage1Limit) {
    return encodeUTF8Stage2(_this__u8e3s4, text, index, lastCharIndex, from, resultPosition, resultLimit, dstOffset);
  }
  // Inline function 'kotlin.toUShort' call
  var this_0 = index - from | 0;
  var tmp_2 = _UShort___init__impl__jigrne(toShort(this_0));
  // Inline function 'kotlin.toUShort' call
  var this_1 = resultPosition - dstOffset | 0;
  var tmp$ret$12 = _UShort___init__impl__jigrne(toShort(this_1));
  return _EncodeResult___init__impl__vkc0cy_0(tmp_2, tmp$ret$12);
}
function codePoint(high, low) {
  // Inline function 'kotlin.code' call
  var highValue = Char__toInt_impl_vasixd(high) - 55232 | 0;
  // Inline function 'kotlin.code' call
  var lowValue = Char__toInt_impl_vasixd(low) - 56320 | 0;
  return highValue << 10 | lowValue;
}
function encodeUTF8Stage2(_this__u8e3s4, text, index1, lastCharIndex, from, resultPosition1, resultLimit, dstOffset) {
  var index = index1;
  var resultPosition = resultPosition1;
  $l$loop_0: do {
    var freeSpace = resultLimit - resultPosition | 0;
    if (freeSpace <= 0 ? true : index >= lastCharIndex) {
      break $l$loop_0;
    }
    var tmp0 = index;
    index = tmp0 + 1 | 0;
    var character = charSequenceGet(text, tmp0);
    var tmp;
    if (!isHighSurrogate(character)) {
      // Inline function 'kotlin.code' call
      tmp = Char__toInt_impl_vasixd(character);
    } else {
      var tmp_0;
      if (index === lastCharIndex ? true : !isLowSurrogate(charSequenceGet(text, index))) {
        tmp_0 = 63;
      } else {
        var tmp1 = index;
        index = tmp1 + 1 | 0;
        tmp_0 = codePoint(character, charSequenceGet(text, tmp1));
      }
      tmp = tmp_0;
    }
    var codepoint = tmp;
    // Inline function 'io.ktor.utils.io.core.internal.charactersSize' call
    var tmp_1;
    if (1 <= codepoint ? codepoint <= 127 : false) {
      tmp_1 = 1;
    } else if (128 <= codepoint ? codepoint <= 2047 : false) {
      tmp_1 = 2;
    } else if (2048 <= codepoint ? codepoint <= 65535 : false) {
      tmp_1 = 3;
    } else if (65536 <= codepoint ? codepoint <= 1114111 : false) {
      tmp_1 = 4;
    } else {
      malformedCodePoint(codepoint);
    }
    if (tmp_1 > freeSpace) {
      index = index - 1 | 0;
      break $l$loop_0;
    }
    // Inline function 'io.ktor.utils.io.core.internal.putUtf8Char' call
    var offset = resultPosition;
    var tmp_2;
    if (0 <= codepoint ? codepoint <= 127 : false) {
      // Inline function 'io.ktor.utils.io.bits.Memory.storeAt' call
      var value = toByte(codepoint);
      _this__u8e3s4.g1m_1.setInt8(offset, value);
      tmp_2 = 1;
    } else if (128 <= codepoint ? codepoint <= 2047 : false) {
      // Inline function 'io.ktor.utils.io.bits.set' call
      var value_0 = toByte(192 | codepoint >> 6 & 31);
      _this__u8e3s4.g1m_1.setInt8(offset, value_0);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_0 = offset + 1 | 0;
      var value_1 = toByte(128 | codepoint & 63);
      _this__u8e3s4.g1m_1.setInt8(index_0, value_1);
      tmp_2 = 2;
    } else if (2048 <= codepoint ? codepoint <= 65535 : false) {
      // Inline function 'io.ktor.utils.io.bits.set' call
      var value_2 = toByte(224 | codepoint >> 12 & 15);
      _this__u8e3s4.g1m_1.setInt8(offset, value_2);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_1 = offset + 1 | 0;
      var value_3 = toByte(128 | codepoint >> 6 & 63);
      _this__u8e3s4.g1m_1.setInt8(index_1, value_3);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_2 = offset + 2 | 0;
      var value_4 = toByte(128 | codepoint & 63);
      _this__u8e3s4.g1m_1.setInt8(index_2, value_4);
      tmp_2 = 3;
    } else if (65536 <= codepoint ? codepoint <= 1114111 : false) {
      // Inline function 'io.ktor.utils.io.bits.set' call
      var value_5 = toByte(240 | codepoint >> 18 & 7);
      _this__u8e3s4.g1m_1.setInt8(offset, value_5);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_3 = offset + 1 | 0;
      var value_6 = toByte(128 | codepoint >> 12 & 63);
      _this__u8e3s4.g1m_1.setInt8(index_3, value_6);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_4 = offset + 2 | 0;
      var value_7 = toByte(128 | codepoint >> 6 & 63);
      _this__u8e3s4.g1m_1.setInt8(index_4, value_7);
      // Inline function 'io.ktor.utils.io.bits.set' call
      var index_5 = offset + 3 | 0;
      var value_8 = toByte(128 | codepoint & 63);
      _this__u8e3s4.g1m_1.setInt8(index_5, value_8);
      tmp_2 = 4;
    } else {
      malformedCodePoint(codepoint);
    }
    var size = tmp_2;
    resultPosition = resultPosition + size | 0;
  }
   while (true);
  // Inline function 'kotlin.toUShort' call
  var this_0 = index - from | 0;
  var tmp_3 = _UShort___init__impl__jigrne(toShort(this_0));
  // Inline function 'kotlin.toUShort' call
  var this_1 = resultPosition - dstOffset | 0;
  var tmp$ret$13 = _UShort___init__impl__jigrne(toShort(this_1));
  return _EncodeResult___init__impl__vkc0cy_0(tmp_3, tmp$ret$13);
}
function get_EmptyByteArray() {
  _init_properties_Unsafe_kt__orlvcq();
  return EmptyByteArray;
}
var EmptyByteArray;
function completeReadHead(_this__u8e3s4, current) {
  _init_properties_Unsafe_kt__orlvcq();
  if (current === _this__u8e3s4)
    return Unit_instance;
  else {
    // Inline function 'io.ktor.utils.io.core.canRead' call
    if (!(current.i1e_1 > current.h1e_1)) {
      _this__u8e3s4.o1p(current);
    } else {
      // Inline function 'io.ktor.utils.io.core.Buffer.endGap' call
      var tmp = current.l1e_1 - current.k1e_1 | 0;
      if (tmp < 8) {
        _this__u8e3s4.p1p(current);
      } else {
        _this__u8e3s4.r1g_1 = current.h1e_1;
      }
    }
  }
}
function prepareReadFirstHead(_this__u8e3s4, minSize) {
  _init_properties_Unsafe_kt__orlvcq();
  return _this__u8e3s4.m1p(minSize);
}
function prepareReadNextHead(_this__u8e3s4, current) {
  _init_properties_Unsafe_kt__orlvcq();
  if (current === _this__u8e3s4) {
    return _this__u8e3s4.y1i() ? _this__u8e3s4 : null;
  }
  return _this__u8e3s4.n1p(current);
}
function unsafeAppend(_this__u8e3s4, builder) {
  _init_properties_Unsafe_kt__orlvcq();
  var builderSize = builder.n();
  var tmp0_elvis_lhs = builder.q1d();
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return 0;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var builderHead = tmp;
  if ((builderSize <= get_PACKET_MAX_COPY_SIZE() ? builderHead.zz() == null : false) ? _this__u8e3s4.i1p(builderHead) : false) {
    builder.s1o();
    return builderSize;
  }
  _this__u8e3s4.h1p(builderHead);
  return builderSize;
}
function prepareWriteHead(_this__u8e3s4, capacity, current) {
  _init_properties_Unsafe_kt__orlvcq();
  if (!(current == null)) {
    _this__u8e3s4.f1m();
  }
  return _this__u8e3s4.r1o(capacity);
}
var properties_initialized_Unsafe_kt_o5mw48;
function _init_properties_Unsafe_kt__orlvcq() {
  if (!properties_initialized_Unsafe_kt_o5mw48) {
    properties_initialized_Unsafe_kt_o5mw48 = true;
    EmptyByteArray = new Int8Array(0);
  }
}
function trySuspend($this, sleepCondition, $completion) {
  var tmp = new $trySuspendCOROUTINE$53($this, sleepCondition, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function $sleepCOROUTINE$52(_this__u8e3s4, sleepCondition, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.v1q_1 = _this__u8e3s4;
  this.w1q_1 = sleepCondition;
}
protoOf($sleepCOROUTINE$52).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          this.ic_1 = 1;
          suspendResult = trySuspend(this.v1q_1, this.w1q_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          if (suspendResult) {
            return Unit_instance;
          } else {
            this.ic_1 = 2;
            continue $sm;
          }

        case 2:
          this.v1q_1.y1c();
          return Unit_instance;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $trySuspendCOROUTINE$53(_this__u8e3s4, sleepCondition, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.j1q_1 = _this__u8e3s4;
  this.k1q_1 = sleepCondition;
}
protoOf($trySuspendCOROUTINE$53).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          this.l1q_1 = false;
          this.m1q_1 = Job_0();
          if (this.j1q_1.x1c_1.atomicfu$compareAndSet(null, this.m1q_1) ? this.k1q_1() : false) {
            this.l1q_1 = true;
            this.ic_1 = 1;
            suspendResult = this.m1q_1.gu(this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 2;
            continue $sm;
          }

        case 1:
          this.ic_1 = 2;
          continue $sm;
        case 2:
          return this.l1q_1;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function AwaitingSlot() {
  this.x1c_1 = atomic$ref$1(null);
}
protoOf(AwaitingSlot).s1f = function (sleepCondition, $completion) {
  var tmp = new $sleepCOROUTINE$52(this, sleepCondition, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(AwaitingSlot).y1c = function () {
  var tmp0_safe_receiver = this.x1c_1.atomicfu$getAndSet(null);
  if (tmp0_safe_receiver == null)
    null;
  else
    tmp0_safe_receiver.fu();
};
protoOf(AwaitingSlot).i1l = function (cause) {
  var tmp0_elvis_lhs = this.x1c_1.atomicfu$getAndSet(null);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return Unit_instance;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var continuation = tmp;
  if (!(cause == null)) {
    continuation.eu(cause);
  } else {
    continuation.fu();
  }
};
function copyToSequentialImpl(_this__u8e3s4, dst, limit, $completion) {
  var tmp = new $copyToSequentialImplCOROUTINE$54(_this__u8e3s4, dst, limit, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function copyToTail(_this__u8e3s4, dst, limit, $completion) {
  var tmp = new $copyToTailCOROUTINE$55(_this__u8e3s4, dst, limit, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function $copyToSequentialImplCOROUTINE$54(_this__u8e3s4, dst, limit, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.f1r_1 = _this__u8e3s4;
  this.g1r_1 = dst;
  this.h1r_1 = limit;
}
protoOf($copyToSequentialImplCOROUTINE$54).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 10;
          if (!!(this.f1r_1 === this.g1r_1)) {
            var message = 'Failed requirement.';
            throw IllegalArgumentException_init_$Create$(toString(message));
          }

          if (!(this.f1r_1.s1d() == null)) {
            this.g1r_1.i12(this.f1r_1.s1d());
            return new Long(0, 0);
          }

          this.i1r_1 = this.h1r_1;
          this.ic_1 = 1;
          continue $sm;
        case 1:
          if (!(this.i1r_1.o6(new Long(0, 0)) > 0)) {
            this.ic_1 = 9;
            continue $sm;
          }

          this.ic_1 = 2;
          suspendResult = this.f1r_1.g1l(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          this.j1r_1 = suspendResult;
          if (!this.j1r_1) {
            this.ic_1 = 9;
            continue $sm;
          } else {
            this.ic_1 = 3;
            continue $sm;
          }

        case 3:
          this.k1r_1 = this.f1r_1.j1l(this.g1r_1, this.i1r_1);
          if (this.k1r_1.equals(new Long(0, 0))) {
            this.ic_1 = 6;
            suspendResult = copyToTail(this.f1r_1, this.g1r_1, this.i1r_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            if (this.g1r_1.g1f() === 0) {
              this.ic_1 = 4;
              suspendResult = this.g1r_1.n1g(1, this);
              if (suspendResult === get_COROUTINE_SUSPENDED()) {
                return suspendResult;
              }
              continue $sm;
            } else {
              this.ic_1 = 5;
              continue $sm;
            }
          }

        case 4:
          this.ic_1 = 5;
          continue $sm;
        case 5:
          this.l1r_1 = this.k1r_1;
          this.ic_1 = 8;
          continue $sm;
        case 6:
          var tail = suspendResult;
          if (tail.equals(new Long(0, 0))) {
            this.ic_1 = 9;
            continue $sm;
          } else {
            this.ic_1 = 7;
            continue $sm;
          }

        case 7:
          this.l1r_1 = tail;
          this.ic_1 = 8;
          continue $sm;
        case 8:
          var copied = this.l1r_1;
          this.i1r_1 = this.i1r_1.mb(copied);
          if (copied.o6(new Long(0, 0)) > 0) {
            this.g1r_1.f6();
          }

          this.ic_1 = 1;
          continue $sm;
        case 9:
          return this.h1r_1.mb(this.i1r_1);
        case 10:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 10) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $copyToTailCOROUTINE$55(_this__u8e3s4, dst, limit, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.u1r_1 = _this__u8e3s4;
  this.v1r_1 = dst;
  this.w1r_1 = limit;
}
protoOf($copyToTailCOROUTINE$55).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 9;
          this.x1r_1 = Companion_getInstance_4().v1k().d1o();
          this.ic_1 = 1;
          continue $sm;
        case 1:
          this.ic_1 = 2;
          continue $sm;
        case 2:
          this.jc_1 = 8;
          this.x1r_1.q1m(coerceAtMost_0(this.w1r_1, toLong(this.x1r_1.l1e_1)).ra());
          this.ic_1 = 3;
          suspendResult = this.u1r_1.d1l(this.x1r_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 3:
          this.z1r_1 = suspendResult;
          if (this.z1r_1 === -1) {
            this.x1r_1.i1o(Companion_getInstance_4().v1k());
            this.y1r_1 = new Long(0, 0);
            this.jc_1 = 9;
            this.ic_1 = 6;
            continue $sm;
          } else {
            this.ic_1 = 4;
            continue $sm;
          }

        case 4:
          this.ic_1 = 5;
          suspendResult = this.v1r_1.z1k(this.x1r_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 5:
          this.y1r_1 = toLong(this.z1r_1);
          this.jc_1 = 9;
          this.ic_1 = 6;
          var tmp_0 = this;
          continue $sm;
        case 6:
          var tmp_1 = this.y1r_1;
          this.jc_1 = 9;
          this.x1r_1.i1o(Companion_getInstance_4().v1k());
          return tmp_1;
        case 7:
          this.jc_1 = 9;
          this.x1r_1.i1o(Companion_getInstance_4().v1k());
          return Unit_instance;
        case 8:
          this.jc_1 = 9;
          var t = this.lc_1;
          this.x1r_1.i1o(Companion_getInstance_4().v1k());
          throw t;
        case 9:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 9) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function get_ByteArrayPool() {
  _init_properties_ByteArrayPool_kt__kfi3uj();
  return ByteArrayPool;
}
var ByteArrayPool;
function ByteArrayPool$1() {
  DefaultPool.call(this, 128);
}
protoOf(ByteArrayPool$1).e1n = function () {
  return new Int8Array(4096);
};
var properties_initialized_ByteArrayPool_kt_td6pfh;
function _init_properties_ByteArrayPool_kt__kfi3uj() {
  if (!properties_initialized_ByteArrayPool_kt_td6pfh) {
    properties_initialized_ByteArrayPool_kt_td6pfh = true;
    ByteArrayPool = new ByteArrayPool$1();
  }
}
function ObjectPool() {
}
function NoPoolImpl() {
}
protoOf(NoPoolImpl).e1o = function (instance) {
};
protoOf(NoPoolImpl).mp = function () {
};
function ByteChannel(autoFlush) {
  autoFlush = autoFlush === VOID ? false : autoFlush;
  return new ByteChannelJS(Companion_getInstance_4().q1e_1, autoFlush);
}
function copyTo(_this__u8e3s4, dst, limit, $completion) {
  var tmp = _this__u8e3s4 instanceof ByteChannelSequentialBase ? _this__u8e3s4 : THROW_CCE();
  return copyToSequentialImpl(tmp, dst instanceof ByteChannelSequentialBase ? dst : THROW_CCE(), limit, $completion);
}
function ByteReadChannel_0(content, offset, length) {
  // Inline function 'kotlin.collections.isEmpty' call
  if (content.length === 0)
    return Companion_getInstance_5().n1e();
  var head = Companion_getInstance_4().v1k().d1o();
  var tail = head;
  var start = offset;
  var end = start + length | 0;
  $l$loop: while (true) {
    tail.n1m(8);
    // Inline function 'kotlin.comparisons.minOf' call
    var a = end - start | 0;
    // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
    var this_0 = tail;
    var b = this_0.k1e_1 - this_0.i1e_1 | 0;
    var size = Math.min(a, b);
    writeFully_0(tail instanceof Buffer ? tail : THROW_CCE(), content, start, size);
    start = start + size | 0;
    if (start === end)
      break $l$loop;
    var current = tail;
    tail = Companion_getInstance_4().v1k().d1o();
    current.j1o(tail);
  }
  // Inline function 'kotlin.apply' call
  var this_1 = new ByteChannelJS(head, false);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.ByteReadChannel.<anonymous>' call
  close_0(this_1);
  return this_1;
}
function ByteChannelJS$attachJob$lambda(this$0) {
  return function (cause) {
    this$0.s1s_1 = null;
    var tmp;
    if (!(cause == null)) {
      this$0.ft(unwrapCancellationException(cause));
      tmp = Unit_instance;
    }
    return Unit_instance;
  };
}
function ByteChannelJS(initial, autoFlush) {
  ByteChannelSequentialBase.call(this, initial, autoFlush);
  this.s1s_1 = null;
}
protoOf(ByteChannelJS).k1l = function (job) {
  var tmp0_safe_receiver = this.s1s_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    tmp0_safe_receiver.co();
  }
  this.s1s_1 = job;
  job.yn(true, VOID, ByteChannelJS$attachJob$lambda(this));
};
protoOf(ByteChannelJS).toString = function () {
  return 'ByteChannel[' + this.s1s_1 + ', ' + hashCode(this) + ']';
};
function ByteReadChannel$Companion$Empty$delegate$lambda() {
  // Inline function 'kotlin.apply' call
  var this_0 = new ByteChannelJS(Companion_getInstance_4().q1e_1, false);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.Companion.Empty$delegate.<anonymous>.<anonymous>' call
  this_0.i12(null);
  return this_0;
}
function Companion_3() {
  Companion_instance_3 = this;
  var tmp = this;
  tmp.d1s_1 = lazy(ByteReadChannel$Companion$Empty$delegate$lambda);
}
protoOf(Companion_3).n1e = function () {
  // Inline function 'kotlin.getValue' call
  var this_0 = this.d1s_1;
  Empty$factory();
  return this_0.l2();
};
var Companion_instance_3;
function Companion_getInstance_5() {
  if (Companion_instance_3 == null)
    new Companion_3();
  return Companion_instance_3;
}
function ByteReadChannel_1() {
}
function Empty$factory() {
  return getPropertyCallableRef('Empty', 1, KProperty1, function (receiver) {
    return receiver.n1e();
  }, null);
}
function DefaultAllocator() {
}
protoOf(DefaultAllocator).f1n = function (size) {
  return new Memory(new DataView(new ArrayBuffer(size)));
};
protoOf(DefaultAllocator).h1n = function (instance) {
};
var DefaultAllocator_instance;
function DefaultAllocator_getInstance() {
  return DefaultAllocator_instance;
}
function of(_this__u8e3s4, array, offset, length) {
  offset = offset === VOID ? 0 : offset;
  length = length === VOID ? array.length - offset | 0 : length;
  // Inline function 'kotlin.js.asDynamic' call
  var typedArray = array;
  return of_0(Companion_getInstance_6(), typedArray, offset, length);
}
function of_0(_this__u8e3s4, view, offset, length) {
  offset = offset === VOID ? 0 : offset;
  length = length === VOID ? view.byteLength : length;
  return of_1(Companion_getInstance_6(), view.buffer, view.byteOffset + offset | 0, length);
}
function of_1(_this__u8e3s4, buffer, offset, length) {
  offset = offset === VOID ? 0 : offset;
  length = length === VOID ? buffer.byteLength - offset | 0 : length;
  return new Memory(new DataView(buffer, offset, length));
}
function Companion_4() {
  Companion_instance_4 = this;
  this.s1p_1 = new Memory(new DataView(new ArrayBuffer(0)));
}
var Companion_instance_4;
function Companion_getInstance_6() {
  if (Companion_instance_4 == null)
    new Companion_4();
  return Companion_instance_4;
}
function Memory(view) {
  Companion_getInstance_6();
  this.g1m_1 = view;
}
protoOf(Memory).t1s = function (offset, length) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(offset >= 0)) {
    // Inline function 'io.ktor.utils.io.bits.Memory.slice.<anonymous>' call
    var message = "offset shouldn't be negative: " + offset;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(length >= 0)) {
    // Inline function 'io.ktor.utils.io.bits.Memory.slice.<anonymous>' call
    var message_0 = "length shouldn't be negative: " + length;
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  var tmp = toLong(offset + length | 0);
  // Inline function 'io.ktor.utils.io.bits.Memory.size' call
  var tmp$ret$2 = toLong(this.g1m_1.byteLength);
  if (tmp.o6(tmp$ret$2) > 0) {
    // Inline function 'io.ktor.utils.io.bits.Memory.size' call
    var tmp$ret$3 = toLong(this.g1m_1.byteLength);
    throw IndexOutOfBoundsException_init_$Create$('offset + length > size: ' + offset + ' + ' + length + ' > ' + tmp$ret$3.toString());
  }
  return new Memory(new DataView(this.g1m_1.buffer, this.g1m_1.byteOffset + offset | 0, length));
};
protoOf(Memory).y1m = function (destination, offset, length, destinationOffset) {
  var src = new Int8Array(this.g1m_1.buffer, this.g1m_1.byteOffset + offset | 0, length);
  var dst = new Int8Array(destination.g1m_1.buffer, destination.g1m_1.byteOffset + destinationOffset | 0, length);
  dst.set(src);
};
function copyTo_0(_this__u8e3s4, destination, offset, length, destinationOffset) {
  copyTo_2(_this__u8e3s4.buffer, destination, offset + _this__u8e3s4.byteOffset | 0, length, destinationOffset);
}
function copyTo_1(_this__u8e3s4, destination, offset, length, destinationOffset) {
  // Inline function 'kotlin.js.asDynamic' call
  var to = destination;
  var from = new Int8Array(_this__u8e3s4.g1m_1.buffer, _this__u8e3s4.g1m_1.byteOffset + offset | 0, length);
  to.set(from, destinationOffset);
}
function copyTo_2(_this__u8e3s4, destination, offset, length, destinationOffset) {
  var from = new Int8Array(_this__u8e3s4, offset, length);
  var to = new Int8Array(destination.g1m_1.buffer, destination.g1m_1.byteOffset + destinationOffset | 0, length);
  to.set(from, 0);
}
function Companion_5() {
}
protoOf(Companion_5).u1s = function (name) {
  switch (name) {
    case 'UTF-8':
    case 'utf-8':
    case 'UTF8':
    case 'utf8':
      return Charsets_getInstance().t1p_1;
  }
  var tmp;
  var tmp_0;
  var tmp_1;
  switch (name) {
    case 'ISO-8859-1':
    case 'iso-8859-1':
      tmp_1 = true;
      break;
    default:
      // Inline function 'kotlin.let' call

      // Inline function 'kotlin.contracts.contract' call

      // Inline function 'io.ktor.utils.io.charsets.Companion.forName.<anonymous>' call

      var it = replace(name, _Char___init__impl__6a9atx(95), _Char___init__impl__6a9atx(45));
      var tmp_2;
      if (it === 'iso-8859-1') {
        tmp_2 = true;
      } else {
        // Inline function 'kotlin.text.lowercase' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp_2 = it.toLowerCase() === 'iso-8859-1';
      }

      tmp_1 = tmp_2;
      break;
  }
  if (tmp_1) {
    tmp_0 = true;
  } else {
    tmp_0 = name === 'latin1';
  }
  if (tmp_0) {
    tmp = true;
  } else {
    tmp = name === 'Latin1';
  }
  if (tmp) {
    return Charsets_getInstance().u1p_1;
  }
  throw IllegalArgumentException_init_$Create$('Charset ' + name + ' is not supported');
};
protoOf(Companion_5).v1s = function (charset) {
  var tmp;
  switch (charset) {
    case 'UTF-8':
    case 'utf-8':
    case 'UTF8':
    case 'utf8':
      tmp = true;
      break;
    default:
      var tmp_0;
      var tmp_1;
      switch (charset) {
        case 'ISO-8859-1':
        case 'iso-8859-1':
          tmp_1 = true;
          break;
        default:
          // Inline function 'kotlin.let' call

          // Inline function 'kotlin.contracts.contract' call

          // Inline function 'io.ktor.utils.io.charsets.Companion.isSupported.<anonymous>' call

          var it = replace(charset, _Char___init__impl__6a9atx(95), _Char___init__impl__6a9atx(45));
          var tmp_2;
          if (it === 'iso-8859-1') {
            tmp_2 = true;
          } else {
            // Inline function 'kotlin.text.lowercase' call
            // Inline function 'kotlin.js.asDynamic' call
            tmp_2 = it.toLowerCase() === 'iso-8859-1';
          }

          tmp_1 = tmp_2;
          break;
      }

      if (tmp_1) {
        tmp_0 = true;
      } else {
        tmp_0 = charset === 'latin1';
      }

      if (tmp_0) {
        tmp = true;
      } else {
        tmp = false;
      }

      break;
  }
  return tmp;
};
var Companion_instance_5;
function Companion_getInstance_7() {
  return Companion_instance_5;
}
function Charset(_name) {
  this.v1p_1 = _name;
}
protoOf(Charset).equals = function (other) {
  if (this === other)
    return true;
  if (other == null ? true : !(this.constructor == other.constructor))
    return false;
  if (!(other instanceof Charset))
    THROW_CCE();
  if (!(this.v1p_1 === other.v1p_1))
    return false;
  return true;
};
protoOf(Charset).hashCode = function () {
  return getStringHashCode(this.v1p_1);
};
protoOf(Charset).toString = function () {
  return this.v1p_1;
};
function get_name(_this__u8e3s4) {
  return _this__u8e3s4.v1p_1;
}
function Charsets() {
  Charsets_instance = this;
  this.t1p_1 = new CharsetImpl('UTF-8');
  this.u1p_1 = new CharsetImpl('ISO-8859-1');
}
var Charsets_instance;
function Charsets_getInstance() {
  if (Charsets_instance == null)
    new Charsets();
  return Charsets_instance;
}
function MalformedInputException(message) {
  extendThrowable(this, message);
  captureStack(this, MalformedInputException);
}
function CharsetDecoder(_charset) {
  this.w1s_1 = _charset;
}
function encodeToByteArray(_this__u8e3s4, input, fromIndex, toIndex) {
  fromIndex = fromIndex === VOID ? 0 : fromIndex;
  toIndex = toIndex === VOID ? charSequenceLength(input) : toIndex;
  return encodeToByteArrayImpl1(_this__u8e3s4, input, fromIndex, toIndex);
}
function CharsetEncoder(_charset) {
  this.x1s_1 = _charset;
}
function CharsetImpl(name) {
  Charset.call(this, name);
  this.z1s_1 = name;
}
protoOf(CharsetImpl).x1p = function () {
  return new CharsetEncoderImpl(this);
};
protoOf(CharsetImpl).w1p = function () {
  return new CharsetDecoderImpl(this);
};
protoOf(CharsetImpl).toString = function () {
  return 'CharsetImpl(name=' + this.z1s_1 + ')';
};
protoOf(CharsetImpl).hashCode = function () {
  return getStringHashCode(this.z1s_1);
};
protoOf(CharsetImpl).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof CharsetImpl))
    return false;
  var tmp0_other_with_cast = other instanceof CharsetImpl ? other : THROW_CCE();
  if (!(this.z1s_1 === tmp0_other_with_cast.z1s_1))
    return false;
  return true;
};
function encodeToByteArrayImpl1(_this__u8e3s4, input, fromIndex, toIndex) {
  fromIndex = fromIndex === VOID ? 0 : fromIndex;
  toIndex = toIndex === VOID ? charSequenceLength(input) : toIndex;
  var start = fromIndex;
  if (start >= toIndex)
    return get_EmptyByteArray();
  var single = Companion_getInstance_4().v1k().d1o();
  try {
    var rc = encodeImpl(_this__u8e3s4, input, start, toIndex, single);
    start = start + rc | 0;
    if (start === toIndex) {
      // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
      var tmp$ret$0 = single.i1e_1 - single.h1e_1 | 0;
      var result = new Int8Array(tmp$ret$0);
      // Inline function 'io.ktor.utils.io.core.readFully' call
      var length = result.length - 0 | 0;
      readFully(single instanceof Buffer ? single : THROW_CCE(), result, 0, length);
      return result;
    }
    var tmp$ret$1;
    $l$block: {
      // Inline function 'io.ktor.utils.io.core.buildPacket' call
      // Inline function 'kotlin.contracts.contract' call
      var builder = new BytePacketBuilder();
      try {
        // Inline function 'io.ktor.utils.io.charsets.encodeToByteArrayImpl1.<anonymous>' call
        builder.p1o(single.g1o());
        encodeToImpl(_this__u8e3s4, builder, input, start, toIndex);
        tmp$ret$1 = builder.l1i();
        break $l$block;
      } catch ($p) {
        if ($p instanceof Error) {
          var t = $p;
          builder.mu();
          throw t;
        } else {
          throw $p;
        }
      }
    }
    return readBytes(tmp$ret$1);
  }finally {
    single.i1o(Companion_getInstance_4().v1k());
  }
}
function CharsetEncoderImpl(charset) {
  CharsetEncoder.call(this, charset);
  this.b1t_1 = charset;
}
protoOf(CharsetEncoderImpl).toString = function () {
  return 'CharsetEncoderImpl(charset=' + this.b1t_1 + ')';
};
protoOf(CharsetEncoderImpl).hashCode = function () {
  return this.b1t_1.hashCode();
};
protoOf(CharsetEncoderImpl).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof CharsetEncoderImpl))
    return false;
  var tmp0_other_with_cast = other instanceof CharsetEncoderImpl ? other : THROW_CCE();
  if (!this.b1t_1.equals(tmp0_other_with_cast.b1t_1))
    return false;
  return true;
};
function CharsetDecoderImpl(charset) {
  CharsetDecoder.call(this, charset);
  this.d1t_1 = charset;
}
protoOf(CharsetDecoderImpl).toString = function () {
  return 'CharsetDecoderImpl(charset=' + this.d1t_1 + ')';
};
protoOf(CharsetDecoderImpl).hashCode = function () {
  return this.d1t_1.hashCode();
};
protoOf(CharsetDecoderImpl).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof CharsetDecoderImpl))
    return false;
  var tmp0_other_with_cast = other instanceof CharsetDecoderImpl ? other : THROW_CCE();
  if (!this.d1t_1.equals(tmp0_other_with_cast.d1t_1))
    return false;
  return true;
};
function encodeImpl(_this__u8e3s4, input, fromIndex, toIndex, dst) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(fromIndex <= toIndex)) {
    // Inline function 'kotlin.require.<anonymous>' call
    var message = 'Failed requirement.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  if (get_charset(_this__u8e3s4).equals(Charsets_getInstance().u1p_1)) {
    return encodeISO88591(input, fromIndex, toIndex, dst);
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(get_charset(_this__u8e3s4) === Charsets_getInstance().t1p_1)) {
    // Inline function 'io.ktor.utils.io.charsets.encodeImpl.<anonymous>' call
    var message_0 = 'Only UTF-8 encoding is supported in JS';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  var encoder = new TextEncoder();
  var start = fromIndex;
  // Inline function 'io.ktor.utils.io.core.Buffer.writeRemaining' call
  var dstRemaining = dst.k1e_1 - dst.i1e_1 | 0;
  $l$loop: while (start < toIndex ? dstRemaining > 0 : false) {
    // Inline function 'kotlin.comparisons.minOf' call
    var a = toIndex - start | 0;
    var b = dstRemaining / 6 | 0;
    var tmp$ret$3 = Math.min(a, b);
    var numChars = coerceAtLeast(tmp$ret$3, 1);
    var dropLastChar = isHighSurrogate(charSequenceGet(input, (start + numChars | 0) - 1 | 0));
    var endIndexExclusive = (dropLastChar ? numChars === 1 : false) ? start + 2 | 0 : dropLastChar ? (start + numChars | 0) - 1 | 0 : start + numChars | 0;
    // Inline function 'kotlin.text.substring' call
    var startIndex = start;
    var tmp$ret$4 = toString(charSequenceSubSequence(input, startIndex, endIndexExclusive));
    var array1 = encoder.encode(tmp$ret$4);
    if (array1.length > dstRemaining)
      break $l$loop;
    writeFully_4(dst, array1);
    start = endIndexExclusive;
    dstRemaining = dstRemaining - array1.length | 0;
  }
  return start - fromIndex | 0;
}
function get_charset(_this__u8e3s4) {
  return _this__u8e3s4.x1s_1;
}
function decode_0(_this__u8e3s4, input, dst, max) {
  var decoder = Decoder(get_name(get_charset_0(_this__u8e3s4)), true);
  var charactersCopied = 0;
  $l$block: {
    // Inline function 'io.ktor.utils.io.core.takeWhileSize' call
    var release = true;
    var tmp0_elvis_lhs = prepareReadFirstHead(input, 1);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      break $l$block;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var current = tmp;
    var size = 1;
    try {
      $l$loop: do {
        // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
        var this_0 = current;
        var before = this_0.i1e_1 - this_0.h1e_1 | 0;
        var after;
        if (before >= size) {
          try {
            var tmp$ret$3;
            $l$block_0: {
              // Inline function 'io.ktor.utils.io.charsets.decode.<anonymous>' call
              var buffer = current;
              var rem = max - charactersCopied | 0;
              // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
              var bufferSize = buffer.i1e_1 - buffer.h1e_1 | 0;
              if (rem < bufferSize) {
                tmp$ret$3 = 0;
                break $l$block_0;
              }
              // Inline function 'io.ktor.utils.io.core.readDirectInt8Array' call
              // Inline function 'kotlin.contracts.contract' call
              // Inline function 'io.ktor.utils.io.core.read' call
              // Inline function 'kotlin.contracts.contract' call
              // Inline function 'io.ktor.utils.io.core.readDirectInt8Array.<anonymous>' call
              var memory = buffer.g1e_1;
              var start = buffer.h1e_1;
              var endExclusive = buffer.i1e_1;
              // Inline function 'io.ktor.utils.io.charsets.decode.<anonymous>.<anonymous>' call
              var view = new Int8Array(memory.g1m_1.buffer, memory.g1m_1.byteOffset + start | 0, endExclusive - start | 0);
              $l$block_2: {
                // Inline function 'io.ktor.utils.io.js.decodeWrap' call
                try {
                  // Inline function 'io.ktor.utils.io.charsets.decode.<anonymous>.<anonymous>.<anonymous>' call
                  var tmp$ret$4;
                  $l$block_1: {
                    // Inline function 'io.ktor.utils.io.js.decodeStream' call
                    // Inline function 'io.ktor.utils.io.js.decodeWrap' call
                    try {
                      tmp$ret$4 = decoder.e1t(view, decodeOptions(true));
                      break $l$block_1;
                    } catch ($p) {
                      if ($p instanceof Error) {
                        var t = $p;
                        var tmp0_elvis_lhs_0 = t.message;
                        throw new MalformedInputException('Failed to decode bytes: ' + (tmp0_elvis_lhs_0 == null ? 'no cause provided' : tmp0_elvis_lhs_0));
                      } else {
                        throw $p;
                      }
                    }
                  }
                  break $l$block_2;
                } catch ($p) {
                  if ($p instanceof Error) {
                    var t_0 = $p;
                    var tmp0_elvis_lhs_1 = t_0.message;
                    throw new MalformedInputException('Failed to decode bytes: ' + (tmp0_elvis_lhs_1 == null ? 'no cause provided' : tmp0_elvis_lhs_1));
                  } else {
                    throw $p;
                  }
                }
              }
              var decodedText = tmp$ret$4;
              dst.d8(decodedText);
              charactersCopied = charactersCopied + decodedText.length | 0;
              var rc = view.byteLength;
              buffer.h1m(rc);
              var tmp_0;
              if (charactersCopied === max) {
                var tmp_1;
                try {
                  tmp_1 = decoder.f1t();
                } catch ($p) {
                  var tmp_2;
                  var _ = $p;
                  tmp_2 = '';
                  tmp_1 = tmp_2;
                }
                var tail = tmp_1;
                // Inline function 'kotlin.text.isNotEmpty' call
                if (charSequenceLength(tail) > 0) {
                  buffer.l1m(bufferSize);
                }
                tmp_0 = 0;
              } else if (charactersCopied < max) {
                tmp_0 = get_MAX_CHARACTERS_SIZE_IN_BYTES();
              } else {
                tmp_0 = 0;
              }
              tmp$ret$3 = tmp_0;
            }
            size = tmp$ret$3;
          }finally {
            // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
            var this_1 = current;
            after = this_1.i1e_1 - this_1.h1e_1 | 0;
          }
        } else {
          after = before;
        }
        release = false;
        var tmp_3;
        if (after === 0) {
          tmp_3 = prepareReadNextHead(input, current);
        } else {
          var tmp_4;
          if (after < size) {
            tmp_4 = true;
          } else {
            // Inline function 'io.ktor.utils.io.core.Buffer.endGap' call
            var this_2 = current;
            var tmp_5 = this_2.l1e_1 - this_2.k1e_1 | 0;
            tmp_4 = tmp_5 < 8;
          }
          if (tmp_4) {
            completeReadHead(input, current);
            tmp_3 = prepareReadFirstHead(input, size);
          } else {
            tmp_3 = current;
          }
        }
        var tmp1_elvis_lhs = tmp_3;
        var tmp_6;
        if (tmp1_elvis_lhs == null) {
          break $l$loop;
        } else {
          tmp_6 = tmp1_elvis_lhs;
        }
        var next = tmp_6;
        current = next;
        release = true;
      }
       while (size > 0);
    }finally {
      if (release) {
        completeReadHead(input, current);
      }
    }
  }
  if (charactersCopied < max) {
    var size_0 = 1;
    $l$block_3: {
      // Inline function 'io.ktor.utils.io.core.takeWhileSize' call
      var release_0 = true;
      var tmp0_elvis_lhs_2 = prepareReadFirstHead(input, 1);
      var tmp_7;
      if (tmp0_elvis_lhs_2 == null) {
        break $l$block_3;
      } else {
        tmp_7 = tmp0_elvis_lhs_2;
      }
      var current_0 = tmp_7;
      var size_1 = 1;
      try {
        $l$loop_0: do {
          // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
          var this_3 = current_0;
          var before_0 = this_3.i1e_1 - this_3.h1e_1 | 0;
          var after_0;
          if (before_0 >= size_1) {
            try {
              // Inline function 'io.ktor.utils.io.charsets.decode.<anonymous>' call
              // Inline function 'io.ktor.utils.io.core.readDirectInt8Array' call
              // Inline function 'kotlin.contracts.contract' call
              // Inline function 'io.ktor.utils.io.core.read' call
              var this_4 = current_0;
              // Inline function 'kotlin.contracts.contract' call
              // Inline function 'io.ktor.utils.io.core.readDirectInt8Array.<anonymous>' call
              var memory_0 = this_4.g1e_1;
              var start_0 = this_4.h1e_1;
              var endExclusive_0 = this_4.i1e_1;
              // Inline function 'io.ktor.utils.io.charsets.decode.<anonymous>.<anonymous>' call
              var view_0 = new Int8Array(memory_0.g1m_1.buffer, memory_0.g1m_1.byteOffset + start_0 | 0, endExclusive_0 - start_0 | 0);
              var result = decodeBufferImpl(view_0, decoder, max - charactersCopied | 0);
              dst.d8(result.g1t_1);
              charactersCopied = charactersCopied + result.g1t_1.length | 0;
              var rc_0 = result.h1t_1;
              this_4.h1m(rc_0);
              var rc_1 = rc_0;
              if (rc_1 > 0)
                size_0 = 1;
              else if (size_0 === get_MAX_CHARACTERS_SIZE_IN_BYTES())
                size_0 = 0;
              else {
                size_0 = size_0 + 1 | 0;
              }
              size_1 = size_0;
            }finally {
              // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
              var this_5 = current_0;
              after_0 = this_5.i1e_1 - this_5.h1e_1 | 0;
            }
          } else {
            after_0 = before_0;
          }
          release_0 = false;
          var tmp_8;
          if (after_0 === 0) {
            tmp_8 = prepareReadNextHead(input, current_0);
          } else {
            var tmp_9;
            if (after_0 < size_1) {
              tmp_9 = true;
            } else {
              // Inline function 'io.ktor.utils.io.core.Buffer.endGap' call
              var this_6 = current_0;
              var tmp_10 = this_6.l1e_1 - this_6.k1e_1 | 0;
              tmp_9 = tmp_10 < 8;
            }
            if (tmp_9) {
              completeReadHead(input, current_0);
              tmp_8 = prepareReadFirstHead(input, size_1);
            } else {
              tmp_8 = current_0;
            }
          }
          var tmp1_elvis_lhs_0 = tmp_8;
          var tmp_11;
          if (tmp1_elvis_lhs_0 == null) {
            break $l$loop_0;
          } else {
            tmp_11 = tmp1_elvis_lhs_0;
          }
          var next_0 = tmp_11;
          current_0 = next_0;
          release_0 = true;
        }
         while (size_1 > 0);
      }finally {
        if (release_0) {
          completeReadHead(input, current_0);
        }
      }
    }
  }
  return charactersCopied;
}
function encodeComplete(_this__u8e3s4, dst) {
  return true;
}
function decodeExactBytes(_this__u8e3s4, input, inputLength) {
  if (inputLength === 0)
    return '';
  // Inline function 'io.ktor.utils.io.core.Input.headRemaining' call
  if ((input.s1g_1 - input.r1g_1 | 0) >= inputLength) {
    var decoder = Decoder(get_charset_0(_this__u8e3s4).v1p_1, true);
    var head = input.o1o();
    var view = input.q1g_1.g1m_1;
    var tmp$ret$2;
    $l$block: {
      // Inline function 'io.ktor.utils.io.js.decodeWrap' call
      try {
        // Inline function 'io.ktor.utils.io.charsets.decodeExactBytes.<anonymous>' call
        var subView = (head.h1e_1 === 0 ? inputLength === view.byteLength : false) ? view : new DataView(view.buffer, view.byteOffset + head.h1e_1 | 0, inputLength);
        tmp$ret$2 = decoder.i1t(subView);
        break $l$block;
      } catch ($p) {
        if ($p instanceof Error) {
          var t = $p;
          var tmp0_elvis_lhs = t.message;
          throw new MalformedInputException('Failed to decode bytes: ' + (tmp0_elvis_lhs == null ? 'no cause provided' : tmp0_elvis_lhs));
        } else {
          throw $p;
        }
      }
    }
    var text = tmp$ret$2;
    input.h1m(inputLength);
    return text;
  }
  return decodeExactBytesSlow(_this__u8e3s4, input, inputLength);
}
function get_charset_0(_this__u8e3s4) {
  return _this__u8e3s4.w1s_1;
}
function decodeExactBytesSlow(_this__u8e3s4, input, inputLength) {
  var decoder = Decoder(get_name(get_charset_0(_this__u8e3s4)), true);
  var inputRemaining = inputLength;
  var sb = StringBuilder_init_$Create$(inputLength);
  $l$block_4: {
    // Inline function 'io.ktor.utils.io.js.decodeWrap' call
    try {
      // Inline function 'io.ktor.utils.io.charsets.decodeExactBytesSlow.<anonymous>' call
      $l$block: {
        // Inline function 'io.ktor.utils.io.core.takeWhileSize' call
        var release = true;
        var tmp0_elvis_lhs = prepareReadFirstHead(input, 6);
        var tmp;
        if (tmp0_elvis_lhs == null) {
          break $l$block;
        } else {
          tmp = tmp0_elvis_lhs;
        }
        var current = tmp;
        var size = 6;
        try {
          $l$loop: do {
            // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
            var this_0 = current;
            var before = this_0.i1e_1 - this_0.h1e_1 | 0;
            var after;
            if (before >= size) {
              try {
                // Inline function 'io.ktor.utils.io.charsets.decodeExactBytesSlow.<anonymous>.<anonymous>' call
                var buffer = current;
                // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
                var chunkSize = buffer.i1e_1 - buffer.h1e_1 | 0;
                // Inline function 'kotlin.comparisons.minOf' call
                var b = inputRemaining;
                var size_0 = Math.min(chunkSize, b);
                var tmp_0;
                if (buffer.h1e_1 === 0 ? buffer.g1e_1.g1m_1.byteLength === size_0 : false) {
                  var tmp$ret$4;
                  $l$block_0: {
                    // Inline function 'io.ktor.utils.io.js.decodeStream' call
                    var buffer_0 = buffer.g1e_1.g1m_1;
                    // Inline function 'io.ktor.utils.io.js.decodeWrap' call
                    try {
                      tmp$ret$4 = decoder.e1t(buffer_0, decodeOptions(true));
                      break $l$block_0;
                    } catch ($p) {
                      if ($p instanceof Error) {
                        var t = $p;
                        var tmp0_elvis_lhs_0 = t.message;
                        throw new MalformedInputException('Failed to decode bytes: ' + (tmp0_elvis_lhs_0 == null ? 'no cause provided' : tmp0_elvis_lhs_0));
                      } else {
                        throw $p;
                      }
                    }
                  }
                  tmp_0 = tmp$ret$4;
                } else {
                  var tmp$ret$6;
                  $l$block_1: {
                    // Inline function 'io.ktor.utils.io.js.decodeStream' call
                    var buffer_1 = new Int8Array(buffer.g1e_1.g1m_1.buffer, buffer.g1e_1.g1m_1.byteOffset + buffer.h1e_1 | 0, size_0);
                    // Inline function 'io.ktor.utils.io.js.decodeWrap' call
                    try {
                      tmp$ret$6 = decoder.e1t(buffer_1, decodeOptions(true));
                      break $l$block_1;
                    } catch ($p) {
                      if ($p instanceof Error) {
                        var t_0 = $p;
                        var tmp0_elvis_lhs_1 = t_0.message;
                        throw new MalformedInputException('Failed to decode bytes: ' + (tmp0_elvis_lhs_1 == null ? 'no cause provided' : tmp0_elvis_lhs_1));
                      } else {
                        throw $p;
                      }
                    }
                  }
                  tmp_0 = tmp$ret$6;
                }
                var text = tmp_0;
                sb.n5(text);
                buffer.h1m(size_0);
                inputRemaining = inputRemaining - size_0 | 0;
                size = inputRemaining > 0 ? 6 : 0;
              }finally {
                // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
                var this_1 = current;
                after = this_1.i1e_1 - this_1.h1e_1 | 0;
              }
            } else {
              after = before;
            }
            release = false;
            var tmp_1;
            if (after === 0) {
              tmp_1 = prepareReadNextHead(input, current);
            } else {
              var tmp_2;
              if (after < size) {
                tmp_2 = true;
              } else {
                // Inline function 'io.ktor.utils.io.core.Buffer.endGap' call
                var this_2 = current;
                var tmp_3 = this_2.l1e_1 - this_2.k1e_1 | 0;
                tmp_2 = tmp_3 < 8;
              }
              if (tmp_2) {
                completeReadHead(input, current);
                tmp_1 = prepareReadFirstHead(input, size);
              } else {
                tmp_1 = current;
              }
            }
            var tmp1_elvis_lhs = tmp_1;
            var tmp_4;
            if (tmp1_elvis_lhs == null) {
              break $l$loop;
            } else {
              tmp_4 = tmp1_elvis_lhs;
            }
            var next = tmp_4;
            current = next;
            release = true;
          }
           while (size > 0);
        }finally {
          if (release) {
            completeReadHead(input, current);
          }
        }
      }
      if (inputRemaining > 0) {
        $l$block_2: {
          // Inline function 'io.ktor.utils.io.core.takeWhile' call
          var release_0 = true;
          var tmp0_elvis_lhs_2 = prepareReadFirstHead(input, 1);
          var tmp_5;
          if (tmp0_elvis_lhs_2 == null) {
            break $l$block_2;
          } else {
            tmp_5 = tmp0_elvis_lhs_2;
          }
          var current_0 = tmp_5;
          try {
            $l$loop_1: do {
              // Inline function 'io.ktor.utils.io.charsets.decodeExactBytesSlow.<anonymous>.<anonymous>' call
              var buffer_2 = current_0;
              // Inline function 'io.ktor.utils.io.core.Buffer.readRemaining' call
              var chunkSize_0 = buffer_2.i1e_1 - buffer_2.h1e_1 | 0;
              // Inline function 'kotlin.comparisons.minOf' call
              var b_0 = inputRemaining;
              var size_1 = Math.min(chunkSize_0, b_0);
              var tmp_6;
              if (buffer_2.h1e_1 === 0 ? buffer_2.g1e_1.g1m_1.byteLength === size_1 : false) {
                tmp_6 = decoder.i1t(buffer_2.g1e_1.g1m_1);
              } else {
                var tmp$ret$14;
                $l$block_3: {
                  // Inline function 'io.ktor.utils.io.js.decodeStream' call
                  var buffer_3 = new Int8Array(buffer_2.g1e_1.g1m_1.buffer, buffer_2.g1e_1.g1m_1.byteOffset + buffer_2.h1e_1 | 0, size_1);
                  // Inline function 'io.ktor.utils.io.js.decodeWrap' call
                  try {
                    tmp$ret$14 = decoder.e1t(buffer_3, decodeOptions(true));
                    break $l$block_3;
                  } catch ($p) {
                    if ($p instanceof Error) {
                      var t_1 = $p;
                      var tmp0_elvis_lhs_3 = t_1.message;
                      throw new MalformedInputException('Failed to decode bytes: ' + (tmp0_elvis_lhs_3 == null ? 'no cause provided' : tmp0_elvis_lhs_3));
                    } else {
                      throw $p;
                    }
                  }
                }
                tmp_6 = tmp$ret$14;
              }
              var text_0 = tmp_6;
              sb.n5(text_0);
              buffer_2.h1m(size_1);
              inputRemaining = inputRemaining - size_1 | 0;
              if (!true) {
                break $l$loop_1;
              }
              release_0 = false;
              var tmp1_elvis_lhs_0 = prepareReadNextHead(input, current_0);
              var tmp_7;
              if (tmp1_elvis_lhs_0 == null) {
                break $l$loop_1;
              } else {
                tmp_7 = tmp1_elvis_lhs_0;
              }
              var next_0 = tmp_7;
              current_0 = next_0;
              release_0 = true;
            }
             while (true);
          }finally {
            if (release_0) {
              completeReadHead(input, current_0);
            }
          }
        }
      }
      sb.n5(decoder.f1t());
      break $l$block_4;
    } catch ($p) {
      if ($p instanceof Error) {
        var t_2 = $p;
        var tmp0_elvis_lhs_4 = t_2.message;
        throw new MalformedInputException('Failed to decode bytes: ' + (tmp0_elvis_lhs_4 == null ? 'no cause provided' : tmp0_elvis_lhs_4));
      } else {
        throw $p;
      }
    }
  }
  if (inputRemaining > 0) {
    throw new EOFException('Not enough bytes available: had only ' + (inputLength - inputRemaining | 0) + ' instead of ' + inputLength);
  }
  return sb.toString();
}
function get_MAX_CHARACTERS_SIZE_IN_BYTES() {
  return MAX_CHARACTERS_SIZE_IN_BYTES;
}
var MAX_CHARACTERS_SIZE_IN_BYTES;
function DecodeBufferResult(charactersDecoded, bytesConsumed) {
  this.g1t_1 = charactersDecoded;
  this.h1t_1 = bytesConsumed;
}
protoOf(DecodeBufferResult).toString = function () {
  return 'DecodeBufferResult(charactersDecoded=' + this.g1t_1 + ', bytesConsumed=' + this.h1t_1 + ')';
};
protoOf(DecodeBufferResult).hashCode = function () {
  var result = getStringHashCode(this.g1t_1);
  result = imul(result, 31) + this.h1t_1 | 0;
  return result;
};
protoOf(DecodeBufferResult).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof DecodeBufferResult))
    return false;
  var tmp0_other_with_cast = other instanceof DecodeBufferResult ? other : THROW_CCE();
  if (!(this.g1t_1 === tmp0_other_with_cast.g1t_1))
    return false;
  if (!(this.h1t_1 === tmp0_other_with_cast.h1t_1))
    return false;
  return true;
};
function decodeBufferImpl(_this__u8e3s4, nativeDecoder, maxCharacters) {
  if (maxCharacters === 0) {
    return new DecodeBufferResult('', 0);
  }
  try {
    var sizeInBytes = coerceAtMost(maxCharacters, _this__u8e3s4.byteLength);
    var text = nativeDecoder.i1t(_this__u8e3s4.subarray(0, sizeInBytes));
    if (text.length <= maxCharacters) {
      return new DecodeBufferResult(text, sizeInBytes);
    }
  } catch ($p) {
    var _ = $p;
  }
  return decodeBufferImplSlow(_this__u8e3s4, nativeDecoder, maxCharacters);
}
function decodeBufferImplSlow(_this__u8e3s4, nativeDecoder, maxCharacters) {
  var maxBytes = coerceAtMost(maxCharacters >= 268435455 ? IntCompanionObject_instance.MAX_VALUE : imul(maxCharacters, 8), _this__u8e3s4.byteLength);
  var sizeInBytes = maxBytes;
  while (sizeInBytes > 8) {
    try {
      var text = nativeDecoder.i1t(_this__u8e3s4.subarray(0, sizeInBytes));
      if (text.length <= maxCharacters) {
        return new DecodeBufferResult(text, sizeInBytes);
      }
    } catch ($p) {
      var _ = $p;
    }
    sizeInBytes = sizeInBytes / 2 | 0;
  }
  sizeInBytes = 8;
  while (sizeInBytes > 0) {
    try {
      var text_0 = nativeDecoder.i1t(_this__u8e3s4.subarray(0, sizeInBytes));
      if (text_0.length <= maxCharacters) {
        return new DecodeBufferResult(text_0, sizeInBytes);
      }
    } catch ($p) {
      var __0 = $p;
    }
    sizeInBytes = sizeInBytes - 1 | 0;
  }
  $l$block: {
    // Inline function 'io.ktor.utils.io.js.decodeWrap' call
    try {
      // Inline function 'io.ktor.utils.io.charsets.decodeBufferImplSlow.<anonymous>' call
      nativeDecoder.i1t(_this__u8e3s4);
      break $l$block;
    } catch ($p) {
      if ($p instanceof Error) {
        var t = $p;
        var tmp0_elvis_lhs = t.message;
        throw new MalformedInputException('Failed to decode bytes: ' + (tmp0_elvis_lhs == null ? 'no cause provided' : tmp0_elvis_lhs));
      } else {
        throw $p;
      }
    }
  }
  throw new MalformedInputException('Unable to decode buffer');
}
function encodeISO88591(input, fromIndex, toIndex, dst) {
  if (fromIndex >= toIndex)
    return 0;
  // Inline function 'io.ktor.utils.io.core.writeDirect' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.write' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.writeDirect.<anonymous>' call
  var memory = dst.g1e_1;
  var start = dst.i1e_1;
  var endExclusive = dst.k1e_1;
  // Inline function 'io.ktor.utils.io.charsets.encodeISO88591.<anonymous>' call
  var view = memory.t1s(start, endExclusive - start | 0).g1m_1;
  var i8 = new Int8Array(view.buffer, view.byteOffset, view.byteLength);
  var writeIndex = 0;
  var inductionVariable = fromIndex;
  if (inductionVariable < toIndex)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.code' call
      var this_0 = charSequenceGet(input, index);
      var character = Char__toInt_impl_vasixd(this_0);
      if (character > 255) {
        failedToMapError(character);
      }
      // Inline function 'org.khronos.webgl.set' call
      var tmp1 = writeIndex;
      writeIndex = tmp1 + 1 | 0;
      // Inline function 'kotlin.js.asDynamic' call
      i8[tmp1] = toByte(character);
    }
     while (inductionVariable < toIndex);
  var rc = writeIndex;
  dst.i1m(rc);
  return toIndex - fromIndex | 0;
}
function failedToMapError(ch) {
  throw new MalformedInputException('The character with unicode point ' + ch + " couldn't be mapped to ISO-8859-1 character");
}
function writeFully_4(_this__u8e3s4, src, offset, length) {
  offset = offset === VOID ? 0 : offset;
  length = length === VOID ? src.byteLength - offset | 0 : length;
  // Inline function 'io.ktor.utils.io.core.write' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.core.writeFully.<anonymous>' call
  var memory = _this__u8e3s4.g1e_1;
  var dstOffset = _this__u8e3s4.i1e_1;
  if ((_this__u8e3s4.k1e_1 - dstOffset | 0) < length) {
    throw new InsufficientSpaceException('Not enough free space to write ' + length + ' bytes');
  }
  copyTo_0(src, memory, offset, length, dstOffset);
  var rc = length;
  _this__u8e3s4.i1m(rc);
}
function Closeable() {
}
function addSuppressedInternal(_this__u8e3s4, other) {
}
function get_PACKET_MAX_COPY_SIZE() {
  return PACKET_MAX_COPY_SIZE;
}
var PACKET_MAX_COPY_SIZE;
function String_0(bytes, offset, length, charset) {
  offset = offset === VOID ? 0 : offset;
  length = length === VOID ? bytes.length : length;
  charset = charset === VOID ? Charsets_getInstance().t1p_1 : charset;
  if ((offset < 0 ? true : length < 0) ? true : (offset + length | 0) > bytes.length) {
    checkIndices(offset, length, bytes);
  }
  // Inline function 'kotlin.js.asDynamic' call
  var i8 = bytes;
  var bufferOffset = i8.byteOffset + offset | 0;
  var buffer = i8.buffer.slice(bufferOffset, bufferOffset + length | 0);
  var view = new ChunkBuffer(of_1(Companion_getInstance_6(), buffer), null, Companion_getInstance_4().r1e_1);
  view.o1m();
  var packet = ByteReadPacket_init_$Create$(view, Companion_getInstance_4().s1e_1);
  return decode(charset.w1p(), packet, IntCompanionObject_instance.MAX_VALUE);
}
function checkIndices(offset, length, bytes) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(offset >= 0)) {
    throw IndexOutOfBoundsException_init_$Create$('offset (' + offset + ") shouldn't be negative");
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(length >= 0)) {
    throw IndexOutOfBoundsException_init_$Create$('length (' + length + ") shouldn't be negative");
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!((offset + length | 0) <= bytes.length)) {
    throw IndexOutOfBoundsException_init_$Create$('offset (' + offset + ') + length (' + length + ') > bytes.size (' + bytes.length + ')');
  }
  throw IndexOutOfBoundsException_init_$Create$_0();
}
function EOFException(message) {
  IOException_init_$Init$(message, this);
  captureStack(this, EOFException);
}
function IOException_init_$Init$(message, $this) {
  IOException.call($this, message, null);
  return $this;
}
function IOException(message, cause) {
  Exception_init_$Init$_0(message, cause, this);
  captureStack(this, IOException);
}
function Decoder(encoding, fatal) {
  fatal = fatal === VOID ? true : fatal;
  var tmp;
  try {
    tmp = toKtor(new TextDecoder(encoding, textDecoderOptions(fatal)));
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Error) {
      var cause = $p;
      tmp_0 = new TextDecoderFallback(encoding, fatal);
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  return tmp;
}
function decodeOptions(stream) {
  // Inline function 'kotlin.apply' call
  var this_0 = new Object();
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.js.decodeOptions.<anonymous>' call
  // Inline function 'kotlin.with' call
  // Inline function 'kotlin.js.asDynamic' call
  // Inline function 'kotlin.contracts.contract' call
  this_0.stream = stream;
  return this_0;
}
function toKtor(_this__u8e3s4) {
  return new toKtor$1(_this__u8e3s4);
}
function textDecoderOptions(fatal) {
  fatal = fatal === VOID ? false : fatal;
  // Inline function 'kotlin.apply' call
  var this_0 = new Object();
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.utils.io.js.textDecoderOptions.<anonymous>' call
  // Inline function 'kotlin.with' call
  // Inline function 'kotlin.js.asDynamic' call
  // Inline function 'kotlin.contracts.contract' call
  this_0.fatal = fatal;
  return this_0;
}
function toKtor$1($this_toKtor) {
  this.j1t_1 = $this_toKtor;
}
protoOf(toKtor$1).f1t = function () {
  return this.j1t_1.decode();
};
protoOf(toKtor$1).i1t = function (buffer) {
  return this.j1t_1.decode(buffer);
};
protoOf(toKtor$1).e1t = function (buffer, options) {
  return this.j1t_1.decode(buffer, options);
};
function get_ENCODING_ALIASES() {
  _init_properties_TextDecoderFallback_kt__nrrftl();
  return ENCODING_ALIASES;
}
var ENCODING_ALIASES;
function get_REPLACEMENT() {
  _init_properties_TextDecoderFallback_kt__nrrftl();
  return REPLACEMENT;
}
var REPLACEMENT;
function TextDecoderFallback(encoding, fatal) {
  this.k1t_1 = fatal;
  // Inline function 'kotlin.text.lowercase' call
  // Inline function 'kotlin.text.trim' call
  // Inline function 'kotlin.js.asDynamic' call
  var requestedEncoding = toString(trim(isCharSequence(encoding) ? encoding : THROW_CCE())).toLowerCase();
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!get_ENCODING_ALIASES().z(requestedEncoding)) {
    // Inline function 'io.ktor.utils.io.js.TextDecoderFallback.<anonymous>' call
    var message = encoding + ' is not supported.';
    throw IllegalStateException_init_$Create$(toString(message));
  }
}
protoOf(TextDecoderFallback).f1t = function () {
  return '';
};
protoOf(TextDecoderFallback).i1t = function (buffer) {
  var tmp$ret$3;
  $l$block: {
    // Inline function 'io.ktor.utils.io.core.buildPacket' call
    // Inline function 'kotlin.contracts.contract' call
    var builder = new BytePacketBuilder();
    try {
      // Inline function 'io.ktor.utils.io.js.TextDecoderFallback.decode.<anonymous>' call
      var bytes = buffer instanceof Int8Array ? buffer : THROW_CCE();
      var inductionVariable = 0;
      var last = bytes.length;
      if (inductionVariable < last)
        $l$loop: do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          // Inline function 'org.khronos.webgl.get' call
          // Inline function 'kotlin.js.asDynamic' call
          var byte = bytes[index];
          var point = toCodePoint(byte);
          if (point < 0) {
            // Inline function 'kotlin.check' call
            // Inline function 'kotlin.contracts.contract' call
            if (!!this.k1t_1) {
              // Inline function 'io.ktor.utils.io.js.TextDecoderFallback.decode.<anonymous>.<anonymous>' call
              var message = 'Invalid character: ' + point;
              throw IllegalStateException_init_$Create$(toString(message));
            }
            writeFully_3(builder, get_REPLACEMENT());
            continue $l$loop;
          }
          if (point > 255) {
            builder.w1m(toByte(point >> 8));
          }
          builder.w1m(toByte(point & 255));
        }
         while (inductionVariable < last);
      tmp$ret$3 = builder.l1i();
      break $l$block;
    } catch ($p) {
      if ($p instanceof Error) {
        var t = $p;
        builder.mu();
        throw t;
      } else {
        throw $p;
      }
    }
  }
  return decodeToString(readBytes(tmp$ret$3));
};
protoOf(TextDecoderFallback).e1t = function (buffer, options) {
  return this.i1t(buffer);
};
function toCodePoint(_this__u8e3s4) {
  _init_properties_TextDecoderFallback_kt__nrrftl();
  var value = _this__u8e3s4 & 255;
  if (isASCII(value)) {
    return value;
  }
  return get_WIN1252_TABLE()[value - 128 | 0];
}
function isASCII(_this__u8e3s4) {
  _init_properties_TextDecoderFallback_kt__nrrftl();
  return 0 <= _this__u8e3s4 ? _this__u8e3s4 <= 127 : false;
}
var properties_initialized_TextDecoderFallback_kt_7y92ax;
function _init_properties_TextDecoderFallback_kt__nrrftl() {
  if (!properties_initialized_TextDecoderFallback_kt_7y92ax) {
    properties_initialized_TextDecoderFallback_kt_7y92ax = true;
    ENCODING_ALIASES = setOf(['ansi_x3.4-1968', 'ascii', 'cp1252', 'cp819', 'csisolatin1', 'ibm819', 'iso-8859-1', 'iso-ir-100', 'iso8859-1', 'iso88591', 'iso_8859-1', 'iso_8859-1:1987', 'l1', 'latin1', 'us-ascii', 'windows-1252', 'x-cp1252']);
    // Inline function 'kotlin.byteArrayOf' call
    REPLACEMENT = new Int8Array([-17, -65, -67]);
  }
}
function get_WIN1252_TABLE() {
  _init_properties_Win1252Table_kt__tl0v64();
  return WIN1252_TABLE;
}
var WIN1252_TABLE;
var properties_initialized_Win1252Table_kt_pkmjoq;
function _init_properties_Win1252Table_kt__tl0v64() {
  if (!properties_initialized_Win1252Table_kt_pkmjoq) {
    properties_initialized_Win1252Table_kt_pkmjoq = true;
    // Inline function 'kotlin.intArrayOf' call
    WIN1252_TABLE = new Int32Array([8364, -1, 8218, 402, 8222, 8230, 8224, 8225, 710, 8240, 352, 8249, 338, -1, 381, -1, -1, 8216, 8217, 8220, 8221, 8226, 8211, 8212, 732, 8482, 353, 8250, 339, -1, 382, 376, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255]);
  }
}
function DefaultPool(capacity) {
  this.i1n_1 = capacity;
  var tmp = this;
  // Inline function 'kotlin.arrayOfNulls' call
  var size = this.i1n_1;
  tmp.j1n_1 = fillArrayVal(Array(size), null);
  this.k1n_1 = 0;
}
protoOf(DefaultPool).l1n = function (instance) {
};
protoOf(DefaultPool).b1o = function (instance) {
  return instance;
};
protoOf(DefaultPool).y1n = function (instance) {
};
protoOf(DefaultPool).d1o = function () {
  if (this.k1n_1 === 0)
    return this.e1n();
  this.k1n_1 = this.k1n_1 - 1 | 0;
  var idx = this.k1n_1;
  var tmp = this.j1n_1[idx];
  var instance = !(tmp == null) ? tmp : THROW_CCE();
  this.j1n_1[idx] = null;
  return this.b1o(instance);
};
protoOf(DefaultPool).e1o = function (instance) {
  this.y1n(instance);
  if (this.k1n_1 === this.i1n_1) {
    this.l1n(instance);
  } else {
    var tmp1 = this.k1n_1;
    this.k1n_1 = tmp1 + 1 | 0;
    this.j1n_1[tmp1] = instance;
  }
};
protoOf(DefaultPool).mp = function () {
  var inductionVariable = 0;
  var last = this.k1n_1;
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var tmp = this.j1n_1[i];
      var instance = !(tmp == null) ? tmp : THROW_CCE();
      this.j1n_1[i] = null;
      this.l1n(instance);
    }
     while (inductionVariable < last);
  this.k1n_1 = 0;
};
//region block: post-declaration
protoOf(ByteChannelSequentialBase).c1l = readRemaining$default;
protoOf(ChannelJob).co = cancel$default;
protoOf(ChannelJob).yn = invokeOnCompletion$default;
protoOf(DefaultPool).f1o = close;
protoOf(ChunkBuffer$Companion$EmptyPool$1).f1o = close;
protoOf(NoPoolImpl).f1o = close;
//endregion
//region block: init
Companion_instance = new Companion();
DEFAULT_BUFFER_SIZE = 4096;
Companion_instance_1 = new Companion_1();
DefaultAllocator_instance = new DefaultAllocator();
Companion_instance_5 = new Companion_5();
MAX_CHARACTERS_SIZE_IN_BYTES = 8;
PACKET_MAX_COPY_SIZE = 200;
//endregion
//region block: exports
export {
  copyTo as copyTo2vm7vz7rr51or,
  discard as discard7plob4gm0ip3,
  readAvailable as readAvailable3hkjy1wf4lycw,
  writeFully as writeFullyuorxug1itxv3,
  IOException_init_$Init$ as IOException_init_$Init$30655oardwnv8,
  Companion_instance_5 as Companion_instance3aiov6iqkz7e8,
  Charsets_getInstance as Charsets_getInstanceqs70pvl4noow,
  Companion_getInstance_5 as Companion_getInstance2ai11rhpust2a,
  MalformedInputException as MalformedInputExceptionbvc6h5ij0ias,
  decode as decode1h5mw63lslzyq,
  encodeToByteArray as encodeToByteArrayomtvgs5lyogm,
  encode as encode35e4rpnc94tb5,
  get_name as get_name2f11g4r0d5pxp,
  completeReadHead as completeReadHeadmsbisaktufcz,
  prepareReadFirstHead as prepareReadFirstHead3bxvcvf0u196c,
  prepareReadNextHead as prepareReadNextHead165u1tlz2sd0o,
  BytePacketBuilder as BytePacketBuilder2d5pjgm948a6v,
  ByteReadPacket as ByteReadPacket19qnebry5xxpy,
  Closeable as Closeableu07ioona9oji,
  Input as Input1claccncp4iy3,
  String_0 as String2althbpus3r3k,
  addSuppressedInternal as addSuppressedInternal1yubdpi5q21j8,
  discard_0 as discard2nktejhnnvzvk,
  readBytes as readBytes2b47ed7nra7rg,
  readShort_0 as readShort3oo850dud33ng,
  readText as readText3x4cv5p7hylp,
  writeFully_3 as writeFully3bzs0b6jknxck,
  writeShort_0 as writeShort2gpvs0skw1vt,
  writeText as writeText338krnmr85lul,
  IOException as IOExceptionktvzt3eudz3d,
  get_ByteArrayPool as get_ByteArrayPool3f7yrgvqxz9ct,
  ByteChannel as ByteChannelgfqke9q216t7,
  ByteReadChannel as ByteReadChannel1dp09w1xstn8w,
  ByteReadChannel_1 as ByteReadChannel2wzou76jce72d,
  WriterScope as WriterScope3b0bo1enaee6b,
  cancel as canceldn4b3cdqcfny,
  close_0 as closeqm43o3junf8o,
  writer as writer1eia5its2a1fh,
};
//endregion

//# sourceMappingURL=ktor-ktor-io.mjs.map
