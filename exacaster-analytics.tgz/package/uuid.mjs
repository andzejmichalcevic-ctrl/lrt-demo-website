import {
  until1jbpn0z3f8lbg as until,
  listOf1jh22dvmctj1r as listOf,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  Char__rangeTo_impl_tkncvp940rgm6i9zbm as Char__rangeTo_impl_tkncvp,
  plus39kp8wyage607 as plus,
  Default_getInstance3u4i6y54ri5cn as Default_getInstance,
  protoOf180f3jzyo7rfj as protoOf,
  objectMeta213120oau977m as objectMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  toString1pkumu07cwy4m as toString,
  IllegalArgumentException_init_$Create$310sysrobvll9 as IllegalArgumentException_init_$Create$,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  charArray2ujmm1qusno00 as charArray,
  concatToString2syawgu50khxi as concatToString,
  contentEquals1cdp6c846cfdi as contentEquals,
  contentHashCode25jw6rgkgywwr as contentHashCode,
  compareTo3ankvs086tmwq as compareTo,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  Comparable198qfk8pnblz0 as Comparable,
  classMetawt99a3kyl3us as classMeta,
  VOID7hggqo3abtya as VOID,
  toByte4i43936u611k as toByte,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
//endregion
//region block: pre-declaration
setMetadataFor(Companion, 'Companion', objectMeta);
setMetadataFor(Uuid, 'Uuid', classMeta, VOID, [Comparable]);
//endregion
var UUID_CHAR_RANGES;
var UUID_HYPHEN_INDICES;
function get_UUID_CHARS() {
  _init_properties_uuid_kt__7swked();
  return UUID_CHARS;
}
var UUID_CHARS;
function get_UUID_BYTES() {
  return UUID_BYTES;
}
var UUID_BYTES;
function get_UUID_STRING_LENGTH() {
  return UUID_STRING_LENGTH;
}
var UUID_STRING_LENGTH;
var properties_initialized_uuid_kt_pyvynx;
function _init_properties_uuid_kt__7swked() {
  if (!properties_initialized_uuid_kt_pyvynx) {
    properties_initialized_uuid_kt_pyvynx = true;
    UUID_CHAR_RANGES = listOf([until(0, 8), until(9, 13), until(14, 18), until(19, 23), until(24, 36)]);
    UUID_HYPHEN_INDICES = listOf([8, 13, 18, 23]);
    UUID_CHARS = plus(Char__rangeTo_impl_tkncvp(_Char___init__impl__6a9atx(48), _Char___init__impl__6a9atx(57)), Char__rangeTo_impl_tkncvp(_Char___init__impl__6a9atx(97), _Char___init__impl__6a9atx(102)));
  }
}
function freeze(_this__u8e3s4) {
  return _this__u8e3s4;
}
function getRandomUuidBytes() {
  return Default_getInstance().yg(get_UUID_BYTES());
}
function Companion() {
  Companion_instance = this;
  this.b4u_1 = listOf([until(0, 4), until(4, 6), until(6, 8), until(8, 10), until(10, 16)]);
}
var Companion_instance;
function Companion_getInstance() {
  if (Companion_instance == null)
    new Companion();
  return Companion_instance;
}
function Uuid(uuidBytes) {
  Companion_getInstance();
  this.c4u_1 = uuidBytes;
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.collections.count' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(this.c4u_1.length === get_UUID_BYTES())) {
    // Inline function 'com.benasher44.uuid.Uuid.<anonymous>' call
    var tmp = get_UUID_BYTES();
    // Inline function 'kotlin.collections.count' call
    var message = 'Invalid UUID bytes. Expected ' + tmp + ' bytes; found ' + this.c4u_1.length;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  freeze(this);
}
protoOf(Uuid).toString = function () {
  var characters = charArray(get_UUID_STRING_LENGTH());
  var charIndex = 0;
  var tmp0_iterator = Companion_getInstance().b4u_1.u();
  while (tmp0_iterator.v()) {
    var range = tmp0_iterator.w();
    var inductionVariable = range.ma_1;
    var last = range.na_1;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var octetPair = this.c4u_1[i];
        var left = octetPair >> 4 & 15;
        var right = octetPair & 15;
        var tmp2 = charIndex;
        charIndex = tmp2 + 1 | 0;
        characters[tmp2] = get_UUID_CHARS().f1(left).ta_1;
        var tmp3 = charIndex;
        charIndex = tmp3 + 1 | 0;
        characters[tmp3] = get_UUID_CHARS().f1(right).ta_1;
      }
       while (!(i === last));
    if (charIndex < get_UUID_STRING_LENGTH()) {
      var tmp4 = charIndex;
      charIndex = tmp4 + 1 | 0;
      characters[tmp4] = _Char___init__impl__6a9atx(45);
    }
  }
  return concatToString(characters);
};
protoOf(Uuid).equals = function (other) {
  var tmp;
  if (other instanceof Uuid) {
    tmp = contentEquals(this.c4u_1, other.c4u_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(Uuid).hashCode = function () {
  return contentHashCode(this.c4u_1);
};
protoOf(Uuid).d4u = function (other) {
  var inductionVariable = 0;
  var last = get_UUID_BYTES();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var compareResult = compareTo(this.c4u_1[i], other.c4u_1[i]);
      if (!(compareResult === 0))
        return compareResult;
    }
     while (inductionVariable < last);
  return 0;
};
protoOf(Uuid).d = function (other) {
  return this.d4u(other instanceof Uuid ? other : THROW_CCE());
};
function uuid4() {
  // Inline function 'com.benasher44.uuid.setVersion' call
  // Inline function 'kotlin.apply' call
  var this_0 = getRandomUuidBytes();
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'com.benasher44.uuid.setVersion.<anonymous>' call
  this_0[6] = toByte(this_0[6] & 15 | 4 << 4);
  this_0[8] = toByte(this_0[8] & 63 | 128);
  return new Uuid(this_0);
}
//region block: init
UUID_BYTES = 16;
UUID_STRING_LENGTH = 36;
//endregion
//region block: exports
export {
  uuid4 as uuid4al7pp0fcb8o5,
};
//endregion

//# sourceMappingURL=uuid.mjs.map
