import {
  mapCapacity1h45rc3eh9p2l as mapCapacity,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  LinkedHashMap_init_$Create$7ps311k1ff73 as LinkedHashMap_init_$Create$,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  protoOf180f3jzyo7rfj as protoOf,
  objectMeta213120oau977m as objectMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  Enum3alwj03lh1n41 as Enum,
  classMetawt99a3kyl3us as classMeta,
  toString1pkumu07cwy4m as toString,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  get_lastIndexx0qsydpfv3mu as get_lastIndex,
  compareTo3ankvs086tmwq as compareTo,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  fillArrayVali8eppxapiek4 as fillArrayVal,
  objectCreate1ve4bgxiu4x98 as objectCreate,
  encodeToByteArray1onwao0uakjfh as encodeToByteArray,
  VOID7hggqo3abtya as VOID,
} from './kotlin-kotlin-stdlib.mjs';
import {
  Charsets_getInstanceqs70pvl4noow as Charsets_getInstance,
  encodeToByteArrayomtvgs5lyogm as encodeToByteArray_0,
  BytePacketBuilder2d5pjgm948a6v as BytePacketBuilder,
  writeShort2gpvs0skw1vt as writeShort,
  writeText338krnmr85lul as writeText,
  readBytes2b47ed7nra7rg as readBytes,
} from './ktor-ktor-io.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
setMetadataFor(Companion, 'Companion', objectMeta);
setMetadataFor(Codes, 'Codes', classMeta, Enum);
setMetadataFor(CloseReason, 'CloseReason', classMeta);
setMetadataFor(NonDisposableHandle, 'NonDisposableHandle', objectMeta);
setMetadataFor(Companion_0, 'Companion', objectMeta);
setMetadataFor(FrameType, 'FrameType', classMeta, Enum);
setMetadataFor(Frame, 'Frame', classMeta);
setMetadataFor(Binary, 'Binary', classMeta, Frame);
setMetadataFor(Text, 'Text', classMeta, Frame);
setMetadataFor(Close, 'Close', classMeta, Frame, VOID, Close_init_$Create$_0);
setMetadataFor(Companion_1, 'Companion', objectMeta);
//endregion
var Codes_NORMAL_instance;
var Codes_GOING_AWAY_instance;
var Codes_PROTOCOL_ERROR_instance;
var Codes_CANNOT_ACCEPT_instance;
var Codes_CLOSED_ABNORMALLY_instance;
var Codes_NOT_CONSISTENT_instance;
var Codes_VIOLATED_POLICY_instance;
var Codes_TOO_BIG_instance;
var Codes_NO_EXTENSION_instance;
var Codes_INTERNAL_ERROR_instance;
var Codes_SERVICE_RESTART_instance;
var Codes_TRY_AGAIN_LATER_instance;
function Companion() {
  Companion_instance = this;
  var tmp = this;
  // Inline function 'kotlin.collections.associateBy' call
  var this_0 = values();
  var capacity = coerceAtLeast(mapCapacity(this_0.length), 16);
  // Inline function 'kotlin.collections.associateByTo' call
  var destination = LinkedHashMap_init_$Create$(capacity);
  var inductionVariable = 0;
  var last = this_0.length;
  while (inductionVariable < last) {
    var element = this_0[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    // Inline function 'io.ktor.websocket.Companion.byCodeMap.<anonymous>' call
    var tmp$ret$0 = element.f2d_1;
    destination.i2(tmp$ret$0, element);
  }
  tmp.g2d_1 = destination;
  this.h2d_1 = Codes_INTERNAL_ERROR_getInstance();
}
protoOf(Companion).i2d = function (code) {
  return this.g2d_1.s2(code);
};
var Companion_instance;
function Companion_getInstance() {
  Codes_initEntries();
  if (Companion_instance == null)
    new Companion();
  return Companion_instance;
}
function values() {
  return [Codes_NORMAL_getInstance(), Codes_GOING_AWAY_getInstance(), Codes_PROTOCOL_ERROR_getInstance(), Codes_CANNOT_ACCEPT_getInstance(), Codes_CLOSED_ABNORMALLY_getInstance(), Codes_NOT_CONSISTENT_getInstance(), Codes_VIOLATED_POLICY_getInstance(), Codes_TOO_BIG_getInstance(), Codes_NO_EXTENSION_getInstance(), Codes_INTERNAL_ERROR_getInstance(), Codes_SERVICE_RESTART_getInstance(), Codes_TRY_AGAIN_LATER_getInstance()];
}
var Codes_entriesInitialized;
function Codes_initEntries() {
  if (Codes_entriesInitialized)
    return Unit_instance;
  Codes_entriesInitialized = true;
  Codes_NORMAL_instance = new Codes('NORMAL', 0, 1000);
  Codes_GOING_AWAY_instance = new Codes('GOING_AWAY', 1, 1001);
  Codes_PROTOCOL_ERROR_instance = new Codes('PROTOCOL_ERROR', 2, 1002);
  Codes_CANNOT_ACCEPT_instance = new Codes('CANNOT_ACCEPT', 3, 1003);
  Codes_CLOSED_ABNORMALLY_instance = new Codes('CLOSED_ABNORMALLY', 4, 1006);
  Codes_NOT_CONSISTENT_instance = new Codes('NOT_CONSISTENT', 5, 1007);
  Codes_VIOLATED_POLICY_instance = new Codes('VIOLATED_POLICY', 6, 1008);
  Codes_TOO_BIG_instance = new Codes('TOO_BIG', 7, 1009);
  Codes_NO_EXTENSION_instance = new Codes('NO_EXTENSION', 8, 1010);
  Codes_INTERNAL_ERROR_instance = new Codes('INTERNAL_ERROR', 9, 1011);
  Codes_SERVICE_RESTART_instance = new Codes('SERVICE_RESTART', 10, 1012);
  Codes_TRY_AGAIN_LATER_instance = new Codes('TRY_AGAIN_LATER', 11, 1013);
  Companion_getInstance();
}
function Codes(name, ordinal, code) {
  Enum.call(this, name, ordinal);
  this.f2d_1 = code;
}
function Codes_NORMAL_getInstance() {
  Codes_initEntries();
  return Codes_NORMAL_instance;
}
function Codes_GOING_AWAY_getInstance() {
  Codes_initEntries();
  return Codes_GOING_AWAY_instance;
}
function Codes_PROTOCOL_ERROR_getInstance() {
  Codes_initEntries();
  return Codes_PROTOCOL_ERROR_instance;
}
function Codes_CANNOT_ACCEPT_getInstance() {
  Codes_initEntries();
  return Codes_CANNOT_ACCEPT_instance;
}
function Codes_CLOSED_ABNORMALLY_getInstance() {
  Codes_initEntries();
  return Codes_CLOSED_ABNORMALLY_instance;
}
function Codes_NOT_CONSISTENT_getInstance() {
  Codes_initEntries();
  return Codes_NOT_CONSISTENT_instance;
}
function Codes_VIOLATED_POLICY_getInstance() {
  Codes_initEntries();
  return Codes_VIOLATED_POLICY_instance;
}
function Codes_TOO_BIG_getInstance() {
  Codes_initEntries();
  return Codes_TOO_BIG_instance;
}
function Codes_NO_EXTENSION_getInstance() {
  Codes_initEntries();
  return Codes_NO_EXTENSION_instance;
}
function Codes_INTERNAL_ERROR_getInstance() {
  Codes_initEntries();
  return Codes_INTERNAL_ERROR_instance;
}
function Codes_SERVICE_RESTART_getInstance() {
  Codes_initEntries();
  return Codes_SERVICE_RESTART_instance;
}
function Codes_TRY_AGAIN_LATER_getInstance() {
  Codes_initEntries();
  return Codes_TRY_AGAIN_LATER_instance;
}
function CloseReason(code, message) {
  this.j2d_1 = code;
  this.k2d_1 = message;
}
protoOf(CloseReason).l2d = function () {
  return Companion_getInstance().i2d(this.j2d_1);
};
protoOf(CloseReason).toString = function () {
  var tmp0_elvis_lhs = this.l2d();
  return 'CloseReason(reason=' + toString(tmp0_elvis_lhs == null ? this.j2d_1 : tmp0_elvis_lhs) + ', message=' + this.k2d_1 + ')';
};
protoOf(CloseReason).hashCode = function () {
  var result = this.j2d_1;
  result = imul(result, 31) + getStringHashCode(this.k2d_1) | 0;
  return result;
};
protoOf(CloseReason).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof CloseReason))
    return false;
  var tmp0_other_with_cast = other instanceof CloseReason ? other : THROW_CCE();
  if (!(this.j2d_1 === tmp0_other_with_cast.j2d_1))
    return false;
  if (!(this.k2d_1 === tmp0_other_with_cast.k2d_1))
    return false;
  return true;
};
function NonDisposableHandle() {
}
protoOf(NonDisposableHandle).mp = function () {
};
protoOf(NonDisposableHandle).toString = function () {
  return 'NonDisposableHandle';
};
var NonDisposableHandle_instance;
function NonDisposableHandle_getInstance() {
  return NonDisposableHandle_instance;
}
var FrameType_TEXT_instance;
var FrameType_BINARY_instance;
var FrameType_CLOSE_instance;
var FrameType_PING_instance;
var FrameType_PONG_instance;
function Companion_0() {
  Companion_instance_0 = this;
  var tmp = this;
  var tmp$ret$1;
  $l$block_0: {
    // Inline function 'kotlin.collections.maxByOrNull' call
    var this_0 = values_0();
    // Inline function 'kotlin.collections.isEmpty' call
    if (this_0.length === 0) {
      tmp$ret$1 = null;
      break $l$block_0;
    }
    var maxElem = this_0[0];
    var lastIndex = get_lastIndex(this_0);
    if (lastIndex === 0) {
      tmp$ret$1 = maxElem;
      break $l$block_0;
    }
    // Inline function 'io.ktor.websocket.Companion.maxOpcode.<anonymous>' call
    var maxValue = maxElem.p2d_1;
    var inductionVariable = 1;
    if (inductionVariable <= lastIndex)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var e = this_0[i];
        // Inline function 'io.ktor.websocket.Companion.maxOpcode.<anonymous>' call
        var v = e.p2d_1;
        if (compareTo(maxValue, v) < 0) {
          maxElem = e;
          maxValue = v;
        }
      }
       while (!(i === lastIndex));
    tmp$ret$1 = maxElem;
  }
  tmp.q2d_1 = ensureNotNull(tmp$ret$1).p2d_1;
  var tmp_0 = this;
  var tmp_1 = 0;
  var tmp_2 = this.q2d_1 + 1 | 0;
  // Inline function 'kotlin.arrayOfNulls' call
  var tmp_3 = fillArrayVal(Array(tmp_2), null);
  while (tmp_1 < tmp_2) {
    var tmp_4 = tmp_1;
    var tmp$ret$6;
    $l$block_2: {
      // Inline function 'kotlin.collections.singleOrNull' call
      var single = null;
      var found = false;
      var indexedObject = values_0();
      var inductionVariable_0 = 0;
      var last = indexedObject.length;
      while (inductionVariable_0 < last) {
        var element = indexedObject[inductionVariable_0];
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        // Inline function 'io.ktor.websocket.Companion.byOpcodeArray.<anonymous>' call
        if (element.p2d_1 === tmp_4) {
          if (found) {
            tmp$ret$6 = null;
            break $l$block_2;
          }
          single = element;
          found = true;
        }
      }
      if (!found) {
        tmp$ret$6 = null;
        break $l$block_2;
      }
      tmp$ret$6 = single;
    }
    tmp_3[tmp_4] = tmp$ret$6;
    tmp_1 = tmp_1 + 1 | 0;
  }
  tmp_0.r2d_1 = tmp_3;
}
var Companion_instance_0;
function Companion_getInstance_0() {
  FrameType_initEntries();
  if (Companion_instance_0 == null)
    new Companion_0();
  return Companion_instance_0;
}
function values_0() {
  return [FrameType_TEXT_getInstance(), FrameType_BINARY_getInstance(), FrameType_CLOSE_getInstance(), FrameType_PING_getInstance(), FrameType_PONG_getInstance()];
}
var FrameType_entriesInitialized;
function FrameType_initEntries() {
  if (FrameType_entriesInitialized)
    return Unit_instance;
  FrameType_entriesInitialized = true;
  FrameType_TEXT_instance = new FrameType('TEXT', 0, false, 1);
  FrameType_BINARY_instance = new FrameType('BINARY', 1, false, 2);
  FrameType_CLOSE_instance = new FrameType('CLOSE', 2, true, 8);
  FrameType_PING_instance = new FrameType('PING', 3, true, 9);
  FrameType_PONG_instance = new FrameType('PONG', 4, true, 10);
  Companion_getInstance_0();
}
function FrameType(name, ordinal, controlFrame, opcode) {
  Enum.call(this, name, ordinal);
  this.o2d_1 = controlFrame;
  this.p2d_1 = opcode;
}
function FrameType_TEXT_getInstance() {
  FrameType_initEntries();
  return FrameType_TEXT_instance;
}
function FrameType_BINARY_getInstance() {
  FrameType_initEntries();
  return FrameType_BINARY_instance;
}
function FrameType_CLOSE_getInstance() {
  FrameType_initEntries();
  return FrameType_CLOSE_instance;
}
function FrameType_PING_getInstance() {
  FrameType_initEntries();
  return FrameType_PING_instance;
}
function FrameType_PONG_getInstance() {
  FrameType_initEntries();
  return FrameType_PONG_instance;
}
function Binary_init_$Init$(fin, data, $this) {
  Binary.call($this, fin, data, false, false, false);
  return $this;
}
function Binary_init_$Create$(fin, data) {
  return Binary_init_$Init$(fin, data, objectCreate(protoOf(Binary)));
}
function Text_init_$Init$(fin, data, $this) {
  Text.call($this, fin, data, false, false, false);
  return $this;
}
function Text_init_$Init$_0(text, $this) {
  var tmp$ret$0;
  $l$block: {
    // Inline function 'io.ktor.utils.io.core.toByteArray' call
    var charset = Charsets_getInstance().t1p_1;
    if (charset.equals(Charsets_getInstance().t1p_1)) {
      tmp$ret$0 = encodeToByteArray(text);
      break $l$block;
    }
    tmp$ret$0 = encodeToByteArray_0(charset.x1p(), text, 0, text.length);
  }
  Text_init_$Init$(true, tmp$ret$0, $this);
  return $this;
}
function Text_init_$Create$(text) {
  return Text_init_$Init$_0(text, objectCreate(protoOf(Text)));
}
function Close_init_$Init$(reason, $this) {
  var tmp$ret$0;
  $l$block: {
    // Inline function 'io.ktor.utils.io.core.buildPacket' call
    // Inline function 'kotlin.contracts.contract' call
    var builder = new BytePacketBuilder();
    try {
      // Inline function 'io.ktor.websocket.Close.<init>.<anonymous>' call
      writeShort(builder, reason.j2d_1);
      writeText(builder, reason.k2d_1);
      tmp$ret$0 = builder.l1i();
      break $l$block;
    } catch ($p) {
      if ($p instanceof Error) {
        var t = $p;
        builder.mu();
        throw t;
      } else {
        throw $p;
      }
    }
  }
  Close_init_$Init$_0(tmp$ret$0, $this);
  return $this;
}
function Close_init_$Create$(reason) {
  return Close_init_$Init$(reason, objectCreate(protoOf(Close)));
}
function Close_init_$Init$_0(packet, $this) {
  Close.call($this, readBytes(packet));
  return $this;
}
function Close_init_$Init$_1($this) {
  Close.call($this, Companion_getInstance_1().s2d_1);
  return $this;
}
function Close_init_$Create$_0() {
  return Close_init_$Init$_1(objectCreate(protoOf(Close)));
}
function Binary(fin, data, rsv1, rsv2, rsv3) {
  rsv1 = rsv1 === VOID ? false : rsv1;
  rsv2 = rsv2 === VOID ? false : rsv2;
  rsv3 = rsv3 === VOID ? false : rsv3;
  Frame.call(this, fin, FrameType_BINARY_getInstance(), data, NonDisposableHandle_instance, rsv1, rsv2, rsv3);
}
function Text(fin, data, rsv1, rsv2, rsv3) {
  rsv1 = rsv1 === VOID ? false : rsv1;
  rsv2 = rsv2 === VOID ? false : rsv2;
  rsv3 = rsv3 === VOID ? false : rsv3;
  Frame.call(this, fin, FrameType_TEXT_getInstance(), data, NonDisposableHandle_instance, rsv1, rsv2, rsv3);
}
function Close(data) {
  Frame.call(this, true, FrameType_CLOSE_getInstance(), data, NonDisposableHandle_instance, false, false, false);
}
function Companion_1() {
  Companion_instance_1 = this;
  this.s2d_1 = new Int8Array(0);
}
var Companion_instance_1;
function Companion_getInstance_1() {
  if (Companion_instance_1 == null)
    new Companion_1();
  return Companion_instance_1;
}
function Frame(fin, frameType, data, disposableHandle, rsv1, rsv2, rsv3) {
  Companion_getInstance_1();
  disposableHandle = disposableHandle === VOID ? NonDisposableHandle_instance : disposableHandle;
  rsv1 = rsv1 === VOID ? false : rsv1;
  rsv2 = rsv2 === VOID ? false : rsv2;
  rsv3 = rsv3 === VOID ? false : rsv3;
  this.t2d_1 = fin;
  this.u2d_1 = frameType;
  this.v2d_1 = data;
  this.w2d_1 = disposableHandle;
  this.x2d_1 = rsv1;
  this.y2d_1 = rsv2;
  this.z2d_1 = rsv3;
}
protoOf(Frame).toString = function () {
  return 'Frame ' + this.u2d_1 + ' (fin=' + this.t2d_1 + ', buffer len = ' + this.v2d_1.length + ')';
};
//region block: init
NonDisposableHandle_instance = new NonDisposableHandle();
//endregion
//region block: exports
export {
  Codes_CLOSED_ABNORMALLY_getInstance as Codes_CLOSED_ABNORMALLY_getInstance20xmcavfn1j8v,
  Codes_NORMAL_getInstance as Codes_NORMAL_getInstance33u9lfki98gcj,
  Binary_init_$Create$ as Binary_init_$Create$1kqm3maz76dye,
  Close_init_$Create$ as Close_init_$Create$xnslhx6b2vkg,
  Text_init_$Create$ as Text_init_$Create$2ts7fidz9bnzk,
  Companion_getInstance as Companion_getInstance3hj6iykoiauw8,
  CloseReason as CloseReason10cphaqpp3ct7,
};
//endregion

//# sourceMappingURL=ktor-ktor-websockets.mjs.map
