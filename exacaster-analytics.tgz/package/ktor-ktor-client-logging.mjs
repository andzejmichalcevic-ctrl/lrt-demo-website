import {
  CoroutineImpl2sn3kjnwmfr10 as CoroutineImpl,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  trim11nh7r46at6sx as trim,
  toString1pkumu07cwy4m as toString,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  protoOf180f3jzyo7rfj as protoOf,
  classMetawt99a3kyl3us as classMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  StringBuilder_init_$Create$2mwec1027v00x as StringBuilder_init_$Create$,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  VOID7hggqo3abtya as VOID,
  Enum3alwj03lh1n41 as Enum,
  objectMeta213120oau977m as objectMeta,
  println2shhhgwwt4c61 as println,
  ArrayList_init_$Create$2qnngtk1et9r9 as ArrayList_init_$Create$,
  Collection1k04j3hzsbod0 as Collection,
  isInterface3d6p8outrmvmk as isInterface,
  emptyList1g2z5xcrvp2zy as emptyList,
  toList3jhuyej2anx2q as toList,
  sortedWith2csnbbb21k0lg as sortedWith,
  joinToString1cxrrlmo0chqs as joinToString,
  compareValues1n2ayl87ihzfk as compareValues,
} from './kotlin-kotlin-stdlib.mjs';
import {
  Job13y4jkazwjho0 as Job,
  GlobalScope_instance1sfulufhd2ijt as GlobalScope_instance,
  Dispatchers_getInstanceitgtkvqfcnx3 as Dispatchers_getInstance,
  launch1c91vkjzdi9sd as launch,
  CoroutineScopefcb5f5dwqcas as CoroutineScope,
} from './kotlinx-coroutines-core.mjs';
import { atomic$boolean$1iggki4z65a2h as atomic$boolean$1 } from './kotlinx-atomicfu.mjs';
import {
  ReadChannelContentz1amb4hnpqp4 as ReadChannelContent,
  OutgoingContent3t2ohmyam9o76 as OutgoingContent,
  Url2829xxbhyjpua as Url,
  HttpHeaders_getInstanceelogg8fjd54u as HttpHeaders_getInstance,
  charset1dribv3ku48b1 as charset,
  contentType317fn4f991q9a as contentType,
  WriteChannelContent1d7f40hsfcaxg as WriteChannelContent,
  ByteArrayContent2n0wb43y6ugs1 as ByteArrayContent,
} from './ktor-ktor-http.mjs';
import {
  Phases_getInstance18vqybk3y2ism as Phases_getInstance,
  Phases_getInstance2gb8yk5kt1qdy as Phases_getInstance_0,
  Phases_getInstance3cv4l5wlctlnh as Phases_getInstance_1,
  Plugin_getInstance3r34ly3r3uhxc as Plugin_getInstance,
  ResponseObserver69e7bll10ek6 as ResponseObserver,
  HttpClientPlugin3rce8c1crrw1q as HttpClientPlugin,
  HttpResponse1532ob1hsse1y as HttpResponse,
  HttpResponseContainer3r9yzy4mwwvc9 as HttpResponseContainer,
} from './ktor-ktor-client-core.mjs';
import {
  Charsets_getInstanceqs70pvl4noow as Charsets_getInstance,
  ByteChannelgfqke9q216t7 as ByteChannel,
  readText3x4cv5p7hylp as readText,
  writer1eia5its2a1fh as writer,
  WriterScope3b0bo1enaee6b as WriterScope,
  closeqm43o3junf8o as close,
  writeFullyuorxug1itxv3 as writeFully,
} from './ktor-ktor-io.mjs';
import {
  AttributeKey3aq8ytwgx54f7 as AttributeKey,
  PipelineContext34fsb0mycu471 as PipelineContext,
  copyToBoth3ldmovxh3mg5n as copyToBoth,
} from './ktor-ktor-utils.mjs';
//region block: imports
//endregion
//region block: pre-declaration
setMetadataFor($logResponseExceptionCOROUTINE$0, '$logResponseExceptionCOROUTINE$0', classMeta, CoroutineImpl);
setMetadataFor($logResponseBodyCOROUTINE$1, '$logResponseBodyCOROUTINE$1', classMeta, CoroutineImpl);
setMetadataFor($closeResponseLogCOROUTINE$2, '$closeResponseLogCOROUTINE$2', classMeta, CoroutineImpl);
setMetadataFor(HttpClientCallLogger, 'HttpClientCallLogger', classMeta, VOID, VOID, VOID, VOID, VOID, [1, 0]);
setMetadataFor(LogLevel, 'LogLevel', classMeta, Enum);
setMetadataFor(LoggedContent, 'LoggedContent', classMeta, ReadChannelContent);
setMetadataFor(Companion, 'Companion', objectMeta);
setMetadataFor(SimpleLogger, 'SimpleLogger', classMeta, VOID, VOID, SimpleLogger);
setMetadataFor(Config, 'Config', classMeta, VOID, VOID, Config);
setMetadataFor(Companion_0, 'Companion', objectMeta, VOID, [HttpClientPlugin]);
setMetadataFor(Logging$setupRequestLogging$slambda, 'Logging$setupRequestLogging$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [2]);
setMetadataFor(Logging$logRequestBody$slambda, 'Logging$logRequestBody$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(Logging$setupResponseLogging$slambda, 'Logging$setupResponseLogging$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [2]);
setMetadataFor(Logging$setupResponseLogging$slambda_1, 'Logging$setupResponseLogging$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [2]);
setMetadataFor(Logging$setupResponseLogging$slambda_3, 'Logging$setupResponseLogging$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(Logging, 'Logging', classMeta, VOID, VOID, VOID, VOID, VOID, [1, 2]);
setMetadataFor(sam$kotlin_Comparator$0, 'sam$kotlin_Comparator$0', classMeta);
setMetadataFor($logResponseBodyCOROUTINE$4, '$logResponseBodyCOROUTINE$4', classMeta, CoroutineImpl);
setMetadataFor(toReadChannel$slambda, 'toReadChannel$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor($observeCOROUTINE$5, '$observeCOROUTINE$5', classMeta, CoroutineImpl);
//endregion
function $logResponseExceptionCOROUTINE$0(_this__u8e3s4, message, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.z3j_1 = _this__u8e3s4;
  this.a3k_1 = message;
}
protoOf($logResponseExceptionCOROUTINE$0).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.z3j_1.e3k_1.gu(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var this_0 = this.a3k_1;
          this.z3j_1.b3k_1.i3k(toString(trim(isCharSequence(this_0) ? this_0 : THROW_CCE())));
          return Unit_instance;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $logResponseBodyCOROUTINE$1(_this__u8e3s4, message, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.r3k_1 = _this__u8e3s4;
  this.s3k_1 = message;
}
protoOf($logResponseBodyCOROUTINE$1).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.r3k_1.f3k_1.gu(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.r3k_1.d3k_1.n5(this.s3k_1);
          return Unit_instance;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $closeResponseLogCOROUTINE$2(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.b3l_1 = _this__u8e3s4;
}
protoOf($closeResponseLogCOROUTINE$2).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          if (!this.b3l_1.h3k_1.atomicfu$compareAndSet(false, true))
            return Unit_instance;
          this.ic_1 = 1;
          suspendResult = this.b3l_1.e3k_1.gu(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var message = toString(trim(this.b3l_1.d3k_1));
          if (charSequenceLength(message) > 0) {
            this.b3l_1.b3k_1.i3k(message);
          }

          return Unit_instance;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function HttpClientCallLogger(logger) {
  this.b3k_1 = logger;
  this.c3k_1 = StringBuilder_init_$Create$();
  this.d3k_1 = StringBuilder_init_$Create$();
  this.e3k_1 = Job();
  this.f3k_1 = Job();
  this.g3k_1 = atomic$boolean$1(false);
  this.h3k_1 = atomic$boolean$1(false);
}
protoOf(HttpClientCallLogger).c3l = function (message) {
  // Inline function 'kotlin.text.appendLine' call
  var this_0 = this.c3k_1;
  // Inline function 'kotlin.text.trim' call
  var value = toString(trim(isCharSequence(message) ? message : THROW_CCE()));
  // Inline function 'kotlin.text.appendLine' call
  this_0.n5(value).o5(_Char___init__impl__6a9atx(10));
};
protoOf(HttpClientCallLogger).d3l = function (message) {
  // Inline function 'kotlin.text.appendLine' call
  var this_0 = this.d3k_1;
  // Inline function 'kotlin.text.trim' call
  var value = toString(trim(isCharSequence(message) ? message : THROW_CCE()));
  // Inline function 'kotlin.text.appendLine' call
  this_0.n5(value).o5(_Char___init__impl__6a9atx(10));
  this.f3k_1.fu();
};
protoOf(HttpClientCallLogger).e3l = function (message, $completion) {
  var tmp = new $logResponseExceptionCOROUTINE$0(this, message, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(HttpClientCallLogger).f3l = function (message, $completion) {
  var tmp = new $logResponseBodyCOROUTINE$1(this, message, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(HttpClientCallLogger).g3l = function () {
  if (!this.g3k_1.atomicfu$compareAndSet(false, true))
    return Unit_instance;
  try {
    var message = toString(trim(this.c3k_1));
    // Inline function 'kotlin.text.isNotEmpty' call
    if (charSequenceLength(message) > 0) {
      this.b3k_1.i3k(message);
    }
  }finally {
    this.e3k_1.fu();
  }
};
protoOf(HttpClientCallLogger).h3l = function ($completion) {
  var tmp = new $closeResponseLogCOROUTINE$2(this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
var LogLevel_ALL_instance;
var LogLevel_HEADERS_instance;
var LogLevel_BODY_instance;
var LogLevel_INFO_instance;
var LogLevel_NONE_instance;
var LogLevel_entriesInitialized;
function LogLevel_initEntries() {
  if (LogLevel_entriesInitialized)
    return Unit_instance;
  LogLevel_entriesInitialized = true;
  LogLevel_ALL_instance = new LogLevel('ALL', 0, true, true, true);
  LogLevel_HEADERS_instance = new LogLevel('HEADERS', 1, true, true, false);
  LogLevel_BODY_instance = new LogLevel('BODY', 2, true, false, true);
  LogLevel_INFO_instance = new LogLevel('INFO', 3, true, false, false);
  LogLevel_NONE_instance = new LogLevel('NONE', 4, false, false, false);
}
function LogLevel(name, ordinal, info, headers, body) {
  Enum.call(this, name, ordinal);
  this.k3l_1 = info;
  this.l3l_1 = headers;
  this.m3l_1 = body;
}
function LogLevel_HEADERS_getInstance() {
  LogLevel_initEntries();
  return LogLevel_HEADERS_instance;
}
function LogLevel_NONE_getInstance() {
  LogLevel_initEntries();
  return LogLevel_NONE_instance;
}
function LoggedContent(originalContent, channel) {
  ReadChannelContent.call(this);
  this.o3l_1 = originalContent;
  this.p3l_1 = channel;
  this.q3l_1 = this.o3l_1.i2c();
  this.r3l_1 = this.o3l_1.k2c();
  this.s3l_1 = this.o3l_1.j2c();
  this.t3l_1 = this.o3l_1.h27();
}
protoOf(LoggedContent).i2c = function () {
  return this.q3l_1;
};
protoOf(LoggedContent).k2c = function () {
  return this.r3l_1;
};
protoOf(LoggedContent).j2c = function () {
  return this.s3l_1;
};
protoOf(LoggedContent).h27 = function () {
  return this.t3l_1;
};
protoOf(LoggedContent).o2c = function () {
  return this.p3l_1;
};
function Companion() {
}
var Companion_instance;
function Companion_getInstance() {
  return Companion_instance;
}
function get_SIMPLE(_this__u8e3s4) {
  return new SimpleLogger();
}
function SimpleLogger() {
}
protoOf(SimpleLogger).i3k = function (message) {
  println('HttpClient: ' + message);
};
function get_ClientCallLogger() {
  _init_properties_Logging_kt__66pui5();
  return ClientCallLogger;
}
var ClientCallLogger;
function get_DisableLogging() {
  _init_properties_Logging_kt__66pui5();
  return DisableLogging;
}
var DisableLogging;
function Config() {
  var tmp = this;
  // Inline function 'kotlin.collections.mutableListOf' call
  tmp.u3l_1 = ArrayList_init_$Create$();
  var tmp_0 = this;
  // Inline function 'kotlin.collections.mutableListOf' call
  tmp_0.v3l_1 = ArrayList_init_$Create$();
  this.w3l_1 = null;
  this.x3l_1 = LogLevel_HEADERS_getInstance();
}
protoOf(Config).y3l = function (value) {
  this.w3l_1 = value;
};
protoOf(Config).z3l = function () {
  var tmp0_elvis_lhs = this.w3l_1;
  return tmp0_elvis_lhs == null ? get_DEFAULT(Companion_instance) : tmp0_elvis_lhs;
};
function setupRequestLogging($this, client) {
  var tmp = Phases_getInstance().l2j_1;
  client.v2g_1.n20(tmp, Logging$setupRequestLogging$slambda_0($this, null));
}
function logRequest($this, request, $completion) {
  var tmp = request.w2i_1;
  var content = tmp instanceof OutgoingContent ? tmp : THROW_CCE();
  var logger = new HttpClientCallLogger($this.a3m_1);
  request.y2i_1.p1t(get_ClientCallLogger(), logger);
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder_init_$Create$();
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'io.ktor.client.plugins.logging.Logging.logRequest.<anonymous>' call
  if ($this.b3m_1.k3l_1) {
    // Inline function 'kotlin.text.appendLine' call
    var value = 'REQUEST: ' + Url(request.t2i_1);
    // Inline function 'kotlin.text.appendLine' call
    this_0.n5(value).o5(_Char___init__impl__6a9atx(10));
    // Inline function 'kotlin.text.appendLine' call
    var value_0 = 'METHOD: ' + request.u2i_1;
    // Inline function 'kotlin.text.appendLine' call
    this_0.n5(value_0).o5(_Char___init__impl__6a9atx(10));
  }
  if ($this.b3m_1.l3l_1) {
    // Inline function 'kotlin.text.appendLine' call
    var value_1 = 'COMMON HEADERS';
    // Inline function 'kotlin.text.appendLine' call
    this_0.n5(value_1).o5(_Char___init__impl__6a9atx(10));
    logHeaders(this_0, request.v2i_1.n1x(), $this.d3m_1);
    // Inline function 'kotlin.text.appendLine' call
    var value_2 = 'CONTENT HEADERS';
    // Inline function 'kotlin.text.appendLine' call
    this_0.n5(value_2).o5(_Char___init__impl__6a9atx(10));
    var tmp$ret$9;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var tmp0_iterator = $this.d3m_1.u();
      while (tmp0_iterator.v()) {
        var element = tmp0_iterator.w();
        // Inline function 'io.ktor.client.plugins.logging.Logging.logRequest.<anonymous>.<anonymous>' call
        if (element.f3m_1(HttpHeaders_getInstance().t23_1)) {
          tmp$ret$9 = element;
          break $l$block;
        }
      }
      tmp$ret$9 = null;
    }
    var tmp0_safe_receiver = tmp$ret$9;
    var contentLengthPlaceholder = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.e3m_1;
    var tmp$ret$11;
    $l$block_0: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var tmp0_iterator_0 = $this.d3m_1.u();
      while (tmp0_iterator_0.v()) {
        var element_0 = tmp0_iterator_0.w();
        // Inline function 'io.ktor.client.plugins.logging.Logging.logRequest.<anonymous>.<anonymous>' call
        if (element_0.f3m_1(HttpHeaders_getInstance().w23_1)) {
          tmp$ret$11 = element_0;
          break $l$block_0;
        }
      }
      tmp$ret$11 = null;
    }
    var tmp1_safe_receiver = tmp$ret$11;
    var contentTypePlaceholder = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.e3m_1;
    var tmp2_safe_receiver = content.k2c();
    if (tmp2_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.contracts.contract' call
      var tmp_0 = HttpHeaders_getInstance().t23_1;
      logHeader(this_0, tmp_0, contentLengthPlaceholder == null ? tmp2_safe_receiver.toString() : contentLengthPlaceholder);
    }
    var tmp3_safe_receiver = content.i2c();
    if (tmp3_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.contracts.contract' call
      var tmp_1 = HttpHeaders_getInstance().w23_1;
      logHeader(this_0, tmp_1, contentTypePlaceholder == null ? tmp3_safe_receiver.toString() : contentTypePlaceholder);
    }
    logHeaders(this_0, content.h27().n1x(), $this.d3m_1);
  }
  var message = this_0.toString();
  // Inline function 'kotlin.text.isNotEmpty' call
  if (charSequenceLength(message) > 0) {
    logger.c3l(message);
  }
  var tmp_2;
  // Inline function 'kotlin.text.isEmpty' call
  if (charSequenceLength(message) === 0) {
    tmp_2 = true;
  } else {
    tmp_2 = !$this.b3m_1.m3l_1;
  }
  if (tmp_2) {
    logger.g3l();
    return null;
  }
  return logRequestBody($this, content, logger, $completion);
}
function logRequestBody($this, content, logger, $completion) {
  var requestLog = StringBuilder_init_$Create$();
  // Inline function 'kotlin.text.appendLine' call
  var value = 'BODY Content-Type: ' + content.i2c();
  // Inline function 'kotlin.text.appendLine' call
  requestLog.n5(value).o5(_Char___init__impl__6a9atx(10));
  var tmp0_safe_receiver = content.i2c();
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : charset(tmp0_safe_receiver);
  var charset_0 = tmp1_elvis_lhs == null ? Charsets_getInstance().t1p_1 : tmp1_elvis_lhs;
  var channel = ByteChannel();
  var tmp = GlobalScope_instance;
  var tmp_0 = Dispatchers_getInstance().fy_1;
  var tmp_1 = launch(tmp, tmp_0, VOID, Logging$logRequestBody$slambda_0(channel, charset_0, requestLog, null));
  tmp_1.wn(Logging$logRequestBody$lambda(logger, requestLog));
  return observe(content, channel, $completion);
}
function logRequestException($this, context, cause) {
  if ($this.b3m_1.k3l_1) {
    $this.a3m_1.i3k('REQUEST ' + Url(context.t2i_1) + ' failed with exception: ' + cause);
  }
}
function setupResponseLogging($this, client) {
  var tmp = Phases_getInstance_0().w2p_1;
  client.w2g_1.n20(tmp, Logging$setupResponseLogging$slambda_0($this, null));
  var tmp_0 = Phases_getInstance_1().r2j_1;
  client.u2g_1.n20(tmp_0, Logging$setupResponseLogging$slambda_2($this, null));
  if (!$this.b3m_1.m3l_1)
    return Unit_instance;
  var observer = Logging$setupResponseLogging$slambda_4($this, null);
  Plugin_getInstance().u36(new ResponseObserver(observer), client);
}
function logResponseException($this, log, request, cause) {
  if (!$this.b3m_1.k3l_1)
    return Unit_instance;
  log.n5('RESPONSE ' + request.g2l() + ' failed with exception: ' + cause);
}
function Companion_0() {
  Companion_instance_0 = this;
  this.g3m_1 = new AttributeKey('ClientLogging');
}
protoOf(Companion_0).k2 = function () {
  return this.g3m_1;
};
protoOf(Companion_0).h3m = function (block) {
  // Inline function 'kotlin.apply' call
  var this_0 = new Config();
  // Inline function 'kotlin.contracts.contract' call
  block(this_0);
  var config = this_0;
  return new Logging(config.z3l(), config.x3l_1, config.u3l_1, config.v3l_1);
};
protoOf(Companion_0).y2j = function (block) {
  return this.h3m(block);
};
protoOf(Companion_0).i3m = function (plugin, scope) {
  setupRequestLogging(plugin, scope);
  setupResponseLogging(plugin, scope);
};
protoOf(Companion_0).z2j = function (plugin, scope) {
  return this.i3m(plugin instanceof Logging ? plugin : THROW_CCE(), scope);
};
var Companion_instance_0;
function Companion_getInstance_0() {
  if (Companion_instance_0 == null)
    new Companion_0();
  return Companion_instance_0;
}
function shouldBeLogged($this, request) {
  var tmp;
  if ($this.c3m_1.b1()) {
    tmp = true;
  } else {
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var this_0 = $this.c3m_1;
      var tmp_0;
      if (isInterface(this_0, Collection)) {
        tmp_0 = this_0.b1();
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var tmp0_iterator = this_0.u();
      while (tmp0_iterator.v()) {
        var element = tmp0_iterator.w();
        // Inline function 'io.ktor.client.plugins.logging.Logging.shouldBeLogged.<anonymous>' call
        if (element(request)) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    tmp = tmp$ret$0;
  }
  return tmp;
}
function Logging$setupRequestLogging$slambda(this$0, resultContinuation) {
  this.r3m_1 = this$0;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(Logging$setupRequestLogging$slambda).n2h = function ($this$intercept, it, $completion) {
  var tmp = this.o2h($this$intercept, it, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(Logging$setupRequestLogging$slambda).dk = function (p1, p2, $completion) {
  var tmp = p1 instanceof PipelineContext ? p1 : THROW_CCE();
  return this.n2h(tmp, !(p2 == null) ? p2 : THROW_CCE(), $completion);
};
protoOf(Logging$setupRequestLogging$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 8;
          if (!shouldBeLogged(this.r3m_1, this.s3m_1.j20_1)) {
            this.s3m_1.j20_1.y2i_1.p1t(get_DisableLogging(), Unit_instance);
            return Unit_instance;
          }

          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = logRequest(this.r3m_1, this.s3m_1.j20_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.u3m_1 = suspendResult;
          this.jc_1 = 8;
          this.ic_1 = 3;
          continue $sm;
        case 2:
          this.jc_1 = 8;
          var tmp_0 = this.lc_1;
          if (tmp_0 instanceof Error) {
            this.v3m_1 = this.lc_1;
            var tmp_1 = this;
            tmp_1.u3m_1 = null;
            this.ic_1 = 3;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 3:
          this.jc_1 = 8;
          this.w3m_1 = this.u3m_1;
          this.ic_1 = 4;
          continue $sm;
        case 4:
          this.jc_1 = 7;
          this.jc_1 = 6;
          this.ic_1 = 5;
          var tmp0_elvis_lhs = this.w3m_1;
          suspendResult = this.s3m_1.n1z(tmp0_elvis_lhs == null ? this.s3m_1.m1z() : tmp0_elvis_lhs, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 5:
          var tmp_2 = this;
          tmp_2.x3m_1 = Unit_instance;
          this.jc_1 = 8;
          this.ic_1 = 9;
          continue $sm;
        case 6:
          this.jc_1 = 7;
          var tmp_3 = this.lc_1;
          if (tmp_3 instanceof Error) {
            var cause = this.lc_1;
            var tmp_4 = this;
            logRequestException(this.r3m_1, this.s3m_1.j20_1, cause);
            throw cause;
          } else {
            throw this.lc_1;
          }

        case 7:
          this.jc_1 = 8;
          var t = this.lc_1;
          throw t;
        case 8:
          throw this.lc_1;
        case 9:
          this.jc_1 = 8;
          return Unit_instance;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 8) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
protoOf(Logging$setupRequestLogging$slambda).o2h = function ($this$intercept, it, completion) {
  var i = new Logging$setupRequestLogging$slambda(this.r3m_1, completion);
  i.s3m_1 = $this$intercept;
  i.t3m_1 = it;
  return i;
};
function Logging$setupRequestLogging$slambda_0(this$0, resultContinuation) {
  var i = new Logging$setupRequestLogging$slambda(this$0, resultContinuation);
  var l = function ($this$intercept, it, $completion) {
    return i.n2h($this$intercept, it, $completion);
  };
  l.$arity = 2;
  return l;
}
function Logging$logRequestBody$slambda($channel, $charset, $requestLog, resultContinuation) {
  this.g3n_1 = $channel;
  this.h3n_1 = $charset;
  this.i3n_1 = $requestLog;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(Logging$logRequestBody$slambda).d1m = function ($this$launch, $completion) {
  var tmp = this.e1m($this$launch, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(Logging$logRequestBody$slambda).gd = function (p1, $completion) {
  return this.d1m((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(Logging$logRequestBody$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          var tmp_0 = this;
          tmp_0.k3n_1 = this.g3n_1;
          var tmp_1 = this;
          tmp_1.l3n_1 = this.h3n_1;
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.k3n_1.c1l(VOID, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var ARGUMENT = suspendResult;
          this.m3n_1 = readText(ARGUMENT, this.l3n_1);
          this.jc_1 = 3;
          this.ic_1 = 4;
          continue $sm;
        case 2:
          this.jc_1 = 3;
          var tmp_2 = this.lc_1;
          if (tmp_2 instanceof Error) {
            var cause = this.lc_1;
            var tmp_3 = this;
            tmp_3.m3n_1 = null;
            this.ic_1 = 4;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 3:
          throw this.lc_1;
        case 4:
          this.jc_1 = 3;
          var tmp0_elvis_lhs = this.m3n_1;
          var text = tmp0_elvis_lhs == null ? '[request body omitted]' : tmp0_elvis_lhs;
          var this_0 = this.i3n_1;
          var value = 'BODY START';
          this_0.n5(value).o5(_Char___init__impl__6a9atx(10));
          this.i3n_1.n5(text).o5(_Char___init__impl__6a9atx(10));
          this.i3n_1.n5('BODY END');
          return Unit_instance;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
protoOf(Logging$logRequestBody$slambda).e1m = function ($this$launch, completion) {
  var i = new Logging$logRequestBody$slambda(this.g3n_1, this.h3n_1, this.i3n_1, completion);
  i.j3n_1 = $this$launch;
  return i;
};
function Logging$logRequestBody$slambda_0($channel, $charset, $requestLog, resultContinuation) {
  var i = new Logging$logRequestBody$slambda($channel, $charset, $requestLog, resultContinuation);
  var l = function ($this$launch, $completion) {
    return i.d1m($this$launch, $completion);
  };
  l.$arity = 1;
  return l;
}
function Logging$logRequestBody$lambda($logger, $requestLog) {
  return function (it) {
    $logger.c3l($requestLog.toString());
    $logger.g3l();
    return Unit_instance;
  };
}
function Logging$setupResponseLogging$slambda(this$0, resultContinuation) {
  this.v3n_1 = this$0;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(Logging$setupResponseLogging$slambda).z2q = function ($this$intercept, response, $completion) {
  var tmp = this.a2r($this$intercept, response, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(Logging$setupResponseLogging$slambda).dk = function (p1, p2, $completion) {
  var tmp = p1 instanceof PipelineContext ? p1 : THROW_CCE();
  return this.z2q(tmp, p2 instanceof HttpResponse ? p2 : THROW_CCE(), $completion);
};
protoOf(Logging$setupResponseLogging$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 10;
          if (this.v3n_1.b3m_1.equals(LogLevel_NONE_getInstance()) ? true : this.x3n_1.b2m().i2k().o1t(get_DisableLogging()))
            return Unit_instance;
          this.y3n_1 = this.x3n_1.b2m().i2k().m1t(get_ClientCallLogger());
          this.z3n_1 = StringBuilder_init_$Create$();
          this.a3o_1 = false;
          this.ic_1 = 1;
          continue $sm;
        case 1:
          this.jc_1 = 4;
          this.jc_1 = 3;
          logResponseHeader(this.z3n_1, this.x3n_1.b2m().u2h(), this.v3n_1.b3m_1, this.v3n_1.d3m_1);
          this.ic_1 = 2;
          suspendResult = this.w3n_1.n1z(this.w3n_1.m1z(), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          var tmp_0 = this;
          tmp_0.b3o_1 = Unit_instance;
          this.jc_1 = 10;
          this.ic_1 = 7;
          continue $sm;
        case 3:
          this.jc_1 = 4;
          var tmp_1 = this.lc_1;
          if (tmp_1 instanceof Error) {
            this.c3o_1 = this.lc_1;
            var tmp_2 = this;
            logResponseException(this.v3n_1, this.z3n_1, this.x3n_1.b2m().d2l(), this.c3o_1);
            this.a3o_1 = true;
            throw this.c3o_1;
          } else {
            throw this.lc_1;
          }

        case 4:
          this.jc_1 = 10;
          this.d3o_1 = this.lc_1;
          this.y3n_1.d3l(this.z3n_1.toString());
          if (this.a3o_1 ? true : !this.v3n_1.b3m_1.m3l_1) {
            this.ic_1 = 5;
            suspendResult = this.y3n_1.h3l(this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 6;
            continue $sm;
          }

        case 5:
          this.ic_1 = 6;
          continue $sm;
        case 6:
          throw this.d3o_1;
        case 7:
          this.jc_1 = 10;
          this.y3n_1.d3l(this.z3n_1.toString());
          if (this.a3o_1 ? true : !this.v3n_1.b3m_1.m3l_1) {
            this.ic_1 = 8;
            suspendResult = this.y3n_1.h3l(this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 9;
            continue $sm;
          }

        case 8:
          this.ic_1 = 9;
          continue $sm;
        case 9:
          return Unit_instance;
        case 10:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 10) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
protoOf(Logging$setupResponseLogging$slambda).a2r = function ($this$intercept, response, completion) {
  var i = new Logging$setupResponseLogging$slambda(this.v3n_1, completion);
  i.w3n_1 = $this$intercept;
  i.x3n_1 = response;
  return i;
};
function Logging$setupResponseLogging$slambda_0(this$0, resultContinuation) {
  var i = new Logging$setupResponseLogging$slambda(this$0, resultContinuation);
  var l = function ($this$intercept, response, $completion) {
    return i.z2q($this$intercept, response, $completion);
  };
  l.$arity = 2;
  return l;
}
function Logging$setupResponseLogging$slambda_1(this$0, resultContinuation) {
  this.m3o_1 = this$0;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(Logging$setupResponseLogging$slambda_1).h2i = function ($this$intercept, it, $completion) {
  var tmp = this.i2i($this$intercept, it, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(Logging$setupResponseLogging$slambda_1).dk = function (p1, p2, $completion) {
  var tmp = p1 instanceof PipelineContext ? p1 : THROW_CCE();
  return this.h2i(tmp, p2 instanceof HttpResponseContainer ? p2 : THROW_CCE(), $completion);
};
protoOf(Logging$setupResponseLogging$slambda_1).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 6;
          if (this.m3o_1.b3m_1.equals(LogLevel_NONE_getInstance()) ? true : this.n3o_1.j20_1.i2k().o1t(get_DisableLogging())) {
            return Unit_instance;
          }

          this.jc_1 = 3;
          this.ic_1 = 1;
          suspendResult = this.n3o_1.o1z(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.jc_1 = 6;
          this.ic_1 = 2;
          continue $sm;
        case 2:
          this.jc_1 = 6;
          return Unit_instance;
        case 3:
          this.jc_1 = 6;
          var tmp_0 = this.lc_1;
          if (tmp_0 instanceof Error) {
            this.p3o_1 = this.lc_1;
            this.q3o_1 = StringBuilder_init_$Create$();
            this.r3o_1 = this.n3o_1.j20_1.i2k().m1t(get_ClientCallLogger());
            logResponseException(this.m3o_1, this.q3o_1, this.n3o_1.j20_1.d2l(), this.p3o_1);
            this.ic_1 = 4;
            suspendResult = this.r3o_1.e3l(this.q3o_1.toString(), this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 4:
          this.ic_1 = 5;
          suspendResult = this.r3o_1.h3l(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 5:
          throw this.p3o_1;
        case 6:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 6) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
protoOf(Logging$setupResponseLogging$slambda_1).i2i = function ($this$intercept, it, completion) {
  var i = new Logging$setupResponseLogging$slambda_1(this.m3o_1, completion);
  i.n3o_1 = $this$intercept;
  i.o3o_1 = it;
  return i;
};
function Logging$setupResponseLogging$slambda_2(this$0, resultContinuation) {
  var i = new Logging$setupResponseLogging$slambda_1(this$0, resultContinuation);
  var l = function ($this$intercept, it, $completion) {
    return i.h2i($this$intercept, it, $completion);
  };
  l.$arity = 2;
  return l;
}
function Logging$setupResponseLogging$slambda_3(this$0, resultContinuation) {
  this.a3p_1 = this$0;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(Logging$setupResponseLogging$slambda_3).y2r = function (it, $completion) {
  var tmp = this.z2r(it, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(Logging$setupResponseLogging$slambda_3).gd = function (p1, $completion) {
  return this.y2r(p1 instanceof HttpResponse ? p1 : THROW_CCE(), $completion);
};
protoOf(Logging$setupResponseLogging$slambda_3).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 10;
          if (this.a3p_1.b3m_1.equals(LogLevel_NONE_getInstance()) ? true : this.b3p_1.b2m().i2k().o1t(get_DisableLogging())) {
            return Unit_instance;
          }

          this.c3p_1 = this.b3p_1.b2m().i2k().m1t(get_ClientCallLogger());
          this.d3p_1 = StringBuilder_init_$Create$();
          this.ic_1 = 1;
          continue $sm;
        case 1:
          this.jc_1 = 4;
          this.jc_1 = 3;
          this.ic_1 = 2;
          suspendResult = logResponseBody(this.d3p_1, contentType(this.b3p_1), this.b3p_1.e2l(), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          this.e3p_1 = suspendResult;
          this.jc_1 = 10;
          this.ic_1 = 7;
          continue $sm;
        case 3:
          this.jc_1 = 4;
          var tmp_0 = this.lc_1;
          if (tmp_0 instanceof Error) {
            this.f3p_1 = this.lc_1;
            var tmp_1 = this;
            tmp_1.e3p_1 = Unit_instance;
            this.jc_1 = 10;
            this.ic_1 = 7;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 4:
          this.jc_1 = 10;
          this.g3p_1 = this.lc_1;
          this.ic_1 = 5;
          var this_0 = this.d3p_1.toString();
          suspendResult = this.c3p_1.f3l(toString(trim(isCharSequence(this_0) ? this_0 : THROW_CCE())), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 5:
          this.ic_1 = 6;
          suspendResult = this.c3p_1.h3l(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 6:
          throw this.g3p_1;
        case 7:
          this.jc_1 = 10;
          this.ic_1 = 8;
          var this_1 = this.d3p_1.toString();
          suspendResult = this.c3p_1.f3l(toString(trim(isCharSequence(this_1) ? this_1 : THROW_CCE())), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 8:
          this.ic_1 = 9;
          suspendResult = this.c3p_1.h3l(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 9:
          return Unit_instance;
        case 10:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 10) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
protoOf(Logging$setupResponseLogging$slambda_3).z2r = function (it, completion) {
  var i = new Logging$setupResponseLogging$slambda_3(this.a3p_1, completion);
  i.b3p_1 = it;
  return i;
};
function Logging$setupResponseLogging$slambda_4(this$0, resultContinuation) {
  var i = new Logging$setupResponseLogging$slambda_3(this$0, resultContinuation);
  var l = function (it, $completion) {
    return i.y2r(it, $completion);
  };
  l.$arity = 1;
  return l;
}
function Logging(logger, level, filters, sanitizedHeaders) {
  Companion_getInstance_0();
  filters = filters === VOID ? emptyList() : filters;
  this.a3m_1 = logger;
  this.b3m_1 = level;
  this.c3m_1 = filters;
  this.d3m_1 = sanitizedHeaders;
}
var properties_initialized_Logging_kt_588vu7;
function _init_properties_Logging_kt__66pui5() {
  if (!properties_initialized_Logging_kt_588vu7) {
    properties_initialized_Logging_kt_588vu7 = true;
    ClientCallLogger = new AttributeKey('CallLogger');
    DisableLogging = new AttributeKey('DisableLogging');
  }
}
function logHeaders(_this__u8e3s4, headers, sanitizedHeaders) {
  // Inline function 'kotlin.collections.sortedBy' call
  var this_0 = toList(headers);
  // Inline function 'kotlin.comparisons.compareBy' call
  var tmp = logHeaders$lambda;
  var tmp$ret$0 = new sam$kotlin_Comparator$0(tmp);
  var sortedHeaders = sortedWith(this_0, tmp$ret$0);
  // Inline function 'kotlin.collections.forEach' call
  var tmp0_iterator = sortedHeaders.u();
  while (tmp0_iterator.v()) {
    var element = tmp0_iterator.w();
    // Inline function 'io.ktor.client.plugins.logging.logHeaders.<anonymous>' call
    // Inline function 'kotlin.collections.component1' call
    var key = element.k2();
    // Inline function 'kotlin.collections.component2' call
    var values = element.l2();
    var tmp$ret$5;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var tmp0_iterator_0 = sanitizedHeaders.u();
      while (tmp0_iterator_0.v()) {
        var element_0 = tmp0_iterator_0.w();
        // Inline function 'io.ktor.client.plugins.logging.logHeaders.<anonymous>.<anonymous>' call
        if (element_0.f3m_1(key)) {
          tmp$ret$5 = element_0;
          break $l$block;
        }
      }
      tmp$ret$5 = null;
    }
    var tmp0_safe_receiver = tmp$ret$5;
    var placeholder = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.e3m_1;
    logHeader(_this__u8e3s4, key, placeholder == null ? joinToString(values, '; ') : placeholder);
  }
}
function logHeader(_this__u8e3s4, key, value) {
  // Inline function 'kotlin.text.appendLine' call
  var value_0 = '-> ' + key + ': ' + value;
  // Inline function 'kotlin.text.appendLine' call
  _this__u8e3s4.d8(value_0).o5(_Char___init__impl__6a9atx(10));
}
function logResponseHeader(log, response, level, sanitizedHeaders) {
  // Inline function 'kotlin.with' call
  // Inline function 'kotlin.contracts.contract' call
  if (level.k3l_1) {
    // Inline function 'kotlin.text.appendLine' call
    var value = 'RESPONSE: ' + response.j2c();
    // Inline function 'kotlin.text.appendLine' call
    log.n5(value).o5(_Char___init__impl__6a9atx(10));
    // Inline function 'kotlin.text.appendLine' call
    var value_0 = 'METHOD: ' + response.b2m().d2l().c2m();
    // Inline function 'kotlin.text.appendLine' call
    log.n5(value_0).o5(_Char___init__impl__6a9atx(10));
    // Inline function 'kotlin.text.appendLine' call
    var value_1 = 'FROM: ' + response.b2m().d2l().g2l();
    // Inline function 'kotlin.text.appendLine' call
    log.n5(value_1).o5(_Char___init__impl__6a9atx(10));
  }
  var tmp;
  if (level.l3l_1) {
    // Inline function 'kotlin.text.appendLine' call
    var value_2 = 'COMMON HEADERS';
    // Inline function 'kotlin.text.appendLine' call
    log.n5(value_2).o5(_Char___init__impl__6a9atx(10));
    logHeaders(log, response.h27().n1x(), sanitizedHeaders);
    tmp = Unit_instance;
  }
}
function logResponseBody(log, contentType, content, $completion) {
  var tmp = new $logResponseBodyCOROUTINE$4(log, contentType, content, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function sam$kotlin_Comparator$0(function_0) {
  this.x3p_1 = function_0;
}
protoOf(sam$kotlin_Comparator$0).q9 = function (a, b) {
  return this.x3p_1(a, b);
};
protoOf(sam$kotlin_Comparator$0).compare = function (a, b) {
  return this.q9(a, b);
};
function logHeaders$lambda(a, b) {
  // Inline function 'kotlin.comparisons.compareValuesBy' call
  // Inline function 'io.ktor.client.plugins.logging.logHeaders.<anonymous>' call
  var tmp = a.k2();
  // Inline function 'io.ktor.client.plugins.logging.logHeaders.<anonymous>' call
  var tmp$ret$1 = b.k2();
  return compareValues(tmp, tmp$ret$1);
}
function $logResponseBodyCOROUTINE$4(log, contentType, content, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.p3p_1 = log;
  this.q3p_1 = contentType;
  this.r3p_1 = content;
}
protoOf($logResponseBodyCOROUTINE$4).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 4;
          var tmp_0 = this;
          tmp_0.s3p_1 = this.p3p_1;
          var tmp_1 = this;
          tmp_1.t3p_1 = this.s3p_1;
          var this_0 = this.t3p_1;
          var value = 'BODY Content-Type: ' + this.q3p_1;
          this_0.n5(value).o5(_Char___init__impl__6a9atx(10));
          var this_1 = this.t3p_1;
          var value_0 = 'BODY START';
          this_1.n5(value_0).o5(_Char___init__impl__6a9atx(10));
          var tmp_2 = this;
          tmp_2.u3p_1 = this.r3p_1;
          var tmp_3 = this;
          var tmp0_safe_receiver = this.q3p_1;
          var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : charset(tmp0_safe_receiver);
          tmp_3.v3p_1 = tmp1_elvis_lhs == null ? Charsets_getInstance().t1p_1 : tmp1_elvis_lhs;
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.u3p_1.c1l(VOID, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var ARGUMENT = suspendResult;
          this.w3p_1 = readText(ARGUMENT, this.v3p_1);
          this.jc_1 = 4;
          this.ic_1 = 3;
          continue $sm;
        case 2:
          this.jc_1 = 4;
          var tmp_4 = this.lc_1;
          if (tmp_4 instanceof Error) {
            var cause = this.lc_1;
            var tmp_5 = this;
            tmp_5.w3p_1 = null;
            this.ic_1 = 3;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 3:
          this.jc_1 = 4;
          var tmp2_elvis_lhs = this.w3p_1;
          var message = tmp2_elvis_lhs == null ? '[response body omitted]' : tmp2_elvis_lhs;
          this.t3p_1.n5(message).o5(_Char___init__impl__6a9atx(10));
          this.t3p_1.n5('BODY END');
          return Unit_instance;
        case 4:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 4) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function observe(_this__u8e3s4, log, $completion) {
  var tmp = new $observeCOROUTINE$5(_this__u8e3s4, log, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function toReadChannel(_this__u8e3s4) {
  var tmp = GlobalScope_instance;
  var tmp_0 = Dispatchers_getInstance().ey_1;
  return writer(tmp, tmp_0, VOID, toReadChannel$slambda_0(_this__u8e3s4, null)).vy();
}
function toReadChannel$slambda($this_toReadChannel, resultContinuation) {
  this.s3q_1 = $this_toReadChannel;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(toReadChannel$slambda).z2m = function ($this$writer, $completion) {
  var tmp = this.a2n($this$writer, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(toReadChannel$slambda).gd = function (p1, $completion) {
  return this.z2m((!(p1 == null) ? isInterface(p1, WriterScope) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(toReadChannel$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.s3q_1.q2c(this.t3q_1.vy(), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          return Unit_instance;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
protoOf(toReadChannel$slambda).a2n = function ($this$writer, completion) {
  var i = new toReadChannel$slambda(this.s3q_1, completion);
  i.t3q_1 = $this$writer;
  return i;
};
function toReadChannel$slambda_0($this_toReadChannel, resultContinuation) {
  var i = new toReadChannel$slambda($this_toReadChannel, resultContinuation);
  var l = function ($this$writer, $completion) {
    return i.z2m($this$writer, $completion);
  };
  l.$arity = 1;
  return l;
}
function $observeCOROUTINE$5(_this__u8e3s4, log, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.g3q_1 = _this__u8e3s4;
  this.h3q_1 = log;
}
protoOf($observeCOROUTINE$5).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          this.i3q_1 = this.g3q_1;
          var tmp_0 = this.i3q_1;
          if (tmp_0 instanceof ByteArrayContent) {
            this.ic_1 = 1;
            suspendResult = writeFully(this.h3q_1, this.g3q_1.l2c(), this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            var tmp_1 = this.i3q_1;
            if (tmp_1 instanceof ReadChannelContent) {
              var tmp_2 = this;
              var responseChannel = ByteChannel();
              var content = this.g3q_1.o2c();
              copyToBoth(content, this.h3q_1, responseChannel);
              tmp_2.j3q_1 = new LoggedContent(this.g3q_1, responseChannel);
              this.ic_1 = 2;
              continue $sm;
            } else {
              var tmp_3 = this.i3q_1;
              if (tmp_3 instanceof WriteChannelContent) {
                var tmp_4 = this;
                var responseChannel_0 = ByteChannel();
                var content_0 = toReadChannel(this.g3q_1);
                copyToBoth(content_0, this.h3q_1, responseChannel_0);
                tmp_4.j3q_1 = new LoggedContent(this.g3q_1, responseChannel_0);
                this.ic_1 = 2;
                continue $sm;
              } else {
                var tmp_5 = this;
                close(this.h3q_1);
                tmp_5.j3q_1 = this.g3q_1;
                this.ic_1 = 2;
                continue $sm;
              }
            }
          }

        case 1:
          close(this.h3q_1);
          this.j3q_1 = this.g3q_1;
          this.ic_1 = 2;
          continue $sm;
        case 2:
          return this.j3q_1;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function get_DEFAULT(_this__u8e3s4) {
  return get_SIMPLE(_this__u8e3s4);
}
//region block: init
Companion_instance = new Companion();
//endregion
//region block: exports
export {
  LogLevel_HEADERS_getInstance as LogLevel_HEADERS_getInstance2l5onq0kxun3t,
  LogLevel_NONE_getInstance as LogLevel_NONE_getInstance20dqm0srjwub0,
  Companion_getInstance_0 as Companion_getInstance1jrxni30zx3hj,
};
//endregion

//# sourceMappingURL=ktor-ktor-client-logging.mjs.map
