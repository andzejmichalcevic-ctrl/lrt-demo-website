type Nullable<T> = T | null | undefined
/** @deprecated  */
export declare const initHook: { get(): any; };
export declare const Analytics: {
    getInstance(): {
        initialize(configuration: JsAnalyticsConfiguration): void;
        track(eventName: string, properties?: any/* Map<string, any> */, context?: any/* Map<string, any> */): void;
        identify(userId: string, properties?: any/* Map<string, any> */, context?: any/* Map<string, any> */): void;
        screen(screenName: string, properties?: any/* Map<string, any> */, context?: any/* Map<string, any> */): void;
        lifecycle(lifecycleState: string, properties?: any/* Map<string, any> */, context?: any/* Map<string, any> */): void;
        flush(): void;
        optIn(): void;
        optOut(): void;
        reset(): void;
    };
};
export declare interface JsAnalyticsConfiguration {
    readonly writeKey: string;
    readonly endpoint: string;
    readonly appName: Nullable<string>;
    readonly appVersion: Nullable<string>;
    readonly appBuild: Nullable<string>;
    readonly flushIntervalSeconds: Nullable<number>;
    readonly flushQueueSize: Nullable<number>;
    readonly maxQueueSize: Nullable<number>;
    readonly maxBatchSize: Nullable<number>;
    readonly enableDebugLogging: Nullable<boolean>;
    readonly trackApplicationLifecycle: Nullable<boolean>;
    readonly collectAdvertisingId: Nullable<boolean>;
    readonly collectLocation: Nullable<boolean>;
    readonly enableEncryption: Nullable<boolean>;
    readonly __doNotUseOrImplementIt: {
        readonly "com.exacaster.analytics.JsAnalyticsConfiguration": unique symbol;
    };
}