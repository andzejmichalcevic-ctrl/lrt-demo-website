import {
  EmptySerializersModule991ju6pz9b79 as EmptySerializersModule,
  StringFormat2r2ka8mzcb3mi as StringFormat,
  Decoder23nde051s631g as Decoder,
  CompositeDecoder2tzm7wpwkr0og as CompositeDecoder,
  SerializerFactory1qv9hivitncuv as SerializerFactory,
  serializer1x79l67jvwntn as serializer,
  InlinePrimitiveDescriptor3i6ccn1a4fw94 as InlinePrimitiveDescriptor,
  SEALED_getInstance3nsev85ow9059 as SEALED_getInstance,
  buildSerialDescriptor2873qmkp8r2ib as buildSerialDescriptor,
  KSerializerzf77vz1967fq as KSerializer,
  MapSerializer11kmegt3g5c1g as MapSerializer,
  SerialDescriptor2pelqekb5ic3a as SerialDescriptor,
  STRING_getInstance2ou4lro9xn2qn as STRING_getInstance,
  ListSerializer1hxuk9dx5n9du as ListSerializer,
  ENUM_getInstance22lfbrqor0c0a as ENUM_getInstance,
  PrimitiveSerialDescriptor3egfp53lutxj2 as PrimitiveSerialDescriptor,
  serializer2lw83vwvpnyms as serializer_0,
  get_isNullable36pbikm8xb7bz as get_isNullable,
  get_isInline5x26qrhi9qs6 as get_isInline,
  get_annotationshjxdbdcl8kmv as get_annotations,
  Encoderqvmrpqtq8hnu as Encoder,
  CompositeEncoderknecpkexzn3v as CompositeEncoder,
  ElementMarker33ojvsajwmzts as ElementMarker,
  SerializationExceptioneqrdve3ts2n9 as SerializationException,
  SerializationException_init_$Init$2mbwpyyvgkydo as SerializationException_init_$Init$,
  Companion_instance2e54edlpusznp as Companion_instance,
  SerializationException_init_$Create$1byppqmdb64jn as SerializationException_init_$Create$,
  CLASS_getInstance14ex35co4jkrb as CLASS_getInstance,
  LIST_getInstancey7k5h8d5cvxt as LIST_getInstance,
  AbstractPolymorphicSerializer1ccxwp48nfy58 as AbstractPolymorphicSerializer,
  findPolymorphicSerializer1nm87hvemahcj as findPolymorphicSerializer,
  DeserializationStrategy1z3z5pj9f7zc8 as DeserializationStrategy,
  SealedClassSerializeriwipiibk55zc as SealedClassSerializer,
  jsonCachedSerialNameslxufy2gu43jt as jsonCachedSerialNames,
  ENUMlmq49cvwy4ow as ENUM,
  PrimitiveKindndgbuh6is7ze as PrimitiveKind,
  PolymorphicKindla9gurooefwb as PolymorphicKind,
  CONTEXTUAL_getInstance1845118lbzky0 as CONTEXTUAL_getInstance,
  MAP_getInstance3s1t6byguxmp9 as MAP_getInstance,
  contextual3hpp1gupsu4al as contextual,
  SerializersModuleCollector3dddz14wd7brg as SerializersModuleCollector,
  AbstractDecoder35guh02ubh2hm as AbstractDecoder,
  MissingFieldException24tqif29emcmi as MissingFieldException,
  AbstractEncoder2gxtu3xmy3f8j as AbstractEncoder,
  OBJECT_getInstance26229tfe4t547 as OBJECT_getInstance,
  findPolymorphicSerializerk638ixyjovk5 as findPolymorphicSerializer_0,
  SerializationStrategyh6ouydnm6hci as SerializationStrategy,
  serializer3ikrxnm8b29d6 as serializer_1,
  serializer36584sjyg5661 as serializer_2,
  serializer1q7c5q67ysppr as serializer_3,
  NamedValueDecoderzk26ztf92xbq as NamedValueDecoder,
  NamedValueEncoder1lca9edk1lf89 as NamedValueEncoder,
  getContextualDescriptor2n1gf3b895yb8 as getContextualDescriptor,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
import {
  protoOf180f3jzyo7rfj as protoOf,
  objectMeta213120oau977m as objectMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  classMetawt99a3kyl3us as classMeta,
  VOID7hggqo3abtya as VOID,
  toString1pkumu07cwy4m as toString,
  IllegalArgumentException_init_$Create$310sysrobvll9 as IllegalArgumentException_init_$Create$,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  equals2au1ep9vhcato as equals,
  Enum3alwj03lh1n41 as Enum,
  interfaceMeta1u1l5puptm1ve as interfaceMeta,
  StringBuilder_init_$Create$2mwec1027v00x as StringBuilder_init_$Create$,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  hashCodeq5arwsb9dgti as hashCode,
  joinToString1cxrrlmo0chqs as joinToString,
  Map140uvy3s5zad8 as Map,
  List3hktaavzmj137 as List,
  LazyThreadSafetyMode_PUBLICATION_getInstance2wcpeyiugdaea as LazyThreadSafetyMode_PUBLICATION_getInstance,
  lazy1261dae0bgscp as lazy,
  getKClassFromExpression3vpejubogshaw as getKClassFromExpression,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  NumberFormatException_init_$Create$kedeltz3bzwr as NumberFormatException_init_$Create$,
  IntCompanionObject_instance3tw56cgyd5vup as IntCompanionObject_instance,
  numberRangeToNumber25vse2rgp6rs8 as numberRangeToNumber,
  ClosedRangehokgr73im9z3 as ClosedRange,
  isInterface3d6p8outrmvmk as isInterface,
  contains2c50nlxg7en7o as contains,
  toDouble1kn912gjoizjp as toDouble,
  StringCompanionObject_instance3alxothmy382k as StringCompanionObject_instance,
  LinkedHashMap_init_$Create$1p3p95clvi93w as LinkedHashMap_init_$Create$,
  toLongOrNullutqivezb0wx1 as toLongOrNull,
  toULongOrNullojoyxi0i9tgj as toULongOrNull,
  ULong3f9k7s38t3rfp as ULong,
  Companion_getInstance1puqqwzccfvrg as Companion_getInstance,
  _ULong___get_data__impl__fggpzb1jl4xe0gulani as _ULong___get_data__impl__fggpzb,
  toDoubleOrNullkxwozihadygj as toDoubleOrNull,
  toBooleanStrictOrNull2j0md398tkvbj as toBooleanStrictOrNull,
  IllegalStateException_init_$Create$3ib9qa3pip8n4 as IllegalStateException_init_$Create$,
  lazy2hsh8ze7j6ikd as lazy_0,
  KProperty1ca4yb4wlo496 as KProperty1,
  getPropertyCallableRef1ajb9in178r5r as getPropertyCallableRef,
  toLongw1zpgk99d84b as toLong,
  _UInt___init__impl__l7qpdl1vpobek1e692 as _UInt___init__impl__l7qpdl,
  UInt__toString_impl_dbgl212oeqkp5cl059g as UInt__toString_impl_dbgl21,
  _ULong___init__impl__c78o9k2uqxdjm6b0lbg as _ULong___init__impl__c78o9k,
  ULong__toString_impl_f9au7k2b7ohj6omvcs4 as ULong__toString_impl_f9au7k,
  _UByte___init__impl__g9hnc415bxbmye0j11o as _UByte___init__impl__g9hnc4,
  UByte__toString_impl_v72jgd49yaowf0kue as UByte__toString_impl_v72jg,
  _UShort___init__impl__jigrne3h2nm35iaibum as _UShort___init__impl__jigrne,
  UShort__toString_impl_edaoee1aumkcln5sauo as UShort__toString_impl_edaoee,
  captureStack1fzi4aczwc4hg as captureStack,
  charSequenceSubSequence1iwpdba8s3jc7 as charSequenceSubSequence,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  coerceAtMost322komnqp70ag as coerceAtMost,
  ArrayList_init_$Create$2qnngtk1et9r9 as ArrayList_init_$Create$,
  singleOrNullrknfaxokm1sl as singleOrNull,
  emptyMapr06gerzljqtm as emptyMap,
  getValue48kllevslyh6 as getValue,
  fillArrayVali8eppxapiek4 as fillArrayVal,
  copyOf2ng0t8oizk6it as copyOf,
  copyOf3rutauicler23 as copyOf_0,
  DeepRecursiveFunction3r49v8igsve1g as DeepRecursiveFunction,
  invoke246lvi6tzooz1 as invoke,
  CoroutineImpl2sn3kjnwmfr10 as CoroutineImpl,
  DeepRecursiveScope1pqaydvh4vdcu as DeepRecursiveScope,
  Unitkvevlwgzwiuc as Unit,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  getKClass1s3j9wy1cofik as getKClass,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  substringBefore3n7kj60w69hju as substringBefore,
  removeSuffix3d61x5lsuvuho as removeSuffix,
  substringAfter1hku067gwr5ve as substringAfter,
  contains3ue2qo8xhmpf1 as contains_0,
  plus17rl43at52ays as plus,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  isFinite1tx0gn65nl9tj as isFinite,
  isFinite2t9l5a275mxm6 as isFinite_0,
  toUInt21lx0mz8wkp7c as toUInt,
  _UInt___get_data__impl__f0vqqw9xdox7iecbly as _UInt___get_data__impl__f0vqqw,
  toULong266mnyksbttkw as toULong,
  toUByteh6p4wmqswkrs as toUByte,
  _UByte___get_data__impl__jof9qrfj1ch8mjizvj as _UByte___get_data__impl__jof9qr,
  toUShort7yqspfnhrot4 as toUShort,
  _UShort___get_data__impl__g02459z5yfs6z0kj0 as _UShort___get_data__impl__g0245,
  objectCreate1ve4bgxiu4x98 as objectCreate,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  toString35i91qxh73cps as toString_0,
  Companion_getInstanceuedpedmz4g65 as Companion_getInstance_0,
  Companion_getInstance1trnkq9cty7vr as Companion_getInstance_1,
  Companion_getInstance2du03jiluw9jj as Companion_getInstance_2,
  setOf45ia9pnfhe90 as setOf,
  Char__toInt_impl_vasixd2xlaiz5u3itpv as Char__toInt_impl_vasixd,
  numberToChar93r9buh19yek as numberToChar,
  equals2v6cggk171b6e as equals_0,
  ByteCompanionObject_instance9rvhjp0l184i as ByteCompanionObject_instance,
  toByte4i43936u611k as toByte,
  ShortCompanionObject_instance3vq120mx8545m as ShortCompanionObject_instance,
  toShort36kaw0zjdq3ex as toShort,
  single29ec4rh52687r as single,
  Char19o2r8palgjof as Char,
  emptySetcxexqki71qfa as emptySet,
  plus1ogy4liedzq5j as plus_0,
  toInt2q8uldh7sc951 as toInt,
  toList3jhuyej2anx2q as toList,
  throwUninitializedPropertyAccessExceptionyynx7gkm73wd as throwUninitializedPropertyAccessException,
  enumEntries20mr21zbe3az4 as enumEntries,
  last1vo29oleiqj36 as last,
  removeLast3759euu1xvfa3 as removeLast,
  lastIndexOf2d52xhix5ymjr as lastIndexOf,
  Long2qws0ah9gnpki as Long,
  Char__minus_impl_a2frrhem8aw2sny2of as Char__minus_impl_a2frrh,
  Companion_getInstance3gn12jgnf4xoo as Companion_getInstance_3,
  numberToLong1a4cndvg6c52s as numberToLong,
  charArray2ujmm1qusno00 as charArray,
  indexOf1xbs558u7wr52 as indexOf,
  StringBuilder_init_$Create$23o1ixl6cos5l as StringBuilder_init_$Create$_0,
  HashMap_init_$Create$3k4af1a3fibv9 as HashMap_init_$Create$,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
setMetadataFor(Json, 'Json', classMeta, VOID, [StringFormat]);
setMetadataFor(Default, 'Default', objectMeta, Json);
setMetadataFor(JsonBuilder, 'JsonBuilder', classMeta);
setMetadataFor(JsonImpl, 'JsonImpl', classMeta, Json);
setMetadataFor(JsonClassDiscriminator, 'JsonClassDiscriminator', classMeta);
setMetadataFor(JsonNames, 'JsonNames', classMeta);
setMetadataFor(JsonConfiguration, 'JsonConfiguration', classMeta);
setMetadataFor(ClassDiscriminatorMode, 'ClassDiscriminatorMode', classMeta, Enum);
setMetadataFor(JsonDecoder, 'JsonDecoder', interfaceMeta, VOID, [Decoder, CompositeDecoder]);
setMetadataFor(Companion, 'Companion', objectMeta);
setMetadataFor(JsonElement, 'JsonElement', classMeta, VOID, VOID, VOID, VOID, {0: JsonElementSerializer_getInstance});
setMetadataFor(JsonObject, 'JsonObject', classMeta, JsonElement, [JsonElement, Map], VOID, VOID, {0: JsonObjectSerializer_getInstance});
setMetadataFor(Companion_0, 'Companion', objectMeta);
setMetadataFor(Companion_1, 'Companion', objectMeta);
setMetadataFor(JsonPrimitive, 'JsonPrimitive', classMeta, JsonElement, VOID, VOID, VOID, {0: JsonPrimitiveSerializer_getInstance});
setMetadataFor(Companion_2, 'Companion', objectMeta);
setMetadataFor(JsonArray, 'JsonArray', classMeta, JsonElement, [JsonElement, List], VOID, VOID, {0: JsonArraySerializer_getInstance});
setMetadataFor(JsonNull, 'JsonNull', objectMeta, JsonPrimitive, [JsonPrimitive, SerializerFactory], VOID, VOID, {0: JsonNull_getInstance});
setMetadataFor(JsonLiteral, 'JsonLiteral', classMeta, JsonPrimitive);
setMetadataFor(JsonObjectBuilder, 'JsonObjectBuilder', classMeta);
setMetadataFor(JsonElementSerializer, 'JsonElementSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(JsonObjectDescriptor, 'JsonObjectDescriptor', objectMeta, VOID, [SerialDescriptor]);
setMetadataFor(JsonObjectSerializer, 'JsonObjectSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(JsonPrimitiveSerializer, 'JsonPrimitiveSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(JsonArrayDescriptor, 'JsonArrayDescriptor', objectMeta, VOID, [SerialDescriptor]);
setMetadataFor(JsonArraySerializer, 'JsonArraySerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(JsonNullSerializer, 'JsonNullSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(JsonLiteralSerializer, 'JsonLiteralSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(defer$1, VOID, classMeta, VOID, [SerialDescriptor]);
setMetadataFor(JsonEncoder, 'JsonEncoder', interfaceMeta, VOID, [Encoder, CompositeEncoder]);
setMetadataFor(Composer, 'Composer', classMeta);
setMetadataFor(ComposerForUnsignedNumbers, 'ComposerForUnsignedNumbers', classMeta, Composer);
setMetadataFor(ComposerForUnquotedLiterals, 'ComposerForUnquotedLiterals', classMeta, Composer);
setMetadataFor(ComposerWithPrettyPrint, 'ComposerWithPrettyPrint', classMeta, Composer);
setMetadataFor(JsonElementMarker, 'JsonElementMarker', classMeta);
setMetadataFor(JsonException, 'JsonException', classMeta, SerializationException);
setMetadataFor(JsonEncodingException, 'JsonEncodingException', classMeta, JsonException);
setMetadataFor(JsonDecodingException, 'JsonDecodingException', classMeta, JsonException);
setMetadataFor(Tombstone, 'Tombstone', objectMeta);
setMetadataFor(JsonPath, 'JsonPath', classMeta, VOID, VOID, JsonPath);
setMetadataFor(JsonTreeReader$readDeepRecursive$slambda, 'JsonTreeReader$readDeepRecursive$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [2]);
setMetadataFor($readObjectCOROUTINE$0, '$readObjectCOROUTINE$0', classMeta, CoroutineImpl);
setMetadataFor(JsonTreeReader, 'JsonTreeReader', classMeta, VOID, VOID, VOID, VOID, VOID, [0]);
setMetadataFor(PolymorphismValidator, 'PolymorphismValidator', classMeta, VOID, [SerializersModuleCollector]);
setMetadataFor(Key, 'Key', classMeta, VOID, VOID, Key);
setMetadataFor(DescriptorSchemaCache, 'DescriptorSchemaCache', classMeta, VOID, VOID, DescriptorSchemaCache);
setMetadataFor(DiscriminatorHolder, 'DiscriminatorHolder', classMeta);
setMetadataFor(StreamingJsonDecoder, 'StreamingJsonDecoder', classMeta, AbstractDecoder, [JsonDecoder, AbstractDecoder]);
setMetadataFor(JsonDecoderForUnsignedTypes, 'JsonDecoderForUnsignedTypes', classMeta, AbstractDecoder);
setMetadataFor(StreamingJsonEncoder, 'StreamingJsonEncoder', classMeta, AbstractEncoder, [JsonEncoder, AbstractEncoder]);
setMetadataFor(AbstractJsonTreeDecoder, 'AbstractJsonTreeDecoder', classMeta, NamedValueDecoder, [NamedValueDecoder, JsonDecoder]);
setMetadataFor(JsonTreeDecoder, 'JsonTreeDecoder', classMeta, AbstractJsonTreeDecoder);
setMetadataFor(JsonTreeListDecoder, 'JsonTreeListDecoder', classMeta, AbstractJsonTreeDecoder);
setMetadataFor(JsonPrimitiveDecoder, 'JsonPrimitiveDecoder', classMeta, AbstractJsonTreeDecoder);
setMetadataFor(JsonTreeMapDecoder, 'JsonTreeMapDecoder', classMeta, JsonTreeDecoder);
setMetadataFor(AbstractJsonTreeEncoder, 'AbstractJsonTreeEncoder', classMeta, NamedValueEncoder, [NamedValueEncoder, JsonEncoder]);
setMetadataFor(JsonTreeEncoder, 'JsonTreeEncoder', classMeta, AbstractJsonTreeEncoder);
setMetadataFor(AbstractJsonTreeEncoder$inlineUnsignedNumberEncoder$1, VOID, classMeta, AbstractEncoder);
setMetadataFor(AbstractJsonTreeEncoder$inlineUnquotedLiteralEncoder$1, VOID, classMeta, AbstractEncoder);
setMetadataFor(JsonPrimitiveEncoder, 'JsonPrimitiveEncoder', classMeta, AbstractJsonTreeEncoder);
setMetadataFor(JsonTreeListEncoder, 'JsonTreeListEncoder', classMeta, AbstractJsonTreeEncoder);
setMetadataFor(JsonTreeMapEncoder, 'JsonTreeMapEncoder', classMeta, JsonTreeEncoder);
setMetadataFor(WriteMode, 'WriteMode', classMeta, Enum);
setMetadataFor(AbstractJsonLexer, 'AbstractJsonLexer', classMeta);
setMetadataFor(CharMappings, 'CharMappings', objectMeta);
setMetadataFor(StringJsonLexer, 'StringJsonLexer', classMeta, AbstractJsonLexer);
setMetadataFor(JsonToStringWriter, 'JsonToStringWriter', classMeta, VOID, VOID, JsonToStringWriter);
//endregion
function Default() {
  Default_instance = this;
  Json.call(this, new JsonConfiguration(), EmptySerializersModule());
}
var Default_instance;
function Default_getInstance() {
  if (Default_instance == null)
    new Default();
  return Default_instance;
}
function Json(configuration, serializersModule) {
  Default_getInstance();
  this.s4g_1 = configuration;
  this.t4g_1 = serializersModule;
  this.u4g_1 = new DescriptorSchemaCache();
}
protoOf(Json).k3r = function () {
  return this.t4g_1;
};
protoOf(Json).g3s = function (serializer, value) {
  var result = new JsonToStringWriter();
  try {
    encodeByWriter(this, result, serializer, value);
    return result.toString();
  }finally {
    result.mu();
  }
};
protoOf(Json).h3s = function (deserializer, string) {
  var lexer = new StringJsonLexer(string);
  var input = new StreamingJsonDecoder(this, WriteMode_OBJ_getInstance(), lexer, deserializer.z3q(), null);
  var result = input.o3r(deserializer);
  lexer.k4h();
  return result;
};
protoOf(Json).v4g = function (serializer, value) {
  return writeJson(this, value, serializer);
};
protoOf(Json).w4g = function (string) {
  return this.h3s(JsonElementSerializer_getInstance(), string);
};
function Json_0(from, builderAction) {
  from = from === VOID ? Default_getInstance() : from;
  var builder = new JsonBuilder(from);
  builderAction(builder);
  var conf = builder.l1i();
  return new JsonImpl(conf, builder.b4i_1);
}
function JsonBuilder(json) {
  this.l4h_1 = json.s4g_1.c4i_1;
  this.m4h_1 = json.s4g_1.h4i_1;
  this.n4h_1 = json.s4g_1.d4i_1;
  this.o4h_1 = json.s4g_1.e4i_1;
  this.p4h_1 = json.s4g_1.f4i_1;
  this.q4h_1 = json.s4g_1.g4i_1;
  this.r4h_1 = json.s4g_1.i4i_1;
  this.s4h_1 = json.s4g_1.j4i_1;
  this.t4h_1 = json.s4g_1.k4i_1;
  this.u4h_1 = json.s4g_1.l4i_1;
  this.v4h_1 = json.s4g_1.r4i_1;
  this.w4h_1 = json.s4g_1.m4i_1;
  this.x4h_1 = json.s4g_1.n4i_1;
  this.y4h_1 = json.s4g_1.o4i_1;
  this.z4h_1 = json.s4g_1.p4i_1;
  this.a4i_1 = json.s4g_1.q4i_1;
  this.b4i_1 = json.k3r();
}
protoOf(JsonBuilder).l1i = function () {
  if (this.t4h_1) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.contracts.contract' call
    if (!(this.u4h_1 === 'type')) {
      // Inline function 'kotlinx.serialization.json.JsonBuilder.build.<anonymous>' call
      var message = 'Class discriminator should not be specified when array polymorphism is specified';
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.contracts.contract' call
    if (!this.v4h_1.equals(ClassDiscriminatorMode_POLYMORPHIC_getInstance())) {
      // Inline function 'kotlinx.serialization.json.JsonBuilder.build.<anonymous>' call
      var message_0 = 'useArrayPolymorphism option can only be used if classDiscriminatorMode in a default POLYMORPHIC state.';
      throw IllegalArgumentException_init_$Create$(toString(message_0));
    }
  }
  if (!this.q4h_1) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.contracts.contract' call
    if (!(this.r4h_1 === '    ')) {
      // Inline function 'kotlinx.serialization.json.JsonBuilder.build.<anonymous>' call
      var message_1 = 'Indent should not be specified when default printing mode is used';
      throw IllegalArgumentException_init_$Create$(toString(message_1));
    }
  } else if (!(this.r4h_1 === '    ')) {
    var tmp$ret$4;
    $l$block: {
      // Inline function 'kotlin.text.all' call
      var indexedObject = this.r4h_1;
      var inductionVariable = 0;
      while (inductionVariable < charSequenceLength(indexedObject)) {
        var element = charSequenceGet(indexedObject, inductionVariable);
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlinx.serialization.json.JsonBuilder.build.<anonymous>' call
        if (!(((element === _Char___init__impl__6a9atx(32) ? true : element === _Char___init__impl__6a9atx(9)) ? true : element === _Char___init__impl__6a9atx(13)) ? true : element === _Char___init__impl__6a9atx(10))) {
          tmp$ret$4 = false;
          break $l$block;
        }
      }
      tmp$ret$4 = true;
    }
    var allWhitespaces = tmp$ret$4;
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.contracts.contract' call
    if (!allWhitespaces) {
      // Inline function 'kotlinx.serialization.json.JsonBuilder.build.<anonymous>' call
      var message_2 = 'Only whitespace, tab, newline and carriage return are allowed as pretty print symbols. Had ' + this.r4h_1;
      throw IllegalArgumentException_init_$Create$(toString(message_2));
    }
  }
  return new JsonConfiguration(this.l4h_1, this.n4h_1, this.o4h_1, this.p4h_1, this.q4h_1, this.m4h_1, this.r4h_1, this.s4h_1, this.t4h_1, this.u4h_1, this.w4h_1, this.x4h_1, this.y4h_1, this.z4h_1, this.a4i_1, this.v4h_1);
};
function validateConfiguration($this) {
  if (equals($this.k3r(), EmptySerializersModule()))
    return Unit_instance;
  var collector = new PolymorphismValidator($this.s4g_1.k4i_1, $this.s4g_1.l4i_1);
  $this.k3r().g4b(collector);
}
function JsonImpl(configuration, module_0) {
  Json.call(this, configuration, module_0);
  validateConfiguration(this);
}
function JsonClassDiscriminator() {
}
function JsonNames() {
}
function JsonConfiguration(encodeDefaults, ignoreUnknownKeys, isLenient, allowStructuredMapKeys, prettyPrint, explicitNulls, prettyPrintIndent, coerceInputValues, useArrayPolymorphism, classDiscriminator, allowSpecialFloatingPointValues, useAlternativeNames, namingStrategy, decodeEnumsCaseInsensitive, allowTrailingComma, classDiscriminatorMode) {
  encodeDefaults = encodeDefaults === VOID ? false : encodeDefaults;
  ignoreUnknownKeys = ignoreUnknownKeys === VOID ? false : ignoreUnknownKeys;
  isLenient = isLenient === VOID ? false : isLenient;
  allowStructuredMapKeys = allowStructuredMapKeys === VOID ? false : allowStructuredMapKeys;
  prettyPrint = prettyPrint === VOID ? false : prettyPrint;
  explicitNulls = explicitNulls === VOID ? true : explicitNulls;
  prettyPrintIndent = prettyPrintIndent === VOID ? '    ' : prettyPrintIndent;
  coerceInputValues = coerceInputValues === VOID ? false : coerceInputValues;
  useArrayPolymorphism = useArrayPolymorphism === VOID ? false : useArrayPolymorphism;
  classDiscriminator = classDiscriminator === VOID ? 'type' : classDiscriminator;
  allowSpecialFloatingPointValues = allowSpecialFloatingPointValues === VOID ? false : allowSpecialFloatingPointValues;
  useAlternativeNames = useAlternativeNames === VOID ? true : useAlternativeNames;
  namingStrategy = namingStrategy === VOID ? null : namingStrategy;
  decodeEnumsCaseInsensitive = decodeEnumsCaseInsensitive === VOID ? false : decodeEnumsCaseInsensitive;
  allowTrailingComma = allowTrailingComma === VOID ? false : allowTrailingComma;
  classDiscriminatorMode = classDiscriminatorMode === VOID ? ClassDiscriminatorMode_POLYMORPHIC_getInstance() : classDiscriminatorMode;
  this.c4i_1 = encodeDefaults;
  this.d4i_1 = ignoreUnknownKeys;
  this.e4i_1 = isLenient;
  this.f4i_1 = allowStructuredMapKeys;
  this.g4i_1 = prettyPrint;
  this.h4i_1 = explicitNulls;
  this.i4i_1 = prettyPrintIndent;
  this.j4i_1 = coerceInputValues;
  this.k4i_1 = useArrayPolymorphism;
  this.l4i_1 = classDiscriminator;
  this.m4i_1 = allowSpecialFloatingPointValues;
  this.n4i_1 = useAlternativeNames;
  this.o4i_1 = namingStrategy;
  this.p4i_1 = decodeEnumsCaseInsensitive;
  this.q4i_1 = allowTrailingComma;
  this.r4i_1 = classDiscriminatorMode;
}
protoOf(JsonConfiguration).toString = function () {
  return 'JsonConfiguration(encodeDefaults=' + this.c4i_1 + ', ignoreUnknownKeys=' + this.d4i_1 + ', isLenient=' + this.e4i_1 + ', ' + ('allowStructuredMapKeys=' + this.f4i_1 + ', prettyPrint=' + this.g4i_1 + ', explicitNulls=' + this.h4i_1 + ', ') + ("prettyPrintIndent='" + this.i4i_1 + "', coerceInputValues=" + this.j4i_1 + ', useArrayPolymorphism=' + this.k4i_1 + ', ') + ("classDiscriminator='" + this.l4i_1 + "', allowSpecialFloatingPointValues=" + this.m4i_1 + ', ') + ('useAlternativeNames=' + this.n4i_1 + ', namingStrategy=' + this.o4i_1 + ', decodeEnumsCaseInsensitive=' + this.p4i_1 + ', ') + ('allowTrailingComma=' + this.q4i_1 + ', classDiscriminatorMode=' + this.r4i_1 + ')');
};
var ClassDiscriminatorMode_NONE_instance;
var ClassDiscriminatorMode_ALL_JSON_OBJECTS_instance;
var ClassDiscriminatorMode_POLYMORPHIC_instance;
var ClassDiscriminatorMode_entriesInitialized;
function ClassDiscriminatorMode_initEntries() {
  if (ClassDiscriminatorMode_entriesInitialized)
    return Unit_instance;
  ClassDiscriminatorMode_entriesInitialized = true;
  ClassDiscriminatorMode_NONE_instance = new ClassDiscriminatorMode('NONE', 0);
  ClassDiscriminatorMode_ALL_JSON_OBJECTS_instance = new ClassDiscriminatorMode('ALL_JSON_OBJECTS', 1);
  ClassDiscriminatorMode_POLYMORPHIC_instance = new ClassDiscriminatorMode('POLYMORPHIC', 2);
}
function ClassDiscriminatorMode(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function ClassDiscriminatorMode_NONE_getInstance() {
  ClassDiscriminatorMode_initEntries();
  return ClassDiscriminatorMode_NONE_instance;
}
function ClassDiscriminatorMode_POLYMORPHIC_getInstance() {
  ClassDiscriminatorMode_initEntries();
  return ClassDiscriminatorMode_POLYMORPHIC_instance;
}
function JsonDecoder() {
}
function get_jsonUnquotedLiteralDescriptor() {
  _init_properties_JsonElement_kt__7cbdc2();
  return jsonUnquotedLiteralDescriptor;
}
var jsonUnquotedLiteralDescriptor;
function Companion() {
}
protoOf(Companion).u4i = function () {
  return JsonObjectSerializer_getInstance();
};
var Companion_instance_0;
function Companion_getInstance_4() {
  return Companion_instance_0;
}
function JsonObject$toString$lambda(_name_for_destructuring_parameter_0__wldtmu) {
  // Inline function 'kotlin.collections.component1' call
  var k = _name_for_destructuring_parameter_0__wldtmu.k2();
  // Inline function 'kotlin.collections.component2' call
  var v = _name_for_destructuring_parameter_0__wldtmu.l2();
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder_init_$Create$();
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.serialization.json.JsonObject.toString.<anonymous>.<anonymous>' call
  printQuoted(this_0, k);
  this_0.o5(_Char___init__impl__6a9atx(58));
  this_0.m5(v);
  return this_0.toString();
}
function JsonObject(content) {
  JsonElement.call(this);
  this.v4i_1 = content;
}
protoOf(JsonObject).h2 = function () {
  return this.v4i_1.h2();
};
protoOf(JsonObject).f2 = function () {
  return this.v4i_1.f2();
};
protoOf(JsonObject).n = function () {
  return this.v4i_1.n();
};
protoOf(JsonObject).g2 = function () {
  return this.v4i_1.g2();
};
protoOf(JsonObject).k1w = function (key) {
  return this.v4i_1.p2(key);
};
protoOf(JsonObject).p2 = function (key) {
  if (!(!(key == null) ? typeof key === 'string' : false))
    return false;
  return this.k1w((!(key == null) ? typeof key === 'string' : false) ? key : THROW_CCE());
};
protoOf(JsonObject).l1w = function (key) {
  return this.v4i_1.s2(key);
};
protoOf(JsonObject).s2 = function (key) {
  if (!(!(key == null) ? typeof key === 'string' : false))
    return null;
  return this.l1w((!(key == null) ? typeof key === 'string' : false) ? key : THROW_CCE());
};
protoOf(JsonObject).b1 = function () {
  return this.v4i_1.b1();
};
protoOf(JsonObject).equals = function (other) {
  return equals(this.v4i_1, other);
};
protoOf(JsonObject).hashCode = function () {
  return hashCode(this.v4i_1);
};
protoOf(JsonObject).toString = function () {
  var tmp = this.v4i_1.h2();
  return joinToString(tmp, ',', '{', '}', VOID, VOID, JsonObject$toString$lambda);
};
function Companion_0() {
}
var Companion_instance_1;
function Companion_getInstance_5() {
  return Companion_instance_1;
}
function JsonElement() {
}
function Companion_1() {
}
var Companion_instance_2;
function Companion_getInstance_6() {
  return Companion_instance_2;
}
function JsonPrimitive() {
  JsonElement.call(this);
}
protoOf(JsonPrimitive).toString = function () {
  return this.e2l();
};
function JsonPrimitive_0(value) {
  _init_properties_JsonElement_kt__7cbdc2();
  if (value == null)
    return JsonNull_getInstance();
  return new JsonLiteral(value, true);
}
function JsonPrimitive_1(value) {
  _init_properties_JsonElement_kt__7cbdc2();
  if (value == null)
    return JsonNull_getInstance();
  return new JsonLiteral(value, false);
}
function JsonPrimitive_2(value) {
  _init_properties_JsonElement_kt__7cbdc2();
  if (value == null)
    return JsonNull_getInstance();
  return new JsonLiteral(value, false);
}
function Companion_2() {
}
var Companion_instance_3;
function Companion_getInstance_7() {
  return Companion_instance_3;
}
function JsonArray(content) {
  JsonElement.call(this);
  this.x4i_1 = content;
}
protoOf(JsonArray).n = function () {
  return this.x4i_1.n();
};
protoOf(JsonArray).y4i = function (element) {
  return this.x4i_1.z(element);
};
protoOf(JsonArray).z = function (element) {
  if (!(element instanceof JsonElement))
    return false;
  return this.y4i(element instanceof JsonElement ? element : THROW_CCE());
};
protoOf(JsonArray).z4i = function (elements) {
  return this.x4i_1.a1(elements);
};
protoOf(JsonArray).a1 = function (elements) {
  return this.z4i(elements);
};
protoOf(JsonArray).f1 = function (index) {
  return this.x4i_1.f1(index);
};
protoOf(JsonArray).a4j = function (element) {
  return this.x4i_1.t1(element);
};
protoOf(JsonArray).t1 = function (element) {
  if (!(element instanceof JsonElement))
    return -1;
  return this.a4j(element instanceof JsonElement ? element : THROW_CCE());
};
protoOf(JsonArray).b1 = function () {
  return this.x4i_1.b1();
};
protoOf(JsonArray).u = function () {
  return this.x4i_1.u();
};
protoOf(JsonArray).v1 = function (fromIndex, toIndex) {
  return this.x4i_1.v1(fromIndex, toIndex);
};
protoOf(JsonArray).equals = function (other) {
  return equals(this.x4i_1, other);
};
protoOf(JsonArray).hashCode = function () {
  return hashCode(this.x4i_1);
};
protoOf(JsonArray).toString = function () {
  return joinToString(this.x4i_1, ',', '[', ']');
};
function _get_$cachedSerializer__te6jhj($this) {
  return $this.c4j_1.l2();
}
function JsonNull$_anonymous__enib48() {
  return JsonNullSerializer_getInstance();
}
function JsonNull() {
  JsonNull_instance = this;
  JsonPrimitive.call(this);
  this.b4j_1 = 'null';
  var tmp = this;
  var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
  tmp.c4j_1 = lazy(tmp_0, JsonNull$_anonymous__enib48);
}
protoOf(JsonNull).w4i = function () {
  return false;
};
protoOf(JsonNull).e2l = function () {
  return this.b4j_1;
};
protoOf(JsonNull).u4i = function () {
  return _get_$cachedSerializer__te6jhj(this);
};
protoOf(JsonNull).w42 = function (typeParamsSerializers) {
  return this.u4i();
};
var JsonNull_instance;
function JsonNull_getInstance() {
  if (JsonNull_instance == null)
    new JsonNull();
  return JsonNull_instance;
}
function JsonLiteral(body, isString, coerceToInlineType) {
  coerceToInlineType = coerceToInlineType === VOID ? null : coerceToInlineType;
  JsonPrimitive.call(this);
  this.d4j_1 = isString;
  this.e4j_1 = coerceToInlineType;
  this.f4j_1 = toString(body);
  if (!(this.e4j_1 == null)) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.contracts.contract' call
    if (!this.e4j_1.t3s()) {
      // Inline function 'kotlin.require.<anonymous>' call
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
  }
}
protoOf(JsonLiteral).w4i = function () {
  return this.d4j_1;
};
protoOf(JsonLiteral).e2l = function () {
  return this.f4j_1;
};
protoOf(JsonLiteral).toString = function () {
  var tmp;
  if (this.d4j_1) {
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder_init_$Create$();
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.serialization.json.JsonLiteral.toString.<anonymous>' call
    printQuoted(this_0, this.f4j_1);
    tmp = this_0.toString();
  } else {
    tmp = this.f4j_1;
  }
  return tmp;
};
protoOf(JsonLiteral).equals = function (other) {
  if (this === other)
    return true;
  if (other == null ? true : !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
    return false;
  if (!(other instanceof JsonLiteral))
    THROW_CCE();
  if (!(this.d4j_1 === other.d4j_1))
    return false;
  if (!(this.f4j_1 === other.f4j_1))
    return false;
  return true;
};
protoOf(JsonLiteral).hashCode = function () {
  var result = getBooleanHashCode(this.d4j_1);
  result = imul(31, result) + getStringHashCode(this.f4j_1) | 0;
  return result;
};
function get_booleanOrNull(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  return toBooleanStrictOrNull_0(_this__u8e3s4.e2l());
}
function get_int(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  // Inline function 'kotlinx.serialization.json.mapExceptions' call
  var tmp;
  try {
    // Inline function 'kotlinx.serialization.json.<get-int>.<anonymous>' call
    tmp = (new StringJsonLexer(_this__u8e3s4.e2l())).g4j();
  } catch ($p) {
    var tmp_0;
    if ($p instanceof JsonDecodingException) {
      var e = $p;
      throw NumberFormatException_init_$Create$(e.message);
    } else {
      throw $p;
    }
  }
  var result = tmp;
  // Inline function 'kotlin.ranges.contains' call
  var this_0 = numberRangeToNumber(IntCompanionObject_instance.MIN_VALUE, IntCompanionObject_instance.MAX_VALUE);
  if (!contains(isInterface(this_0, ClosedRange) ? this_0 : THROW_CCE(), result))
    throw NumberFormatException_init_$Create$(_this__u8e3s4.e2l() + ' is not an Int');
  return result.ra();
}
function get_long(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  // Inline function 'kotlinx.serialization.json.mapExceptions' call
  var tmp;
  try {
    // Inline function 'kotlinx.serialization.json.<get-long>.<anonymous>' call
    tmp = (new StringJsonLexer(_this__u8e3s4.e2l())).g4j();
  } catch ($p) {
    var tmp_0;
    if ($p instanceof JsonDecodingException) {
      var e = $p;
      throw NumberFormatException_init_$Create$(e.message);
    } else {
      throw $p;
    }
  }
  return tmp;
}
function get_float(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  // Inline function 'kotlin.text.toFloat' call
  var this_0 = _this__u8e3s4.e2l();
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return toDouble(this_0);
}
function get_double(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  return toDouble(_this__u8e3s4.e2l());
}
function get_contentOrNull(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  var tmp;
  if (_this__u8e3s4 instanceof JsonNull) {
    tmp = null;
  } else {
    tmp = _this__u8e3s4.e2l();
  }
  return tmp;
}
function get_jsonPrimitive(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  var tmp0_elvis_lhs = _this__u8e3s4 instanceof JsonPrimitive ? _this__u8e3s4 : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    error(_this__u8e3s4, 'JsonPrimitive');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function error(_this__u8e3s4, element) {
  _init_properties_JsonElement_kt__7cbdc2();
  throw IllegalArgumentException_init_$Create$('Element ' + getKClassFromExpression(_this__u8e3s4) + ' is not a ' + element);
}
var properties_initialized_JsonElement_kt_abxy8s;
function _init_properties_JsonElement_kt__7cbdc2() {
  if (!properties_initialized_JsonElement_kt_abxy8s) {
    properties_initialized_JsonElement_kt_abxy8s = true;
    jsonUnquotedLiteralDescriptor = InlinePrimitiveDescriptor('kotlinx.serialization.json.JsonUnquotedLiteral', serializer(StringCompanionObject_instance));
  }
}
function JsonObjectBuilder() {
  var tmp = this;
  // Inline function 'kotlin.collections.linkedMapOf' call
  tmp.h4j_1 = LinkedHashMap_init_$Create$();
}
protoOf(JsonObjectBuilder).i4j = function (key, element) {
  return this.h4j_1.i2(key, element);
};
protoOf(JsonObjectBuilder).l1i = function () {
  return new JsonObject(this.h4j_1);
};
function JsonElementSerializer$descriptor$lambda($this$buildSerialDescriptor) {
  $this$buildSerialDescriptor.p3r('JsonPrimitive', defer(JsonElementSerializer$descriptor$lambda$lambda));
  $this$buildSerialDescriptor.p3r('JsonNull', defer(JsonElementSerializer$descriptor$lambda$lambda_0));
  $this$buildSerialDescriptor.p3r('JsonLiteral', defer(JsonElementSerializer$descriptor$lambda$lambda_1));
  $this$buildSerialDescriptor.p3r('JsonObject', defer(JsonElementSerializer$descriptor$lambda$lambda_2));
  $this$buildSerialDescriptor.p3r('JsonArray', defer(JsonElementSerializer$descriptor$lambda$lambda_3));
  return Unit_instance;
}
function JsonElementSerializer$descriptor$lambda$lambda() {
  return JsonPrimitiveSerializer_getInstance().j4j_1;
}
function JsonElementSerializer$descriptor$lambda$lambda_0() {
  return JsonNullSerializer_getInstance().k4j_1;
}
function JsonElementSerializer$descriptor$lambda$lambda_1() {
  return JsonLiteralSerializer_getInstance().l4j_1;
}
function JsonElementSerializer$descriptor$lambda$lambda_2() {
  return JsonObjectSerializer_getInstance().m4j_1;
}
function JsonElementSerializer$descriptor$lambda$lambda_3() {
  return JsonArraySerializer_getInstance().n4j_1;
}
function JsonElementSerializer() {
  JsonElementSerializer_instance = this;
  var tmp = this;
  var tmp_0 = SEALED_getInstance();
  tmp.o4j_1 = buildSerialDescriptor('kotlinx.serialization.json.JsonElement', tmp_0, [], JsonElementSerializer$descriptor$lambda);
}
protoOf(JsonElementSerializer).z3q = function () {
  return this.o4j_1;
};
protoOf(JsonElementSerializer).p4j = function (encoder, value) {
  verify(encoder);
  if (value instanceof JsonPrimitive) {
    encoder.l3r(JsonPrimitiveSerializer_getInstance(), value);
  } else {
    if (value instanceof JsonObject) {
      encoder.l3r(JsonObjectSerializer_getInstance(), value);
    } else {
      if (value instanceof JsonArray) {
        encoder.l3r(JsonArraySerializer_getInstance(), value);
      }
    }
  }
};
protoOf(JsonElementSerializer).m3r = function (encoder, value) {
  return this.p4j(encoder, value instanceof JsonElement ? value : THROW_CCE());
};
protoOf(JsonElementSerializer).n3r = function (decoder) {
  var input = asJsonDecoder(decoder);
  return input.t4i();
};
var JsonElementSerializer_instance;
function JsonElementSerializer_getInstance() {
  if (JsonElementSerializer_instance == null)
    new JsonElementSerializer();
  return JsonElementSerializer_instance;
}
function JsonObjectDescriptor() {
  JsonObjectDescriptor_instance = this;
  this.q4j_1 = MapSerializer(serializer(StringCompanionObject_instance), JsonElementSerializer_getInstance()).z3q();
  this.r4j_1 = 'kotlinx.serialization.json.JsonObject';
}
protoOf(JsonObjectDescriptor).a3r = function () {
  return this.q4j_1.a3r();
};
protoOf(JsonObjectDescriptor).s3s = function () {
  return this.q4j_1.s3s();
};
protoOf(JsonObjectDescriptor).t3s = function () {
  return this.q4j_1.t3s();
};
protoOf(JsonObjectDescriptor).o3s = function () {
  return this.q4j_1.o3s();
};
protoOf(JsonObjectDescriptor).u3s = function () {
  return this.q4j_1.u3s();
};
protoOf(JsonObjectDescriptor).v3s = function (index) {
  return this.q4j_1.v3s(index);
};
protoOf(JsonObjectDescriptor).w3s = function (index) {
  return this.q4j_1.w3s(index);
};
protoOf(JsonObjectDescriptor).x3s = function (name) {
  return this.q4j_1.x3s(name);
};
protoOf(JsonObjectDescriptor).y3s = function (index) {
  return this.q4j_1.y3s(index);
};
protoOf(JsonObjectDescriptor).z3s = function (index) {
  return this.q4j_1.z3s(index);
};
protoOf(JsonObjectDescriptor).e3s = function () {
  return this.r4j_1;
};
var JsonObjectDescriptor_instance;
function JsonObjectDescriptor_getInstance() {
  if (JsonObjectDescriptor_instance == null)
    new JsonObjectDescriptor();
  return JsonObjectDescriptor_instance;
}
function JsonObjectSerializer() {
  JsonObjectSerializer_instance = this;
  this.m4j_1 = JsonObjectDescriptor_getInstance();
}
protoOf(JsonObjectSerializer).z3q = function () {
  return this.m4j_1;
};
protoOf(JsonObjectSerializer).s4j = function (encoder, value) {
  verify(encoder);
  MapSerializer(serializer(StringCompanionObject_instance), JsonElementSerializer_getInstance()).m3r(encoder, value);
};
protoOf(JsonObjectSerializer).m3r = function (encoder, value) {
  return this.s4j(encoder, value instanceof JsonObject ? value : THROW_CCE());
};
protoOf(JsonObjectSerializer).n3r = function (decoder) {
  verify_0(decoder);
  return new JsonObject(MapSerializer(serializer(StringCompanionObject_instance), JsonElementSerializer_getInstance()).n3r(decoder));
};
var JsonObjectSerializer_instance;
function JsonObjectSerializer_getInstance() {
  if (JsonObjectSerializer_instance == null)
    new JsonObjectSerializer();
  return JsonObjectSerializer_instance;
}
function JsonPrimitiveSerializer() {
  JsonPrimitiveSerializer_instance = this;
  this.j4j_1 = buildSerialDescriptor('kotlinx.serialization.json.JsonPrimitive', STRING_getInstance(), []);
}
protoOf(JsonPrimitiveSerializer).z3q = function () {
  return this.j4j_1;
};
protoOf(JsonPrimitiveSerializer).t4j = function (encoder, value) {
  verify(encoder);
  var tmp;
  if (value instanceof JsonNull) {
    encoder.l3r(JsonNullSerializer_getInstance(), JsonNull_getInstance());
    tmp = Unit_instance;
  } else {
    var tmp_0 = JsonLiteralSerializer_getInstance();
    encoder.l3r(tmp_0, value instanceof JsonLiteral ? value : THROW_CCE());
    tmp = Unit_instance;
  }
  return tmp;
};
protoOf(JsonPrimitiveSerializer).m3r = function (encoder, value) {
  return this.t4j(encoder, value instanceof JsonPrimitive ? value : THROW_CCE());
};
protoOf(JsonPrimitiveSerializer).n3r = function (decoder) {
  var result = asJsonDecoder(decoder).t4i();
  if (!(result instanceof JsonPrimitive))
    throw JsonDecodingException_0(-1, 'Unexpected JSON element, expected JsonPrimitive, had ' + getKClassFromExpression(result), toString(result));
  return result;
};
var JsonPrimitiveSerializer_instance;
function JsonPrimitiveSerializer_getInstance() {
  if (JsonPrimitiveSerializer_instance == null)
    new JsonPrimitiveSerializer();
  return JsonPrimitiveSerializer_instance;
}
function JsonArrayDescriptor() {
  JsonArrayDescriptor_instance = this;
  this.u4j_1 = ListSerializer(JsonElementSerializer_getInstance()).z3q();
  this.v4j_1 = 'kotlinx.serialization.json.JsonArray';
}
protoOf(JsonArrayDescriptor).a3r = function () {
  return this.u4j_1.a3r();
};
protoOf(JsonArrayDescriptor).s3s = function () {
  return this.u4j_1.s3s();
};
protoOf(JsonArrayDescriptor).t3s = function () {
  return this.u4j_1.t3s();
};
protoOf(JsonArrayDescriptor).o3s = function () {
  return this.u4j_1.o3s();
};
protoOf(JsonArrayDescriptor).u3s = function () {
  return this.u4j_1.u3s();
};
protoOf(JsonArrayDescriptor).v3s = function (index) {
  return this.u4j_1.v3s(index);
};
protoOf(JsonArrayDescriptor).w3s = function (index) {
  return this.u4j_1.w3s(index);
};
protoOf(JsonArrayDescriptor).x3s = function (name) {
  return this.u4j_1.x3s(name);
};
protoOf(JsonArrayDescriptor).y3s = function (index) {
  return this.u4j_1.y3s(index);
};
protoOf(JsonArrayDescriptor).z3s = function (index) {
  return this.u4j_1.z3s(index);
};
protoOf(JsonArrayDescriptor).e3s = function () {
  return this.v4j_1;
};
var JsonArrayDescriptor_instance;
function JsonArrayDescriptor_getInstance() {
  if (JsonArrayDescriptor_instance == null)
    new JsonArrayDescriptor();
  return JsonArrayDescriptor_instance;
}
function JsonArraySerializer() {
  JsonArraySerializer_instance = this;
  this.n4j_1 = JsonArrayDescriptor_getInstance();
}
protoOf(JsonArraySerializer).z3q = function () {
  return this.n4j_1;
};
protoOf(JsonArraySerializer).w4j = function (encoder, value) {
  verify(encoder);
  ListSerializer(JsonElementSerializer_getInstance()).m3r(encoder, value);
};
protoOf(JsonArraySerializer).m3r = function (encoder, value) {
  return this.w4j(encoder, value instanceof JsonArray ? value : THROW_CCE());
};
protoOf(JsonArraySerializer).n3r = function (decoder) {
  verify_0(decoder);
  return new JsonArray(ListSerializer(JsonElementSerializer_getInstance()).n3r(decoder));
};
var JsonArraySerializer_instance;
function JsonArraySerializer_getInstance() {
  if (JsonArraySerializer_instance == null)
    new JsonArraySerializer();
  return JsonArraySerializer_instance;
}
function JsonNullSerializer() {
  JsonNullSerializer_instance = this;
  this.k4j_1 = buildSerialDescriptor('kotlinx.serialization.json.JsonNull', ENUM_getInstance(), []);
}
protoOf(JsonNullSerializer).z3q = function () {
  return this.k4j_1;
};
protoOf(JsonNullSerializer).x4j = function (encoder, value) {
  verify(encoder);
  encoder.g3v();
};
protoOf(JsonNullSerializer).m3r = function (encoder, value) {
  return this.x4j(encoder, value instanceof JsonNull ? value : THROW_CCE());
};
protoOf(JsonNullSerializer).n3r = function (decoder) {
  verify_0(decoder);
  if (decoder.y3t()) {
    throw new JsonDecodingException("Expected 'null' literal");
  }
  decoder.z3t();
  return JsonNull_getInstance();
};
var JsonNullSerializer_instance;
function JsonNullSerializer_getInstance() {
  if (JsonNullSerializer_instance == null)
    new JsonNullSerializer();
  return JsonNullSerializer_instance;
}
function defer(deferred) {
  return new defer$1(deferred);
}
function JsonLiteralSerializer() {
  JsonLiteralSerializer_instance = this;
  this.l4j_1 = PrimitiveSerialDescriptor('kotlinx.serialization.json.JsonLiteral', STRING_getInstance());
}
protoOf(JsonLiteralSerializer).z3q = function () {
  return this.l4j_1;
};
protoOf(JsonLiteralSerializer).y4j = function (encoder, value) {
  verify(encoder);
  if (value.d4j_1) {
    return encoder.p3v(value.f4j_1);
  }
  if (!(value.e4j_1 == null)) {
    return encoder.r3v(value.e4j_1).p3v(value.f4j_1);
  }
  var tmp0_safe_receiver = toLongOrNull(value.f4j_1);
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    return encoder.l3v(tmp0_safe_receiver);
  }
  var tmp1_safe_receiver = toULongOrNull(value.f4j_1);
  var tmp = tmp1_safe_receiver;
  if ((tmp == null ? null : new ULong(tmp)) == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    var tmp_0 = tmp1_safe_receiver;
    // Inline function 'kotlin.contracts.contract' call
    var it = (tmp_0 == null ? null : new ULong(tmp_0)).nl_1;
    var tmp_1 = encoder.r3v(serializer_0(Companion_getInstance()).z3q());
    // Inline function 'kotlin.ULong.toLong' call
    var tmp$ret$1 = _ULong___get_data__impl__fggpzb(it);
    tmp_1.l3v(tmp$ret$1);
    return Unit_instance;
  }
  var tmp2_safe_receiver = toDoubleOrNull(value.f4j_1);
  if (tmp2_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    return encoder.n3v(tmp2_safe_receiver);
  }
  var tmp3_safe_receiver = toBooleanStrictOrNull(value.f4j_1);
  if (tmp3_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    return encoder.h3v(tmp3_safe_receiver);
  }
  encoder.p3v(value.f4j_1);
};
protoOf(JsonLiteralSerializer).m3r = function (encoder, value) {
  return this.y4j(encoder, value instanceof JsonLiteral ? value : THROW_CCE());
};
protoOf(JsonLiteralSerializer).n3r = function (decoder) {
  var result = asJsonDecoder(decoder).t4i();
  if (!(result instanceof JsonLiteral))
    throw JsonDecodingException_0(-1, 'Unexpected JSON element, expected JsonLiteral, had ' + getKClassFromExpression(result), toString(result));
  return result;
};
var JsonLiteralSerializer_instance;
function JsonLiteralSerializer_getInstance() {
  if (JsonLiteralSerializer_instance == null)
    new JsonLiteralSerializer();
  return JsonLiteralSerializer_instance;
}
function verify(encoder) {
  asJsonEncoder(encoder);
}
function asJsonDecoder(_this__u8e3s4) {
  var tmp0_elvis_lhs = isInterface(_this__u8e3s4, JsonDecoder) ? _this__u8e3s4 : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalStateException_init_$Create$('This serializer can be used only with Json format.' + ('Expected Decoder to be JsonDecoder, got ' + getKClassFromExpression(_this__u8e3s4)));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function verify_0(decoder) {
  asJsonDecoder(decoder);
}
function asJsonEncoder(_this__u8e3s4) {
  var tmp0_elvis_lhs = isInterface(_this__u8e3s4, JsonEncoder) ? _this__u8e3s4 : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalStateException_init_$Create$('This serializer can be used only with Json format.' + ('Expected Encoder to be JsonEncoder, got ' + getKClassFromExpression(_this__u8e3s4)));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function _get_original__l7ku1m($this) {
  // Inline function 'kotlin.getValue' call
  var this_0 = $this.z4j_1;
  original$factory();
  return this_0.l2();
}
function defer$1($deferred) {
  this.z4j_1 = lazy_0($deferred);
}
protoOf(defer$1).e3s = function () {
  return _get_original__l7ku1m(this).e3s();
};
protoOf(defer$1).u3s = function () {
  return _get_original__l7ku1m(this).u3s();
};
protoOf(defer$1).s3s = function () {
  return _get_original__l7ku1m(this).s3s();
};
protoOf(defer$1).y3s = function (index) {
  return _get_original__l7ku1m(this).y3s(index);
};
protoOf(defer$1).x3s = function (name) {
  return _get_original__l7ku1m(this).x3s(name);
};
protoOf(defer$1).v3s = function (index) {
  return _get_original__l7ku1m(this).v3s(index);
};
protoOf(defer$1).w3s = function (index) {
  return _get_original__l7ku1m(this).w3s(index);
};
protoOf(defer$1).z3s = function (index) {
  return _get_original__l7ku1m(this).z3s(index);
};
function original$factory() {
  return getPropertyCallableRef('original', 1, KProperty1, function (receiver) {
    return _get_original__l7ku1m(receiver);
  }, null);
}
function JsonEncoder() {
}
function Composer(writer) {
  this.b4k_1 = writer;
  this.c4k_1 = true;
}
protoOf(Composer).d4k = function () {
  this.c4k_1 = true;
};
protoOf(Composer).e4k = function () {
  return Unit_instance;
};
protoOf(Composer).f4k = function () {
  this.c4k_1 = false;
};
protoOf(Composer).g4k = function () {
  this.c4k_1 = false;
};
protoOf(Composer).h4k = function () {
  return Unit_instance;
};
protoOf(Composer).i4k = function (v) {
  return this.b4k_1.j4k(v);
};
protoOf(Composer).k4k = function (v) {
  return this.b4k_1.l4k(v);
};
protoOf(Composer).m4k = function (v) {
  return this.b4k_1.l4k(v.toString());
};
protoOf(Composer).n4k = function (v) {
  return this.b4k_1.l4k(v.toString());
};
protoOf(Composer).o4k = function (v) {
  return this.b4k_1.p4k(toLong(v));
};
protoOf(Composer).q4k = function (v) {
  return this.b4k_1.p4k(toLong(v));
};
protoOf(Composer).r4k = function (v) {
  return this.b4k_1.p4k(toLong(v));
};
protoOf(Composer).s4k = function (v) {
  return this.b4k_1.p4k(v);
};
protoOf(Composer).t4k = function (v) {
  return this.b4k_1.l4k(v.toString());
};
protoOf(Composer).u4k = function (value) {
  return this.b4k_1.v4k(value);
};
function Composer_0(sb, json) {
  return json.s4g_1.g4i_1 ? new ComposerWithPrettyPrint(sb, json) : new Composer(sb);
}
function ComposerForUnsignedNumbers(writer, forceQuoting) {
  Composer.call(this, writer);
  this.y4k_1 = forceQuoting;
}
protoOf(ComposerForUnsignedNumbers).r4k = function (v) {
  if (this.y4k_1) {
    // Inline function 'kotlin.toUInt' call
    var tmp$ret$0 = _UInt___init__impl__l7qpdl(v);
    this.u4k(UInt__toString_impl_dbgl21(tmp$ret$0));
  } else {
    // Inline function 'kotlin.toUInt' call
    var tmp$ret$1 = _UInt___init__impl__l7qpdl(v);
    this.k4k(UInt__toString_impl_dbgl21(tmp$ret$1));
  }
};
protoOf(ComposerForUnsignedNumbers).s4k = function (v) {
  if (this.y4k_1) {
    // Inline function 'kotlin.toULong' call
    var tmp$ret$0 = _ULong___init__impl__c78o9k(v);
    this.u4k(ULong__toString_impl_f9au7k(tmp$ret$0));
  } else {
    // Inline function 'kotlin.toULong' call
    var tmp$ret$1 = _ULong___init__impl__c78o9k(v);
    this.k4k(ULong__toString_impl_f9au7k(tmp$ret$1));
  }
};
protoOf(ComposerForUnsignedNumbers).o4k = function (v) {
  if (this.y4k_1) {
    // Inline function 'kotlin.toUByte' call
    var tmp$ret$0 = _UByte___init__impl__g9hnc4(v);
    this.u4k(UByte__toString_impl_v72jg(tmp$ret$0));
  } else {
    // Inline function 'kotlin.toUByte' call
    var tmp$ret$1 = _UByte___init__impl__g9hnc4(v);
    this.k4k(UByte__toString_impl_v72jg(tmp$ret$1));
  }
};
protoOf(ComposerForUnsignedNumbers).q4k = function (v) {
  if (this.y4k_1) {
    // Inline function 'kotlin.toUShort' call
    var tmp$ret$0 = _UShort___init__impl__jigrne(v);
    this.u4k(UShort__toString_impl_edaoee(tmp$ret$0));
  } else {
    // Inline function 'kotlin.toUShort' call
    var tmp$ret$1 = _UShort___init__impl__jigrne(v);
    this.k4k(UShort__toString_impl_edaoee(tmp$ret$1));
  }
};
function ComposerForUnquotedLiterals(writer, forceQuoting) {
  Composer.call(this, writer);
  this.b4l_1 = forceQuoting;
}
protoOf(ComposerForUnquotedLiterals).u4k = function (value) {
  if (this.b4l_1) {
    protoOf(Composer).u4k.call(this, value);
  } else {
    protoOf(Composer).k4k.call(this, value);
  }
};
function ComposerWithPrettyPrint(writer, json) {
  Composer.call(this, writer);
  this.e4l_1 = json;
  this.f4l_1 = 0;
}
protoOf(ComposerWithPrettyPrint).d4k = function () {
  this.c4k_1 = true;
  this.f4l_1 = this.f4l_1 + 1 | 0;
};
protoOf(ComposerWithPrettyPrint).e4k = function () {
  this.f4l_1 = this.f4l_1 - 1 | 0;
};
protoOf(ComposerWithPrettyPrint).f4k = function () {
  this.c4k_1 = false;
  this.k4k('\n');
  // Inline function 'kotlin.repeat' call
  var times = this.f4l_1;
  // Inline function 'kotlin.contracts.contract' call
  var inductionVariable = 0;
  if (inductionVariable < times)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlinx.serialization.json.internal.ComposerWithPrettyPrint.nextItem.<anonymous>' call
      this.k4k(this.e4l_1.s4g_1.i4i_1);
    }
     while (inductionVariable < times);
};
protoOf(ComposerWithPrettyPrint).g4k = function () {
  if (this.c4k_1)
    this.c4k_1 = false;
  else {
    this.f4k();
  }
};
protoOf(ComposerWithPrettyPrint).h4k = function () {
  this.i4k(_Char___init__impl__6a9atx(32));
};
function readIfAbsent($this, descriptor, index) {
  $this.h4l_1 = !descriptor.z3s(index) ? descriptor.w3s(index).o3s() : false;
  return $this.h4l_1;
}
function JsonElementMarker$readIfAbsent$ref($boundThis) {
  var l = function (p0, p1) {
    return readIfAbsent($boundThis, p0, p1);
  };
  l.callableName = 'readIfAbsent';
  return l;
}
function JsonElementMarker(descriptor) {
  var tmp = this;
  tmp.g4l_1 = new ElementMarker(descriptor, JsonElementMarker$readIfAbsent$ref(this));
  this.h4l_1 = false;
}
protoOf(JsonElementMarker).o40 = function (index) {
  this.g4l_1.o40(index);
};
protoOf(JsonElementMarker).p40 = function () {
  return this.g4l_1.p40();
};
function invalidTrailingComma(_this__u8e3s4, entity) {
  entity = entity === VOID ? 'object' : entity;
  _this__u8e3s4.i4l('Trailing comma before the end of JSON ' + entity, _this__u8e3s4.g4h_1 - 1 | 0, "Trailing commas are non-complaint JSON and not allowed by default. Use 'allowTrailingCommas = true' in 'Json {}' builder to support them.");
}
function throwInvalidFloatingPointDecoded(_this__u8e3s4, result) {
  _this__u8e3s4.j4l('Unexpected special floating-point value ' + toString(result) + '. By default, ' + 'non-finite floating point values are prohibited because they do not conform JSON specification', VOID, get_specialFlowingValuesHint());
}
function JsonEncodingException(message) {
  JsonException.call(this, message);
  captureStack(this, JsonEncodingException);
}
function InvalidKeyKindException(keyDescriptor) {
  return new JsonEncodingException("Value of type '" + keyDescriptor.e3s() + "' can't be used in JSON as a key in the map. " + ("It should have either primitive or enum kind, but its kind is '" + keyDescriptor.u3s() + "'.\n") + get_allowStructuredMapKeysHint());
}
function InvalidFloatingPointEncoded(value, key, output) {
  return new JsonEncodingException(unexpectedFpErrorMessage(value, key, output));
}
function JsonDecodingException(message) {
  JsonException.call(this, message);
  captureStack(this, JsonDecodingException);
}
function JsonDecodingException_0(offset, message, input) {
  return JsonDecodingException_1(offset, message + '\nJSON input: ' + minify(input, offset));
}
function InvalidFloatingPointDecoded(value, key, output) {
  return JsonDecodingException_1(-1, unexpectedFpErrorMessage(value, key, output));
}
function JsonDecodingException_1(offset, message) {
  return new JsonDecodingException(offset >= 0 ? 'Unexpected JSON token at offset ' + offset + ': ' + message : message);
}
function UnknownKeyException(key, input) {
  return JsonDecodingException_1(-1, "Encountered an unknown key '" + key + "'.\n" + (get_ignoreUnknownKeysHint() + '\n') + ('Current input: ' + minify(input)));
}
function InvalidFloatingPointEncoded_0(value, output) {
  return new JsonEncodingException('Unexpected special floating-point value ' + toString(value) + '. By default, ' + 'non-finite floating point values are prohibited because they do not conform JSON specification. ' + (get_specialFlowingValuesHint() + '\n') + ('Current output: ' + minify(output)));
}
function JsonException(message) {
  SerializationException_init_$Init$(message, this);
  captureStack(this, JsonException);
}
function unexpectedFpErrorMessage(value, key, output) {
  return 'Unexpected special floating-point value ' + toString(value) + ' with key ' + key + '. By default, ' + 'non-finite floating point values are prohibited because they do not conform JSON specification. ' + (get_specialFlowingValuesHint() + '\n') + ('Current output: ' + minify(output));
}
function minify(_this__u8e3s4, offset) {
  offset = offset === VOID ? -1 : offset;
  if (charSequenceLength(_this__u8e3s4) < 200)
    return _this__u8e3s4;
  if (offset === -1) {
    var start = charSequenceLength(_this__u8e3s4) - 60 | 0;
    if (start <= 0)
      return _this__u8e3s4;
    // Inline function 'kotlin.text.substring' call
    var endIndex = charSequenceLength(_this__u8e3s4);
    return '.....' + toString(charSequenceSubSequence(_this__u8e3s4, start, endIndex));
  }
  var start_0 = offset - 30 | 0;
  var end = offset + 30 | 0;
  var prefix = start_0 <= 0 ? '' : '.....';
  var suffix = end >= charSequenceLength(_this__u8e3s4) ? '' : '.....';
  // Inline function 'kotlin.text.substring' call
  var startIndex = coerceAtLeast(start_0, 0);
  var endIndex_0 = coerceAtMost(end, charSequenceLength(_this__u8e3s4));
  return prefix + toString(charSequenceSubSequence(_this__u8e3s4, startIndex, endIndex_0)) + suffix;
}
function get_JsonDeserializationNamesKey() {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  return JsonDeserializationNamesKey;
}
var JsonDeserializationNamesKey;
function get_JsonSerializationNamesKey() {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  return JsonSerializationNamesKey;
}
var JsonSerializationNamesKey;
function getJsonNameIndex(_this__u8e3s4, json, name) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  if (decodeCaseInsensitive(json, _this__u8e3s4)) {
    // Inline function 'kotlin.text.lowercase' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$1 = name.toLowerCase();
    return getJsonNameIndexSlowPath(_this__u8e3s4, json, tmp$ret$1);
  }
  var strategy = namingStrategy(_this__u8e3s4, json);
  if (!(strategy == null))
    return getJsonNameIndexSlowPath(_this__u8e3s4, json, name);
  var index = _this__u8e3s4.x3s(name);
  if (!(index === -3))
    return index;
  if (!json.s4g_1.n4i_1)
    return index;
  return getJsonNameIndexSlowPath(_this__u8e3s4, json, name);
}
function getJsonNameIndexOrThrow(_this__u8e3s4, json, name, suffix) {
  suffix = suffix === VOID ? '' : suffix;
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var index = getJsonNameIndex(_this__u8e3s4, json, name);
  if (index === -3)
    throw SerializationException_init_$Create$(_this__u8e3s4.e3s() + " does not contain element with name '" + name + "'" + suffix);
  return index;
}
function getJsonElementName(_this__u8e3s4, json, index) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var strategy = namingStrategy(_this__u8e3s4, json);
  return strategy == null ? _this__u8e3s4.y3s(index) : serializationNamesIndices(_this__u8e3s4, json, strategy)[index];
}
function namingStrategy(_this__u8e3s4, json) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  return equals(_this__u8e3s4.u3s(), CLASS_getInstance()) ? json.s4g_1.o4i_1 : null;
}
function deserializationNamesMap(_this__u8e3s4, descriptor) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var tmp = get_schemaCache(_this__u8e3s4);
  var tmp_0 = get_JsonDeserializationNamesKey();
  return tmp.l4l(descriptor, tmp_0, deserializationNamesMap$lambda(descriptor, _this__u8e3s4));
}
function decodeCaseInsensitive(_this__u8e3s4, descriptor) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  return _this__u8e3s4.s4g_1.p4i_1 ? equals(descriptor.u3s(), ENUM_getInstance()) : false;
}
function getJsonNameIndexSlowPath(_this__u8e3s4, json, name) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var tmp0_elvis_lhs = deserializationNamesMap(json, _this__u8e3s4).s2(name);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    tmp = -3;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function serializationNamesIndices(_this__u8e3s4, json, strategy) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var tmp = get_schemaCache(json);
  var tmp_0 = get_JsonSerializationNamesKey();
  return tmp.l4l(_this__u8e3s4, tmp_0, serializationNamesIndices$lambda(_this__u8e3s4, strategy));
}
function buildDeserializationNamesMap(_this__u8e3s4, json) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  // Inline function 'kotlin.collections.mutableMapOf' call
  var builder = LinkedHashMap_init_$Create$();
  var useLowercaseEnums = decodeCaseInsensitive(json, _this__u8e3s4);
  var strategyForClasses = namingStrategy(_this__u8e3s4, json);
  var inductionVariable = 0;
  var last = _this__u8e3s4.s3s();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.collections.filterIsInstance' call
      // Inline function 'kotlin.collections.filterIsInstanceTo' call
      var this_0 = _this__u8e3s4.v3s(i);
      var destination = ArrayList_init_$Create$();
      var tmp0_iterator = this_0.u();
      while (tmp0_iterator.v()) {
        var element = tmp0_iterator.w();
        if (element instanceof JsonNames) {
          destination.r(element);
        }
      }
      var tmp1_safe_receiver = singleOrNull(destination);
      var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.m4l_1;
      if (tmp2_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var inductionVariable_0 = 0;
        var last_0 = tmp2_safe_receiver.length;
        while (inductionVariable_0 < last_0) {
          var element_0 = tmp2_safe_receiver[inductionVariable_0];
          inductionVariable_0 = inductionVariable_0 + 1 | 0;
          // Inline function 'kotlinx.serialization.json.internal.buildDeserializationNamesMap.<anonymous>' call
          var tmp;
          if (useLowercaseEnums) {
            // Inline function 'kotlin.text.lowercase' call
            // Inline function 'kotlin.js.asDynamic' call
            tmp = element_0.toLowerCase();
          } else {
            tmp = element_0;
          }
          buildDeserializationNamesMap$putOrThrow(builder, _this__u8e3s4, tmp, i);
        }
      }
      var tmp_0;
      if (useLowercaseEnums) {
        // Inline function 'kotlin.text.lowercase' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp_0 = _this__u8e3s4.y3s(i).toLowerCase();
      } else if (!(strategyForClasses == null)) {
        tmp_0 = strategyForClasses.n4l(_this__u8e3s4, i, _this__u8e3s4.y3s(i));
      } else {
        tmp_0 = null;
      }
      var nameToPut = tmp_0;
      if (nameToPut == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        // Inline function 'kotlin.contracts.contract' call
        buildDeserializationNamesMap$putOrThrow(builder, _this__u8e3s4, nameToPut, i);
      }
    }
     while (inductionVariable < last);
  // Inline function 'kotlin.collections.ifEmpty' call
  var tmp_1;
  if (builder.b1()) {
    // Inline function 'kotlinx.serialization.json.internal.buildDeserializationNamesMap.<anonymous>' call
    tmp_1 = emptyMap();
  } else {
    tmp_1 = builder;
  }
  return tmp_1;
}
function buildDeserializationNamesMap$putOrThrow(_this__u8e3s4, $this_buildDeserializationNamesMap, name, index) {
  var entity = equals($this_buildDeserializationNamesMap.u3s(), ENUM_getInstance()) ? 'enum value' : 'property';
  // Inline function 'kotlin.collections.contains' call
  // Inline function 'kotlin.collections.containsKey' call
  if ((isInterface(_this__u8e3s4, Map) ? _this__u8e3s4 : THROW_CCE()).p2(name)) {
    throw new JsonException("The suggested name '" + name + "' for " + entity + ' ' + $this_buildDeserializationNamesMap.y3s(index) + ' is already one of the names for ' + entity + ' ' + ($this_buildDeserializationNamesMap.y3s(getValue(_this__u8e3s4, name)) + ' in ' + $this_buildDeserializationNamesMap));
  }
  // Inline function 'kotlin.collections.set' call
  _this__u8e3s4.i2(name, index);
}
function deserializationNamesMap$lambda($descriptor, $this_deserializationNamesMap) {
  return function () {
    return buildDeserializationNamesMap($descriptor, $this_deserializationNamesMap);
  };
}
function serializationNamesIndices$lambda($this_serializationNamesIndices, $strategy) {
  return function () {
    var tmp = 0;
    var tmp_0 = $this_serializationNamesIndices.s3s();
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = fillArrayVal(Array(tmp_0), null);
    while (tmp < tmp_0) {
      var tmp_2 = tmp;
      var baseName = $this_serializationNamesIndices.y3s(tmp_2);
      tmp_1[tmp_2] = $strategy.n4l($this_serializationNamesIndices, tmp_2, baseName);
      tmp = tmp + 1 | 0;
    }
    return tmp_1;
  };
}
var properties_initialized_JsonNamesMap_kt_ljpf42;
function _init_properties_JsonNamesMap_kt__cbbp0k() {
  if (!properties_initialized_JsonNamesMap_kt_ljpf42) {
    properties_initialized_JsonNamesMap_kt_ljpf42 = true;
    JsonDeserializationNamesKey = new Key();
    JsonSerializationNamesKey = new Key();
  }
}
function Tombstone() {
}
var Tombstone_instance;
function Tombstone_getInstance() {
  return Tombstone_instance;
}
function resize($this) {
  var newSize = imul($this.q4l_1, 2);
  $this.o4l_1 = copyOf($this.o4l_1, newSize);
  $this.p4l_1 = copyOf_0($this.p4l_1, newSize);
}
function JsonPath() {
  var tmp = this;
  // Inline function 'kotlin.arrayOfNulls' call
  tmp.o4l_1 = fillArrayVal(Array(8), null);
  var tmp_0 = this;
  var tmp_1 = 0;
  var tmp_2 = new Int32Array(8);
  while (tmp_1 < 8) {
    tmp_2[tmp_1] = -1;
    tmp_1 = tmp_1 + 1 | 0;
  }
  tmp_0.p4l_1 = tmp_2;
  this.q4l_1 = -1;
}
protoOf(JsonPath).r4l = function (sd) {
  this.q4l_1 = this.q4l_1 + 1 | 0;
  var depth = this.q4l_1;
  if (depth === this.o4l_1.length) {
    resize(this);
  }
  this.o4l_1[depth] = sd;
};
protoOf(JsonPath).s4l = function (index) {
  this.p4l_1[this.q4l_1] = index;
};
protoOf(JsonPath).t4l = function (key) {
  var tmp;
  if (!(this.p4l_1[this.q4l_1] === -2)) {
    this.q4l_1 = this.q4l_1 + 1 | 0;
    tmp = this.q4l_1 === this.o4l_1.length;
  } else {
    tmp = false;
  }
  if (tmp) {
    resize(this);
  }
  this.o4l_1[this.q4l_1] = key;
  this.p4l_1[this.q4l_1] = -2;
};
protoOf(JsonPath).u4l = function () {
  if (this.p4l_1[this.q4l_1] === -2) {
    this.o4l_1[this.q4l_1] = Tombstone_instance;
  }
};
protoOf(JsonPath).v4l = function () {
  var depth = this.q4l_1;
  if (this.p4l_1[depth] === -2) {
    this.p4l_1[depth] = -1;
    this.q4l_1 = this.q4l_1 - 1 | 0;
  }
  if (!(this.q4l_1 === -1)) {
    this.q4l_1 = this.q4l_1 - 1 | 0;
  }
};
protoOf(JsonPath).w4l = function () {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder_init_$Create$();
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.serialization.json.internal.JsonPath.getPath.<anonymous>' call
  this_0.n5('$');
  // Inline function 'kotlin.repeat' call
  var times = this.q4l_1 + 1 | 0;
  // Inline function 'kotlin.contracts.contract' call
  var inductionVariable = 0;
  if (inductionVariable < times)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlinx.serialization.json.internal.JsonPath.getPath.<anonymous>.<anonymous>' call
      var element = this.o4l_1[index];
      if (!(element == null) ? isInterface(element, SerialDescriptor) : false) {
        if (equals(element.u3s(), LIST_getInstance())) {
          if (!(this.p4l_1[index] === -1)) {
            this_0.n5('[');
            this_0.h8(this.p4l_1[index]);
            this_0.n5(']');
          }
        } else {
          var idx = this.p4l_1[index];
          if (idx >= 0) {
            this_0.n5('.');
            this_0.n5(element.y3s(idx));
          }
        }
      } else {
        if (!(element === Tombstone_instance)) {
          this_0.n5('[');
          this_0.n5("'");
          this_0.m5(element);
          this_0.n5("'");
          this_0.n5(']');
        }
      }
    }
     while (inductionVariable < times);
  return this_0.toString();
};
protoOf(JsonPath).toString = function () {
  return this.w4l();
};
function encodeByWriter(json, writer, serializer, value) {
  var tmp = WriteMode_OBJ_getInstance();
  // Inline function 'kotlin.arrayOfNulls' call
  var size = get_entries().n();
  var tmp$ret$0 = fillArrayVal(Array(size), null);
  var encoder = StreamingJsonEncoder_init_$Create$(writer, json, tmp, tmp$ret$0);
  encoder.l3r(serializer, value);
}
function readObject($this) {
  // Inline function 'kotlinx.serialization.json.internal.JsonTreeReader.readObjectImpl' call
  var lastToken = $this.f4m_1.j4m(get_TC_BEGIN_OBJ());
  if ($this.f4m_1.k4m() === get_TC_COMMA()) {
    $this.f4m_1.j4l('Unexpected leading comma');
  }
  // Inline function 'kotlin.collections.linkedMapOf' call
  var result = LinkedHashMap_init_$Create$();
  $l$loop: while ($this.f4m_1.l4m()) {
    var key = $this.g4m_1 ? $this.f4m_1.n4m() : $this.f4m_1.m4m();
    $this.f4m_1.j4m(get_TC_COLON());
    // Inline function 'kotlinx.serialization.json.internal.JsonTreeReader.readObject.<anonymous>' call
    var element = $this.o4m();
    // Inline function 'kotlin.collections.set' call
    result.i2(key, element);
    lastToken = $this.f4m_1.p4m();
    var tmp0_subject = lastToken;
    if (tmp0_subject !== get_TC_COMMA())
      if (tmp0_subject === get_TC_END_OBJ())
        break $l$loop;
      else {
        $this.f4m_1.j4l('Expected end of the object or comma');
      }
  }
  if (lastToken === get_TC_BEGIN_OBJ()) {
    $this.f4m_1.j4m(get_TC_END_OBJ());
  } else if (lastToken === get_TC_COMMA()) {
    if (!$this.h4m_1) {
      invalidTrailingComma($this.f4m_1);
    }
    $this.f4m_1.j4m(get_TC_END_OBJ());
  }
  return new JsonObject(result);
}
function readObject_0(_this__u8e3s4, $this, $completion) {
  var tmp = new $readObjectCOROUTINE$0($this, _this__u8e3s4, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function readArray($this) {
  var lastToken = $this.f4m_1.p4m();
  if ($this.f4m_1.k4m() === get_TC_COMMA()) {
    $this.f4m_1.j4l('Unexpected leading comma');
  }
  // Inline function 'kotlin.collections.arrayListOf' call
  var result = ArrayList_init_$Create$();
  while ($this.f4m_1.l4m()) {
    var element = $this.o4m();
    result.r(element);
    lastToken = $this.f4m_1.p4m();
    if (!(lastToken === get_TC_COMMA())) {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.require' call
      var this_0 = $this.f4m_1;
      var condition = lastToken === get_TC_END_LIST();
      var position = this_0.g4h_1;
      if (!condition) {
        // Inline function 'kotlinx.serialization.json.internal.JsonTreeReader.readArray.<anonymous>' call
        var tmp$ret$1 = 'Expected end of the array or comma';
        this_0.j4l(tmp$ret$1, position);
      }
    }
  }
  if (lastToken === get_TC_BEGIN_LIST()) {
    $this.f4m_1.j4m(get_TC_END_LIST());
  } else if (lastToken === get_TC_COMMA()) {
    if (!$this.h4m_1) {
      invalidTrailingComma($this.f4m_1, 'array');
    }
    $this.f4m_1.j4m(get_TC_END_LIST());
  }
  return new JsonArray(result);
}
function readValue($this, isString) {
  var tmp;
  if ($this.g4m_1 ? true : !isString) {
    tmp = $this.f4m_1.n4m();
  } else {
    tmp = $this.f4m_1.m4m();
  }
  var string = tmp;
  if (!isString ? string === get_NULL() : false)
    return JsonNull_getInstance();
  return new JsonLiteral(string, isString);
}
function readDeepRecursive($this) {
  return invoke(new DeepRecursiveFunction(JsonTreeReader$readDeepRecursive$slambda_0($this, null)), Unit_instance);
}
function JsonTreeReader$readDeepRecursive$slambda(this$0, resultContinuation) {
  this.m4n_1 = this$0;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(JsonTreeReader$readDeepRecursive$slambda).r4n = function ($this$$receiver, it, $completion) {
  var tmp = this.s4n($this$$receiver, it, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(JsonTreeReader$readDeepRecursive$slambda).dk = function (p1, p2, $completion) {
  var tmp = p1 instanceof DeepRecursiveScope ? p1 : THROW_CCE();
  return this.r4n(tmp, p2 instanceof Unit ? p2 : THROW_CCE(), $completion);
};
protoOf(JsonTreeReader$readDeepRecursive$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          this.p4n_1 = this.m4n_1.f4m_1.k4m();
          if (this.p4n_1 === get_TC_STRING()) {
            this.q4n_1 = readValue(this.m4n_1, true);
            this.ic_1 = 2;
            continue $sm;
          } else {
            if (this.p4n_1 === get_TC_OTHER()) {
              this.q4n_1 = readValue(this.m4n_1, false);
              this.ic_1 = 2;
              continue $sm;
            } else {
              if (this.p4n_1 === get_TC_BEGIN_OBJ()) {
                this.ic_1 = 1;
                suspendResult = readObject_0(this.n4n_1, this.m4n_1, this);
                if (suspendResult === get_COROUTINE_SUSPENDED()) {
                  return suspendResult;
                }
                continue $sm;
              } else {
                if (this.p4n_1 === get_TC_BEGIN_LIST()) {
                  this.q4n_1 = readArray(this.m4n_1);
                  this.ic_1 = 2;
                  continue $sm;
                } else {
                  var tmp_0 = this;
                  this.m4n_1.f4m_1.j4l("Can't begin reading element, unexpected token");
                }
              }
            }
          }

          break;
        case 1:
          this.q4n_1 = suspendResult;
          this.ic_1 = 2;
          continue $sm;
        case 2:
          return this.q4n_1;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
protoOf(JsonTreeReader$readDeepRecursive$slambda).s4n = function ($this$$receiver, it, completion) {
  var i = new JsonTreeReader$readDeepRecursive$slambda(this.m4n_1, completion);
  i.n4n_1 = $this$$receiver;
  i.o4n_1 = it;
  return i;
};
function JsonTreeReader$readDeepRecursive$slambda_0(this$0, resultContinuation) {
  var i = new JsonTreeReader$readDeepRecursive$slambda(this$0, resultContinuation);
  var l = function ($this$$receiver, it, $completion) {
    return i.r4n($this$$receiver, it, $completion);
  };
  l.$arity = 2;
  return l;
}
function $readObjectCOROUTINE$0(_this__u8e3s4, _this__u8e3s4_0, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.y4m_1 = _this__u8e3s4;
  this.z4m_1 = _this__u8e3s4_0;
}
protoOf($readObjectCOROUTINE$0).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 5;
          var tmp_0 = this;
          tmp_0.a4n_1 = this.y4m_1;
          this.b4n_1 = this.a4n_1.f4m_1.j4m(get_TC_BEGIN_OBJ());
          if (this.a4n_1.f4m_1.k4m() === get_TC_COMMA()) {
            this.a4n_1.f4m_1.j4l('Unexpected leading comma');
          }

          var tmp_1 = this;
          tmp_1.c4n_1 = LinkedHashMap_init_$Create$();
          this.ic_1 = 1;
          continue $sm;
        case 1:
          if (!this.a4n_1.f4m_1.l4m()) {
            this.ic_1 = 4;
            continue $sm;
          }

          this.d4n_1 = this.a4n_1.g4m_1 ? this.a4n_1.f4m_1.n4m() : this.a4n_1.f4m_1.m4m();
          this.a4n_1.f4m_1.j4m(get_TC_COLON());
          this.ic_1 = 2;
          suspendResult = this.z4m_1.vj(Unit_instance, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          var element = suspendResult;
          var this_0 = this.c4n_1;
          var key = this.d4n_1;
          this_0.i2(key, element);
          this.b4n_1 = this.a4n_1.f4m_1.p4m();
          var tmp0_subject = this.b4n_1;
          if (tmp0_subject === get_TC_COMMA()) {
            this.ic_1 = 3;
            continue $sm;
          } else {
            if (tmp0_subject === get_TC_END_OBJ()) {
              this.ic_1 = 4;
              continue $sm;
            } else {
              this.a4n_1.f4m_1.j4l('Expected end of the object or comma');
            }
          }

          break;
        case 3:
          this.ic_1 = 1;
          continue $sm;
        case 4:
          if (this.b4n_1 === get_TC_BEGIN_OBJ()) {
            this.a4n_1.f4m_1.j4m(get_TC_END_OBJ());
          } else if (this.b4n_1 === get_TC_COMMA()) {
            if (!this.a4n_1.h4m_1) {
              invalidTrailingComma(this.a4n_1.f4m_1);
            }
            this.a4n_1.f4m_1.j4m(get_TC_END_OBJ());
          }

          return new JsonObject(this.c4n_1);
        case 5:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 5) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function JsonTreeReader(configuration, lexer) {
  this.f4m_1 = lexer;
  this.g4m_1 = configuration.e4i_1;
  this.h4m_1 = configuration.q4i_1;
  this.i4m_1 = 0;
}
protoOf(JsonTreeReader).o4m = function () {
  var token = this.f4m_1.k4m();
  var tmp;
  if (token === get_TC_STRING()) {
    tmp = readValue(this, true);
  } else if (token === get_TC_OTHER()) {
    tmp = readValue(this, false);
  } else if (token === get_TC_BEGIN_OBJ()) {
    var tmp_0;
    this.i4m_1 = this.i4m_1 + 1 | 0;
    if (this.i4m_1 === 200) {
      tmp_0 = readDeepRecursive(this);
    } else {
      tmp_0 = readObject(this);
    }
    var result = tmp_0;
    this.i4m_1 = this.i4m_1 - 1 | 0;
    tmp = result;
  } else if (token === get_TC_BEGIN_LIST()) {
    tmp = readArray(this);
  } else {
    this.f4m_1.j4l('Cannot read Json element because of unexpected ' + tokenDescription(token));
  }
  return tmp;
};
function classDiscriminator(_this__u8e3s4, json) {
  var tmp0_iterator = _this__u8e3s4.a3r().u();
  while (tmp0_iterator.v()) {
    var annotation = tmp0_iterator.w();
    if (annotation instanceof JsonClassDiscriminator)
      return annotation.t4n_1;
  }
  return json.s4g_1.l4i_1;
}
function decodeSerializableValuePolymorphic(_this__u8e3s4, deserializer) {
  var tmp;
  if (!(deserializer instanceof AbstractPolymorphicSerializer)) {
    tmp = true;
  } else {
    tmp = _this__u8e3s4.s4i().s4g_1.k4i_1;
  }
  if (tmp) {
    return deserializer.n3r(_this__u8e3s4);
  }
  var discriminator = classDiscriminator(deserializer.z3q(), _this__u8e3s4.s4i());
  // Inline function 'kotlinx.serialization.json.internal.cast' call
  var value = _this__u8e3s4.t4i();
  var descriptor = deserializer.z3q();
  if (!(value instanceof JsonObject)) {
    throw JsonDecodingException_1(-1, 'Expected ' + getKClass(JsonObject) + ' as the serialized body of ' + descriptor.e3s() + ', but had ' + getKClassFromExpression(value));
  }
  var jsonTree = value;
  var tmp0_safe_receiver = jsonTree.l1w(discriminator);
  var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : get_jsonPrimitive(tmp0_safe_receiver);
  var type = tmp1_safe_receiver == null ? null : get_contentOrNull(tmp1_safe_receiver);
  var tmp_0;
  try {
    tmp_0 = findPolymorphicSerializer(deserializer, _this__u8e3s4, type);
  } catch ($p) {
    var tmp_1;
    if ($p instanceof SerializationException) {
      var it = $p;
      throw JsonDecodingException_0(-1, ensureNotNull(it.message), jsonTree.toString());
    } else {
      throw $p;
    }
  }
  var tmp_2 = tmp_0;
  var actualSerializer = isInterface(tmp_2, DeserializationStrategy) ? tmp_2 : THROW_CCE();
  return readPolymorphicJson(_this__u8e3s4.s4i(), discriminator, jsonTree, actualSerializer);
}
function validateIfSealed(serializer, actualSerializer, classDiscriminator) {
  if (!(serializer instanceof SealedClassSerializer))
    return Unit_instance;
  if (jsonCachedSerialNames(actualSerializer.z3q()).z(classDiscriminator)) {
    var baseName = serializer.z3q().e3s();
    var actualName = actualSerializer.z3q().e3s();
    // Inline function 'kotlin.error' call
    var message = "Sealed class '" + actualName + "' cannot be serialized as base class '" + baseName + "' because" + (" it has property name that conflicts with JSON class discriminator '" + classDiscriminator + "'. ") + 'You can either change class discriminator in JsonConfiguration, ' + 'rename property with @SerialName annotation or fall back to array polymorphism';
    throw IllegalStateException_init_$Create$(toString(message));
  }
}
function checkKind(kind) {
  if (kind instanceof ENUM) {
    // Inline function 'kotlin.error' call
    var message = "Enums cannot be serialized polymorphically with 'type' parameter. You can use 'JsonBuilder.useArrayPolymorphism' instead";
    throw IllegalStateException_init_$Create$(toString(message));
  }
  if (kind instanceof PrimitiveKind) {
    // Inline function 'kotlin.error' call
    var message_0 = "Primitives cannot be serialized polymorphically with 'type' parameter. You can use 'JsonBuilder.useArrayPolymorphism' instead";
    throw IllegalStateException_init_$Create$(toString(message_0));
  }
  if (kind instanceof PolymorphicKind) {
    // Inline function 'kotlin.error' call
    var message_1 = 'Actual serializer for polymorphic cannot be polymorphic itself';
    throw IllegalStateException_init_$Create$(toString(message_1));
  }
}
function validateIfSealed$accessor$1ad0flx(serializer, actualSerializer, classDiscriminator) {
  return validateIfSealed(serializer, actualSerializer, classDiscriminator);
}
function checkKind_0($this, descriptor, actualClass) {
  var kind = descriptor.u3s();
  var tmp;
  if (kind instanceof PolymorphicKind) {
    tmp = true;
  } else {
    tmp = equals(kind, CONTEXTUAL_getInstance());
  }
  if (tmp) {
    throw IllegalArgumentException_init_$Create$('Serializer for ' + actualClass.s6() + " can't be registered as a subclass for polymorphic serialization " + ('because its kind ' + kind + ' is not concrete. To work with multiple hierarchies, register it as a base class.'));
  }
  if ($this.u4n_1)
    return Unit_instance;
  var tmp_0;
  var tmp_1;
  if (equals(kind, LIST_getInstance()) ? true : equals(kind, MAP_getInstance())) {
    tmp_1 = true;
  } else {
    tmp_1 = kind instanceof PrimitiveKind;
  }
  if (tmp_1) {
    tmp_0 = true;
  } else {
    tmp_0 = kind instanceof ENUM;
  }
  if (tmp_0) {
    throw IllegalArgumentException_init_$Create$('Serializer for ' + actualClass.s6() + ' of kind ' + kind + ' cannot be serialized polymorphically with class discriminator.');
  }
}
function checkDiscriminatorCollisions($this, descriptor, actualClass) {
  var inductionVariable = 0;
  var last = descriptor.s3s();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var name = descriptor.y3s(i);
      if (name === $this.v4n_1) {
        throw IllegalArgumentException_init_$Create$('Polymorphic serializer for ' + actualClass + " has property '" + name + "' that conflicts " + 'with JSON class discriminator. You can either change class discriminator in JsonConfiguration, ' + 'rename property with @SerialName annotation ' + 'or fall back to array polymorphism');
      }
    }
     while (inductionVariable < last);
}
function PolymorphismValidator(useArrayPolymorphism, discriminator) {
  this.u4n_1 = useArrayPolymorphism;
  this.v4n_1 = discriminator;
}
protoOf(PolymorphismValidator).o4b = function (kClass, provider) {
};
protoOf(PolymorphismValidator).r4b = function (baseClass, actualClass, actualSerializer) {
  var descriptor = actualSerializer.z3q();
  checkKind_0(this, descriptor, actualClass);
  if (!this.u4n_1) {
    checkDiscriminatorCollisions(this, descriptor, actualClass);
  }
};
protoOf(PolymorphismValidator).s4b = function (baseClass, defaultSerializerProvider) {
};
protoOf(PolymorphismValidator).t4b = function (baseClass, defaultDeserializerProvider) {
};
function Key() {
}
function DescriptorSchemaCache() {
  this.k4l_1 = createMapForCache(16);
}
protoOf(DescriptorSchemaCache).w4n = function (descriptor, key, value) {
  // Inline function 'kotlin.collections.set' call
  // Inline function 'kotlin.collections.getOrPut' call
  var this_0 = this.k4l_1;
  var value_0 = this_0.s2(descriptor);
  var tmp;
  if (value_0 == null) {
    // Inline function 'kotlinx.serialization.json.internal.DescriptorSchemaCache.set.<anonymous>' call
    var answer = createMapForCache(2);
    this_0.i2(descriptor, answer);
    tmp = answer;
  } else {
    tmp = value_0;
  }
  var this_1 = tmp;
  var key_0 = key instanceof Key ? key : THROW_CCE();
  var value_1 = !(value == null) ? value : THROW_CCE();
  this_1.i2(key_0, value_1);
};
protoOf(DescriptorSchemaCache).l4l = function (descriptor, key, defaultValue) {
  var tmp0_safe_receiver = this.x4n(descriptor, key);
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    return tmp0_safe_receiver;
  }
  var value = defaultValue();
  this.w4n(descriptor, key, value);
  return value;
};
protoOf(DescriptorSchemaCache).x4n = function (descriptor, key) {
  var tmp0_safe_receiver = this.k4l_1.s2(descriptor);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    tmp = tmp0_safe_receiver.s2(key instanceof Key ? key : THROW_CCE());
  }
  var tmp_0 = tmp;
  return !(tmp_0 == null) ? tmp_0 : null;
};
function DiscriminatorHolder(discriminatorToSkip) {
  this.y4n_1 = discriminatorToSkip;
}
function trySkip(_this__u8e3s4, $this, unknownKey) {
  if (_this__u8e3s4 == null)
    return false;
  if (_this__u8e3s4.y4n_1 === unknownKey) {
    _this__u8e3s4.y4n_1 = null;
    return true;
  }
  return false;
}
function skipLeftoverElements($this, descriptor) {
  $l$loop: while (true) {
    var tmp = $this.c3v(descriptor);
    if (!!(tmp === -1)) {
      break $l$loop;
    }
  }
}
function checkLeadingComma($this) {
  if ($this.a4h_1.k4m() === get_TC_COMMA()) {
    $this.a4h_1.j4l('Unexpected leading comma');
  }
}
function decodeMapIndex($this) {
  var hasComma = false;
  var decodingKey = !(($this.c4h_1 % 2 | 0) === 0);
  if (decodingKey) {
    if (!($this.c4h_1 === -1)) {
      hasComma = $this.a4h_1.a4o();
    }
  } else {
    $this.a4h_1.z4n(get_COLON());
  }
  var tmp;
  if ($this.a4h_1.l4m()) {
    if (decodingKey) {
      if ($this.c4h_1 === -1) {
        // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.require' call
        var this_0 = $this.a4h_1;
        var condition = !hasComma;
        var position = this_0.g4h_1;
        if (!condition) {
          // Inline function 'kotlinx.serialization.json.internal.StreamingJsonDecoder.decodeMapIndex.<anonymous>' call
          var tmp$ret$0 = 'Unexpected leading comma';
          this_0.j4l(tmp$ret$0, position);
        }
      } else {
        // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.require' call
        var this_1 = $this.a4h_1;
        var condition_0 = hasComma;
        var position_0 = this_1.g4h_1;
        if (!condition_0) {
          // Inline function 'kotlinx.serialization.json.internal.StreamingJsonDecoder.decodeMapIndex.<anonymous>' call
          var tmp$ret$1 = 'Expected comma after the key-value pair';
          this_1.j4l(tmp$ret$1, position_0);
        }
      }
    }
    $this.c4h_1 = $this.c4h_1 + 1 | 0;
    tmp = $this.c4h_1;
  } else {
    if (hasComma ? !$this.y4g_1.s4g_1.q4i_1 : false) {
      invalidTrailingComma($this.a4h_1);
    }
    tmp = -1;
  }
  return tmp;
}
function coerceInputValue($this, descriptor, index) {
  var tmp$ret$0;
  $l$block_3: {
    // Inline function 'kotlinx.serialization.json.internal.tryCoerceValue' call
    var this_0 = $this.y4g_1;
    if (!descriptor.z3s(index)) {
      tmp$ret$0 = false;
      break $l$block_3;
    }
    var elementDescriptor = descriptor.w3s(index);
    var tmp;
    if (!elementDescriptor.o3s()) {
      // Inline function 'kotlinx.serialization.json.internal.StreamingJsonDecoder.coerceInputValue.<anonymous>' call
      tmp = $this.a4h_1.b4o(true);
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$0 = true;
      break $l$block_3;
    }
    if (equals(elementDescriptor.u3s(), ENUM_getInstance())) {
      var tmp_0;
      if (elementDescriptor.o3s()) {
        // Inline function 'kotlinx.serialization.json.internal.StreamingJsonDecoder.coerceInputValue.<anonymous>' call
        tmp_0 = $this.a4h_1.b4o(false);
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp$ret$0 = false;
        break $l$block_3;
      }
      // Inline function 'kotlinx.serialization.json.internal.StreamingJsonDecoder.coerceInputValue.<anonymous>' call
      var tmp0_elvis_lhs = $this.a4h_1.c4o($this.e4h_1.e4i_1);
      var tmp_1;
      if (tmp0_elvis_lhs == null) {
        tmp$ret$0 = false;
        break $l$block_3;
      } else {
        tmp_1 = tmp0_elvis_lhs;
      }
      var enumValue = tmp_1;
      var enumIndex = getJsonNameIndex(elementDescriptor, this_0, enumValue);
      if (enumIndex === -3) {
        // Inline function 'kotlinx.serialization.json.internal.StreamingJsonDecoder.coerceInputValue.<anonymous>' call
        $this.a4h_1.m4m();
        tmp$ret$0 = true;
        break $l$block_3;
      }
    }
    tmp$ret$0 = false;
  }
  return tmp$ret$0;
}
function decodeObjectIndex($this, descriptor) {
  var hasComma = $this.a4h_1.a4o();
  while ($this.a4h_1.l4m()) {
    hasComma = false;
    var key = decodeStringKey($this);
    $this.a4h_1.z4n(get_COLON());
    var index = getJsonNameIndex(descriptor, $this.y4g_1, key);
    var tmp;
    if (!(index === -3)) {
      var tmp_0;
      if ($this.e4h_1.j4i_1 ? coerceInputValue($this, descriptor, index) : false) {
        hasComma = $this.a4h_1.a4o();
        tmp_0 = false;
      } else {
        var tmp0_safe_receiver = $this.f4h_1;
        if (tmp0_safe_receiver == null)
          null;
        else {
          tmp0_safe_receiver.o40(index);
        }
        return index;
      }
      tmp = tmp_0;
    } else {
      tmp = true;
    }
    var isUnknown = tmp;
    if (isUnknown) {
      hasComma = handleUnknown($this, key);
    }
  }
  if (hasComma ? !$this.y4g_1.s4g_1.q4i_1 : false) {
    invalidTrailingComma($this.a4h_1);
  }
  var tmp1_safe_receiver = $this.f4h_1;
  var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.p40();
  var tmp_1;
  if (tmp2_elvis_lhs == null) {
    tmp_1 = -1;
  } else {
    tmp_1 = tmp2_elvis_lhs;
  }
  return tmp_1;
}
function handleUnknown($this, key) {
  if ($this.e4h_1.d4i_1 ? true : trySkip($this.d4h_1, $this, key)) {
    $this.a4h_1.e4o($this.e4h_1.e4i_1);
  } else {
    $this.a4h_1.d4o(key);
  }
  return $this.a4h_1.a4o();
}
function decodeListIndex($this) {
  var hasComma = $this.a4h_1.a4o();
  var tmp;
  if ($this.a4h_1.l4m()) {
    if (!($this.c4h_1 === -1) ? !hasComma : false) {
      $this.a4h_1.j4l('Expected end of the array or comma');
    }
    $this.c4h_1 = $this.c4h_1 + 1 | 0;
    tmp = $this.c4h_1;
  } else {
    if (hasComma ? !$this.y4g_1.s4g_1.q4i_1 : false) {
      invalidTrailingComma($this.a4h_1, 'array');
    }
    tmp = -1;
  }
  return tmp;
}
function decodeStringKey($this) {
  var tmp;
  if ($this.e4h_1.e4i_1) {
    tmp = $this.a4h_1.g4o();
  } else {
    tmp = $this.a4h_1.f4o();
  }
  return tmp;
}
function StreamingJsonDecoder(json, mode, lexer, descriptor, discriminatorHolder) {
  AbstractDecoder.call(this);
  this.y4g_1 = json;
  this.z4g_1 = mode;
  this.a4h_1 = lexer;
  this.b4h_1 = this.y4g_1.k3r();
  this.c4h_1 = -1;
  this.d4h_1 = discriminatorHolder;
  this.e4h_1 = this.y4g_1.s4g_1;
  this.f4h_1 = this.e4h_1.h4i_1 ? null : new JsonElementMarker(descriptor);
}
protoOf(StreamingJsonDecoder).s4i = function () {
  return this.y4g_1;
};
protoOf(StreamingJsonDecoder).k3r = function () {
  return this.b4h_1;
};
protoOf(StreamingJsonDecoder).t4i = function () {
  return (new JsonTreeReader(this.y4g_1.s4g_1, this.a4h_1)).o4m();
};
protoOf(StreamingJsonDecoder).o3r = function (deserializer) {
  try {
    var tmp;
    if (!(deserializer instanceof AbstractPolymorphicSerializer)) {
      tmp = true;
    } else {
      tmp = this.y4g_1.s4g_1.k4i_1;
    }
    if (tmp) {
      return deserializer.n3r(this);
    }
    var discriminator = classDiscriminator(deserializer.z3q(), this.y4g_1);
    var tmp0_elvis_lhs = this.a4h_1.h4o(discriminator, this.e4h_1.e4i_1);
    var tmp_0;
    if (tmp0_elvis_lhs == null) {
      return decodeSerializableValuePolymorphic(this, isInterface(deserializer, DeserializationStrategy) ? deserializer : THROW_CCE());
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    var type = tmp_0;
    var tmp_1;
    try {
      tmp_1 = findPolymorphicSerializer(deserializer, this, type);
    } catch ($p) {
      var tmp_2;
      if ($p instanceof SerializationException) {
        var it = $p;
        var message = removeSuffix(substringBefore(ensureNotNull(it.message), _Char___init__impl__6a9atx(10)), '.');
        var hint = substringAfter(ensureNotNull(it.message), _Char___init__impl__6a9atx(10), '');
        this.a4h_1.j4l(message, VOID, hint);
      } else {
        throw $p;
      }
      tmp_1 = tmp_2;
    }
    var tmp_3 = tmp_1;
    var actualSerializer = isInterface(tmp_3, DeserializationStrategy) ? tmp_3 : THROW_CCE();
    this.d4h_1 = new DiscriminatorHolder(discriminator);
    return actualSerializer.n3r(this);
  } catch ($p) {
    if ($p instanceof MissingFieldException) {
      var e = $p;
      if (contains_0(ensureNotNull(e.message), 'at path'))
        throw e;
      throw new MissingFieldException(e.k3s_1, plus(e.message, ' at path: ') + this.a4h_1.h4h_1.w4l(), e);
    } else {
      throw $p;
    }
  }
};
protoOf(StreamingJsonDecoder).m3u = function (descriptor) {
  var newMode = switchMode(this.y4g_1, descriptor);
  this.a4h_1.h4h_1.r4l(descriptor);
  this.a4h_1.z4n(newMode.k4o_1);
  checkLeadingComma(this);
  var tmp;
  switch (newMode.aa_1) {
    case 1:
    case 2:
    case 3:
      tmp = new StreamingJsonDecoder(this.y4g_1, newMode, this.a4h_1, descriptor, this.d4h_1);
      break;
    default:
      var tmp_0;
      if (this.z4g_1.equals(newMode) ? this.y4g_1.s4g_1.h4i_1 : false) {
        tmp_0 = this;
      } else {
        tmp_0 = new StreamingJsonDecoder(this.y4g_1, newMode, this.a4h_1, descriptor, this.d4h_1);
      }

      tmp = tmp_0;
      break;
  }
  return tmp;
};
protoOf(StreamingJsonDecoder).n3u = function (descriptor) {
  if (this.y4g_1.s4g_1.d4i_1 ? descriptor.s3s() === 0 : false) {
    skipLeftoverElements(this, descriptor);
  }
  if (this.a4h_1.a4o() ? !this.y4g_1.s4g_1.q4i_1 : false) {
    invalidTrailingComma(this.a4h_1, '');
  }
  this.a4h_1.z4n(this.z4g_1.l4o_1);
  this.a4h_1.h4h_1.v4l();
};
protoOf(StreamingJsonDecoder).y3t = function () {
  var tmp;
  var tmp0_safe_receiver = this.f4h_1;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.h4l_1;
  if (!(tmp1_elvis_lhs == null ? false : tmp1_elvis_lhs)) {
    tmp = !this.a4h_1.m4o();
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(StreamingJsonDecoder).z3t = function () {
  return null;
};
protoOf(StreamingJsonDecoder).y3u = function (descriptor, index, deserializer, previousValue) {
  var isMapKey = this.z4g_1.equals(WriteMode_MAP_getInstance()) ? (index & 1) === 0 : false;
  if (isMapKey) {
    this.a4h_1.h4h_1.u4l();
  }
  var value = protoOf(AbstractDecoder).y3u.call(this, descriptor, index, deserializer, previousValue);
  if (isMapKey) {
    this.a4h_1.h4h_1.t4l(value);
  }
  return value;
};
protoOf(StreamingJsonDecoder).c3v = function (descriptor) {
  var index;
  switch (this.z4g_1.aa_1) {
    case 0:
      index = decodeObjectIndex(this, descriptor);
      break;
    case 2:
      index = decodeMapIndex(this);
      break;
    default:
      index = decodeListIndex(this);
      break;
  }
  if (!this.z4g_1.equals(WriteMode_MAP_getInstance())) {
    this.a4h_1.h4h_1.s4l(index);
  }
  return index;
};
protoOf(StreamingJsonDecoder).a3u = function () {
  return this.a4h_1.n4o();
};
protoOf(StreamingJsonDecoder).b3u = function () {
  var value = this.a4h_1.g4j();
  if (!value.equals(toLong(value.zb()))) {
    this.a4h_1.j4l("Failed to parse byte for input '" + value.toString() + "'");
  }
  return value.zb();
};
protoOf(StreamingJsonDecoder).c3u = function () {
  var value = this.a4h_1.g4j();
  if (!value.equals(toLong(value.ac()))) {
    this.a4h_1.j4l("Failed to parse short for input '" + value.toString() + "'");
  }
  return value.ac();
};
protoOf(StreamingJsonDecoder).d3u = function () {
  var value = this.a4h_1.g4j();
  if (!value.equals(toLong(value.ra()))) {
    this.a4h_1.j4l("Failed to parse int for input '" + value.toString() + "'");
  }
  return value.ra();
};
protoOf(StreamingJsonDecoder).e3u = function () {
  return this.a4h_1.g4j();
};
protoOf(StreamingJsonDecoder).f3u = function () {
  var tmp$ret$4;
  $l$block: {
    // Inline function 'kotlinx.serialization.json.internal.parseString' call
    var this_0 = this.a4h_1;
    var input = this_0.n4m();
    try {
      // Inline function 'kotlinx.serialization.json.internal.StreamingJsonDecoder.decodeFloat.<anonymous>' call
      // Inline function 'kotlin.text.toFloat' call
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp$ret$4 = toDouble(input);
      break $l$block;
    } catch ($p) {
      if ($p instanceof IllegalArgumentException) {
        var e = $p;
        this_0.j4l("Failed to parse type '" + 'float' + "' for input '" + input + "'");
      } else {
        throw $p;
      }
    }
  }
  var result = tmp$ret$4;
  var specialFp = this.y4g_1.s4g_1.m4i_1;
  if (specialFp ? true : isFinite(result))
    return result;
  throwInvalidFloatingPointDecoded(this.a4h_1, result);
};
protoOf(StreamingJsonDecoder).g3u = function () {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlinx.serialization.json.internal.parseString' call
    var this_0 = this.a4h_1;
    var input = this_0.n4m();
    try {
      // Inline function 'kotlinx.serialization.json.internal.StreamingJsonDecoder.decodeDouble.<anonymous>' call
      tmp$ret$1 = toDouble(input);
      break $l$block;
    } catch ($p) {
      if ($p instanceof IllegalArgumentException) {
        var e = $p;
        this_0.j4l("Failed to parse type '" + 'double' + "' for input '" + input + "'");
      } else {
        throw $p;
      }
    }
  }
  var result = tmp$ret$1;
  var specialFp = this.y4g_1.s4g_1.m4i_1;
  if (specialFp ? true : isFinite_0(result))
    return result;
  throwInvalidFloatingPointDecoded(this.a4h_1, result);
};
protoOf(StreamingJsonDecoder).h3u = function () {
  var string = this.a4h_1.n4m();
  if (!(string.length === 1)) {
    this.a4h_1.j4l("Expected single char, but got '" + string + "'");
  }
  return charSequenceGet(string, 0);
};
protoOf(StreamingJsonDecoder).i3u = function () {
  var tmp;
  if (this.e4h_1.e4i_1) {
    tmp = this.a4h_1.g4o();
  } else {
    tmp = this.a4h_1.m4m();
  }
  return tmp;
};
protoOf(StreamingJsonDecoder).k3u = function (descriptor) {
  return get_isUnsignedNumber(descriptor) ? new JsonDecoderForUnsignedTypes(this.a4h_1, this.y4g_1) : protoOf(AbstractDecoder).k3u.call(this, descriptor);
};
protoOf(StreamingJsonDecoder).j3u = function (enumDescriptor) {
  return getJsonNameIndexOrThrow(enumDescriptor, this.y4g_1, this.i3u(), ' at path ' + this.a4h_1.h4h_1.w4l());
};
function JsonDecoderForUnsignedTypes(lexer, json) {
  AbstractDecoder.call(this);
  this.o4o_1 = lexer;
  this.p4o_1 = json.k3r();
}
protoOf(JsonDecoderForUnsignedTypes).k3r = function () {
  return this.p4o_1;
};
protoOf(JsonDecoderForUnsignedTypes).c3v = function (descriptor) {
  var message = 'unsupported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(JsonDecoderForUnsignedTypes).d3u = function () {
  var tmp$ret$2;
  $l$block: {
    // Inline function 'kotlinx.serialization.json.internal.parseString' call
    var this_0 = this.o4o_1;
    var input = this_0.n4m();
    try {
      // Inline function 'kotlinx.serialization.json.internal.JsonDecoderForUnsignedTypes.decodeInt.<anonymous>' call
      // Inline function 'kotlin.UInt.toInt' call
      var this_1 = toUInt(input);
      tmp$ret$2 = _UInt___get_data__impl__f0vqqw(this_1);
      break $l$block;
    } catch ($p) {
      if ($p instanceof IllegalArgumentException) {
        var e = $p;
        this_0.j4l("Failed to parse type '" + 'UInt' + "' for input '" + input + "'");
      } else {
        throw $p;
      }
    }
  }
  return tmp$ret$2;
};
protoOf(JsonDecoderForUnsignedTypes).e3u = function () {
  var tmp$ret$2;
  $l$block: {
    // Inline function 'kotlinx.serialization.json.internal.parseString' call
    var this_0 = this.o4o_1;
    var input = this_0.n4m();
    try {
      // Inline function 'kotlinx.serialization.json.internal.JsonDecoderForUnsignedTypes.decodeLong.<anonymous>' call
      // Inline function 'kotlin.ULong.toLong' call
      var this_1 = toULong(input);
      tmp$ret$2 = _ULong___get_data__impl__fggpzb(this_1);
      break $l$block;
    } catch ($p) {
      if ($p instanceof IllegalArgumentException) {
        var e = $p;
        this_0.j4l("Failed to parse type '" + 'ULong' + "' for input '" + input + "'");
      } else {
        throw $p;
      }
    }
  }
  return tmp$ret$2;
};
protoOf(JsonDecoderForUnsignedTypes).b3u = function () {
  var tmp$ret$2;
  $l$block: {
    // Inline function 'kotlinx.serialization.json.internal.parseString' call
    var this_0 = this.o4o_1;
    var input = this_0.n4m();
    try {
      // Inline function 'kotlinx.serialization.json.internal.JsonDecoderForUnsignedTypes.decodeByte.<anonymous>' call
      // Inline function 'kotlin.UByte.toByte' call
      var this_1 = toUByte(input);
      tmp$ret$2 = _UByte___get_data__impl__jof9qr(this_1);
      break $l$block;
    } catch ($p) {
      if ($p instanceof IllegalArgumentException) {
        var e = $p;
        this_0.j4l("Failed to parse type '" + 'UByte' + "' for input '" + input + "'");
      } else {
        throw $p;
      }
    }
  }
  return tmp$ret$2;
};
protoOf(JsonDecoderForUnsignedTypes).c3u = function () {
  var tmp$ret$2;
  $l$block: {
    // Inline function 'kotlinx.serialization.json.internal.parseString' call
    var this_0 = this.o4o_1;
    var input = this_0.n4m();
    try {
      // Inline function 'kotlinx.serialization.json.internal.JsonDecoderForUnsignedTypes.decodeShort.<anonymous>' call
      // Inline function 'kotlin.UShort.toShort' call
      var this_1 = toUShort(input);
      tmp$ret$2 = _UShort___get_data__impl__g0245(this_1);
      break $l$block;
    } catch ($p) {
      if ($p instanceof IllegalArgumentException) {
        var e = $p;
        this_0.j4l("Failed to parse type '" + 'UShort' + "' for input '" + input + "'");
      } else {
        throw $p;
      }
    }
  }
  return tmp$ret$2;
};
function get_unsignedNumberDescriptors() {
  _init_properties_StreamingJsonEncoder_kt__pn1bsi();
  return unsignedNumberDescriptors;
}
var unsignedNumberDescriptors;
function StreamingJsonEncoder_init_$Init$(output, json, mode, modeReuseCache, $this) {
  StreamingJsonEncoder.call($this, Composer_0(output, json), json, mode, modeReuseCache);
  return $this;
}
function StreamingJsonEncoder_init_$Create$(output, json, mode, modeReuseCache) {
  return StreamingJsonEncoder_init_$Init$(output, json, mode, modeReuseCache, objectCreate(protoOf(StreamingJsonEncoder)));
}
function encodeTypeInfo($this, descriptor) {
  $this.x4l_1.f4k();
  $this.p3v(ensureNotNull($this.e4m_1));
  $this.x4l_1.i4k(get_COLON());
  $this.x4l_1.h4k();
  $this.p3v(descriptor.e3s());
}
function StreamingJsonEncoder(composer, json, mode, modeReuseCache) {
  AbstractEncoder.call(this);
  this.x4l_1 = composer;
  this.y4l_1 = json;
  this.z4l_1 = mode;
  this.a4m_1 = modeReuseCache;
  this.b4m_1 = this.y4l_1.k3r();
  this.c4m_1 = this.y4l_1.s4g_1;
  this.d4m_1 = false;
  this.e4m_1 = null;
  var i = this.z4l_1.aa_1;
  if (!(this.a4m_1 == null)) {
    if (!(this.a4m_1[i] === null) ? true : !(this.a4m_1[i] === this)) {
      this.a4m_1[i] = this;
    }
  }
}
protoOf(StreamingJsonEncoder).s4i = function () {
  return this.y4l_1;
};
protoOf(StreamingJsonEncoder).k3r = function () {
  return this.b4m_1;
};
protoOf(StreamingJsonEncoder).a4k = function (element) {
  this.l3r(JsonElementSerializer_getInstance(), element);
};
protoOf(StreamingJsonEncoder).h3w = function (descriptor, index) {
  return this.c4m_1.c4i_1;
};
protoOf(StreamingJsonEncoder).l3r = function (serializer, value) {
  $l$block: {
    // Inline function 'kotlinx.serialization.json.internal.encodePolymorphically' call
    if (this.s4i().s4g_1.k4i_1) {
      serializer.m3r(this, value);
      break $l$block;
    }
    var isPolymorphicSerializer = serializer instanceof AbstractPolymorphicSerializer;
    var tmp;
    if (isPolymorphicSerializer) {
      tmp = !this.s4i().s4g_1.r4i_1.equals(ClassDiscriminatorMode_NONE_getInstance());
    } else {
      var tmp_0;
      switch (this.s4i().s4g_1.r4i_1.aa_1) {
        case 0:
        case 2:
          tmp_0 = false;
          break;
        case 1:
          // Inline function 'kotlin.let' call

          // Inline function 'kotlin.contracts.contract' call

          // Inline function 'kotlinx.serialization.json.internal.encodePolymorphically.<anonymous>' call

          var it = serializer.z3q().u3s();
          tmp_0 = equals(it, CLASS_getInstance()) ? true : equals(it, OBJECT_getInstance());
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
      tmp = tmp_0;
    }
    var needDiscriminator = tmp;
    var baseClassDiscriminator = needDiscriminator ? classDiscriminator(serializer.z3q(), this.s4i()) : null;
    var tmp_1;
    if (isPolymorphicSerializer) {
      var casted = serializer instanceof AbstractPolymorphicSerializer ? serializer : THROW_CCE();
      $l$block_0: {
        // Inline function 'kotlin.requireNotNull' call
        // Inline function 'kotlin.contracts.contract' call
        if (value == null) {
          // Inline function 'kotlinx.serialization.json.internal.encodePolymorphically.<anonymous>' call
          var message = 'Value for serializer ' + serializer.z3q() + ' should always be non-null. Please report issue to the kotlinx.serialization tracker.';
          throw IllegalArgumentException_init_$Create$(toString(message));
        } else {
          break $l$block_0;
        }
      }
      var actual = findPolymorphicSerializer_0(casted, this, value);
      if (!(baseClassDiscriminator == null)) {
        validateIfSealed$accessor$1ad0flx(serializer, actual, baseClassDiscriminator);
      }
      checkKind(actual.z3q().u3s());
      tmp_1 = isInterface(actual, SerializationStrategy) ? actual : THROW_CCE();
    } else {
      tmp_1 = serializer;
    }
    var actualSerializer = tmp_1;
    if (!(baseClassDiscriminator == null)) {
      // Inline function 'kotlinx.serialization.json.internal.StreamingJsonEncoder.encodeSerializableValue.<anonymous>' call
      this.e4m_1 = baseClassDiscriminator;
    }
    actualSerializer.m3r(this, value);
  }
};
protoOf(StreamingJsonEncoder).m3u = function (descriptor) {
  var newMode = switchMode(this.y4l_1, descriptor);
  if (!(newMode.k4o_1 === get_INVALID())) {
    this.x4l_1.i4k(newMode.k4o_1);
    this.x4l_1.d4k();
  }
  if (!(this.e4m_1 == null)) {
    encodeTypeInfo(this, descriptor);
    this.e4m_1 = null;
  }
  if (this.z4l_1.equals(newMode)) {
    return this;
  }
  var tmp0_safe_receiver = this.a4m_1;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver[newMode.aa_1];
  return tmp1_elvis_lhs == null ? new StreamingJsonEncoder(this.x4l_1, this.y4l_1, newMode, this.a4m_1) : tmp1_elvis_lhs;
};
protoOf(StreamingJsonEncoder).n3u = function (descriptor) {
  if (!(this.z4l_1.l4o_1 === get_INVALID())) {
    this.x4l_1.e4k();
    this.x4l_1.g4k();
    this.x4l_1.i4k(this.z4l_1.l4o_1);
  }
};
protoOf(StreamingJsonEncoder).e3v = function (descriptor, index) {
  switch (this.z4l_1.aa_1) {
    case 1:
      if (!this.x4l_1.c4k_1) {
        this.x4l_1.i4k(get_COMMA());
      }

      this.x4l_1.f4k();
      break;
    case 2:
      if (!this.x4l_1.c4k_1) {
        var tmp = this;
        var tmp_0;
        if ((index % 2 | 0) === 0) {
          this.x4l_1.i4k(get_COMMA());
          this.x4l_1.f4k();
          tmp_0 = true;
        } else {
          this.x4l_1.i4k(get_COLON());
          this.x4l_1.h4k();
          tmp_0 = false;
        }
        tmp.d4m_1 = tmp_0;
      } else {
        this.d4m_1 = true;
        this.x4l_1.f4k();
      }

      break;
    case 3:
      if (index === 0)
        this.d4m_1 = true;
      if (index === 1) {
        this.x4l_1.i4k(get_COMMA());
        this.x4l_1.h4k();
        this.d4m_1 = false;
      }

      break;
    default:
      if (!this.x4l_1.c4k_1) {
        this.x4l_1.i4k(get_COMMA());
      }

      this.x4l_1.f4k();
      this.p3v(getJsonElementName(descriptor, this.y4l_1, index));
      this.x4l_1.i4k(get_COLON());
      this.x4l_1.h4k();
      break;
  }
  return true;
};
protoOf(StreamingJsonEncoder).d3w = function (descriptor, index, serializer, value) {
  if (!(value == null) ? true : this.c4m_1.h4i_1) {
    protoOf(AbstractEncoder).d3w.call(this, descriptor, index, serializer, value);
  }
};
protoOf(StreamingJsonEncoder).r3v = function (descriptor) {
  var tmp;
  if (get_isUnsignedNumber(descriptor)) {
    // Inline function 'kotlinx.serialization.json.internal.StreamingJsonEncoder.composerAs' call
    var tmp_0;
    var tmp_1 = this.x4l_1;
    if (tmp_1 instanceof ComposerForUnsignedNumbers) {
      tmp_0 = this.x4l_1;
    } else {
      tmp_0 = new ComposerForUnsignedNumbers(this.x4l_1.b4k_1, this.d4m_1);
    }
    var tmp$ret$1 = tmp_0;
    tmp = new StreamingJsonEncoder(tmp$ret$1, this.y4l_1, this.z4l_1, null);
  } else if (get_isUnquotedLiteral(descriptor)) {
    // Inline function 'kotlinx.serialization.json.internal.StreamingJsonEncoder.composerAs' call
    var tmp_2;
    var tmp_3 = this.x4l_1;
    if (tmp_3 instanceof ComposerForUnquotedLiterals) {
      tmp_2 = this.x4l_1;
    } else {
      tmp_2 = new ComposerForUnquotedLiterals(this.x4l_1.b4k_1, this.d4m_1);
    }
    var tmp$ret$3 = tmp_2;
    tmp = new StreamingJsonEncoder(tmp$ret$3, this.y4l_1, this.z4l_1, null);
  } else {
    tmp = protoOf(AbstractEncoder).r3v.call(this, descriptor);
  }
  return tmp;
};
protoOf(StreamingJsonEncoder).g3v = function () {
  this.x4l_1.k4k(get_NULL());
};
protoOf(StreamingJsonEncoder).h3v = function (value) {
  if (this.d4m_1) {
    this.p3v(value.toString());
  } else {
    this.x4l_1.t4k(value);
  }
};
protoOf(StreamingJsonEncoder).i3v = function (value) {
  if (this.d4m_1) {
    this.p3v(value.toString());
  } else {
    this.x4l_1.o4k(value);
  }
};
protoOf(StreamingJsonEncoder).j3v = function (value) {
  if (this.d4m_1) {
    this.p3v(value.toString());
  } else {
    this.x4l_1.q4k(value);
  }
};
protoOf(StreamingJsonEncoder).k3v = function (value) {
  if (this.d4m_1) {
    this.p3v(value.toString());
  } else {
    this.x4l_1.r4k(value);
  }
};
protoOf(StreamingJsonEncoder).l3v = function (value) {
  if (this.d4m_1) {
    this.p3v(value.toString());
  } else {
    this.x4l_1.s4k(value);
  }
};
protoOf(StreamingJsonEncoder).m3v = function (value) {
  if (this.d4m_1) {
    this.p3v(value.toString());
  } else {
    this.x4l_1.m4k(value);
  }
  if (!this.c4m_1.m4i_1 ? !isFinite(value) : false) {
    throw InvalidFloatingPointEncoded_0(value, toString(this.x4l_1.b4k_1));
  }
};
protoOf(StreamingJsonEncoder).n3v = function (value) {
  if (this.d4m_1) {
    this.p3v(value.toString());
  } else {
    this.x4l_1.n4k(value);
  }
  if (!this.c4m_1.m4i_1 ? !isFinite_0(value) : false) {
    throw InvalidFloatingPointEncoded_0(value, toString(this.x4l_1.b4k_1));
  }
};
protoOf(StreamingJsonEncoder).o3v = function (value) {
  this.p3v(toString_0(value));
};
protoOf(StreamingJsonEncoder).p3v = function (value) {
  return this.x4l_1.u4k(value);
};
protoOf(StreamingJsonEncoder).q3v = function (enumDescriptor, index) {
  this.p3v(enumDescriptor.y3s(index));
};
function get_isUnsignedNumber(_this__u8e3s4) {
  _init_properties_StreamingJsonEncoder_kt__pn1bsi();
  return _this__u8e3s4.t3s() ? get_unsignedNumberDescriptors().z(_this__u8e3s4) : false;
}
function get_isUnquotedLiteral(_this__u8e3s4) {
  _init_properties_StreamingJsonEncoder_kt__pn1bsi();
  return _this__u8e3s4.t3s() ? equals(_this__u8e3s4, get_jsonUnquotedLiteralDescriptor()) : false;
}
var properties_initialized_StreamingJsonEncoder_kt_6ifwwk;
function _init_properties_StreamingJsonEncoder_kt__pn1bsi() {
  if (!properties_initialized_StreamingJsonEncoder_kt_6ifwwk) {
    properties_initialized_StreamingJsonEncoder_kt_6ifwwk = true;
    unsignedNumberDescriptors = setOf([serializer_1(Companion_getInstance_0()).z3q(), serializer_0(Companion_getInstance()).z3q(), serializer_2(Companion_getInstance_1()).z3q(), serializer_3(Companion_getInstance_2()).z3q()]);
  }
}
function get_ESCAPE_STRINGS() {
  _init_properties_StringOps_kt__fcy1db();
  return ESCAPE_STRINGS;
}
var ESCAPE_STRINGS;
var ESCAPE_MARKERS;
function toHexChar(i) {
  _init_properties_StringOps_kt__fcy1db();
  var d = i & 15;
  var tmp;
  if (d < 10) {
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(48);
    var tmp$ret$0 = Char__toInt_impl_vasixd(this_0);
    tmp = numberToChar(d + tmp$ret$0 | 0);
  } else {
    var tmp_0 = d - 10 | 0;
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(97);
    var tmp$ret$1 = Char__toInt_impl_vasixd(this_1);
    tmp = numberToChar(tmp_0 + tmp$ret$1 | 0);
  }
  return tmp;
}
function printQuoted(_this__u8e3s4, value) {
  _init_properties_StringOps_kt__fcy1db();
  _this__u8e3s4.o5(get_STRING());
  var lastPos = 0;
  var inductionVariable = 0;
  var last = charSequenceLength(value) - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.code' call
      var this_0 = charSequenceGet(value, i);
      var c = Char__toInt_impl_vasixd(this_0);
      if (c < get_ESCAPE_STRINGS().length ? !(get_ESCAPE_STRINGS()[c] == null) : false) {
        _this__u8e3s4.e8(value, lastPos, i);
        _this__u8e3s4.n5(get_ESCAPE_STRINGS()[c]);
        lastPos = i + 1 | 0;
      }
    }
     while (inductionVariable <= last);
  if (!(lastPos === 0)) {
    _this__u8e3s4.e8(value, lastPos, value.length);
  } else {
    _this__u8e3s4.n5(value);
  }
  _this__u8e3s4.o5(get_STRING());
}
function toBooleanStrictOrNull_0(_this__u8e3s4) {
  _init_properties_StringOps_kt__fcy1db();
  return equals_0(_this__u8e3s4, 'true', true) ? true : equals_0(_this__u8e3s4, 'false', true) ? false : null;
}
var properties_initialized_StringOps_kt_wzaea7;
function _init_properties_StringOps_kt__fcy1db() {
  if (!properties_initialized_StringOps_kt_wzaea7) {
    properties_initialized_StringOps_kt_wzaea7 = true;
    // Inline function 'kotlin.apply' call
    // Inline function 'kotlin.arrayOfNulls' call
    var this_0 = fillArrayVal(Array(93), null);
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.serialization.json.internal.ESCAPE_STRINGS.<anonymous>' call
    var inductionVariable = 0;
    if (inductionVariable <= 31)
      do {
        var c = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var c1 = toHexChar(c >> 12);
        var c2 = toHexChar(c >> 8);
        var c3 = toHexChar(c >> 4);
        var c4 = toHexChar(c);
        this_0[c] = '\\u' + toString_0(c1) + toString_0(c2) + toString_0(c3) + toString_0(c4);
      }
       while (inductionVariable <= 31);
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(34);
    this_0[Char__toInt_impl_vasixd(this_1)] = '\\"';
    // Inline function 'kotlin.code' call
    var this_2 = _Char___init__impl__6a9atx(92);
    this_0[Char__toInt_impl_vasixd(this_2)] = '\\\\';
    // Inline function 'kotlin.code' call
    var this_3 = _Char___init__impl__6a9atx(9);
    this_0[Char__toInt_impl_vasixd(this_3)] = '\\t';
    // Inline function 'kotlin.code' call
    var this_4 = _Char___init__impl__6a9atx(8);
    this_0[Char__toInt_impl_vasixd(this_4)] = '\\b';
    // Inline function 'kotlin.code' call
    var this_5 = _Char___init__impl__6a9atx(10);
    this_0[Char__toInt_impl_vasixd(this_5)] = '\\n';
    // Inline function 'kotlin.code' call
    var this_6 = _Char___init__impl__6a9atx(13);
    this_0[Char__toInt_impl_vasixd(this_6)] = '\\r';
    this_0[12] = '\\f';
    ESCAPE_STRINGS = this_0;
    // Inline function 'kotlin.apply' call
    var this_7 = new Int8Array(93);
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.serialization.json.internal.ESCAPE_MARKERS.<anonymous>' call
    var inductionVariable_0 = 0;
    if (inductionVariable_0 <= 31)
      do {
        var c_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        this_7[c_0] = 1;
      }
       while (inductionVariable_0 <= 31);
    // Inline function 'kotlin.code' call
    var this_8 = _Char___init__impl__6a9atx(34);
    this_7[Char__toInt_impl_vasixd(this_8)] = 34;
    // Inline function 'kotlin.code' call
    var this_9 = _Char___init__impl__6a9atx(92);
    this_7[Char__toInt_impl_vasixd(this_9)] = 92;
    // Inline function 'kotlin.code' call
    var this_10 = _Char___init__impl__6a9atx(9);
    this_7[Char__toInt_impl_vasixd(this_10)] = 116;
    // Inline function 'kotlin.code' call
    var this_11 = _Char___init__impl__6a9atx(8);
    this_7[Char__toInt_impl_vasixd(this_11)] = 98;
    // Inline function 'kotlin.code' call
    var this_12 = _Char___init__impl__6a9atx(10);
    this_7[Char__toInt_impl_vasixd(this_12)] = 110;
    // Inline function 'kotlin.code' call
    var this_13 = _Char___init__impl__6a9atx(13);
    this_7[Char__toInt_impl_vasixd(this_13)] = 114;
    this_7[12] = 102;
    ESCAPE_MARKERS = this_7;
  }
}
function unparsedPrimitive($this, primitive) {
  throw JsonDecodingException_0(-1, "Failed to parse literal as '" + primitive + "' value", toString($this.v4o()));
}
function asLiteral(_this__u8e3s4, $this, type) {
  var tmp0_elvis_lhs = _this__u8e3s4 instanceof JsonLiteral ? _this__u8e3s4 : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw JsonDecodingException_1(-1, "Unexpected 'null' literal when non-nullable " + type + ' was expected');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function AbstractJsonTreeDecoder(json, value) {
  NamedValueDecoder.call(this);
  this.s4o_1 = json;
  this.t4o_1 = value;
  this.u4o_1 = this.s4i().s4g_1;
}
protoOf(AbstractJsonTreeDecoder).s4i = function () {
  return this.s4o_1;
};
protoOf(AbstractJsonTreeDecoder).l2 = function () {
  return this.t4o_1;
};
protoOf(AbstractJsonTreeDecoder).k3r = function () {
  return this.s4i().k3r();
};
protoOf(AbstractJsonTreeDecoder).v4o = function () {
  var tmp0_safe_receiver = this.m48();
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.currentObject.<anonymous>' call
    tmp = this.w4o(tmp0_safe_receiver);
  }
  var tmp1_elvis_lhs = tmp;
  return tmp1_elvis_lhs == null ? this.l2() : tmp1_elvis_lhs;
};
protoOf(AbstractJsonTreeDecoder).t4i = function () {
  return this.v4o();
};
protoOf(AbstractJsonTreeDecoder).o3r = function (deserializer) {
  return decodeSerializableValuePolymorphic(this, deserializer);
};
protoOf(AbstractJsonTreeDecoder).n48 = function (parentName, childName) {
  return childName;
};
protoOf(AbstractJsonTreeDecoder).m3u = function (descriptor) {
  var currentObject = this.v4o();
  var tmp0_subject = descriptor.u3s();
  var tmp;
  var tmp_0;
  if (equals(tmp0_subject, LIST_getInstance())) {
    tmp_0 = true;
  } else {
    tmp_0 = tmp0_subject instanceof PolymorphicKind;
  }
  if (tmp_0) {
    var tmp_1 = this.s4i();
    // Inline function 'kotlinx.serialization.json.internal.cast' call
    if (!(currentObject instanceof JsonArray)) {
      throw JsonDecodingException_1(-1, 'Expected ' + getKClass(JsonArray) + ' as the serialized body of ' + descriptor.e3s() + ', but had ' + getKClassFromExpression(currentObject));
    }
    tmp = new JsonTreeListDecoder(tmp_1, currentObject);
  } else {
    if (equals(tmp0_subject, MAP_getInstance())) {
      // Inline function 'kotlinx.serialization.json.internal.selectMapMode' call
      var this_0 = this.s4i();
      var keyDescriptor = carrierDescriptor(descriptor.w3s(0), this_0.k3r());
      var keyKind = keyDescriptor.u3s();
      var tmp_2;
      var tmp_3;
      if (keyKind instanceof PrimitiveKind) {
        tmp_3 = true;
      } else {
        tmp_3 = equals(keyKind, ENUM_getInstance());
      }
      if (tmp_3) {
        // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.beginStructure.<anonymous>' call
        var tmp_4 = this.s4i();
        // Inline function 'kotlinx.serialization.json.internal.cast' call
        if (!(currentObject instanceof JsonObject)) {
          throw JsonDecodingException_1(-1, 'Expected ' + getKClass(JsonObject) + ' as the serialized body of ' + descriptor.e3s() + ', but had ' + getKClassFromExpression(currentObject));
        }
        tmp_2 = new JsonTreeMapDecoder(tmp_4, currentObject);
      } else {
        if (this_0.s4g_1.f4i_1) {
          // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.beginStructure.<anonymous>' call
          var tmp_5 = this.s4i();
          // Inline function 'kotlinx.serialization.json.internal.cast' call
          if (!(currentObject instanceof JsonArray)) {
            throw JsonDecodingException_1(-1, 'Expected ' + getKClass(JsonArray) + ' as the serialized body of ' + descriptor.e3s() + ', but had ' + getKClassFromExpression(currentObject));
          }
          tmp_2 = new JsonTreeListDecoder(tmp_5, currentObject);
        } else {
          throw InvalidKeyKindException(keyDescriptor);
        }
      }
      tmp = tmp_2;
    } else {
      var tmp_6 = this.s4i();
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      if (!(currentObject instanceof JsonObject)) {
        throw JsonDecodingException_1(-1, 'Expected ' + getKClass(JsonObject) + ' as the serialized body of ' + descriptor.e3s() + ', but had ' + getKClassFromExpression(currentObject));
      }
      tmp = new JsonTreeDecoder(tmp_6, currentObject);
    }
  }
  return tmp;
};
protoOf(AbstractJsonTreeDecoder).n3u = function (descriptor) {
};
protoOf(AbstractJsonTreeDecoder).y3t = function () {
  var tmp = this.v4o();
  return !(tmp instanceof JsonNull);
};
protoOf(AbstractJsonTreeDecoder).x4o = function (tag) {
  var currentElement = this.w4o(tag);
  var tmp0_elvis_lhs = currentElement instanceof JsonPrimitive ? currentElement : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw JsonDecodingException_0(-1, 'Expected JsonPrimitive at ' + tag + ', found ' + currentElement, toString(this.v4o()));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
protoOf(AbstractJsonTreeDecoder).y4o = function (tag, enumDescriptor) {
  return getJsonNameIndexOrThrow(enumDescriptor, this.s4i(), this.x4o(tag).e2l());
};
protoOf(AbstractJsonTreeDecoder).v49 = function (tag, enumDescriptor) {
  return this.y4o((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), enumDescriptor);
};
protoOf(AbstractJsonTreeDecoder).z4o = function (tag) {
  return !(this.w4o(tag) === JsonNull_getInstance());
};
protoOf(AbstractJsonTreeDecoder).l49 = function (tag) {
  return this.z4o((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
};
protoOf(AbstractJsonTreeDecoder).a4p = function (tag) {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.primitive' call
    var this_0 = this.x4o(tag);
    try {
      var tmp0_elvis_lhs = get_booleanOrNull(this_0);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        unparsedPrimitive(this, 'boolean');
      } else {
        tmp = tmp0_elvis_lhs;
      }
      tmp$ret$1 = tmp;
      break $l$block;
    } catch ($p) {
      if ($p instanceof IllegalArgumentException) {
        var e = $p;
        unparsedPrimitive(this, 'boolean');
      } else {
        throw $p;
      }
    }
  }
  return tmp$ret$1;
};
protoOf(AbstractJsonTreeDecoder).m49 = function (tag) {
  return this.a4p((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
};
protoOf(AbstractJsonTreeDecoder).b4p = function (tag) {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.primitive' call
    var this_0 = this.x4o(tag);
    try {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.decodeTaggedByte.<anonymous>' call
      var result = get_int(this_0);
      var tmp;
      var containsLower = ByteCompanionObject_instance.MIN_VALUE;
      if (result <= ByteCompanionObject_instance.MAX_VALUE ? containsLower <= result : false) {
        tmp = toByte(result);
      } else {
        tmp = null;
      }
      var tmp0_elvis_lhs = tmp;
      var tmp_0;
      if (tmp0_elvis_lhs == null) {
        unparsedPrimitive(this, 'byte');
      } else {
        tmp_0 = tmp0_elvis_lhs;
      }
      tmp$ret$1 = tmp_0;
      break $l$block;
    } catch ($p) {
      if ($p instanceof IllegalArgumentException) {
        var e = $p;
        unparsedPrimitive(this, 'byte');
      } else {
        throw $p;
      }
    }
  }
  return tmp$ret$1;
};
protoOf(AbstractJsonTreeDecoder).n49 = function (tag) {
  return this.b4p((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
};
protoOf(AbstractJsonTreeDecoder).c4p = function (tag) {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.primitive' call
    var this_0 = this.x4o(tag);
    try {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.decodeTaggedShort.<anonymous>' call
      var result = get_int(this_0);
      var tmp;
      var containsLower = ShortCompanionObject_instance.MIN_VALUE;
      if (result <= ShortCompanionObject_instance.MAX_VALUE ? containsLower <= result : false) {
        tmp = toShort(result);
      } else {
        tmp = null;
      }
      var tmp0_elvis_lhs = tmp;
      var tmp_0;
      if (tmp0_elvis_lhs == null) {
        unparsedPrimitive(this, 'short');
      } else {
        tmp_0 = tmp0_elvis_lhs;
      }
      tmp$ret$1 = tmp_0;
      break $l$block;
    } catch ($p) {
      if ($p instanceof IllegalArgumentException) {
        var e = $p;
        unparsedPrimitive(this, 'short');
      } else {
        throw $p;
      }
    }
  }
  return tmp$ret$1;
};
protoOf(AbstractJsonTreeDecoder).o49 = function (tag) {
  return this.c4p((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
};
protoOf(AbstractJsonTreeDecoder).d4p = function (tag) {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.primitive' call
    var this_0 = this.x4o(tag);
    try {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.decodeTaggedInt.<anonymous>' call
      var tmp0_elvis_lhs = get_int(this_0);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        unparsedPrimitive(this, 'int');
      } else {
        tmp = tmp0_elvis_lhs;
      }
      tmp$ret$1 = tmp;
      break $l$block;
    } catch ($p) {
      if ($p instanceof IllegalArgumentException) {
        var e = $p;
        unparsedPrimitive(this, 'int');
      } else {
        throw $p;
      }
    }
  }
  return tmp$ret$1;
};
protoOf(AbstractJsonTreeDecoder).p49 = function (tag) {
  return this.d4p((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
};
protoOf(AbstractJsonTreeDecoder).e4p = function (tag) {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.primitive' call
    var this_0 = this.x4o(tag);
    try {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.decodeTaggedLong.<anonymous>' call
      var tmp0_elvis_lhs = get_long(this_0);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        unparsedPrimitive(this, 'long');
      } else {
        tmp = tmp0_elvis_lhs;
      }
      tmp$ret$1 = tmp;
      break $l$block;
    } catch ($p) {
      if ($p instanceof IllegalArgumentException) {
        var e = $p;
        unparsedPrimitive(this, 'long');
      } else {
        throw $p;
      }
    }
  }
  return tmp$ret$1;
};
protoOf(AbstractJsonTreeDecoder).q49 = function (tag) {
  return this.e4p((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
};
protoOf(AbstractJsonTreeDecoder).f4p = function (tag) {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.primitive' call
    var this_0 = this.x4o(tag);
    try {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.decodeTaggedFloat.<anonymous>' call
      var tmp0_elvis_lhs = get_float(this_0);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        unparsedPrimitive(this, 'float');
      } else {
        tmp = tmp0_elvis_lhs;
      }
      tmp$ret$1 = tmp;
      break $l$block;
    } catch ($p) {
      if ($p instanceof IllegalArgumentException) {
        var e = $p;
        unparsedPrimitive(this, 'float');
      } else {
        throw $p;
      }
    }
  }
  var result = tmp$ret$1;
  var specialFp = this.s4i().s4g_1.m4i_1;
  if (specialFp ? true : isFinite(result))
    return result;
  throw InvalidFloatingPointDecoded(result, tag, toString(this.v4o()));
};
protoOf(AbstractJsonTreeDecoder).r49 = function (tag) {
  return this.f4p((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
};
protoOf(AbstractJsonTreeDecoder).g4p = function (tag) {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.primitive' call
    var this_0 = this.x4o(tag);
    try {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.decodeTaggedDouble.<anonymous>' call
      var tmp0_elvis_lhs = get_double(this_0);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        unparsedPrimitive(this, 'double');
      } else {
        tmp = tmp0_elvis_lhs;
      }
      tmp$ret$1 = tmp;
      break $l$block;
    } catch ($p) {
      if ($p instanceof IllegalArgumentException) {
        var e = $p;
        unparsedPrimitive(this, 'double');
      } else {
        throw $p;
      }
    }
  }
  var result = tmp$ret$1;
  var specialFp = this.s4i().s4g_1.m4i_1;
  if (specialFp ? true : isFinite_0(result))
    return result;
  throw InvalidFloatingPointDecoded(result, tag, toString(this.v4o()));
};
protoOf(AbstractJsonTreeDecoder).s49 = function (tag) {
  return this.g4p((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
};
protoOf(AbstractJsonTreeDecoder).h4p = function (tag) {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.primitive' call
    var this_0 = this.x4o(tag);
    try {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.decodeTaggedChar.<anonymous>' call
      var tmp0_elvis_lhs = single(this_0.e2l());
      var tmp;
      var tmp_0 = tmp0_elvis_lhs;
      if ((tmp_0 == null ? null : new Char(tmp_0)) == null) {
        unparsedPrimitive(this, 'char');
      } else {
        tmp = tmp0_elvis_lhs;
      }
      tmp$ret$1 = tmp;
      break $l$block;
    } catch ($p) {
      if ($p instanceof IllegalArgumentException) {
        var e = $p;
        unparsedPrimitive(this, 'char');
      } else {
        throw $p;
      }
    }
  }
  return tmp$ret$1;
};
protoOf(AbstractJsonTreeDecoder).t49 = function (tag) {
  return this.h4p((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
};
protoOf(AbstractJsonTreeDecoder).i4p = function (tag) {
  var value = this.x4o(tag);
  if (!this.s4i().s4g_1.e4i_1) {
    var literal = asLiteral(value, this, 'string');
    if (!literal.d4j_1)
      throw JsonDecodingException_0(-1, "String literal for key '" + tag + "' should be quoted.\n" + get_lenientHint(), toString(this.v4o()));
  }
  if (value instanceof JsonNull)
    throw JsonDecodingException_0(-1, "Unexpected 'null' value instead of string literal", toString(this.v4o()));
  return value.e2l();
};
protoOf(AbstractJsonTreeDecoder).u49 = function (tag) {
  return this.i4p((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
};
protoOf(AbstractJsonTreeDecoder).j4p = function (tag, inlineDescriptor) {
  return get_isUnsignedNumber(inlineDescriptor) ? new JsonDecoderForUnsignedTypes(new StringJsonLexer(this.x4o(tag).e2l()), this.s4i()) : protoOf(NamedValueDecoder).w49.call(this, tag, inlineDescriptor);
};
protoOf(AbstractJsonTreeDecoder).w49 = function (tag, inlineDescriptor) {
  return this.j4p((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), inlineDescriptor);
};
protoOf(AbstractJsonTreeDecoder).k3u = function (descriptor) {
  return !(this.m48() == null) ? protoOf(NamedValueDecoder).k3u.call(this, descriptor) : (new JsonPrimitiveDecoder(this.s4i(), this.l2())).k3u(descriptor);
};
function coerceInputValue_0($this, descriptor, index, tag) {
  var tmp$ret$0;
  $l$block_3: {
    // Inline function 'kotlinx.serialization.json.internal.tryCoerceValue' call
    var this_0 = $this.s4i();
    if (!descriptor.z3s(index)) {
      tmp$ret$0 = false;
      break $l$block_3;
    }
    var elementDescriptor = descriptor.w3s(index);
    var tmp;
    if (!elementDescriptor.o3s()) {
      // Inline function 'kotlinx.serialization.json.internal.JsonTreeDecoder.coerceInputValue.<anonymous>' call
      var tmp_0 = $this.w4o(tag);
      tmp = tmp_0 instanceof JsonNull;
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$0 = true;
      break $l$block_3;
    }
    if (equals(elementDescriptor.u3s(), ENUM_getInstance())) {
      var tmp_1;
      if (elementDescriptor.o3s()) {
        // Inline function 'kotlinx.serialization.json.internal.JsonTreeDecoder.coerceInputValue.<anonymous>' call
        var tmp_2 = $this.w4o(tag);
        tmp_1 = tmp_2 instanceof JsonNull;
      } else {
        tmp_1 = false;
      }
      if (tmp_1) {
        tmp$ret$0 = false;
        break $l$block_3;
      }
      // Inline function 'kotlinx.serialization.json.internal.JsonTreeDecoder.coerceInputValue.<anonymous>' call
      var tmp_3 = $this.w4o(tag);
      var tmp0_safe_receiver = tmp_3 instanceof JsonPrimitive ? tmp_3 : null;
      var tmp0_elvis_lhs = tmp0_safe_receiver == null ? null : get_contentOrNull(tmp0_safe_receiver);
      var tmp_4;
      if (tmp0_elvis_lhs == null) {
        tmp$ret$0 = false;
        break $l$block_3;
      } else {
        tmp_4 = tmp0_elvis_lhs;
      }
      var enumValue = tmp_4;
      var enumIndex = getJsonNameIndex(elementDescriptor, this_0, enumValue);
      if (enumIndex === -3) {
        // Inline function 'kotlinx.serialization.json.internal.tryCoerceValue.<anonymous>' call
        tmp$ret$0 = true;
        break $l$block_3;
      }
    }
    tmp$ret$0 = false;
  }
  return tmp$ret$0;
}
function absenceIsNull($this, descriptor, index) {
  $this.t4p_1 = (!$this.s4i().s4g_1.h4i_1 ? !descriptor.z3s(index) : false) ? descriptor.w3s(index).o3s() : false;
  return $this.t4p_1;
}
function JsonTreeDecoder(json, value, polyDiscriminator, polyDescriptor) {
  polyDiscriminator = polyDiscriminator === VOID ? null : polyDiscriminator;
  polyDescriptor = polyDescriptor === VOID ? null : polyDescriptor;
  AbstractJsonTreeDecoder.call(this, json, value);
  this.p4p_1 = value;
  this.q4p_1 = polyDiscriminator;
  this.r4p_1 = polyDescriptor;
  this.s4p_1 = 0;
  this.t4p_1 = false;
}
protoOf(JsonTreeDecoder).l2 = function () {
  return this.p4p_1;
};
protoOf(JsonTreeDecoder).c3v = function (descriptor) {
  while (this.s4p_1 < descriptor.s3s()) {
    var tmp1 = this.s4p_1;
    this.s4p_1 = tmp1 + 1 | 0;
    var name = this.i48(descriptor, tmp1);
    var index = this.s4p_1 - 1 | 0;
    this.t4p_1 = false;
    var tmp;
    var tmp_0;
    // Inline function 'kotlin.collections.contains' call
    // Inline function 'kotlin.collections.containsKey' call
    var this_0 = this.l2();
    if ((isInterface(this_0, Map) ? this_0 : THROW_CCE()).p2(name)) {
      tmp_0 = true;
    } else {
      tmp_0 = absenceIsNull(this, descriptor, index);
    }
    if (tmp_0) {
      tmp = !this.u4o_1.j4i_1 ? true : !coerceInputValue_0(this, descriptor, index, name);
    } else {
      tmp = false;
    }
    if (tmp) {
      return index;
    }
  }
  return -1;
};
protoOf(JsonTreeDecoder).y3t = function () {
  return !this.t4p_1 ? protoOf(AbstractJsonTreeDecoder).y3t.call(this) : false;
};
protoOf(JsonTreeDecoder).j48 = function (descriptor, index) {
  var strategy = namingStrategy(descriptor, this.s4i());
  var baseName = descriptor.y3s(index);
  if (strategy == null) {
    if (!this.u4o_1.n4i_1)
      return baseName;
    if (this.l2().f2().z(baseName))
      return baseName;
  }
  var deserializationNamesMap_0 = deserializationNamesMap(this.s4i(), descriptor);
  // Inline function 'kotlin.collections.find' call
  var this_0 = this.l2().f2();
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.collections.firstOrNull' call
    var tmp0_iterator = this_0.u();
    while (tmp0_iterator.v()) {
      var element = tmp0_iterator.w();
      // Inline function 'kotlinx.serialization.json.internal.JsonTreeDecoder.elementName.<anonymous>' call
      if (deserializationNamesMap_0.s2(element) === index) {
        tmp$ret$1 = element;
        break $l$block;
      }
    }
    tmp$ret$1 = null;
  }
  var tmp0_safe_receiver = tmp$ret$1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    return tmp0_safe_receiver;
  }
  var fallbackName = strategy == null ? null : strategy.n4l(descriptor, index, baseName);
  return fallbackName == null ? baseName : fallbackName;
};
protoOf(JsonTreeDecoder).w4o = function (tag) {
  return getValue(this.l2(), tag);
};
protoOf(JsonTreeDecoder).m3u = function (descriptor) {
  if (descriptor === this.r4p_1) {
    var tmp = this.s4i();
    // Inline function 'kotlinx.serialization.json.internal.cast' call
    var value = this.v4o();
    var descriptor_0 = this.r4p_1;
    if (!(value instanceof JsonObject)) {
      throw JsonDecodingException_1(-1, 'Expected ' + getKClass(JsonObject) + ' as the serialized body of ' + descriptor_0.e3s() + ', but had ' + getKClassFromExpression(value));
    }
    return new JsonTreeDecoder(tmp, value, this.q4p_1, this.r4p_1);
  }
  return protoOf(AbstractJsonTreeDecoder).m3u.call(this, descriptor);
};
protoOf(JsonTreeDecoder).n3u = function (descriptor) {
  var tmp;
  if (this.u4o_1.d4i_1) {
    tmp = true;
  } else {
    var tmp_0 = descriptor.u3s();
    tmp = tmp_0 instanceof PolymorphicKind;
  }
  if (tmp)
    return Unit_instance;
  var strategy = namingStrategy(descriptor, this.s4i());
  var tmp_1;
  if (strategy == null ? !this.u4o_1.n4i_1 : false) {
    tmp_1 = jsonCachedSerialNames(descriptor);
  } else if (!(strategy == null)) {
    tmp_1 = deserializationNamesMap(this.s4i(), descriptor).f2();
  } else {
    var tmp_2 = jsonCachedSerialNames(descriptor);
    // Inline function 'kotlin.collections.orEmpty' call
    var tmp0_safe_receiver = get_schemaCache(this.s4i()).x4n(descriptor, get_JsonDeserializationNamesKey());
    var tmp0_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.f2();
    var tmp$ret$0 = tmp0_elvis_lhs == null ? emptySet() : tmp0_elvis_lhs;
    tmp_1 = plus_0(tmp_2, tmp$ret$0);
  }
  var names = tmp_1;
  var tmp1_iterator = this.l2().f2().u();
  while (tmp1_iterator.v()) {
    var key = tmp1_iterator.w();
    if (!names.z(key) ? !(key === this.q4p_1) : false) {
      throw UnknownKeyException(key, this.l2().toString());
    }
  }
};
function JsonTreeListDecoder(json, value) {
  AbstractJsonTreeDecoder.call(this, json, value);
  this.z4p_1 = value;
  this.a4q_1 = this.z4p_1.n();
  this.b4q_1 = -1;
}
protoOf(JsonTreeListDecoder).l2 = function () {
  return this.z4p_1;
};
protoOf(JsonTreeListDecoder).j48 = function (descriptor, index) {
  return index.toString();
};
protoOf(JsonTreeListDecoder).w4o = function (tag) {
  return this.z4p_1.f1(toInt(tag));
};
protoOf(JsonTreeListDecoder).c3v = function (descriptor) {
  while (this.b4q_1 < (this.a4q_1 - 1 | 0)) {
    this.b4q_1 = this.b4q_1 + 1 | 0;
    return this.b4q_1;
  }
  return -1;
};
function JsonPrimitiveDecoder(json, value) {
  AbstractJsonTreeDecoder.call(this, json, value);
  this.h4q_1 = value;
  this.e49(get_PRIMITIVE_TAG());
}
protoOf(JsonPrimitiveDecoder).l2 = function () {
  return this.h4q_1;
};
protoOf(JsonPrimitiveDecoder).c3v = function (descriptor) {
  return 0;
};
protoOf(JsonPrimitiveDecoder).w4o = function (tag) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(tag === get_PRIMITIVE_TAG())) {
    // Inline function 'kotlinx.serialization.json.internal.JsonPrimitiveDecoder.currentElement.<anonymous>' call
    var message = "This input can only handle primitives with '" + get_PRIMITIVE_TAG() + "' tag";
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  return this.h4q_1;
};
function JsonTreeMapDecoder(json, value) {
  JsonTreeDecoder.call(this, json, value);
  this.s4q_1 = value;
  this.t4q_1 = toList(this.s4q_1.f2());
  this.u4q_1 = imul(this.t4q_1.n(), 2);
  this.v4q_1 = -1;
}
protoOf(JsonTreeMapDecoder).l2 = function () {
  return this.s4q_1;
};
protoOf(JsonTreeMapDecoder).j48 = function (descriptor, index) {
  var i = index / 2 | 0;
  return this.t4q_1.f1(i);
};
protoOf(JsonTreeMapDecoder).c3v = function (descriptor) {
  while (this.v4q_1 < (this.u4q_1 - 1 | 0)) {
    this.v4q_1 = this.v4q_1 + 1 | 0;
    return this.v4q_1;
  }
  return -1;
};
protoOf(JsonTreeMapDecoder).w4o = function (tag) {
  return (this.v4q_1 % 2 | 0) === 0 ? JsonPrimitive_0(tag) : getValue(this.s4q_1, tag);
};
protoOf(JsonTreeMapDecoder).n3u = function (descriptor) {
};
function readPolymorphicJson(_this__u8e3s4, discriminator, element, deserializer) {
  return (new JsonTreeDecoder(_this__u8e3s4, element, discriminator, deserializer.z3q())).o3r(deserializer);
}
function writeJson(json, value, serializer) {
  var result = {_v: null};
  var encoder = new JsonTreeEncoder(json, writeJson$lambda(result));
  encoder.l3r(serializer, value);
  var tmp;
  if (result._v == null) {
    throwUninitializedPropertyAccessException('result');
  } else {
    tmp = result._v;
  }
  return tmp;
}
function JsonTreeEncoder(json, nodeConsumer) {
  AbstractJsonTreeEncoder.call(this, json, nodeConsumer);
  var tmp = this;
  // Inline function 'kotlin.collections.linkedMapOf' call
  tmp.g4r_1 = LinkedHashMap_init_$Create$();
}
protoOf(JsonTreeEncoder).h4r = function (key, element) {
  // Inline function 'kotlin.collections.set' call
  this.g4r_1.i2(key, element);
};
protoOf(JsonTreeEncoder).d3w = function (descriptor, index, serializer, value) {
  if (!(value == null) ? true : this.z4q_1.h4i_1) {
    protoOf(AbstractJsonTreeEncoder).d3w.call(this, descriptor, index, serializer, value);
  }
};
protoOf(JsonTreeEncoder).i4r = function () {
  return new JsonObject(this.g4r_1);
};
function inlineUnsignedNumberEncoder($this, tag) {
  return new AbstractJsonTreeEncoder$inlineUnsignedNumberEncoder$1($this, tag);
}
function inlineUnquotedLiteralEncoder($this, tag, inlineDescriptor) {
  return new AbstractJsonTreeEncoder$inlineUnquotedLiteralEncoder$1($this, tag, inlineDescriptor);
}
function AbstractJsonTreeEncoder$inlineUnsignedNumberEncoder$1(this$0, $tag) {
  this.x4r_1 = this$0;
  this.y4r_1 = $tag;
  AbstractEncoder.call(this);
  this.w4r_1 = this$0.x4q_1.k3r();
}
protoOf(AbstractJsonTreeEncoder$inlineUnsignedNumberEncoder$1).k3r = function () {
  return this.w4r_1;
};
protoOf(AbstractJsonTreeEncoder$inlineUnsignedNumberEncoder$1).z4r = function (s) {
  return this.x4r_1.h4r(this.y4r_1, new JsonLiteral(s, false));
};
protoOf(AbstractJsonTreeEncoder$inlineUnsignedNumberEncoder$1).k3v = function (value) {
  // Inline function 'kotlin.toUInt' call
  var tmp$ret$0 = _UInt___init__impl__l7qpdl(value);
  return this.z4r(UInt__toString_impl_dbgl21(tmp$ret$0));
};
protoOf(AbstractJsonTreeEncoder$inlineUnsignedNumberEncoder$1).l3v = function (value) {
  // Inline function 'kotlin.toULong' call
  var tmp$ret$0 = _ULong___init__impl__c78o9k(value);
  return this.z4r(ULong__toString_impl_f9au7k(tmp$ret$0));
};
protoOf(AbstractJsonTreeEncoder$inlineUnsignedNumberEncoder$1).i3v = function (value) {
  // Inline function 'kotlin.toUByte' call
  var tmp$ret$0 = _UByte___init__impl__g9hnc4(value);
  return this.z4r(UByte__toString_impl_v72jg(tmp$ret$0));
};
protoOf(AbstractJsonTreeEncoder$inlineUnsignedNumberEncoder$1).j3v = function (value) {
  // Inline function 'kotlin.toUShort' call
  var tmp$ret$0 = _UShort___init__impl__jigrne(value);
  return this.z4r(UShort__toString_impl_edaoee(tmp$ret$0));
};
function AbstractJsonTreeEncoder$inlineUnquotedLiteralEncoder$1(this$0, $tag, $inlineDescriptor) {
  this.a4s_1 = this$0;
  this.b4s_1 = $tag;
  this.c4s_1 = $inlineDescriptor;
  AbstractEncoder.call(this);
}
protoOf(AbstractJsonTreeEncoder$inlineUnquotedLiteralEncoder$1).k3r = function () {
  return this.a4s_1.x4q_1.k3r();
};
protoOf(AbstractJsonTreeEncoder$inlineUnquotedLiteralEncoder$1).p3v = function (value) {
  return this.a4s_1.h4r(this.b4s_1, new JsonLiteral(value, false, this.c4s_1));
};
function AbstractJsonTreeEncoder$beginStructure$lambda(this$0) {
  return function (node) {
    this$0.h4r(this$0.d49(), node);
    return Unit_instance;
  };
}
function AbstractJsonTreeEncoder(json, nodeConsumer) {
  NamedValueEncoder.call(this);
  this.x4q_1 = json;
  this.y4q_1 = nodeConsumer;
  this.z4q_1 = this.x4q_1.s4g_1;
  this.a4r_1 = null;
}
protoOf(AbstractJsonTreeEncoder).s4i = function () {
  return this.x4q_1;
};
protoOf(AbstractJsonTreeEncoder).k3r = function () {
  return this.x4q_1.k3r();
};
protoOf(AbstractJsonTreeEncoder).j48 = function (descriptor, index) {
  return getJsonElementName(descriptor, this.x4q_1, index);
};
protoOf(AbstractJsonTreeEncoder).a4k = function (element) {
  this.l3r(JsonElementSerializer_getInstance(), element);
};
protoOf(AbstractJsonTreeEncoder).h3w = function (descriptor, index) {
  return this.z4q_1.c4i_1;
};
protoOf(AbstractJsonTreeEncoder).n48 = function (parentName, childName) {
  return childName;
};
protoOf(AbstractJsonTreeEncoder).f3w = function () {
};
protoOf(AbstractJsonTreeEncoder).g3v = function () {
  var tmp0_elvis_lhs = this.m48();
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return this.y4q_1(JsonNull_getInstance());
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var tag = tmp;
  this.j4r(tag);
};
protoOf(AbstractJsonTreeEncoder).j4r = function (tag) {
  return this.h4r(tag, JsonNull_getInstance());
};
protoOf(AbstractJsonTreeEncoder).q48 = function (tag) {
  return this.j4r((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
};
protoOf(AbstractJsonTreeEncoder).k4r = function (tag, value) {
  return this.h4r(tag, JsonPrimitive_1(value));
};
protoOf(AbstractJsonTreeEncoder).r48 = function (tag, value) {
  return this.k4r((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
};
protoOf(AbstractJsonTreeEncoder).l4r = function (tag, value) {
  return this.h4r(tag, JsonPrimitive_1(value));
};
protoOf(AbstractJsonTreeEncoder).s48 = function (tag, value) {
  return this.l4r((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
};
protoOf(AbstractJsonTreeEncoder).m4r = function (tag, value) {
  return this.h4r(tag, JsonPrimitive_1(value));
};
protoOf(AbstractJsonTreeEncoder).t48 = function (tag, value) {
  return this.m4r((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
};
protoOf(AbstractJsonTreeEncoder).n4r = function (tag, value) {
  return this.h4r(tag, JsonPrimitive_1(value));
};
protoOf(AbstractJsonTreeEncoder).u48 = function (tag, value) {
  return this.n4r((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
};
protoOf(AbstractJsonTreeEncoder).o4r = function (tag, value) {
  this.h4r(tag, JsonPrimitive_1(value));
  if (!this.z4q_1.m4i_1 ? !isFinite(value) : false) {
    throw InvalidFloatingPointEncoded(value, tag, toString(this.i4r()));
  }
};
protoOf(AbstractJsonTreeEncoder).v48 = function (tag, value) {
  return this.o4r((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
};
protoOf(AbstractJsonTreeEncoder).l3r = function (serializer, value) {
  if (!(this.m48() == null) ? true : !get_requiresTopLevelTag(carrierDescriptor(serializer.z3q(), this.k3r()))) {
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.encodePolymorphically' call
      if (this.s4i().s4g_1.k4i_1) {
        serializer.m3r(this, value);
        break $l$block;
      }
      var isPolymorphicSerializer = serializer instanceof AbstractPolymorphicSerializer;
      var tmp;
      if (isPolymorphicSerializer) {
        tmp = !this.s4i().s4g_1.r4i_1.equals(ClassDiscriminatorMode_NONE_getInstance());
      } else {
        var tmp_0;
        switch (this.s4i().s4g_1.r4i_1.aa_1) {
          case 0:
          case 2:
            tmp_0 = false;
            break;
          case 1:
            // Inline function 'kotlin.let' call

            // Inline function 'kotlin.contracts.contract' call

            // Inline function 'kotlinx.serialization.json.internal.encodePolymorphically.<anonymous>' call

            var it = serializer.z3q().u3s();
            tmp_0 = equals(it, CLASS_getInstance()) ? true : equals(it, OBJECT_getInstance());
            break;
          default:
            noWhenBranchMatchedException();
            break;
        }
        tmp = tmp_0;
      }
      var needDiscriminator = tmp;
      var baseClassDiscriminator = needDiscriminator ? classDiscriminator(serializer.z3q(), this.s4i()) : null;
      var tmp_1;
      if (isPolymorphicSerializer) {
        var casted = serializer instanceof AbstractPolymorphicSerializer ? serializer : THROW_CCE();
        $l$block_0: {
          // Inline function 'kotlin.requireNotNull' call
          // Inline function 'kotlin.contracts.contract' call
          if (value == null) {
            // Inline function 'kotlinx.serialization.json.internal.encodePolymorphically.<anonymous>' call
            var message = 'Value for serializer ' + serializer.z3q() + ' should always be non-null. Please report issue to the kotlinx.serialization tracker.';
            throw IllegalArgumentException_init_$Create$(toString(message));
          } else {
            break $l$block_0;
          }
        }
        var actual = findPolymorphicSerializer_0(casted, this, value);
        if (!(baseClassDiscriminator == null)) {
          validateIfSealed$accessor$1ad0flx(serializer, actual, baseClassDiscriminator);
        }
        checkKind(actual.z3q().u3s());
        tmp_1 = isInterface(actual, SerializationStrategy) ? actual : THROW_CCE();
      } else {
        tmp_1 = serializer;
      }
      var actualSerializer = tmp_1;
      if (!(baseClassDiscriminator == null)) {
        // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeEncoder.encodeSerializableValue.<anonymous>' call
        this.a4r_1 = baseClassDiscriminator;
      }
      actualSerializer.m3r(this, value);
    }
  } else {
    // Inline function 'kotlin.apply' call
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeEncoder.encodeSerializableValue.<anonymous>' call
    (new JsonPrimitiveEncoder(this.x4q_1, this.y4q_1)).l3r(serializer, value);
  }
};
protoOf(AbstractJsonTreeEncoder).p4r = function (tag, value) {
  this.h4r(tag, JsonPrimitive_1(value));
  if (!this.z4q_1.m4i_1 ? !isFinite_0(value) : false) {
    throw InvalidFloatingPointEncoded(value, tag, toString(this.i4r()));
  }
};
protoOf(AbstractJsonTreeEncoder).w48 = function (tag, value) {
  return this.p4r((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
};
protoOf(AbstractJsonTreeEncoder).q4r = function (tag, value) {
  return this.h4r(tag, JsonPrimitive_2(value));
};
protoOf(AbstractJsonTreeEncoder).x48 = function (tag, value) {
  return this.q4r((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
};
protoOf(AbstractJsonTreeEncoder).r4r = function (tag, value) {
  return this.h4r(tag, JsonPrimitive_0(toString_0(value)));
};
protoOf(AbstractJsonTreeEncoder).y48 = function (tag, value) {
  return this.r4r((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
};
protoOf(AbstractJsonTreeEncoder).s4r = function (tag, value) {
  return this.h4r(tag, JsonPrimitive_0(value));
};
protoOf(AbstractJsonTreeEncoder).z48 = function (tag, value) {
  return this.s4r((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
};
protoOf(AbstractJsonTreeEncoder).t4r = function (tag, enumDescriptor, ordinal) {
  return this.h4r(tag, JsonPrimitive_0(enumDescriptor.y3s(ordinal)));
};
protoOf(AbstractJsonTreeEncoder).a49 = function (tag, enumDescriptor, ordinal) {
  return this.t4r((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), enumDescriptor, ordinal);
};
protoOf(AbstractJsonTreeEncoder).u4r = function (tag, value) {
  this.h4r(tag, JsonPrimitive_0(toString(value)));
};
protoOf(AbstractJsonTreeEncoder).o48 = function (tag, value) {
  return this.u4r((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
};
protoOf(AbstractJsonTreeEncoder).v4r = function (tag, inlineDescriptor) {
  return get_isUnsignedNumber(inlineDescriptor) ? inlineUnsignedNumberEncoder(this, tag) : get_isUnquotedLiteral(inlineDescriptor) ? inlineUnquotedLiteralEncoder(this, tag, inlineDescriptor) : protoOf(NamedValueEncoder).b49.call(this, tag, inlineDescriptor);
};
protoOf(AbstractJsonTreeEncoder).b49 = function (tag, inlineDescriptor) {
  return this.v4r((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), inlineDescriptor);
};
protoOf(AbstractJsonTreeEncoder).r3v = function (descriptor) {
  return !(this.m48() == null) ? protoOf(NamedValueEncoder).r3v.call(this, descriptor) : (new JsonPrimitiveEncoder(this.x4q_1, this.y4q_1)).r3v(descriptor);
};
protoOf(AbstractJsonTreeEncoder).m3u = function (descriptor) {
  var tmp;
  if (this.m48() == null) {
    tmp = this.y4q_1;
  } else {
    tmp = AbstractJsonTreeEncoder$beginStructure$lambda(this);
  }
  var consumer = tmp;
  var tmp0_subject = descriptor.u3s();
  var tmp_0;
  var tmp_1;
  if (equals(tmp0_subject, LIST_getInstance())) {
    tmp_1 = true;
  } else {
    tmp_1 = tmp0_subject instanceof PolymorphicKind;
  }
  if (tmp_1) {
    tmp_0 = new JsonTreeListEncoder(this.x4q_1, consumer);
  } else {
    if (equals(tmp0_subject, MAP_getInstance())) {
      // Inline function 'kotlinx.serialization.json.internal.selectMapMode' call
      var this_0 = this.x4q_1;
      var keyDescriptor = carrierDescriptor(descriptor.w3s(0), this_0.k3r());
      var keyKind = keyDescriptor.u3s();
      var tmp_2;
      var tmp_3;
      if (keyKind instanceof PrimitiveKind) {
        tmp_3 = true;
      } else {
        tmp_3 = equals(keyKind, ENUM_getInstance());
      }
      if (tmp_3) {
        // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeEncoder.beginStructure.<anonymous>' call
        tmp_2 = new JsonTreeMapEncoder(this.x4q_1, consumer);
      } else {
        if (this_0.s4g_1.f4i_1) {
          // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeEncoder.beginStructure.<anonymous>' call
          tmp_2 = new JsonTreeListEncoder(this.x4q_1, consumer);
        } else {
          throw InvalidKeyKindException(keyDescriptor);
        }
      }
      tmp_0 = tmp_2;
    } else {
      tmp_0 = new JsonTreeEncoder(this.x4q_1, consumer);
    }
  }
  var encoder = tmp_0;
  if (!(this.a4r_1 == null)) {
    encoder.h4r(ensureNotNull(this.a4r_1), JsonPrimitive_0(descriptor.e3s()));
    this.a4r_1 = null;
  }
  return encoder;
};
protoOf(AbstractJsonTreeEncoder).c49 = function (descriptor) {
  this.y4q_1(this.i4r());
};
function get_requiresTopLevelTag(_this__u8e3s4) {
  var tmp;
  var tmp_0 = _this__u8e3s4.u3s();
  if (tmp_0 instanceof PrimitiveKind) {
    tmp = true;
  } else {
    tmp = _this__u8e3s4.u3s() === ENUM_getInstance();
  }
  return tmp;
}
function JsonPrimitiveEncoder(json, nodeConsumer) {
  AbstractJsonTreeEncoder.call(this, json, nodeConsumer);
  this.i4s_1 = null;
  this.e49('primitive');
}
protoOf(JsonPrimitiveEncoder).h4r = function (key, element) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(key === 'primitive')) {
    // Inline function 'kotlinx.serialization.json.internal.JsonPrimitiveEncoder.putElement.<anonymous>' call
    var message = "This output can only consume primitives with 'primitive' tag";
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(this.i4s_1 == null)) {
    // Inline function 'kotlinx.serialization.json.internal.JsonPrimitiveEncoder.putElement.<anonymous>' call
    var message_0 = 'Primitive element was already recorded. Does call to .encodeXxx happen more than once?';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  this.i4s_1 = element;
  this.y4q_1(element);
};
protoOf(JsonPrimitiveEncoder).i4r = function () {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.requireNotNull' call
    var value = this.i4s_1;
    // Inline function 'kotlin.contracts.contract' call
    if (value == null) {
      // Inline function 'kotlinx.serialization.json.internal.JsonPrimitiveEncoder.getCurrent.<anonymous>' call
      var message = 'Primitive element has not been recorded. Is call to .encodeXxx is missing in serializer?';
      throw IllegalArgumentException_init_$Create$(toString(message));
    } else {
      tmp$ret$1 = value;
      break $l$block;
    }
  }
  return tmp$ret$1;
};
function JsonTreeListEncoder(json, nodeConsumer) {
  AbstractJsonTreeEncoder.call(this, json, nodeConsumer);
  var tmp = this;
  // Inline function 'kotlin.collections.arrayListOf' call
  tmp.o4s_1 = ArrayList_init_$Create$();
}
protoOf(JsonTreeListEncoder).j48 = function (descriptor, index) {
  return index.toString();
};
protoOf(JsonTreeListEncoder).h4r = function (key, element) {
  var idx = toInt(key);
  this.o4s_1.r1(idx, element);
};
protoOf(JsonTreeListEncoder).i4r = function () {
  return new JsonArray(this.o4s_1);
};
function _get_tag__e6h4qf($this) {
  var tmp = $this.v4s_1;
  if (!(tmp == null))
    return tmp;
  else {
    throwUninitializedPropertyAccessException('tag');
  }
}
function JsonTreeMapEncoder(json, nodeConsumer) {
  JsonTreeEncoder.call(this, json, nodeConsumer);
  this.w4s_1 = true;
}
protoOf(JsonTreeMapEncoder).h4r = function (key, element) {
  if (this.w4s_1) {
    var tmp = this;
    var tmp_0;
    if (element instanceof JsonPrimitive) {
      tmp_0 = element.e2l();
    } else {
      if (element instanceof JsonObject) {
        throw InvalidKeyKindException(JsonObjectSerializer_getInstance().m4j_1);
      } else {
        if (element instanceof JsonArray) {
          throw InvalidKeyKindException(JsonArraySerializer_getInstance().n4j_1);
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
    tmp.v4s_1 = tmp_0;
    this.w4s_1 = false;
  } else {
    // Inline function 'kotlin.collections.set' call
    var this_0 = this.g4r_1;
    var key_0 = _get_tag__e6h4qf(this);
    this_0.i2(key_0, element);
    this.w4s_1 = true;
  }
};
protoOf(JsonTreeMapEncoder).i4r = function () {
  return new JsonObject(this.g4r_1);
};
function get_PRIMITIVE_TAG() {
  return PRIMITIVE_TAG;
}
var PRIMITIVE_TAG;
function writeJson$lambda($result) {
  return function (it) {
    $result._v = it;
    return Unit_instance;
  };
}
var WriteMode_OBJ_instance;
var WriteMode_LIST_instance;
var WriteMode_MAP_instance;
var WriteMode_POLY_OBJ_instance;
function values() {
  return [WriteMode_OBJ_getInstance(), WriteMode_LIST_getInstance(), WriteMode_MAP_getInstance(), WriteMode_POLY_OBJ_getInstance()];
}
function get_entries() {
  if ($ENTRIES == null)
    $ENTRIES = enumEntries(values());
  return $ENTRIES;
}
var WriteMode_entriesInitialized;
function WriteMode_initEntries() {
  if (WriteMode_entriesInitialized)
    return Unit_instance;
  WriteMode_entriesInitialized = true;
  WriteMode_OBJ_instance = new WriteMode('OBJ', 0, get_BEGIN_OBJ(), get_END_OBJ());
  WriteMode_LIST_instance = new WriteMode('LIST', 1, get_BEGIN_LIST(), get_END_LIST());
  WriteMode_MAP_instance = new WriteMode('MAP', 2, get_BEGIN_OBJ(), get_END_OBJ());
  WriteMode_POLY_OBJ_instance = new WriteMode('POLY_OBJ', 3, get_BEGIN_LIST(), get_END_LIST());
}
var $ENTRIES;
function WriteMode(name, ordinal, begin, end) {
  Enum.call(this, name, ordinal);
  this.k4o_1 = begin;
  this.l4o_1 = end;
}
function switchMode(_this__u8e3s4, desc) {
  var tmp0_subject = desc.u3s();
  var tmp;
  if (tmp0_subject instanceof PolymorphicKind) {
    tmp = WriteMode_POLY_OBJ_getInstance();
  } else {
    if (equals(tmp0_subject, LIST_getInstance())) {
      tmp = WriteMode_LIST_getInstance();
    } else {
      if (equals(tmp0_subject, MAP_getInstance())) {
        // Inline function 'kotlinx.serialization.json.internal.selectMapMode' call
        var keyDescriptor = carrierDescriptor(desc.w3s(0), _this__u8e3s4.k3r());
        var keyKind = keyDescriptor.u3s();
        var tmp_0;
        var tmp_1;
        if (keyKind instanceof PrimitiveKind) {
          tmp_1 = true;
        } else {
          tmp_1 = equals(keyKind, ENUM_getInstance());
        }
        if (tmp_1) {
          // Inline function 'kotlinx.serialization.json.internal.switchMode.<anonymous>' call
          tmp_0 = WriteMode_MAP_getInstance();
        } else {
          if (_this__u8e3s4.s4g_1.f4i_1) {
            // Inline function 'kotlinx.serialization.json.internal.switchMode.<anonymous>' call
            tmp_0 = WriteMode_LIST_getInstance();
          } else {
            throw InvalidKeyKindException(keyDescriptor);
          }
        }
        tmp = tmp_0;
      } else {
        tmp = WriteMode_OBJ_getInstance();
      }
    }
  }
  return tmp;
}
function carrierDescriptor(_this__u8e3s4, module_0) {
  var tmp;
  if (equals(_this__u8e3s4.u3s(), CONTEXTUAL_getInstance())) {
    var tmp0_safe_receiver = getContextualDescriptor(module_0, _this__u8e3s4);
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : carrierDescriptor(tmp0_safe_receiver, module_0);
    tmp = tmp1_elvis_lhs == null ? _this__u8e3s4 : tmp1_elvis_lhs;
  } else if (_this__u8e3s4.t3s()) {
    tmp = carrierDescriptor(_this__u8e3s4.w3s(0), module_0);
  } else {
    tmp = _this__u8e3s4;
  }
  return tmp;
}
function WriteMode_OBJ_getInstance() {
  WriteMode_initEntries();
  return WriteMode_OBJ_instance;
}
function WriteMode_LIST_getInstance() {
  WriteMode_initEntries();
  return WriteMode_LIST_instance;
}
function WriteMode_MAP_getInstance() {
  WriteMode_initEntries();
  return WriteMode_MAP_instance;
}
function WriteMode_POLY_OBJ_getInstance() {
  WriteMode_initEntries();
  return WriteMode_POLY_OBJ_instance;
}
function appendEscape($this, lastPosition, current) {
  $this.x4s(lastPosition, current);
  return appendEsc($this, current + 1 | 0);
}
function decodedString($this, lastPosition, currentPosition) {
  $this.x4s(lastPosition, currentPosition);
  var result = $this.j4h_1.toString();
  $this.j4h_1.k8(0);
  return result;
}
function takePeeked($this) {
  // Inline function 'kotlin.also' call
  var this_0 = ensureNotNull($this.i4h_1);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.takePeeked.<anonymous>' call
  $this.i4h_1 = null;
  return this_0;
}
function wasUnquotedString($this) {
  return !(charSequenceGet($this.y4s(), $this.g4h_1 - 1 | 0) === _Char___init__impl__6a9atx(34));
}
function appendEsc($this, startPosition) {
  var currentPosition = startPosition;
  currentPosition = $this.z4s(currentPosition);
  if (currentPosition === -1) {
    $this.j4l('Expected escape sequence to continue, got EOF');
  }
  var tmp = $this.y4s();
  var tmp0 = currentPosition;
  currentPosition = tmp0 + 1 | 0;
  var currentChar = charSequenceGet(tmp, tmp0);
  if (currentChar === _Char___init__impl__6a9atx(117)) {
    return appendHex($this, $this.y4s(), currentPosition);
  }
  // Inline function 'kotlin.code' call
  var tmp$ret$0 = Char__toInt_impl_vasixd(currentChar);
  var c = escapeToChar(tmp$ret$0);
  if (c === _Char___init__impl__6a9atx(0)) {
    $this.j4l("Invalid escaped char '" + toString_0(currentChar) + "'");
  }
  $this.j4h_1.o5(c);
  return currentPosition;
}
function appendHex($this, source, startPos) {
  if ((startPos + 4 | 0) >= charSequenceLength(source)) {
    $this.g4h_1 = startPos;
    $this.a4t();
    if (($this.g4h_1 + 4 | 0) >= charSequenceLength(source)) {
      $this.j4l('Unexpected EOF during unicode escape');
    }
    return appendHex($this, source, $this.g4h_1);
  }
  $this.j4h_1.o5(numberToChar((((fromHexChar($this, source, startPos) << 12) + (fromHexChar($this, source, startPos + 1 | 0) << 8) | 0) + (fromHexChar($this, source, startPos + 2 | 0) << 4) | 0) + fromHexChar($this, source, startPos + 3 | 0) | 0));
  return startPos + 4 | 0;
}
function fromHexChar($this, source, currentPosition) {
  var character = charSequenceGet(source, currentPosition);
  var tmp;
  if (_Char___init__impl__6a9atx(48) <= character ? character <= _Char___init__impl__6a9atx(57) : false) {
    // Inline function 'kotlin.code' call
    var tmp_0 = Char__toInt_impl_vasixd(character);
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(48);
    tmp = tmp_0 - Char__toInt_impl_vasixd(this_0) | 0;
  } else if (_Char___init__impl__6a9atx(97) <= character ? character <= _Char___init__impl__6a9atx(102) : false) {
    // Inline function 'kotlin.code' call
    var tmp_1 = Char__toInt_impl_vasixd(character);
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(97);
    tmp = (tmp_1 - Char__toInt_impl_vasixd(this_1) | 0) + 10 | 0;
  } else if (_Char___init__impl__6a9atx(65) <= character ? character <= _Char___init__impl__6a9atx(70) : false) {
    // Inline function 'kotlin.code' call
    var tmp_2 = Char__toInt_impl_vasixd(character);
    // Inline function 'kotlin.code' call
    var this_2 = _Char___init__impl__6a9atx(65);
    tmp = (tmp_2 - Char__toInt_impl_vasixd(this_2) | 0) + 10 | 0;
  } else {
    $this.j4l("Invalid toHexChar char '" + toString_0(character) + "' in unicode escape");
  }
  return tmp;
}
function consumeBoolean($this, start) {
  var current = $this.z4s(start);
  if (current >= charSequenceLength($this.y4s()) ? true : current === -1) {
    $this.j4l('EOF');
  }
  // Inline function 'kotlin.code' call
  var tmp = $this.y4s();
  var tmp0 = current;
  current = tmp0 + 1 | 0;
  var this_0 = charSequenceGet(tmp, tmp0);
  var tmp1_subject = Char__toInt_impl_vasixd(this_0) | 32;
  var tmp_0;
  // Inline function 'kotlin.code' call
  var this_1 = _Char___init__impl__6a9atx(116);
  if (tmp1_subject === Char__toInt_impl_vasixd(this_1)) {
    consumeBooleanLiteral($this, 'rue', current);
    tmp_0 = true;
  } else {
    // Inline function 'kotlin.code' call
    var this_2 = _Char___init__impl__6a9atx(102);
    if (tmp1_subject === Char__toInt_impl_vasixd(this_2)) {
      consumeBooleanLiteral($this, 'alse', current);
      tmp_0 = false;
    } else {
      $this.j4l("Expected valid boolean literal prefix, but had '" + $this.n4m() + "'");
    }
  }
  return tmp_0;
}
function consumeBooleanLiteral($this, literalSuffix, current) {
  if ((charSequenceLength($this.y4s()) - current | 0) < literalSuffix.length) {
    $this.j4l('Unexpected end of boolean literal');
  }
  var inductionVariable = 0;
  var last = charSequenceLength(literalSuffix) - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var expected = charSequenceGet(literalSuffix, i);
      var actual = charSequenceGet($this.y4s(), current + i | 0);
      // Inline function 'kotlin.code' call
      var tmp = Char__toInt_impl_vasixd(expected);
      // Inline function 'kotlin.code' call
      if (!(tmp === (Char__toInt_impl_vasixd(actual) | 32))) {
        $this.j4l("Expected valid boolean literal prefix, but had '" + $this.n4m() + "'");
      }
    }
     while (inductionVariable <= last);
  $this.g4h_1 = current + literalSuffix.length | 0;
}
function consumeNumericLiteral$calculateExponent(exponentAccumulator, isExponentPositive) {
  var tmp;
  switch (isExponentPositive) {
    case false:
      // Inline function 'kotlin.math.pow' call

      var x = -exponentAccumulator.p6();
      tmp = Math.pow(10.0, x);
      break;
    case true:
      // Inline function 'kotlin.math.pow' call

      var x_0 = exponentAccumulator.p6();
      tmp = Math.pow(10.0, x_0);
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
}
function AbstractJsonLexer() {
  this.g4h_1 = 0;
  this.h4h_1 = new JsonPath();
  this.i4h_1 = null;
  this.j4h_1 = StringBuilder_init_$Create$();
}
protoOf(AbstractJsonLexer).a4t = function () {
};
protoOf(AbstractJsonLexer).b4t = function (c) {
  return (((c === _Char___init__impl__6a9atx(125) ? true : c === _Char___init__impl__6a9atx(93)) ? true : c === _Char___init__impl__6a9atx(58)) ? true : c === _Char___init__impl__6a9atx(44)) ? false : true;
};
protoOf(AbstractJsonLexer).k4h = function () {
  var nextToken = this.p4m();
  if (!(nextToken === 10)) {
    this.j4l('Expected EOF after parsing, but had ' + toString_0(charSequenceGet(this.y4s(), this.g4h_1 - 1 | 0)) + ' instead');
  }
};
protoOf(AbstractJsonLexer).j4m = function (expected) {
  var token = this.p4m();
  if (!(token === expected)) {
    this.c4t(expected);
  }
  return token;
};
protoOf(AbstractJsonLexer).z4n = function (expected) {
  this.a4t();
  var source = this.y4s();
  var cpos = this.g4h_1;
  $l$loop_0: while (true) {
    cpos = this.z4s(cpos);
    if (cpos === -1)
      break $l$loop_0;
    var tmp0 = cpos;
    cpos = tmp0 + 1 | 0;
    var c = charSequenceGet(source, tmp0);
    if (((c === _Char___init__impl__6a9atx(32) ? true : c === _Char___init__impl__6a9atx(10)) ? true : c === _Char___init__impl__6a9atx(13)) ? true : c === _Char___init__impl__6a9atx(9))
      continue $l$loop_0;
    this.g4h_1 = cpos;
    if (c === expected)
      return Unit_instance;
    this.d4t(expected);
  }
  this.g4h_1 = cpos;
  this.d4t(expected);
};
protoOf(AbstractJsonLexer).d4t = function (expected) {
  if (this.g4h_1 > 0 ? expected === _Char___init__impl__6a9atx(34) : false) {
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.withPositionRollback' call
      var snapshot = this.g4h_1;
      try {
        // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.unexpectedToken.<anonymous>' call
        this.g4h_1 = this.g4h_1 - 1 | 0;
        tmp$ret$1 = this.n4m();
        break $l$block;
      }finally {
        this.g4h_1 = snapshot;
      }
    }
    var inputLiteral = tmp$ret$1;
    if (inputLiteral === 'null') {
      this.i4l("Expected string literal but 'null' literal was found", this.g4h_1 - 1 | 0, "Use 'coerceInputValues = true' in 'Json {}' builder to coerce nulls if property has a default value.");
    }
  }
  this.c4t(charToTokenClass(expected));
};
protoOf(AbstractJsonLexer).e4t = function (expectedToken, wasConsumed) {
  var expected = tokenDescription(expectedToken);
  var position = wasConsumed ? this.g4h_1 - 1 | 0 : this.g4h_1;
  var s = (this.g4h_1 === charSequenceLength(this.y4s()) ? true : position < 0) ? 'EOF' : toString_0(charSequenceGet(this.y4s(), position));
  this.j4l('Expected ' + expected + ", but had '" + s + "' instead", position);
};
protoOf(AbstractJsonLexer).c4t = function (expectedToken, wasConsumed, $super) {
  wasConsumed = wasConsumed === VOID ? true : wasConsumed;
  return $super === VOID ? this.e4t(expectedToken, wasConsumed) : $super.e4t.call(this, expectedToken, wasConsumed);
};
protoOf(AbstractJsonLexer).k4m = function () {
  var source = this.y4s();
  var cpos = this.g4h_1;
  $l$loop_0: while (true) {
    cpos = this.z4s(cpos);
    if (cpos === -1)
      break $l$loop_0;
    var ch = charSequenceGet(source, cpos);
    if (((ch === _Char___init__impl__6a9atx(32) ? true : ch === _Char___init__impl__6a9atx(10)) ? true : ch === _Char___init__impl__6a9atx(13)) ? true : ch === _Char___init__impl__6a9atx(9)) {
      cpos = cpos + 1 | 0;
      continue $l$loop_0;
    }
    this.g4h_1 = cpos;
    return charToTokenClass(ch);
  }
  this.g4h_1 = cpos;
  return 10;
};
protoOf(AbstractJsonLexer).b4o = function (doConsume) {
  var current = this.f4t();
  current = this.z4s(current);
  var len = charSequenceLength(this.y4s()) - current | 0;
  if (len < 4 ? true : current === -1)
    return false;
  var inductionVariable = 0;
  if (inductionVariable <= 3)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      if (!(charSequenceGet('null', i) === charSequenceGet(this.y4s(), current + i | 0)))
        return false;
    }
     while (inductionVariable <= 3);
  if (len > 4 ? charToTokenClass(charSequenceGet(this.y4s(), current + 4 | 0)) === 0 : false)
    return false;
  if (doConsume) {
    this.g4h_1 = current + 4 | 0;
  }
  return true;
};
protoOf(AbstractJsonLexer).m4o = function (doConsume, $super) {
  doConsume = doConsume === VOID ? true : doConsume;
  return $super === VOID ? this.b4o(doConsume) : $super.b4o.call(this, doConsume);
};
protoOf(AbstractJsonLexer).f4t = function () {
  var current = this.g4h_1;
  $l$loop_0: while (true) {
    current = this.z4s(current);
    if (current === -1)
      break $l$loop_0;
    var c = charSequenceGet(this.y4s(), current);
    if (((c === _Char___init__impl__6a9atx(32) ? true : c === _Char___init__impl__6a9atx(10)) ? true : c === _Char___init__impl__6a9atx(13)) ? true : c === _Char___init__impl__6a9atx(9)) {
      current = current + 1 | 0;
    } else {
      break $l$loop_0;
    }
  }
  this.g4h_1 = current;
  return current;
};
protoOf(AbstractJsonLexer).c4o = function (isLenient) {
  var token = this.k4m();
  var tmp;
  if (isLenient) {
    if (!(token === 1) ? !(token === 0) : false)
      return null;
    tmp = this.n4m();
  } else {
    if (!(token === 1))
      return null;
    tmp = this.m4m();
  }
  var string = tmp;
  this.i4h_1 = string;
  return string;
};
protoOf(AbstractJsonLexer).g4t = function () {
  this.i4h_1 = null;
};
protoOf(AbstractJsonLexer).h4t = function (startPos, endPos) {
  // Inline function 'kotlin.text.substring' call
  var this_0 = this.y4s();
  return toString(charSequenceSubSequence(this_0, startPos, endPos));
};
protoOf(AbstractJsonLexer).m4m = function () {
  if (!(this.i4h_1 == null)) {
    return takePeeked(this);
  }
  return this.f4o();
};
protoOf(AbstractJsonLexer).consumeString2 = function (source, startPosition, current) {
  var currentPosition = current;
  var lastPosition = startPosition;
  var char = charSequenceGet(source, currentPosition);
  var usedAppend = false;
  while (!(char === _Char___init__impl__6a9atx(34))) {
    if (char === _Char___init__impl__6a9atx(92)) {
      usedAppend = true;
      currentPosition = this.z4s(appendEscape(this, lastPosition, currentPosition));
      if (currentPosition === -1) {
        this.j4l('Unexpected EOF', currentPosition);
      }
      lastPosition = currentPosition;
    } else {
      currentPosition = currentPosition + 1 | 0;
      if (currentPosition >= charSequenceLength(source)) {
        usedAppend = true;
        this.x4s(lastPosition, currentPosition);
        currentPosition = this.z4s(currentPosition);
        if (currentPosition === -1) {
          this.j4l('Unexpected EOF', currentPosition);
        }
        lastPosition = currentPosition;
      }
    }
    char = charSequenceGet(source, currentPosition);
  }
  var tmp;
  if (!usedAppend) {
    tmp = this.h4t(lastPosition, currentPosition);
  } else {
    tmp = decodedString(this, lastPosition, currentPosition);
  }
  var string = tmp;
  this.g4h_1 = currentPosition + 1 | 0;
  return string;
};
protoOf(AbstractJsonLexer).g4o = function () {
  var result = this.n4m();
  if (result === 'null' ? wasUnquotedString(this) : false) {
    this.j4l("Unexpected 'null' value instead of string literal");
  }
  return result;
};
protoOf(AbstractJsonLexer).n4m = function () {
  if (!(this.i4h_1 == null)) {
    return takePeeked(this);
  }
  var current = this.f4t();
  if (current >= charSequenceLength(this.y4s()) ? true : current === -1) {
    this.j4l('EOF', current);
  }
  var token = charToTokenClass(charSequenceGet(this.y4s(), current));
  if (token === 1) {
    return this.m4m();
  }
  if (!(token === 0)) {
    this.j4l('Expected beginning of the string, but got ' + toString_0(charSequenceGet(this.y4s(), current)));
  }
  var usedAppend = false;
  while (charToTokenClass(charSequenceGet(this.y4s(), current)) === 0) {
    current = current + 1 | 0;
    if (current >= charSequenceLength(this.y4s())) {
      usedAppend = true;
      this.x4s(this.g4h_1, current);
      var eof = this.z4s(current);
      if (eof === -1) {
        this.g4h_1 = current;
        return decodedString(this, 0, 0);
      } else {
        current = eof;
      }
    }
  }
  var tmp;
  if (!usedAppend) {
    tmp = this.h4t(this.g4h_1, current);
  } else {
    tmp = decodedString(this, this.g4h_1, current);
  }
  var result = tmp;
  this.g4h_1 = current;
  return result;
};
protoOf(AbstractJsonLexer).x4s = function (fromIndex, toIndex) {
  this.j4h_1.e8(this.y4s(), fromIndex, toIndex);
};
protoOf(AbstractJsonLexer).e4o = function (allowLenientStrings) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var tokenStack = ArrayList_init_$Create$();
  var lastToken = this.k4m();
  if (!(lastToken === 8) ? !(lastToken === 6) : false) {
    this.n4m();
    return Unit_instance;
  }
  $l$loop: while (true) {
    lastToken = this.k4m();
    if (lastToken === 1) {
      if (allowLenientStrings) {
        this.n4m();
      } else {
        this.f4o();
      }
      continue $l$loop;
    }
    var tmp0_subject = lastToken;
    if (tmp0_subject === 8 ? true : tmp0_subject === 6) {
      tokenStack.r(lastToken);
    } else if (tmp0_subject === 9) {
      if (!(last(tokenStack) === 8))
        throw JsonDecodingException_0(this.g4h_1, 'found ] instead of } at path: ' + this.h4h_1, this.y4s());
      removeLast(tokenStack);
    } else if (tmp0_subject === 7) {
      if (!(last(tokenStack) === 6))
        throw JsonDecodingException_0(this.g4h_1, 'found } instead of ] at path: ' + this.h4h_1, this.y4s());
      removeLast(tokenStack);
    } else if (tmp0_subject === 10) {
      this.j4l('Unexpected end of input due to malformed JSON during ignoring unknown keys');
    }
    this.p4m();
    if (tokenStack.n() === 0)
      return Unit_instance;
  }
};
protoOf(AbstractJsonLexer).toString = function () {
  return "JsonReader(source='" + this.y4s() + "', currentPosition=" + this.g4h_1 + ')';
};
protoOf(AbstractJsonLexer).d4o = function (key) {
  var processed = this.h4t(0, this.g4h_1);
  var lastIndexOf_0 = lastIndexOf(processed, key);
  this.i4l("Encountered an unknown key '" + key + "'", lastIndexOf_0, "Use 'ignoreUnknownKeys = true' in 'Json {}' builder to ignore unknown keys.");
};
protoOf(AbstractJsonLexer).i4l = function (message, position, hint) {
  var tmp;
  // Inline function 'kotlin.text.isEmpty' call
  if (charSequenceLength(hint) === 0) {
    tmp = '';
  } else {
    tmp = '\n' + hint;
  }
  var hintMessage = tmp;
  throw JsonDecodingException_0(position, message + ' at path: ' + this.h4h_1.w4l() + hintMessage, this.y4s());
};
protoOf(AbstractJsonLexer).j4l = function (message, position, hint, $super) {
  position = position === VOID ? this.g4h_1 : position;
  hint = hint === VOID ? '' : hint;
  return $super === VOID ? this.i4l(message, position, hint) : $super.i4l.call(this, message, position, hint);
};
protoOf(AbstractJsonLexer).g4j = function () {
  var current = this.f4t();
  current = this.z4s(current);
  if (current >= charSequenceLength(this.y4s()) ? true : current === -1) {
    this.j4l('EOF');
  }
  var tmp;
  if (charSequenceGet(this.y4s(), current) === _Char___init__impl__6a9atx(34)) {
    current = current + 1 | 0;
    if (current === charSequenceLength(this.y4s())) {
      this.j4l('EOF');
    }
    tmp = true;
  } else {
    tmp = false;
  }
  var hasQuotation = tmp;
  var accumulator = new Long(0, 0);
  var exponentAccumulator = new Long(0, 0);
  var isNegative = false;
  var isExponentPositive = false;
  var hasExponent = false;
  var start = current;
  $l$loop_4: while (!(current === charSequenceLength(this.y4s()))) {
    var ch = charSequenceGet(this.y4s(), current);
    if ((ch === _Char___init__impl__6a9atx(101) ? true : ch === _Char___init__impl__6a9atx(69)) ? !hasExponent : false) {
      if (current === start) {
        this.j4l('Unexpected symbol ' + toString_0(ch) + ' in numeric literal');
      }
      isExponentPositive = true;
      hasExponent = true;
      current = current + 1 | 0;
      continue $l$loop_4;
    }
    if (ch === _Char___init__impl__6a9atx(45) ? hasExponent : false) {
      if (current === start) {
        this.j4l("Unexpected symbol '-' in numeric literal");
      }
      isExponentPositive = false;
      current = current + 1 | 0;
      continue $l$loop_4;
    }
    if (ch === _Char___init__impl__6a9atx(43) ? hasExponent : false) {
      if (current === start) {
        this.j4l("Unexpected symbol '+' in numeric literal");
      }
      isExponentPositive = true;
      current = current + 1 | 0;
      continue $l$loop_4;
    }
    if (ch === _Char___init__impl__6a9atx(45)) {
      if (!(current === start)) {
        this.j4l("Unexpected symbol '-' in numeric literal");
      }
      isNegative = true;
      current = current + 1 | 0;
      continue $l$loop_4;
    }
    var token = charToTokenClass(ch);
    if (!(token === 0))
      break $l$loop_4;
    current = current + 1 | 0;
    var digit = Char__minus_impl_a2frrh(ch, _Char___init__impl__6a9atx(48));
    if (!(0 <= digit ? digit <= 9 : false)) {
      this.j4l("Unexpected symbol '" + toString_0(ch) + "' in numeric literal");
    }
    if (hasExponent) {
      // Inline function 'kotlin.Long.plus' call
      // Inline function 'kotlin.Long.times' call
      exponentAccumulator = exponentAccumulator.da(toLong(10)).lb(toLong(digit));
      continue $l$loop_4;
    }
    // Inline function 'kotlin.Long.minus' call
    // Inline function 'kotlin.Long.times' call
    accumulator = accumulator.da(toLong(10)).mb(toLong(digit));
    if (accumulator.o6(new Long(0, 0)) > 0) {
      this.j4l('Numeric value overflow');
    }
  }
  var hasChars = !(current === start);
  if (start === current ? true : isNegative ? start === (current - 1 | 0) : false) {
    this.j4l('Expected numeric literal');
  }
  if (hasQuotation) {
    if (!hasChars) {
      this.j4l('EOF');
    }
    if (!(charSequenceGet(this.y4s(), current) === _Char___init__impl__6a9atx(34))) {
      this.j4l('Expected closing quotation mark');
    }
    current = current + 1 | 0;
  }
  this.g4h_1 = current;
  if (hasExponent) {
    var doubleAccumulator = accumulator.p6() * consumeNumericLiteral$calculateExponent(exponentAccumulator, isExponentPositive);
    var tmp_0;
    Companion_getInstance_3();
    if (doubleAccumulator > (new Long(-1, 2147483647)).p6()) {
      tmp_0 = true;
    } else {
      Companion_getInstance_3();
      tmp_0 = doubleAccumulator < (new Long(0, -2147483648)).p6();
    }
    if (tmp_0) {
      this.j4l('Numeric value overflow');
    }
    // Inline function 'kotlin.math.floor' call
    if (!(Math.floor(doubleAccumulator) === doubleAccumulator)) {
      this.j4l("Can't convert " + doubleAccumulator + ' to Long');
    }
    accumulator = numberToLong(doubleAccumulator);
  }
  var tmp_1;
  if (isNegative) {
    tmp_1 = accumulator;
  } else {
    var tmp_2 = accumulator;
    Companion_getInstance_3();
    if (!tmp_2.equals(new Long(0, -2147483648))) {
      tmp_1 = accumulator.qb();
    } else {
      this.j4l('Numeric value overflow');
    }
  }
  return tmp_1;
};
protoOf(AbstractJsonLexer).n4o = function () {
  var current = this.f4t();
  if (current === charSequenceLength(this.y4s())) {
    this.j4l('EOF');
  }
  var tmp;
  if (charSequenceGet(this.y4s(), current) === _Char___init__impl__6a9atx(34)) {
    current = current + 1 | 0;
    tmp = true;
  } else {
    tmp = false;
  }
  var hasQuotation = tmp;
  var result = consumeBoolean(this, current);
  if (hasQuotation) {
    if (this.g4h_1 === charSequenceLength(this.y4s())) {
      this.j4l('EOF');
    }
    if (!(charSequenceGet(this.y4s(), this.g4h_1) === _Char___init__impl__6a9atx(34))) {
      this.j4l('Expected closing quotation mark');
    }
    this.g4h_1 = this.g4h_1 + 1 | 0;
  }
  return result;
};
function charToTokenClass(c) {
  var tmp;
  // Inline function 'kotlin.code' call
  if (Char__toInt_impl_vasixd(c) < 126) {
    var tmp_0 = CharMappings_getInstance().j4t_1;
    // Inline function 'kotlin.code' call
    tmp = tmp_0[Char__toInt_impl_vasixd(c)];
  } else {
    tmp = 0;
  }
  return tmp;
}
function get_TC_WHITESPACE() {
  return TC_WHITESPACE;
}
var TC_WHITESPACE;
function get_TC_EOF() {
  return TC_EOF;
}
var TC_EOF;
function get_STRING() {
  return STRING;
}
var STRING;
function get_TC_STRING() {
  return TC_STRING;
}
var TC_STRING;
function get_STRING_ESC() {
  return STRING_ESC;
}
var STRING_ESC;
function get_TC_BEGIN_OBJ() {
  return TC_BEGIN_OBJ;
}
var TC_BEGIN_OBJ;
function get_TC_COLON() {
  return TC_COLON;
}
var TC_COLON;
function get_TC_COMMA() {
  return TC_COMMA;
}
var TC_COMMA;
function get_COLON() {
  return COLON;
}
var COLON;
function get_BEGIN_OBJ() {
  return BEGIN_OBJ;
}
var BEGIN_OBJ;
function get_END_OBJ() {
  return END_OBJ;
}
var END_OBJ;
function get_BEGIN_LIST() {
  return BEGIN_LIST;
}
var BEGIN_LIST;
function get_END_LIST() {
  return END_LIST;
}
var END_LIST;
function get_lenientHint() {
  return lenientHint;
}
var lenientHint;
function get_INVALID() {
  return INVALID;
}
var INVALID;
function get_COMMA() {
  return COMMA;
}
var COMMA;
function get_NULL() {
  return NULL;
}
var NULL;
function tokenDescription(token) {
  return token === 1 ? "quotation mark '\"'" : token === 2 ? "string escape sequence '\\'" : token === 4 ? "comma ','" : token === 5 ? "colon ':'" : token === 6 ? "start of the object '{'" : token === 7 ? "end of the object '}'" : token === 8 ? "start of the array '['" : token === 9 ? "end of the array ']'" : token === 10 ? 'end of the input' : token === 127 ? 'invalid token' : 'valid token';
}
function get_TC_OTHER() {
  return TC_OTHER;
}
var TC_OTHER;
function escapeToChar(c) {
  return c < 117 ? CharMappings_getInstance().i4t_1[c] : _Char___init__impl__6a9atx(0);
}
function get_TC_BEGIN_LIST() {
  return TC_BEGIN_LIST;
}
var TC_BEGIN_LIST;
function get_TC_END_LIST() {
  return TC_END_LIST;
}
var TC_END_LIST;
function get_TC_END_OBJ() {
  return TC_END_OBJ;
}
var TC_END_OBJ;
function get_ignoreUnknownKeysHint() {
  return ignoreUnknownKeysHint;
}
var ignoreUnknownKeysHint;
function initEscape($this) {
  var inductionVariable = 0;
  if (inductionVariable <= 31)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      initC2ESC($this, i, _Char___init__impl__6a9atx(117));
    }
     while (inductionVariable <= 31);
  initC2ESC($this, 8, _Char___init__impl__6a9atx(98));
  initC2ESC($this, 9, _Char___init__impl__6a9atx(116));
  initC2ESC($this, 10, _Char___init__impl__6a9atx(110));
  initC2ESC($this, 12, _Char___init__impl__6a9atx(102));
  initC2ESC($this, 13, _Char___init__impl__6a9atx(114));
  initC2ESC_0($this, _Char___init__impl__6a9atx(47), _Char___init__impl__6a9atx(47));
  initC2ESC_0($this, _Char___init__impl__6a9atx(34), _Char___init__impl__6a9atx(34));
  initC2ESC_0($this, _Char___init__impl__6a9atx(92), _Char___init__impl__6a9atx(92));
}
function initCharToToken($this) {
  var inductionVariable = 0;
  if (inductionVariable <= 32)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      initC2TC($this, i, 127);
    }
     while (inductionVariable <= 32);
  initC2TC($this, 9, 3);
  initC2TC($this, 10, 3);
  initC2TC($this, 13, 3);
  initC2TC($this, 32, 3);
  initC2TC_0($this, _Char___init__impl__6a9atx(44), 4);
  initC2TC_0($this, _Char___init__impl__6a9atx(58), 5);
  initC2TC_0($this, _Char___init__impl__6a9atx(123), 6);
  initC2TC_0($this, _Char___init__impl__6a9atx(125), 7);
  initC2TC_0($this, _Char___init__impl__6a9atx(91), 8);
  initC2TC_0($this, _Char___init__impl__6a9atx(93), 9);
  initC2TC_0($this, _Char___init__impl__6a9atx(34), 1);
  initC2TC_0($this, _Char___init__impl__6a9atx(92), 2);
}
function initC2ESC($this, c, esc) {
  if (!(esc === _Char___init__impl__6a9atx(117))) {
    // Inline function 'kotlin.code' call
    var tmp$ret$0 = Char__toInt_impl_vasixd(esc);
    $this.i4t_1[tmp$ret$0] = numberToChar(c);
  }
}
function initC2ESC_0($this, c, esc) {
  // Inline function 'kotlin.code' call
  var tmp$ret$0 = Char__toInt_impl_vasixd(c);
  return initC2ESC($this, tmp$ret$0, esc);
}
function initC2TC($this, c, cl) {
  $this.j4t_1[c] = cl;
}
function initC2TC_0($this, c, cl) {
  // Inline function 'kotlin.code' call
  var tmp$ret$0 = Char__toInt_impl_vasixd(c);
  return initC2TC($this, tmp$ret$0, cl);
}
function CharMappings() {
  CharMappings_instance = this;
  this.i4t_1 = charArray(117);
  this.j4t_1 = new Int8Array(126);
  initEscape(this);
  initCharToToken(this);
}
var CharMappings_instance;
function CharMappings_getInstance() {
  if (CharMappings_instance == null)
    new CharMappings();
  return CharMappings_instance;
}
function get_specialFlowingValuesHint() {
  return specialFlowingValuesHint;
}
var specialFlowingValuesHint;
function get_allowStructuredMapKeysHint() {
  return allowStructuredMapKeysHint;
}
var allowStructuredMapKeysHint;
function StringJsonLexer(source) {
  AbstractJsonLexer.call(this);
  this.o4t_1 = source;
}
protoOf(StringJsonLexer).y4s = function () {
  return this.o4t_1;
};
protoOf(StringJsonLexer).z4s = function (position) {
  return position < this.o4t_1.length ? position : -1;
};
protoOf(StringJsonLexer).p4m = function () {
  var source = this.o4t_1;
  $l$loop: while (!(this.g4h_1 === -1) ? this.g4h_1 < source.length : false) {
    var tmp1 = this.g4h_1;
    this.g4h_1 = tmp1 + 1 | 0;
    var ch = charSequenceGet(source, tmp1);
    var tc = charToTokenClass(ch);
    var tmp;
    if (tc === get_TC_WHITESPACE()) {
      continue $l$loop;
    } else {
      tmp = tc;
    }
    return tmp;
  }
  return get_TC_EOF();
};
protoOf(StringJsonLexer).a4o = function () {
  var current = this.f4t();
  if (current === this.o4t_1.length ? true : current === -1)
    return false;
  if (charSequenceGet(this.o4t_1, current) === _Char___init__impl__6a9atx(44)) {
    this.g4h_1 = this.g4h_1 + 1 | 0;
    return true;
  }
  return false;
};
protoOf(StringJsonLexer).l4m = function () {
  var current = this.g4h_1;
  if (current === -1)
    return false;
  $l$loop: while (current < this.o4t_1.length) {
    var c = charSequenceGet(this.o4t_1, current);
    if (((c === _Char___init__impl__6a9atx(32) ? true : c === _Char___init__impl__6a9atx(10)) ? true : c === _Char___init__impl__6a9atx(13)) ? true : c === _Char___init__impl__6a9atx(9)) {
      current = current + 1 | 0;
      continue $l$loop;
    }
    this.g4h_1 = current;
    return this.b4t(c);
  }
  this.g4h_1 = current;
  return false;
};
protoOf(StringJsonLexer).f4t = function () {
  var current = this.g4h_1;
  if (current === -1)
    return current;
  $l$loop: while (current < this.o4t_1.length) {
    var c = charSequenceGet(this.o4t_1, current);
    if (((c === _Char___init__impl__6a9atx(32) ? true : c === _Char___init__impl__6a9atx(10)) ? true : c === _Char___init__impl__6a9atx(13)) ? true : c === _Char___init__impl__6a9atx(9)) {
      current = current + 1 | 0;
    } else {
      break $l$loop;
    }
  }
  this.g4h_1 = current;
  return current;
};
protoOf(StringJsonLexer).z4n = function (expected) {
  if (this.g4h_1 === -1) {
    this.d4t(expected);
  }
  var source = this.o4t_1;
  $l$loop: while (this.g4h_1 < source.length) {
    var tmp1 = this.g4h_1;
    this.g4h_1 = tmp1 + 1 | 0;
    var c = charSequenceGet(source, tmp1);
    if (((c === _Char___init__impl__6a9atx(32) ? true : c === _Char___init__impl__6a9atx(10)) ? true : c === _Char___init__impl__6a9atx(13)) ? true : c === _Char___init__impl__6a9atx(9))
      continue $l$loop;
    if (c === expected)
      return Unit_instance;
    this.d4t(expected);
  }
  this.g4h_1 = -1;
  this.d4t(expected);
};
protoOf(StringJsonLexer).f4o = function () {
  this.z4n(get_STRING());
  var current = this.g4h_1;
  var closingQuote = indexOf(this.o4t_1, _Char___init__impl__6a9atx(34), current);
  if (closingQuote === -1) {
    this.n4m();
    this.e4t(get_TC_STRING(), false);
  }
  var inductionVariable = current;
  if (inductionVariable < closingQuote)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      if (charSequenceGet(this.o4t_1, i) === get_STRING_ESC()) {
        return this.consumeString2(this.o4t_1, this.g4h_1, i);
      }
    }
     while (inductionVariable < closingQuote);
  this.g4h_1 = closingQuote + 1 | 0;
  // Inline function 'kotlin.text.substring' call
  // Inline function 'kotlin.js.asDynamic' call
  return this.o4t_1.substring(current, closingQuote);
};
protoOf(StringJsonLexer).h4o = function (keyToMatch, isLenient) {
  var positionSnapshot = this.g4h_1;
  try {
    if (!(this.p4m() === get_TC_BEGIN_OBJ()))
      return null;
    var firstKey = this.c4o(isLenient);
    if (!(firstKey === keyToMatch))
      return null;
    this.g4t();
    if (!(this.p4m() === get_TC_COLON()))
      return null;
    return this.c4o(isLenient);
  }finally {
    this.g4h_1 = positionSnapshot;
    this.g4t();
  }
};
function get_schemaCache(_this__u8e3s4) {
  return _this__u8e3s4.u4g_1;
}
function JsonToStringWriter() {
  this.x4g_1 = StringBuilder_init_$Create$_0(128);
}
protoOf(JsonToStringWriter).p4k = function (value) {
  this.x4g_1.i8(value);
};
protoOf(JsonToStringWriter).j4k = function (char) {
  this.x4g_1.o5(char);
};
protoOf(JsonToStringWriter).l4k = function (text) {
  this.x4g_1.n5(text);
};
protoOf(JsonToStringWriter).v4k = function (text) {
  printQuoted(this.x4g_1, text);
};
protoOf(JsonToStringWriter).mu = function () {
  this.x4g_1.l8();
};
protoOf(JsonToStringWriter).toString = function () {
  return this.x4g_1.toString();
};
function createMapForCache(initialCapacity) {
  return HashMap_init_$Create$(initialCapacity);
}
//region block: post-declaration
protoOf(defer$1).o3s = get_isNullable;
protoOf(defer$1).t3s = get_isInline;
protoOf(defer$1).a3r = get_annotations;
protoOf(PolymorphismValidator).q4b = contextual;
//endregion
//region block: init
Companion_instance_0 = new Companion();
Companion_instance_1 = new Companion_0();
Companion_instance_2 = new Companion_1();
Companion_instance_3 = new Companion_2();
Tombstone_instance = new Tombstone();
PRIMITIVE_TAG = 'primitive';
TC_WHITESPACE = 3;
TC_EOF = 10;
STRING = _Char___init__impl__6a9atx(34);
TC_STRING = 1;
STRING_ESC = _Char___init__impl__6a9atx(92);
TC_BEGIN_OBJ = 6;
TC_COLON = 5;
TC_COMMA = 4;
COLON = _Char___init__impl__6a9atx(58);
BEGIN_OBJ = _Char___init__impl__6a9atx(123);
END_OBJ = _Char___init__impl__6a9atx(125);
BEGIN_LIST = _Char___init__impl__6a9atx(91);
END_LIST = _Char___init__impl__6a9atx(93);
lenientHint = "Use 'isLenient = true' in 'Json {}' builder to accept non-compliant JSON.";
INVALID = _Char___init__impl__6a9atx(0);
COMMA = _Char___init__impl__6a9atx(44);
NULL = 'null';
TC_OTHER = 0;
TC_BEGIN_LIST = 8;
TC_END_LIST = 9;
TC_END_OBJ = 7;
ignoreUnknownKeysHint = "Use 'ignoreUnknownKeys = true' in 'Json {}' builder to ignore unknown keys.";
specialFlowingValuesHint = "It is possible to deserialize them using 'JsonBuilder.allowSpecialFloatingPointValues = true'";
allowStructuredMapKeysHint = "Use 'allowStructuredMapKeys = true' in 'Json {}' builder to convert such maps to [key1, value1, key2, value2,...] arrays.";
//endregion
//region block: exports
export {
  Default_getInstance as Default_getInstance363hicrc7jsft,
  JsonNull_getInstance as JsonNull_getInstance2gh8fwl8w0wl7,
  Companion_instance_0 as Companion_instance2dhls90gezp41,
  JsonArray as JsonArray2urf8ey7u44sd,
  JsonDecoder as JsonDecoder1rijst5ne6qla,
  JsonEncoder as JsonEncoder1qlse6simkfi1,
  JsonNull as JsonNull2liwjj96vm0w2,
  JsonObjectBuilder as JsonObjectBuilder2nl6rv6vdayuk,
  JsonObject as JsonObjectee06ihoeeiqj,
  JsonPrimitive_0 as JsonPrimitiveolttw629wj53,
  JsonPrimitive_1 as JsonPrimitive2fp8648nd60dn,
  JsonPrimitive_2 as JsonPrimitive1xkjzc5d7ihuv,
  JsonPrimitive as JsonPrimitive3ttzjh2ft5dnx,
  Json_0 as Jsonsmkyu9xjl7fv,
};
//endregion

//# sourceMappingURL=kotlinx-serialization-kotlinx-serialization-json.mjs.map
