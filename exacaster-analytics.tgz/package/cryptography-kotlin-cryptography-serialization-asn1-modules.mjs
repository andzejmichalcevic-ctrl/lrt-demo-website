import {
  protoOf180f3jzyo7rfj as protoOf,
  interfaceMeta1u1l5puptm1ve as interfaceMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  isInterface3d6p8outrmvmk as isInterface,
  toString1pkumu07cwy4m as toString,
  IllegalStateException_init_$Create$3ib9qa3pip8n4 as IllegalStateException_init_$Create$,
  classMetawt99a3kyl3us as classMeta,
  VOID7hggqo3abtya as VOID,
  objectMeta213120oau977m as objectMeta,
  getKClass1s3j9wy1cofik as getKClass,
  objectCreate1ve4bgxiu4x98 as objectCreate,
} from './kotlin-kotlin-stdlib.mjs';
import {
  Companion_instance1lybiqv5r9a9w as Companion_instance,
  ObjectIdentifierz6uf0uceu1gm as ObjectIdentifier,
  _ObjectIdentifier___init__impl__7hutfrpi3i6lsjnc1q as _ObjectIdentifier___init__impl__7hutfr,
  $serializer_getInstance2ldxc6slhxdj4 as $serializer_getInstance,
} from './cryptography-kotlin-cryptography-serialization-asn1.mjs';
import {
  CONTEXTUAL_getInstance1845118lbzky0 as CONTEXTUAL_getInstance,
  buildSerialDescriptor2873qmkp8r2ib as buildSerialDescriptor,
  OPEN_getInstance3ec6az8uwus55 as OPEN_getInstance,
  KSerializerzf77vz1967fq as KSerializer,
  NothingSerializer3oixyyf77l4xt as NothingSerializer,
  ContextualSerializer1uidivg94sh5v as ContextualSerializer,
  PluginGeneratedSerialDescriptorqdzeg5asqhfg as PluginGeneratedSerialDescriptor,
  UnknownFieldException_init_$Create$1mnsp66c6fnup as UnknownFieldException_init_$Create$,
  typeParametersSerializers2likxjr48tr7y as typeParametersSerializers,
  GeneratedSerializer1f7t7hssdd2ws as GeneratedSerializer,
  throwMissingFieldException2cmke0v3ynf14 as throwMissingFieldException,
  IntSerializer_getInstance2q7s8kvk1il5u as IntSerializer_getInstance,
  ByteArraySerializer_getInstance1p0ix35e82iv6 as ByteArraySerializer_getInstance,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
//region block: imports
//endregion
//region block: pre-declaration
setMetadataFor(AlgorithmIdentifier, 'AlgorithmIdentifier', interfaceMeta);
setMetadataFor(AlgorithmIdentifierSerializer, 'AlgorithmIdentifierSerializer', classMeta, VOID, [KSerializer]);
setMetadataFor(KeyAlgorithmIdentifier, 'KeyAlgorithmIdentifier', interfaceMeta, VOID, [AlgorithmIdentifier], VOID, VOID, {0: KeyAlgorithmIdentifierSerializer_getInstance});
setMetadataFor(RsaKeyAlgorithmIdentifier, 'RsaKeyAlgorithmIdentifier', objectMeta, VOID, [KeyAlgorithmIdentifier]);
setMetadataFor(UnknownKeyAlgorithmIdentifier, 'UnknownKeyAlgorithmIdentifier', classMeta, VOID, [KeyAlgorithmIdentifier]);
setMetadataFor(KeyAlgorithmIdentifierSerializer, 'KeyAlgorithmIdentifierSerializer', objectMeta, AlgorithmIdentifierSerializer);
setMetadataFor(Companion, 'Companion', objectMeta);
setMetadataFor($serializer, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(SubjectPublicKeyInfo, 'SubjectPublicKeyInfo', classMeta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_0});
setMetadataFor(Companion_0, 'Companion', objectMeta);
setMetadataFor($serializer_0, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(PrivateKeyInfo, 'PrivateKeyInfo', classMeta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_1});
//endregion
function AlgorithmIdentifier() {
}
function AlgorithmIdentifierSerializer$descriptor$lambda($this$buildSerialDescriptor) {
  $this$buildSerialDescriptor.p3r('algorithm', Companion_instance.u4i().z3q());
  $this$buildSerialDescriptor.p3r('parameters', buildSerialDescriptor('Any', CONTEXTUAL_getInstance(), []));
  return Unit_instance;
}
function AlgorithmIdentifierSerializer() {
  var tmp = this;
  var tmp_0 = OPEN_getInstance();
  tmp.w4x_1 = buildSerialDescriptor('AlgorithmIdentifier', tmp_0, [], AlgorithmIdentifierSerializer$descriptor$lambda);
}
protoOf(AlgorithmIdentifierSerializer).z4x = function (_this__u8e3s4, serializer, value) {
  _this__u8e3s4.d3w(serializer.z3q(), 1, serializer, value);
};
protoOf(AlgorithmIdentifierSerializer).z3q = function () {
  return this.w4x_1;
};
protoOf(AlgorithmIdentifierSerializer).a4y = function (encoder, value) {
  var descriptor = this.w4x_1;
  var composite = encoder.m3u(descriptor);
  // Inline function 'dev.whyoleg.cryptography.serialization.asn1.modules.AlgorithmIdentifierSerializer.serialize.<anonymous>' call
  composite.c3w(Companion_instance.u4i().z3q(), 0, Companion_instance.u4i(), new ObjectIdentifier(value.v4x()));
  this.x4x(composite, value);
  composite.n3u(descriptor);
  return Unit_instance;
};
protoOf(AlgorithmIdentifierSerializer).m3r = function (encoder, value) {
  return this.a4y(encoder, (!(value == null) ? isInterface(value, AlgorithmIdentifier) : false) ? value : THROW_CCE());
};
protoOf(AlgorithmIdentifierSerializer).n3r = function (decoder) {
  // Inline function 'kotlinx.serialization.encoding.decodeStructure' call
  var descriptor = this.w4x_1;
  var composite = decoder.m3u(descriptor);
  // Inline function 'dev.whyoleg.cryptography.serialization.asn1.modules.AlgorithmIdentifierSerializer.deserialize.<anonymous>' call
  var tmp;
  if (composite.b3v()) {
    var algorithm = composite.z3u(Companion_instance.u4i().z3q(), 0, Companion_instance.u4i()).t4w_1;
    tmp = this.y4x(composite, algorithm);
  } else {
    var message = 'For now only sequential decoding is supported';
    throw IllegalStateException_init_$Create$(toString(message));
  }
  var result = tmp;
  composite.n3u(descriptor);
  return result;
};
function RsaKeyAlgorithmIdentifier() {
}
protoOf(RsaKeyAlgorithmIdentifier).v4x = function () {
  return get_RSA(Companion_instance);
};
protoOf(RsaKeyAlgorithmIdentifier).b4y = function () {
  return null;
};
var RsaKeyAlgorithmIdentifier_instance;
function RsaKeyAlgorithmIdentifier_getInstance() {
  return RsaKeyAlgorithmIdentifier_instance;
}
function get_RSA(_this__u8e3s4) {
  return _ObjectIdentifier___init__impl__7hutfr('1.2.840.113549.1.1.1');
}
function KeyAlgorithmIdentifier() {
}
function UnknownKeyAlgorithmIdentifier(algorithm) {
  this.c4y_1 = algorithm;
}
protoOf(UnknownKeyAlgorithmIdentifier).v4x = function () {
  return this.c4y_1;
};
protoOf(UnknownKeyAlgorithmIdentifier).b4y = function () {
  return null;
};
function KeyAlgorithmIdentifierSerializer() {
  KeyAlgorithmIdentifierSerializer_instance = this;
  AlgorithmIdentifierSerializer.call(this);
}
protoOf(KeyAlgorithmIdentifierSerializer).e4y = function (_this__u8e3s4, value) {
  var tmp;
  if (value instanceof RsaKeyAlgorithmIdentifier) {
    this.z4x(_this__u8e3s4, NothingSerializer(), RsaKeyAlgorithmIdentifier_instance.b4y());
    tmp = Unit_instance;
  } else {
    if (value instanceof UnknownKeyAlgorithmIdentifier) {
      this.z4x(_this__u8e3s4, NothingSerializer(), value.b4y());
      tmp = Unit_instance;
    } else {
      this.z4x(_this__u8e3s4, NothingSerializer(), null);
      tmp = Unit_instance;
    }
  }
  return tmp;
};
protoOf(KeyAlgorithmIdentifierSerializer).x4x = function (_this__u8e3s4, value) {
  return this.e4y(_this__u8e3s4, isInterface(value, KeyAlgorithmIdentifier) ? value : THROW_CCE());
};
protoOf(KeyAlgorithmIdentifierSerializer).y4x = function (_this__u8e3s4, algorithm) {
  return algorithm === get_RSA(Companion_instance) ? RsaKeyAlgorithmIdentifier_instance : new UnknownKeyAlgorithmIdentifier(algorithm);
};
var KeyAlgorithmIdentifierSerializer_instance;
function KeyAlgorithmIdentifierSerializer_getInstance() {
  if (KeyAlgorithmIdentifierSerializer_instance == null)
    new KeyAlgorithmIdentifierSerializer();
  return KeyAlgorithmIdentifierSerializer_instance;
}
function Companion() {
  Companion_instance_0 = this;
  var tmp = this;
  // Inline function 'kotlin.arrayOf' call
  var tmp_0 = getKClass(KeyAlgorithmIdentifier);
  var tmp_1 = KeyAlgorithmIdentifierSerializer_getInstance();
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$2 = [];
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  tmp.f4y_1 = [new ContextualSerializer(tmp_0, tmp_1, tmp$ret$2), null];
}
protoOf(Companion).u4i = function () {
  return $serializer_getInstance_0();
};
var Companion_instance_0;
function Companion_getInstance() {
  if (Companion_instance_0 == null)
    new Companion();
  return Companion_instance_0;
}
function $serializer() {
  $serializer_instance = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('dev.whyoleg.cryptography.serialization.asn1.modules.SubjectPublicKeyInfo', this, 2);
  tmp0_serialDesc.w41('algorithm', false);
  tmp0_serialDesc.w41('subjectPublicKey', false);
  this.g4y_1 = tmp0_serialDesc;
}
protoOf($serializer).z3q = function () {
  return this.g4y_1;
};
protoOf($serializer).l42 = function () {
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [Companion_getInstance().f4y_1[0], $serializer_getInstance()];
};
protoOf($serializer).n3r = function (decoder) {
  var tmp0_desc = this.g4y_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = null;
  var tmp5_local1 = null;
  var tmp6_input = decoder.m3u(tmp0_desc);
  var tmp7_cached = Companion_getInstance().f4y_1;
  if (tmp6_input.b3v()) {
    tmp4_local0 = tmp6_input.y3u(tmp0_desc, 0, tmp7_cached[0], tmp4_local0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp6_input.y3u(tmp0_desc, 1, $serializer_getInstance(), tmp5_local1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp6_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp6_input.y3u(tmp0_desc, 0, tmp7_cached[0], tmp4_local0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp6_input.y3u(tmp0_desc, 1, $serializer_getInstance(), tmp5_local1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp6_input.n3u(tmp0_desc);
  return SubjectPublicKeyInfo_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
};
protoOf($serializer).h4y = function (encoder, value) {
  var tmp0_desc = this.g4y_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  var tmp2_cached = Companion_getInstance().f4y_1;
  tmp1_output.c3w(tmp0_desc, 0, tmp2_cached[0], value.i4y_1);
  tmp1_output.c3w(tmp0_desc, 1, $serializer_getInstance(), value.j4y_1);
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer).m3r = function (encoder, value) {
  return this.h4y(encoder, value instanceof SubjectPublicKeyInfo ? value : THROW_CCE());
};
var $serializer_instance;
function $serializer_getInstance_0() {
  if ($serializer_instance == null)
    new $serializer();
  return $serializer_instance;
}
function SubjectPublicKeyInfo_init_$Init$(seen1, algorithm, subjectPublicKey, serializationConstructorMarker, $this) {
  if (!(3 === (3 & seen1))) {
    throwMissingFieldException(seen1, 3, $serializer_getInstance_0().g4y_1);
  }
  $this.i4y_1 = algorithm;
  $this.j4y_1 = subjectPublicKey;
  return $this;
}
function SubjectPublicKeyInfo_init_$Create$(seen1, algorithm, subjectPublicKey, serializationConstructorMarker) {
  return SubjectPublicKeyInfo_init_$Init$(seen1, algorithm, subjectPublicKey, serializationConstructorMarker, objectCreate(protoOf(SubjectPublicKeyInfo)));
}
function SubjectPublicKeyInfo(algorithm, subjectPublicKey) {
  Companion_getInstance();
  this.i4y_1 = algorithm;
  this.j4y_1 = subjectPublicKey;
}
function Companion_0() {
  Companion_instance_1 = this;
  var tmp = this;
  // Inline function 'kotlin.arrayOf' call
  var tmp_0 = getKClass(KeyAlgorithmIdentifier);
  var tmp_1 = KeyAlgorithmIdentifierSerializer_getInstance();
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$2 = [];
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  tmp.k4y_1 = [null, new ContextualSerializer(tmp_0, tmp_1, tmp$ret$2), null];
}
protoOf(Companion_0).u4i = function () {
  return $serializer_getInstance_1();
};
var Companion_instance_1;
function Companion_getInstance_0() {
  if (Companion_instance_1 == null)
    new Companion_0();
  return Companion_instance_1;
}
function $serializer_0() {
  $serializer_instance_0 = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('dev.whyoleg.cryptography.serialization.asn1.modules.PrivateKeyInfo', this, 3);
  tmp0_serialDesc.w41('version', false);
  tmp0_serialDesc.w41('privateKeyAlgorithm', false);
  tmp0_serialDesc.w41('privateKey', false);
  this.l4y_1 = tmp0_serialDesc;
}
protoOf($serializer_0).z3q = function () {
  return this.l4y_1;
};
protoOf($serializer_0).l42 = function () {
  var tmp0_cached = Companion_getInstance_0().k4y_1;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [IntSerializer_getInstance(), tmp0_cached[1], ByteArraySerializer_getInstance()];
};
protoOf($serializer_0).n3r = function (decoder) {
  var tmp0_desc = this.l4y_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = 0;
  var tmp5_local1 = null;
  var tmp6_local2 = null;
  var tmp7_input = decoder.m3u(tmp0_desc);
  var tmp8_cached = Companion_getInstance_0().k4y_1;
  if (tmp7_input.b3v()) {
    tmp4_local0 = tmp7_input.r3u(tmp0_desc, 0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp7_input.y3u(tmp0_desc, 1, tmp8_cached[1], tmp5_local1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
    tmp6_local2 = tmp7_input.y3u(tmp0_desc, 2, ByteArraySerializer_getInstance(), tmp6_local2);
    tmp3_bitMask0 = tmp3_bitMask0 | 4;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp7_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp7_input.r3u(tmp0_desc, 0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp7_input.y3u(tmp0_desc, 1, tmp8_cached[1], tmp5_local1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        case 2:
          tmp6_local2 = tmp7_input.y3u(tmp0_desc, 2, ByteArraySerializer_getInstance(), tmp6_local2);
          tmp3_bitMask0 = tmp3_bitMask0 | 4;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp7_input.n3u(tmp0_desc);
  return PrivateKeyInfo_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
};
protoOf($serializer_0).m4y = function (encoder, value) {
  var tmp0_desc = this.l4y_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  var tmp2_cached = Companion_getInstance_0().k4y_1;
  tmp1_output.v3v(tmp0_desc, 0, value.n4y_1);
  tmp1_output.c3w(tmp0_desc, 1, tmp2_cached[1], value.o4y_1);
  tmp1_output.c3w(tmp0_desc, 2, ByteArraySerializer_getInstance(), value.p4y_1);
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer_0).m3r = function (encoder, value) {
  return this.m4y(encoder, value instanceof PrivateKeyInfo ? value : THROW_CCE());
};
var $serializer_instance_0;
function $serializer_getInstance_1() {
  if ($serializer_instance_0 == null)
    new $serializer_0();
  return $serializer_instance_0;
}
function PrivateKeyInfo_init_$Init$(seen1, version, privateKeyAlgorithm, privateKey, serializationConstructorMarker, $this) {
  if (!(7 === (7 & seen1))) {
    throwMissingFieldException(seen1, 7, $serializer_getInstance_1().l4y_1);
  }
  $this.n4y_1 = version;
  $this.o4y_1 = privateKeyAlgorithm;
  $this.p4y_1 = privateKey;
  return $this;
}
function PrivateKeyInfo_init_$Create$(seen1, version, privateKeyAlgorithm, privateKey, serializationConstructorMarker) {
  return PrivateKeyInfo_init_$Init$(seen1, version, privateKeyAlgorithm, privateKey, serializationConstructorMarker, objectCreate(protoOf(PrivateKeyInfo)));
}
function PrivateKeyInfo(version, privateKeyAlgorithm, privateKey) {
  Companion_getInstance_0();
  this.n4y_1 = version;
  this.o4y_1 = privateKeyAlgorithm;
  this.p4y_1 = privateKey;
}
//region block: post-declaration
protoOf($serializer).m42 = typeParametersSerializers;
protoOf($serializer_0).m42 = typeParametersSerializers;
//endregion
//region block: init
RsaKeyAlgorithmIdentifier_instance = new RsaKeyAlgorithmIdentifier();
//endregion
//region block: exports
export {
  PrivateKeyInfo as PrivateKeyInfou42ielkmgvu2,
  get_RSA as get_RSA30ci1l0u72mkd,
  SubjectPublicKeyInfo as SubjectPublicKeyInfo1tner6n57cb2l,
  Companion_getInstance_0 as Companion_getInstancefp1mml3gm8u5,
  RsaKeyAlgorithmIdentifier_instance as RsaKeyAlgorithmIdentifier_instance2u9y4u3euyfj4,
  Companion_getInstance as Companion_getInstance3ld3jdhb4r99r,
};
//endregion

//# sourceMappingURL=cryptography-kotlin-cryptography-serialization-asn1-modules.mjs.map
