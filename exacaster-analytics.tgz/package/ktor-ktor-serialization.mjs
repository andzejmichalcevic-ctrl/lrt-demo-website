import {
  Exceptiondt2hlxn7j7vw as Exception,
  VOID7hggqo3abtya as VOID,
  Exception_init_$Init$2fx1sms2m4tu1 as Exception_init_$Init$,
  captureStack1fzi4aczwc4hg as captureStack,
  protoOf180f3jzyo7rfj as protoOf,
  classMetawt99a3kyl3us as classMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  interfaceMeta1u1l5puptm1ve as interfaceMeta,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  CoroutineImpl2sn3kjnwmfr10 as CoroutineImpl,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  isInterface3d6p8outrmvmk as isInterface,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
} from './kotlin-kotlin-stdlib.mjs';
import {
  Charsets_getInstanceqs70pvl4noow as Charsets_getInstance,
  Companion_instance3aiov6iqkz7e8 as Companion_instance,
} from './ktor-ktor-io.mjs';
import {
  HttpHeaders_getInstanceelogg8fjd54u as HttpHeaders_getInstance,
  parseAndSortHeader33xgq5fx7y6j1 as parseAndSortHeader,
  NullBody_instance2i6w0hfghwfg0 as NullBody_instance,
} from './ktor-ktor-http.mjs';
import {
  asFlow3ngsnn5xpz8pw as asFlow,
  firstOrNull3jjcu7fygcopr as firstOrNull,
} from './kotlinx-coroutines-core.mjs';
//region block: imports
//endregion
//region block: pre-declaration
setMetadataFor(ContentConvertException, 'ContentConvertException', classMeta, Exception);
setMetadataFor(JsonConvertException, 'JsonConvertException', classMeta, ContentConvertException);
function register$default(contentType, converter, configuration, $super) {
  var tmp;
  if (configuration === VOID) {
    tmp = Configuration$register$lambda;
  } else {
    tmp = configuration;
  }
  configuration = tmp;
  var tmp_0;
  if ($super === VOID) {
    this.a2e(contentType, converter, configuration);
    tmp_0 = Unit_instance;
  } else {
    tmp_0 = $super.a2e.call(this, contentType, converter, configuration);
  }
  return tmp_0;
}
setMetadataFor(Configuration, 'Configuration', interfaceMeta);
function serialize(contentType, charset, typeInfo, value, $completion) {
  return this.d2e(contentType, charset, typeInfo, value, $completion);
}
function serializeNullable(contentType, charset, typeInfo, value, $completion) {
  return this.c2e(contentType, charset, typeInfo, ensureNotNull(value), $completion);
}
setMetadataFor(ContentConverter, 'ContentConverter', interfaceMeta, VOID, VOID, VOID, VOID, VOID, [4, 3]);
setMetadataFor(sam$kotlinx_coroutines_flow_FlowCollector$0, 'sam$kotlinx_coroutines_flow_FlowCollector$0', classMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(deserialize$o$collect$slambda, 'deserialize$o$collect$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor($collectCOROUTINE$1, '$collectCOROUTINE$1', classMeta, CoroutineImpl);
setMetadataFor(_no_name_provided__qut3iv, VOID, classMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(deserialize$slambda, 'deserialize$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor($deserializeCOROUTINE$0, '$deserializeCOROUTINE$0', classMeta, CoroutineImpl);
//endregion
function ContentConvertException(message, cause) {
  cause = cause === VOID ? null : cause;
  Exception_init_$Init$(message, cause, this);
  captureStack(this, ContentConvertException);
}
function JsonConvertException(message, cause) {
  cause = cause === VOID ? null : cause;
  ContentConvertException.call(this, message, cause);
  captureStack(this, JsonConvertException);
}
function Configuration$register$lambda($this$null) {
  return Unit_instance;
}
function Configuration() {
}
function ContentConverter() {
}
function deserialize(_this__u8e3s4, body, typeInfo, charset, $completion) {
  var tmp = new $deserializeCOROUTINE$0(_this__u8e3s4, body, typeInfo, charset, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function suitableCharset(_this__u8e3s4, defaultCharset) {
  defaultCharset = defaultCharset === VOID ? Charsets_getInstance().t1p_1 : defaultCharset;
  var tmp0_elvis_lhs = suitableCharsetOrNull(_this__u8e3s4, defaultCharset);
  return tmp0_elvis_lhs == null ? defaultCharset : tmp0_elvis_lhs;
}
function suitableCharsetOrNull(_this__u8e3s4, defaultCharset) {
  defaultCharset = defaultCharset === VOID ? Charsets_getInstance().t1p_1 : defaultCharset;
  var tmp0_iterator = parseAndSortHeader(_this__u8e3s4.l1w(HttpHeaders_getInstance().f23_1)).u();
  while (tmp0_iterator.v()) {
    var charset = tmp0_iterator.w().we();
    if (charset === '*')
      return defaultCharset;
    else if (Companion_instance.v1s(charset))
      return Companion_instance.u1s(charset);
  }
  return null;
}
function sam$kotlinx_coroutines_flow_FlowCollector$0(function_0) {
  this.r2e_1 = function_0;
}
protoOf(sam$kotlinx_coroutines_flow_FlowCollector$0).a14 = function (value, $completion) {
  return this.r2e_1(value, $completion);
};
function deserialize$o$collect$slambda($$this$unsafeFlow, $charset, $typeInfo, $body, resultContinuation) {
  this.a2f_1 = $$this$unsafeFlow;
  this.b2f_1 = $charset;
  this.c2f_1 = $typeInfo;
  this.d2f_1 = $body;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(deserialize$o$collect$slambda).j2f = function (value, $completion) {
  var tmp = this.k2f(value, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(deserialize$o$collect$slambda).gd = function (p1, $completion) {
  return this.j2f((!(p1 == null) ? isInterface(p1, ContentConverter) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(deserialize$o$collect$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          var tmp_0 = this;
          tmp_0.f2f_1 = this.a2f_1;
          var tmp_1 = this;
          tmp_1.g2f_1 = this.e2f_1;
          var tmp_2 = this;
          tmp_2.h2f_1 = this.g2f_1;
          this.ic_1 = 1;
          suspendResult = this.h2f_1.e2e(this.b2f_1, this.c2f_1, this.d2f_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.i2f_1 = suspendResult;
          this.ic_1 = 2;
          suspendResult = this.f2f_1.a14(this.i2f_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          return Unit_instance;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
protoOf(deserialize$o$collect$slambda).k2f = function (value, completion) {
  var i = new deserialize$o$collect$slambda(this.a2f_1, this.b2f_1, this.c2f_1, this.d2f_1, completion);
  i.e2f_1 = value;
  return i;
};
function deserialize$o$collect$slambda_0($$this$unsafeFlow, $charset, $typeInfo, $body, resultContinuation) {
  var i = new deserialize$o$collect$slambda($$this$unsafeFlow, $charset, $typeInfo, $body, resultContinuation);
  var l = function (value, $completion) {
    return i.j2f(value, $completion);
  };
  l.$arity = 1;
  return l;
}
function $collectCOROUTINE$1(_this__u8e3s4, collector, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.t2f_1 = _this__u8e3s4;
  this.u2f_1 = collector;
}
protoOf($collectCOROUTINE$1).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          var tmp_0 = this;
          tmp_0.v2f_1 = this.u2f_1;
          this.ic_1 = 1;
          var tmp_1 = deserialize$o$collect$slambda_0(this.v2f_1, this.t2f_1.x2f_1, this.t2f_1.y2f_1, this.t2f_1.z2f_1, null);
          suspendResult = this.t2f_1.w2f_1.b14(new sam$kotlinx_coroutines_flow_FlowCollector$0(tmp_1), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          return Unit_instance;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function _no_name_provided__qut3iv($this, $charset, $typeInfo, $body) {
  this.w2f_1 = $this;
  this.x2f_1 = $charset;
  this.y2f_1 = $typeInfo;
  this.z2f_1 = $body;
}
protoOf(_no_name_provided__qut3iv).a2g = function (collector, $completion) {
  var tmp = new $collectCOROUTINE$1(this, collector, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(_no_name_provided__qut3iv).b14 = function (collector, $completion) {
  return this.a2g(collector, $completion);
};
function deserialize$slambda($body, resultContinuation) {
  this.j2g_1 = $body;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(deserialize$slambda).l2g = function (it, $completion) {
  var tmp = this.m2g(it, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(deserialize$slambda).gd = function (p1, $completion) {
  return this.l2g((p1 == null ? true : !(p1 == null)) ? p1 : THROW_CCE(), $completion);
};
protoOf(deserialize$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      if (tmp === 0) {
        this.jc_1 = 1;
        return !(this.k2g_1 == null) ? true : this.j2g_1.h1f();
      } else if (tmp === 1) {
        throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      throw e;
    }
   while (true);
};
protoOf(deserialize$slambda).m2g = function (it, completion) {
  var i = new deserialize$slambda(this.j2g_1, completion);
  i.k2g_1 = it;
  return i;
};
function deserialize$slambda_0($body, resultContinuation) {
  var i = new deserialize$slambda($body, resultContinuation);
  var l = function (it, $completion) {
    return i.l2g(it, $completion);
  };
  l.$arity = 1;
  return l;
}
function $deserializeCOROUTINE$0(_this__u8e3s4, body, typeInfo, charset, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.n2e_1 = _this__u8e3s4;
  this.o2e_1 = body;
  this.p2e_1 = typeInfo;
  this.q2e_1 = charset;
}
protoOf($deserializeCOROUTINE$0).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          var this_0 = asFlow(this.n2e_1);
          var tmp_0 = new _no_name_provided__qut3iv(this_0, this.q2e_1, this.p2e_1, this.o2e_1);
          suspendResult = firstOrNull(tmp_0, deserialize$slambda_0(this.o2e_1, null), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var result = suspendResult;
          var tmp_1;
          if (!(result == null)) {
            tmp_1 = result;
          } else {
            if (!this.o2e_1.h1f()) {
              tmp_1 = this.o2e_1;
            } else {
              var tmp0_safe_receiver = this.p2e_1.b21_1;
              if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i7()) === true) {
                tmp_1 = NullBody_instance;
              } else {
                throw new ContentConvertException('No suitable converter found for ' + this.p2e_1);
              }
            }
          }

          return tmp_1;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
//region block: exports
export {
  deserialize as deserialize3kqe4vxpbxz1,
  register$default as register$default1vru4l6f6i5dq,
  Configuration as Configuration20xgygxdzhlk5,
  ContentConverter as ContentConverteryzo4k0ursexh,
  JsonConvertException as JsonConvertExceptiongnc5x6xwaf77,
  suitableCharset as suitableCharset1jgdcpdzbzgzn,
};
//endregion

//# sourceMappingURL=ktor-ktor-serialization.mjs.map
