import {
  Unit_instance1fbcbse1fwigr as Unit_instance,
  protoOf180f3jzyo7rfj as protoOf,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  Continuation1aa2oekvx7jm7 as Continuation,
  classMetawt99a3kyl3us as classMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  VOID7hggqo3abtya as VOID,
  throwUninitializedPropertyAccessExceptionyynx7gkm73wd as throwUninitializedPropertyAccessException,
  ArrayList_init_$Create$1s1wkrw82c0iw as ArrayList_init_$Create$,
  Companion_instance2oawqq9qiaris as Companion_instance,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  intercepted2ogpsikxxj4u0 as intercepted,
  fillArrayVali8eppxapiek4 as fillArrayVal,
  CoroutineImpl2sn3kjnwmfr10 as CoroutineImpl,
  copyToArray2j022khrow2yi as copyToArray,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  emptyList1g2z5xcrvp2zy as emptyList,
  EmptyCoroutineContext_getInstance31fow51ayy30t as EmptyCoroutineContext_getInstance,
  createCoroutineUnintercepted3gya308dmbbtg as createCoroutineUnintercepted,
  interfaceMeta1u1l5puptm1ve as interfaceMeta,
  isInterface3d6p8outrmvmk as isInterface,
  toString1pkumu07cwy4m as toString,
  IllegalStateException_init_$Create$3ib9qa3pip8n4 as IllegalStateException_init_$Create$,
  toString30pk9tzaqopn as toString_0,
  objectMeta213120oau977m as objectMeta,
  hashCodeq5arwsb9dgti as hashCode,
  equals2au1ep9vhcato as equals,
  CancellationException_init_$Create$tastk7hwpe6q as CancellationException_init_$Create$,
  Result__exceptionOrNull_impl_p6xea9boty10p2dkn4 as Result__exceptionOrNull_impl_p6xea9,
  _Result___get_value__impl__bjfvqgo6z1uu11rodr as _Result___get_value__impl__bjfvqg,
  AbstractCoroutineContextKey9xr9r6wlj5bm as AbstractCoroutineContextKey,
  Key_instance17k9ki7fvysxq as Key_instance,
  AbstractCoroutineContextElement2rpehg0hv5szw as AbstractCoroutineContextElement,
  getxe4seun860fg as get,
  minusKey2uxs00uz5ceqp as minusKey,
  ContinuationInterceptor2624y0vaqwxwf as ContinuationInterceptor,
  RuntimeException_init_$Create$2bna3ujtv2xfg as RuntimeException_init_$Create$,
  addSuppressedu5jwjfvsc039 as addSuppressed,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  CancellationException_init_$Create$35hy9ztjr481d as CancellationException_init_$Create$_0,
  Enum3alwj03lh1n41 as Enum,
  startCoroutine327fwvtqvedik as startCoroutine,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  Long2qws0ah9gnpki as Long,
  Companion_getInstance3gn12jgnf4xoo as Companion_getInstance,
  ArrayDeque_init_$Create$h67uqnktr40s as ArrayDeque_init_$Create$,
  RuntimeException1r3t0zl97011n as RuntimeException,
  RuntimeException_init_$Init$pie20kq3b0k5 as RuntimeException_init_$Init$,
  captureStack1fzi4aczwc4hg as captureStack,
  Error3ofk6owajcepa as Error_0,
  Error_init_$Init$1mferl5sasanp as Error_init_$Init$,
  Element2gr7ezmxqaln7 as Element,
  StringBuilder_init_$Create$2mwec1027v00x as StringBuilder_init_$Create$,
  CancellationException3b36o9qz53rgr as CancellationException,
  ArrayList3it5z8td81qkl as ArrayList,
  IllegalStateException_init_$Create$3oc7yxbr91okv as IllegalStateException_init_$Create$_0,
  plusolev77jfy5r9 as plus,
  get6d5x931vk0s as get_0,
  fold36i9psb7d5v48 as fold,
  minusKeyyqanvso9aovh as minusKey_0,
  anyToString3ho3k49fc56mj as anyToString,
  createFailure8paxfkfa5dc7 as createFailure,
  UnsupportedOperationException2tkumpmhredt3 as UnsupportedOperationException,
  UnsupportedOperationException_init_$Create$1j11kynu3hen2 as UnsupportedOperationException_init_$Create$,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  toLongw1zpgk99d84b as toLong,
  IllegalArgumentException_init_$Create$310sysrobvll9 as IllegalArgumentException_init_$Create$,
  listOf1jh22dvmctj1r as listOf,
  ArrayList_init_$Create$2qnngtk1et9r9 as ArrayList_init_$Create$_0,
  NoSuchElementException_init_$Create$wjvpfebkn9od as NoSuchElementException_init_$Create$,
  compareTo3ankvs086tmwq as compareTo,
  last2n4gf5az1lkn4 as last,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  IllegalStateException_init_$Init$13tvpwythio9e as IllegalStateException_init_$Init$,
  NoSuchElementException679xzhnp5bpj as NoSuchElementException,
  NoSuchElementException_init_$Init$t057lwce4s32 as NoSuchElementException_init_$Init$,
  getKClass1s3j9wy1cofik as getKClass,
  copyOf2ng0t8oizk6it as copyOf,
  IntCompanionObject_instance3tw56cgyd5vup as IntCompanionObject_instance,
  throwKotlinNothingValueException2lxmvl03dor6f as throwKotlinNothingValueException,
  Exceptiondt2hlxn7j7vw as Exception,
  toLongOrNullutqivezb0wx1 as toLongOrNull,
  plus20p0vtfmu0596 as plus_0,
  List3hktaavzmj137 as List,
  listOfvhqybd2zx248 as listOf_0,
  Unitkvevlwgzwiuc as Unit,
  getKClassFromExpression3vpejubogshaw as getKClassFromExpression,
  CancellationException_init_$Init$2ahklm0bmfmy1 as CancellationException_init_$Init$,
  CancellationException_init_$Init$n55z32xt5rdh as CancellationException_init_$Init$_0,
  HashSet_init_$Create$7yrdg7emowlg as HashSet_init_$Create$,
  RuntimeException_init_$Init$tgzj522na926 as RuntimeException_init_$Init$_0,
  LinkedHashSet_init_$Create$3qv13l7kzf0ni as LinkedHashSet_init_$Create$,
  removeFirstOrNull15yg2tczrh8a7 as removeFirstOrNull,
  MutableList1beimitadwkna as MutableList,
  coerceIn302bduskdb54x as coerceIn,
  UnsupportedOperationException_init_$Create$3ardu5em03a22 as UnsupportedOperationException_init_$Create$_0,
} from './kotlin-kotlin-stdlib.mjs';
import {
  atomic$ref$130aurmcwdfdf1 as atomic$ref$1,
  atomic$int$11d5swdyn6j0pu as atomic$int$1,
  atomic$boolean$1iggki4z65a2h as atomic$boolean$1,
  atomicfu$AtomicRefArray$ofNulls2kz3j9ehigwa3 as atomicfu$AtomicRefArray$ofNulls,
  atomic$long$129k9zwo6n9ogd as atomic$long$1,
} from './kotlinx-atomicfu.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
function cancel$default(cause, $super) {
  cause = cause === VOID ? null : cause;
  var tmp;
  if ($super === VOID) {
    this.bo(cause);
    tmp = Unit_instance;
  } else {
    tmp = $super.bo.call(this, cause);
  }
  return tmp;
}
function invokeOnCompletion$default(onCancelling, invokeImmediately, handler, $super) {
  onCancelling = onCancelling === VOID ? false : onCancelling;
  invokeImmediately = invokeImmediately === VOID ? true : invokeImmediately;
  return $super === VOID ? this.xn(onCancelling, invokeImmediately, handler) : $super.xn.call(this, onCancelling, invokeImmediately, handler);
}
setMetadataFor(Job, 'Job', interfaceMeta, VOID, [Element], VOID, VOID, VOID, [0]);
setMetadataFor(ParentJob, 'ParentJob', interfaceMeta, VOID, [Job], VOID, VOID, VOID, [0]);
setMetadataFor(JobSupport, 'JobSupport', classMeta, VOID, [Job, ParentJob], VOID, VOID, VOID, [0]);
setMetadataFor(CoroutineScope, 'CoroutineScope', interfaceMeta);
setMetadataFor(AbstractCoroutine, 'AbstractCoroutine', classMeta, JobSupport, [JobSupport, Job, Continuation, CoroutineScope], VOID, VOID, VOID, [0]);
setMetadataFor(CancelHandlerBase, 'CancelHandlerBase', classMeta);
setMetadataFor(NotCompleted, 'NotCompleted', interfaceMeta);
setMetadataFor(CancelHandler, 'CancelHandler', classMeta, CancelHandlerBase, [CancelHandlerBase, NotCompleted]);
setMetadataFor(DisposeHandlersOnCancel, 'DisposeHandlersOnCancel', classMeta, CancelHandler);
setMetadataFor(LinkedListNode, 'LinkedListNode', classMeta, VOID, VOID, LinkedListNode);
setMetadataFor(CompletionHandlerBase, 'CompletionHandlerBase', classMeta, LinkedListNode);
setMetadataFor(Incomplete, 'Incomplete', interfaceMeta);
setMetadataFor(JobNode, 'JobNode', classMeta, CompletionHandlerBase, [CompletionHandlerBase, Incomplete]);
setMetadataFor(AwaitAllNode, 'AwaitAllNode', classMeta, JobNode);
setMetadataFor(AwaitAll, 'AwaitAll', classMeta, VOID, VOID, VOID, VOID, VOID, [0]);
setMetadataFor($awaitAllCOROUTINE$0, '$awaitAllCOROUTINE$0', classMeta, CoroutineImpl);
setMetadataFor(StandaloneCoroutine, 'StandaloneCoroutine', classMeta, AbstractCoroutine, VOID, VOID, VOID, VOID, [0]);
setMetadataFor(LazyStandaloneCoroutine, 'LazyStandaloneCoroutine', classMeta, StandaloneCoroutine, VOID, VOID, VOID, VOID, [0]);
setMetadataFor($awaitCOROUTINE$1, '$awaitCOROUTINE$1', classMeta, CoroutineImpl);
setMetadataFor(DeferredCoroutine, 'DeferredCoroutine', classMeta, AbstractCoroutine, [AbstractCoroutine, Job], VOID, VOID, VOID, [0]);
setMetadataFor(LazyDeferredCoroutine, 'LazyDeferredCoroutine', classMeta, DeferredCoroutine, VOID, VOID, VOID, VOID, [0]);
setMetadataFor(CancellableContinuation, 'CancellableContinuation', interfaceMeta, VOID, [Continuation]);
setMetadataFor(DisposeOnCancel, 'DisposeOnCancel', classMeta, CancelHandler);
setMetadataFor(Runnable, 'Runnable', interfaceMeta);
setMetadataFor(SchedulerTask, 'SchedulerTask', classMeta, VOID, [Runnable]);
setMetadataFor(DispatchedTask, 'DispatchedTask', classMeta, SchedulerTask);
setMetadataFor(Waiter, 'Waiter', interfaceMeta);
setMetadataFor(CancellableContinuationImpl, 'CancellableContinuationImpl', classMeta, DispatchedTask, [DispatchedTask, CancellableContinuation, Waiter]);
setMetadataFor(Active, 'Active', objectMeta, VOID, [NotCompleted]);
setMetadataFor(CompletedContinuation, 'CompletedContinuation', classMeta);
setMetadataFor(InvokeOnCancel, 'InvokeOnCancel', classMeta, CancelHandler);
setMetadataFor($awaitCOROUTINE$2, '$awaitCOROUTINE$2', classMeta, CoroutineImpl);
setMetadataFor(CompletableDeferredImpl, 'CompletableDeferredImpl', classMeta, JobSupport, [JobSupport, Job], VOID, VOID, VOID, [0]);
setMetadataFor(CompletableJob, 'CompletableJob', interfaceMeta, VOID, [Job], VOID, VOID, VOID, [0]);
setMetadataFor(CompletedExceptionally, 'CompletedExceptionally', classMeta);
setMetadataFor(CancelledContinuation, 'CancelledContinuation', classMeta, CompletedExceptionally);
setMetadataFor(CompletedWithCancellation, 'CompletedWithCancellation', classMeta);
setMetadataFor(Key, 'Key', objectMeta, AbstractCoroutineContextKey);
setMetadataFor(CoroutineDispatcher, 'CoroutineDispatcher', classMeta, AbstractCoroutineContextElement, [AbstractCoroutineContextElement, ContinuationInterceptor]);
setMetadataFor(Key_0, 'Key', objectMeta);
setMetadataFor(Key_1, 'Key', objectMeta);
setMetadataFor(CoroutineName, 'CoroutineName', classMeta, AbstractCoroutineContextElement);
setMetadataFor(GlobalScope, 'GlobalScope', objectMeta, VOID, [CoroutineScope]);
setMetadataFor(CoroutineStart, 'CoroutineStart', classMeta, Enum);
setMetadataFor(Delay, 'Delay', interfaceMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(EventLoop, 'EventLoop', classMeta, CoroutineDispatcher);
setMetadataFor(ThreadLocalEventLoop, 'ThreadLocalEventLoop', objectMeta);
setMetadataFor(CompletionHandlerException, 'CompletionHandlerException', classMeta, RuntimeException);
setMetadataFor(CoroutinesInternalError, 'CoroutinesInternalError', classMeta, Error_0);
setMetadataFor(Key_2, 'Key', objectMeta);
setMetadataFor(ChildHandle, 'ChildHandle', interfaceMeta);
setMetadataFor(NonDisposableHandle, 'NonDisposableHandle', objectMeta, VOID, [ChildHandle]);
setMetadataFor(Empty, 'Empty', classMeta, VOID, [Incomplete]);
setMetadataFor(LinkedListHead, 'LinkedListHead', classMeta, LinkedListNode, VOID, LinkedListHead);
setMetadataFor(NodeList, 'NodeList', classMeta, LinkedListHead, [LinkedListHead, Incomplete], NodeList);
setMetadataFor(SynchronizedObject, 'SynchronizedObject', classMeta, VOID, VOID, SynchronizedObject);
setMetadataFor(Finishing, 'Finishing', classMeta, SynchronizedObject, [SynchronizedObject, Incomplete]);
setMetadataFor(ChildCompletion, 'ChildCompletion', classMeta, JobNode);
setMetadataFor(AwaitContinuation, 'AwaitContinuation', classMeta, CancellableContinuationImpl);
setMetadataFor(JobCancellingNode, 'JobCancellingNode', classMeta, JobNode);
setMetadataFor(InactiveNodeList, 'InactiveNodeList', classMeta, VOID, [Incomplete]);
setMetadataFor(ChildHandleNode, 'ChildHandleNode', classMeta, JobCancellingNode, [JobCancellingNode, ChildHandle]);
setMetadataFor(InvokeOnCancelling, 'InvokeOnCancelling', classMeta, JobCancellingNode);
setMetadataFor(InvokeOnCompletion, 'InvokeOnCompletion', classMeta, JobNode);
setMetadataFor(ResumeOnCompletion, 'ResumeOnCompletion', classMeta, JobNode);
setMetadataFor(ResumeAwaitOnCompletion, 'ResumeAwaitOnCompletion', classMeta, JobNode);
setMetadataFor(IncompleteStateBox, 'IncompleteStateBox', classMeta);
setMetadataFor(ChildContinuation, 'ChildContinuation', classMeta, JobCancellingNode);
setMetadataFor(JobImpl, 'JobImpl', classMeta, JobSupport, [JobSupport, CompletableJob], VOID, VOID, VOID, [0]);
setMetadataFor(MainCoroutineDispatcher, 'MainCoroutineDispatcher', classMeta, CoroutineDispatcher);
setMetadataFor(SupervisorJobImpl, 'SupervisorJobImpl', classMeta, JobImpl, VOID, VOID, VOID, VOID, [0]);
setMetadataFor(TimeoutCancellationException, 'TimeoutCancellationException', classMeta, CancellationException);
setMetadataFor(Unconfined, 'Unconfined', objectMeta, CoroutineDispatcher);
setMetadataFor(Key_3, 'Key', objectMeta);
setMetadataFor(BufferOverflow, 'BufferOverflow', classMeta, Enum);
setMetadataFor(ConcurrentLinkedListNode, 'ConcurrentLinkedListNode', classMeta);
setMetadataFor(Segment, 'Segment', classMeta, ConcurrentLinkedListNode, [ConcurrentLinkedListNode, NotCompleted]);
setMetadataFor(ChannelSegment, 'ChannelSegment', classMeta, Segment);
setMetadataFor($hasNextCOROUTINE$6, '$hasNextCOROUTINE$6', classMeta, CoroutineImpl);
setMetadataFor(SendBroadcast, 'SendBroadcast', classMeta, VOID, [Waiter]);
setMetadataFor(BufferedChannelIterator, 'BufferedChannelIterator', classMeta, VOID, [Waiter], VOID, VOID, VOID, [0, 3]);
function cancel$default_0(cause, $super) {
  cause = cause === VOID ? null : cause;
  var tmp;
  if ($super === VOID) {
    this.bo(cause);
    tmp = Unit_instance;
  } else {
    tmp = $super.bo.call(this, cause);
  }
  return tmp;
}
setMetadataFor(ReceiveChannel, 'ReceiveChannel', interfaceMeta, VOID, VOID, VOID, VOID, VOID, [0]);
function close$default(cause, $super) {
  cause = cause === VOID ? null : cause;
  return $super === VOID ? this.i12(cause) : $super.i12.call(this, cause);
}
setMetadataFor(SendChannel, 'SendChannel', interfaceMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(BufferedChannel, 'BufferedChannel', classMeta, VOID, [ReceiveChannel, SendChannel], VOID, VOID, VOID, [1, 4, 0, 3]);
setMetadataFor(WaiterEB, 'WaiterEB', classMeta);
setMetadataFor(ReceiveCatching, 'ReceiveCatching', classMeta, VOID, [Waiter]);
setMetadataFor(Factory, 'Factory', objectMeta);
setMetadataFor(Failed, 'Failed', classMeta, VOID, VOID, Failed);
setMetadataFor(Closed, 'Closed', classMeta, Failed);
setMetadataFor(Companion, 'Companion', objectMeta);
setMetadataFor(ChannelResult, 'ChannelResult', classMeta);
setMetadataFor(ClosedSendChannelException, 'ClosedSendChannelException', classMeta, IllegalStateException);
setMetadataFor(ClosedReceiveChannelException, 'ClosedReceiveChannelException', classMeta, NoSuchElementException);
setMetadataFor(ConflatedBufferedChannel, 'ConflatedBufferedChannel', classMeta, BufferedChannel, VOID, VOID, VOID, VOID, [1, 0]);
setMetadataFor($collectCOROUTINE$10, '$collectCOROUTINE$10', classMeta, CoroutineImpl);
setMetadataFor(_no_name_provided__qut3iv, VOID, classMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor($collectCOROUTINE$13, '$collectCOROUTINE$13', classMeta, CoroutineImpl);
setMetadataFor(AbstractSharedFlow, 'AbstractSharedFlow', classMeta, SynchronizedObject);
setMetadataFor(StateFlowImpl, 'StateFlowImpl', classMeta, AbstractSharedFlow, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(AbstractSharedFlowSlot, 'AbstractSharedFlowSlot', classMeta);
setMetadataFor(StateFlowSlot, 'StateFlowSlot', classMeta, AbstractSharedFlowSlot, VOID, StateFlowSlot, VOID, VOID, [0]);
setMetadataFor($onSubscriptionCOROUTINE$18, '$onSubscriptionCOROUTINE$18', classMeta, CoroutineImpl);
setMetadataFor(SubscribedFlowCollector, 'SubscribedFlowCollector', classMeta, VOID, VOID, VOID, VOID, VOID, [1, 0]);
setMetadataFor($collectCOROUTINE$19, '$collectCOROUTINE$19', classMeta, CoroutineImpl);
setMetadataFor(ReadonlyStateFlow, 'ReadonlyStateFlow', classMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor($emitCOROUTINE$22, '$emitCOROUTINE$22', classMeta, CoroutineImpl);
setMetadataFor(_no_name_provided__qut3iv_0, VOID, classMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor($firstOrNullCOROUTINE$21, '$firstOrNullCOROUTINE$21', classMeta, CoroutineImpl);
setMetadataFor(OpDescriptor, 'OpDescriptor', classMeta);
setMetadataFor(SegmentOrClosed, 'SegmentOrClosed', classMeta);
setMetadataFor(ExceptionSuccessfullyProcessed, 'ExceptionSuccessfullyProcessed', objectMeta, Exception);
setMetadataFor(DispatchedContinuation, 'DispatchedContinuation', classMeta, DispatchedTask, [DispatchedTask, Continuation]);
setMetadataFor(UndeliveredElementException, 'UndeliveredElementException', classMeta, RuntimeException);
setMetadataFor(ContextScope, 'ContextScope', classMeta, VOID, [CoroutineScope]);
setMetadataFor(ScopeCoroutine, 'ScopeCoroutine', classMeta, AbstractCoroutine, VOID, VOID, VOID, VOID, [0]);
setMetadataFor(Symbol, 'Symbol', classMeta);
setMetadataFor(SelectInstance, 'SelectInstance', interfaceMeta);
setMetadataFor(ClauseData, 'ClauseData', classMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(SelectImplementation, 'SelectImplementation', classMeta, CancelHandler, [CancelHandler, SelectInstance, Waiter], VOID, VOID, VOID, [0, 2]);
setMetadataFor(TrySelectDetailedResult, 'TrySelectDetailedResult', classMeta, Enum);
setMetadataFor(CancellableContinuationWithOwner, 'CancellableContinuationWithOwner', classMeta, VOID, [CancellableContinuation, Waiter]);
setMetadataFor(SemaphoreImpl, 'SemaphoreImpl', classMeta, VOID, VOID, VOID, VOID, VOID, [0]);
setMetadataFor(MutexImpl, 'MutexImpl', classMeta, SemaphoreImpl, VOID, VOID, VOID, VOID, [1, 0]);
setMetadataFor(SemaphoreSegment, 'SemaphoreSegment', classMeta, Segment);
setMetadataFor(SetTimeoutBasedDispatcher, 'SetTimeoutBasedDispatcher', classMeta, CoroutineDispatcher, [CoroutineDispatcher, Delay], VOID, VOID, VOID, [1]);
setMetadataFor(NodeDispatcher, 'NodeDispatcher', objectMeta, SetTimeoutBasedDispatcher, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(MessageQueue, 'MessageQueue', classMeta, VOID, [MutableList]);
setMetadataFor(ScheduledMessageQueue, 'ScheduledMessageQueue', classMeta, MessageQueue);
setMetadataFor(WindowMessageQueue, 'WindowMessageQueue', classMeta, MessageQueue);
setMetadataFor(Dispatchers, 'Dispatchers', objectMeta);
setMetadataFor(JsMainDispatcher, 'JsMainDispatcher', classMeta, MainCoroutineDispatcher);
setMetadataFor(UnconfinedEventLoop, 'UnconfinedEventLoop', classMeta, EventLoop, VOID, UnconfinedEventLoop);
setMetadataFor(JobCancellationException, 'JobCancellationException', classMeta, CancellationException);
setMetadataFor(TaskContext, 'TaskContext', objectMeta);
setMetadataFor(AbortFlowException, 'AbortFlowException', classMeta, CancellationException);
setMetadataFor(SafeCollector, 'SafeCollector', classMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(DiagnosticCoroutineContextException, 'DiagnosticCoroutineContextException', classMeta, RuntimeException);
setMetadataFor(SetTimeoutDispatcher, 'SetTimeoutDispatcher', objectMeta, SetTimeoutBasedDispatcher, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(ClearTimeout, 'ClearTimeout', classMeta, CancelHandler);
setMetadataFor(WindowClearTimeout, 'WindowClearTimeout', classMeta, ClearTimeout);
setMetadataFor(WindowDispatcher, 'WindowDispatcher', classMeta, CoroutineDispatcher, [CoroutineDispatcher, Delay], VOID, VOID, VOID, [1]);
setMetadataFor(CommonThreadLocal, 'CommonThreadLocal', classMeta, VOID, VOID, CommonThreadLocal);
//endregion
function AbstractCoroutine(parentContext, initParentJob, active) {
  JobSupport.call(this, active);
  if (initParentJob) {
    this.qm(parentContext.pc(Key_instance_3));
  }
  this.tm_1 = parentContext.nf(this);
}
protoOf(AbstractCoroutine).i6 = function () {
  return this.tm_1;
};
protoOf(AbstractCoroutine).um = function () {
  return this.tm_1;
};
protoOf(AbstractCoroutine).vm = function () {
  return protoOf(JobSupport).vm.call(this);
};
protoOf(AbstractCoroutine).wm = function (value) {
};
protoOf(AbstractCoroutine).xm = function (cause, handled) {
};
protoOf(AbstractCoroutine).ym = function () {
  return get_classSimpleName(this) + ' was cancelled';
};
protoOf(AbstractCoroutine).zm = function (state) {
  if (state instanceof CompletedExceptionally) {
    this.xm(state.an_1, state.cn());
  } else {
    this.wm((state == null ? true : !(state == null)) ? state : THROW_CCE());
  }
};
protoOf(AbstractCoroutine).j6 = function (result) {
  var state = this.dn(toState_0(result));
  if (state === get_COMPLETING_WAITING_CHILDREN())
    return Unit_instance;
  this.en(state);
};
protoOf(AbstractCoroutine).en = function (state) {
  return this.fn(state);
};
protoOf(AbstractCoroutine).gn = function (exception) {
  handleCoroutineException(this.tm_1, exception);
};
protoOf(AbstractCoroutine).hn = function () {
  var tmp0_elvis_lhs = get_coroutineName(this.tm_1);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return protoOf(JobSupport).hn.call(this);
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var coroutineName = tmp;
  return '"' + coroutineName + '":' + protoOf(JobSupport).hn.call(this);
};
protoOf(AbstractCoroutine).in = function (start, receiver, block) {
  start.ln(block, receiver, this);
};
function awaitAll(_this__u8e3s4, $completion) {
  var tmp = new $awaitAllCOROUTINE$0(_this__u8e3s4, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function DisposeHandlersOnCancel($outer, nodes) {
  this.bp_1 = $outer;
  CancelHandler.call(this);
  this.ap_1 = nodes;
}
protoOf(DisposeHandlersOnCancel).cp = function () {
  // Inline function 'kotlin.collections.forEach' call
  var indexedObject = this.ap_1;
  var inductionVariable = 0;
  var last = indexedObject.length;
  while (inductionVariable < last) {
    var element = indexedObject[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    // Inline function 'kotlinx.coroutines.DisposeHandlersOnCancel.disposeAll.<anonymous>' call
    element.lp().mp();
  }
};
protoOf(DisposeHandlersOnCancel).np = function (cause) {
  this.cp();
};
protoOf(DisposeHandlersOnCancel).invoke = function (cause) {
  return this.np(cause);
};
protoOf(DisposeHandlersOnCancel).toString = function () {
  return 'DisposeHandlersOnCancel[' + this.ap_1 + ']';
};
function AwaitAllNode($outer, continuation) {
  this.kp_1 = $outer;
  JobNode.call(this);
  this.hp_1 = continuation;
  this.jp_1 = atomic$ref$1(null);
}
protoOf(AwaitAllNode).lp = function () {
  var tmp = this.ip_1;
  if (!(tmp == null))
    return tmp;
  else {
    throwUninitializedPropertyAccessException('handle');
  }
};
protoOf(AwaitAllNode).op = function (value) {
  this.jp_1.kotlinx$atomicfu$value = value;
};
protoOf(AwaitAllNode).pp = function () {
  return this.jp_1.kotlinx$atomicfu$value;
};
protoOf(AwaitAllNode).np = function (cause) {
  if (!(cause == null)) {
    var token = this.hp_1.tp(cause);
    if (!(token == null)) {
      this.hp_1.up(token);
      var tmp0_safe_receiver = this.pp();
      if (tmp0_safe_receiver == null)
        null;
      else {
        tmp0_safe_receiver.cp();
      }
    }
  } else if (this.kp_1.rp_1.atomicfu$decrementAndGet() === 0) {
    // Inline function 'kotlin.coroutines.resume' call
    var this_0 = this.hp_1;
    // Inline function 'kotlin.collections.map' call
    var this_1 = this.kp_1.qp_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(this_1.length);
    var inductionVariable = 0;
    var last = this_1.length;
    while (inductionVariable < last) {
      var item = this_1[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlinx.coroutines.AwaitAllNode.invoke.<anonymous>' call
      var tmp$ret$0 = item.sp();
      destination.r(tmp$ret$0);
    }
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$3 = _Result___init__impl__xyqfz8(destination);
    this_0.j6(tmp$ret$3);
  }
};
protoOf(AwaitAllNode).invoke = function (cause) {
  return this.np(cause);
};
function AwaitAll(deferreds) {
  this.qp_1 = deferreds;
  this.rp_1 = atomic$int$1(this.qp_1.length);
}
protoOf(AwaitAll).iq = function ($completion) {
  // Inline function 'kotlinx.coroutines.suspendCancellableCoroutine.<anonymous>' call
  var cancellable = new CancellableContinuationImpl(intercepted($completion), get_MODE_CANCELLABLE());
  cancellable.pq();
  // Inline function 'kotlinx.coroutines.AwaitAll.await.<anonymous>' call
  var tmp = 0;
  var tmp_0 = this.qp_1.length;
  // Inline function 'kotlin.arrayOfNulls' call
  var tmp_1 = fillArrayVal(Array(tmp_0), null);
  while (tmp < tmp_0) {
    var tmp_2 = tmp;
    var deferred = this.qp_1[tmp_2];
    deferred.rn();
    // Inline function 'kotlin.apply' call
    var this_0 = new AwaitAllNode(this, cancellable);
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.coroutines.AwaitAll.await.<anonymous>.<anonymous>' call
    var tmp_3 = this_0;
    // Inline function 'kotlinx.coroutines.asHandler' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp_3.ip_1 = deferred.wn(this_0);
    tmp_1[tmp_2] = this_0;
    tmp = tmp + 1 | 0;
  }
  var nodes = tmp_1;
  var disposer = new DisposeHandlersOnCancel(this, nodes);
  // Inline function 'kotlin.collections.forEach' call
  var inductionVariable = 0;
  var last = nodes.length;
  while (inductionVariable < last) {
    var element = nodes[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    // Inline function 'kotlinx.coroutines.AwaitAll.await.<anonymous>.<anonymous>' call
    element.op(disposer);
  }
  if (cancellable.qn()) {
    disposer.cp();
  } else {
    // Inline function 'kotlinx.coroutines.asHandler' call
    // Inline function 'kotlin.js.asDynamic' call
    cancellable.qq(disposer);
  }
  return cancellable.rq();
};
function $awaitAllCOROUTINE$0(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.yo_1 = _this__u8e3s4;
}
protoOf($awaitAllCOROUTINE$0).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          if (this.yo_1.b1()) {
            this.zo_1 = emptyList();
            this.ic_1 = 2;
            continue $sm;
          } else {
            this.ic_1 = 1;
            var this_0 = this.yo_1;
            suspendResult = (new AwaitAll(copyToArray(this_0))).iq(this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          }

        case 1:
          this.zo_1 = suspendResult;
          this.ic_1 = 2;
          continue $sm;
        case 2:
          return this.zo_1;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function launch(_this__u8e3s4, context, start, block) {
  context = context === VOID ? EmptyCoroutineContext_getInstance() : context;
  start = start === VOID ? CoroutineStart_DEFAULT_getInstance() : start;
  var newContext = newCoroutineContext(_this__u8e3s4, context);
  var coroutine = start.sq() ? new LazyStandaloneCoroutine(newContext, block) : new StandaloneCoroutine(newContext, true);
  coroutine.in(start, coroutine, block);
  return coroutine;
}
function async(_this__u8e3s4, context, start, block) {
  context = context === VOID ? EmptyCoroutineContext_getInstance() : context;
  start = start === VOID ? CoroutineStart_DEFAULT_getInstance() : start;
  var newContext = newCoroutineContext(_this__u8e3s4, context);
  var coroutine = start.sq() ? new LazyDeferredCoroutine(newContext, block) : new DeferredCoroutine(newContext, true);
  coroutine.in(start, coroutine, block);
  return coroutine;
}
function StandaloneCoroutine(parentContext, active) {
  AbstractCoroutine.call(this, parentContext, true, active);
}
protoOf(StandaloneCoroutine).mo = function (exception) {
  handleCoroutineException(this.tm_1, exception);
  return true;
};
function LazyStandaloneCoroutine(parentContext, block) {
  StandaloneCoroutine.call(this, parentContext, false);
  this.zq_1 = createCoroutineUnintercepted(block, this, this);
}
protoOf(LazyStandaloneCoroutine).sn = function () {
  startCoroutineCancellable(this.zq_1, this);
};
function $awaitCOROUTINE$1(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.ir_1 = _this__u8e3s4;
}
protoOf($awaitCOROUTINE$1).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.ir_1.po(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          return (suspendResult == null ? true : !(suspendResult == null)) ? suspendResult : THROW_CCE();
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function DeferredCoroutine(parentContext, active) {
  AbstractCoroutine.call(this, parentContext, true, active);
}
protoOf(DeferredCoroutine).sp = function () {
  var tmp = this.oo();
  return (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
};
protoOf(DeferredCoroutine).mr = function ($completion) {
  var tmp = new $awaitCOROUTINE$1(this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
function LazyDeferredCoroutine(parentContext, block) {
  DeferredCoroutine.call(this, parentContext, false);
  this.qr_1 = createCoroutineUnintercepted(block, this, this);
}
protoOf(LazyDeferredCoroutine).sn = function () {
  startCoroutineCancellable(this.qr_1, this);
};
function CancellableContinuation() {
}
function disposeOnCancellation(_this__u8e3s4, handle) {
  // Inline function 'kotlinx.coroutines.asHandler' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$1 = new DisposeOnCancel(handle);
  return _this__u8e3s4.qq(tmp$ret$1);
}
function DisposeOnCancel(handle) {
  CancelHandler.call(this);
  this.vr_1 = handle;
}
protoOf(DisposeOnCancel).np = function (cause) {
  return this.vr_1.mp();
};
protoOf(DisposeOnCancel).invoke = function (cause) {
  return this.np(cause);
};
protoOf(DisposeOnCancel).toString = function () {
  return 'DisposeOnCancel[' + this.vr_1 + ']';
};
function getOrCreateCancellableContinuation(delegate) {
  if (!(delegate instanceof DispatchedContinuation)) {
    return new CancellableContinuationImpl(delegate, get_MODE_CANCELLABLE());
  }
  var tmp0_safe_receiver = delegate.cs();
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.takeIf' call
    // Inline function 'kotlin.contracts.contract' call
    var tmp_0;
    // Inline function 'kotlinx.coroutines.getOrCreateCancellableContinuation.<anonymous>' call
    if (tmp0_safe_receiver.ds()) {
      tmp_0 = tmp0_safe_receiver;
    } else {
      tmp_0 = null;
    }
    tmp = tmp_0;
  }
  var tmp1_elvis_lhs = tmp;
  var tmp_1;
  if (tmp1_elvis_lhs == null) {
    return new CancellableContinuationImpl(delegate, get_MODE_CANCELLABLE_REUSABLE());
  } else {
    tmp_1 = tmp1_elvis_lhs;
  }
  return tmp_1;
}
function get_RESUME_TOKEN() {
  _init_properties_CancellableContinuationImpl_kt__6rrtdd();
  return RESUME_TOKEN;
}
var RESUME_TOKEN;
function _get_parentHandle__f8dcex($this) {
  return $this.oq_1.kotlinx$atomicfu$value;
}
function _get_stateDebugRepresentation__bf18u4($this) {
  var tmp0_subject = $this.pn();
  var tmp;
  if (!(tmp0_subject == null) ? isInterface(tmp0_subject, NotCompleted) : false) {
    tmp = 'Active';
  } else {
    if (tmp0_subject instanceof CancelledContinuation) {
      tmp = 'Cancelled';
    } else {
      tmp = 'Completed';
    }
  }
  return tmp;
}
function isReusable($this) {
  var tmp;
  if (get_isReusableMode($this.fs_1)) {
    var tmp_0 = $this.kq_1;
    tmp = (tmp_0 instanceof DispatchedContinuation ? tmp_0 : THROW_CCE()).es();
  } else {
    tmp = false;
  }
  return tmp;
}
function cancelLater($this, cause) {
  if (!isReusable($this))
    return false;
  var tmp = $this.kq_1;
  var dispatched = tmp instanceof DispatchedContinuation ? tmp : THROW_CCE();
  return dispatched.gs(cause);
}
function callSegmentOnCancellation($this, segment, cause) {
  // Inline function 'kotlinx.coroutines.index' call
  var index = $this.mq_1.kotlinx$atomicfu$value & 536870911;
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!(index === 536870911)) {
    // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.callSegmentOnCancellation.<anonymous>' call
    var message = 'The index for Segment.onCancellation(..) is broken';
    throw IllegalStateException_init_$Create$(toString(message));
  }
  // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.callCancelHandlerSafely' call
  try {
    // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.callSegmentOnCancellation.<anonymous>' call
    segment.ls(index, cause, $this.i6());
  } catch ($p) {
    if ($p instanceof Error) {
      var ex = $p;
      handleCoroutineException($this.i6(), new CompletionHandlerException('Exception in invokeOnCancellation handler for ' + $this, ex));
    } else {
      throw $p;
    }
  }
}
function trySuspend($this) {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = $this.mq_1;
  while (true) {
    // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.trySuspend.<anonymous>' call
    var cur = this_0.kotlinx$atomicfu$value;
    // Inline function 'kotlinx.coroutines.decision' call
    switch (cur >> _get_DECISION_SHIFT_$accessor$2jt7ek_1tkg2i()) {
      case 0:
        // Inline function 'kotlinx.coroutines.decisionAndIndex' call

        // Inline function 'kotlinx.coroutines.index' call

        var index = cur & 536870911;
        var tmp$ret$2 = (1 << _get_DECISION_SHIFT_$accessor$2jt7ek_1tkg2i()) + index | 0;
        if ($this.mq_1.atomicfu$compareAndSet(cur, tmp$ret$2))
          return true;
        break;
      case 2:
        return false;
      default:
        // Inline function 'kotlin.error' call

        var message = 'Already suspended';
        throw IllegalStateException_init_$Create$(toString(message));
    }
  }
}
function tryResume($this) {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = $this.mq_1;
  while (true) {
    // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.tryResume.<anonymous>' call
    var cur = this_0.kotlinx$atomicfu$value;
    // Inline function 'kotlinx.coroutines.decision' call
    switch (cur >> _get_DECISION_SHIFT_$accessor$2jt7ek_1tkg2i()) {
      case 0:
        // Inline function 'kotlinx.coroutines.decisionAndIndex' call

        // Inline function 'kotlinx.coroutines.index' call

        var index = cur & 536870911;
        var tmp$ret$2 = (2 << _get_DECISION_SHIFT_$accessor$2jt7ek_1tkg2i()) + index | 0;
        if ($this.mq_1.atomicfu$compareAndSet(cur, tmp$ret$2))
          return true;
        break;
      case 1:
        return false;
      default:
        // Inline function 'kotlin.error' call

        var message = 'Already resumed';
        throw IllegalStateException_init_$Create$(toString(message));
    }
  }
}
function installParentHandle($this) {
  var tmp0_elvis_lhs = $this.i6().pc(Key_instance_3);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var parent = tmp;
  // Inline function 'kotlinx.coroutines.asHandler' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$1 = new ChildContinuation($this);
  var handle = parent.yn(true, VOID, tmp$ret$1);
  $this.oq_1.atomicfu$compareAndSet(null, handle);
  return handle;
}
function invokeOnCancellationImpl($this, handler) {
  // Inline function 'kotlinx.coroutines.assert' call
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = $this.nq_1;
  while (true) {
    // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.invokeOnCancellationImpl.<anonymous>' call
    var state = this_0.kotlinx$atomicfu$value;
    if (state instanceof Active) {
      if ($this.nq_1.atomicfu$compareAndSet(state, handler))
        return Unit_instance;
    } else {
      var tmp;
      if (state instanceof CancelHandler) {
        tmp = true;
      } else {
        tmp = state instanceof Segment;
      }
      if (tmp) {
        multipleHandlersError($this, handler, state);
      } else {
        if (state instanceof CompletedExceptionally) {
          if (!state.us()) {
            multipleHandlersError($this, handler, state);
          }
          if (state instanceof CancelledContinuation) {
            var tmp1_safe_receiver = state instanceof CompletedExceptionally ? state : null;
            var cause = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.an_1;
            if (handler instanceof CancelHandler) {
              $this.rs(handler, cause);
            } else {
              var segment = handler instanceof Segment ? handler : THROW_CCE();
              callSegmentOnCancellation($this, segment, cause);
            }
          }
          return Unit_instance;
        } else {
          if (state instanceof CompletedContinuation) {
            if (!(state.ns_1 == null)) {
              multipleHandlersError($this, handler, state);
            }
            if (handler instanceof Segment)
              return Unit_instance;
            if (!(handler instanceof CancelHandler))
              THROW_CCE();
            if (state.ss()) {
              $this.rs(handler, state.qs_1);
              return Unit_instance;
            }
            var update = state.ts(VOID, handler);
            if ($this.nq_1.atomicfu$compareAndSet(state, update))
              return Unit_instance;
          } else {
            if (handler instanceof Segment)
              return Unit_instance;
            if (!(handler instanceof CancelHandler))
              THROW_CCE();
            var update_0 = new CompletedContinuation(state, handler);
            if ($this.nq_1.atomicfu$compareAndSet(state, update_0))
              return Unit_instance;
          }
        }
      }
    }
  }
}
function multipleHandlersError($this, handler, state) {
  // Inline function 'kotlin.error' call
  var message = "It's prohibited to register multiple handlers, tried to register " + toString(handler) + ', already has ' + toString_0(state);
  throw IllegalStateException_init_$Create$(toString(message));
}
function makeCancelHandler($this, handler) {
  var tmp;
  if (handler instanceof CancelHandler) {
    tmp = handler;
  } else {
    tmp = new InvokeOnCancel(handler);
  }
  return tmp;
}
function dispatchResume($this, mode) {
  if (tryResume($this))
    return Unit_instance;
  dispatch($this, mode);
}
function resumedState($this, state, proposedUpdate, resumeMode, onCancellation, idempotent) {
  var tmp;
  if (proposedUpdate instanceof CompletedExceptionally) {
    // Inline function 'kotlinx.coroutines.assert' call
    // Inline function 'kotlinx.coroutines.assert' call
    tmp = proposedUpdate;
  } else {
    if (!get_isCancellableMode(resumeMode) ? idempotent == null : false) {
      tmp = proposedUpdate;
    } else {
      var tmp_0;
      var tmp_1;
      if (!(onCancellation == null)) {
        tmp_1 = true;
      } else {
        tmp_1 = state instanceof CancelHandler;
      }
      if (tmp_1) {
        tmp_0 = true;
      } else {
        tmp_0 = !(idempotent == null);
      }
      if (tmp_0) {
        tmp = new CompletedContinuation(proposedUpdate, state instanceof CancelHandler ? state : null, onCancellation, idempotent);
      } else {
        tmp = proposedUpdate;
      }
    }
  }
  return tmp;
}
function resumeImpl($this, proposedUpdate, resumeMode, onCancellation) {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = $this.nq_1;
  while (true) {
    $l$block: {
      // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.resumeImpl.<anonymous>' call
      var state = this_0.kotlinx$atomicfu$value;
      if (!(state == null) ? isInterface(state, NotCompleted) : false) {
        var update = resumedState($this, state, proposedUpdate, resumeMode, onCancellation, null);
        if (!$this.nq_1.atomicfu$compareAndSet(state, update)) {
          break $l$block;
        }
        detachChildIfNonResuable($this);
        dispatchResume($this, resumeMode);
        return Unit_instance;
      } else {
        if (state instanceof CancelledContinuation) {
          if (state.zs()) {
            if (onCancellation == null)
              null;
            else {
              // Inline function 'kotlin.let' call
              // Inline function 'kotlin.contracts.contract' call
              $this.vs(onCancellation, state.an_1);
            }
            return Unit_instance;
          }
        }
      }
      alreadyResumedError($this, proposedUpdate);
    }
  }
}
function resumeImpl$default($this, proposedUpdate, resumeMode, onCancellation, $super) {
  onCancellation = onCancellation === VOID ? null : onCancellation;
  return resumeImpl($this, proposedUpdate, resumeMode, onCancellation);
}
function tryResumeImpl($this, proposedUpdate, idempotent, onCancellation) {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = $this.nq_1;
  while (true) {
    $l$block: {
      // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.tryResumeImpl.<anonymous>' call
      var state = this_0.kotlinx$atomicfu$value;
      if (!(state == null) ? isInterface(state, NotCompleted) : false) {
        var update = resumedState($this, state, proposedUpdate, $this.fs_1, onCancellation, idempotent);
        if (!$this.nq_1.atomicfu$compareAndSet(state, update)) {
          break $l$block;
        }
        detachChildIfNonResuable($this);
        return get_RESUME_TOKEN();
      } else {
        if (state instanceof CompletedContinuation) {
          var tmp;
          if (!(idempotent == null) ? state.ps_1 === idempotent : false) {
            // Inline function 'kotlinx.coroutines.assert' call
            tmp = get_RESUME_TOKEN();
          } else {
            tmp = null;
          }
          return tmp;
        } else {
          return null;
        }
      }
    }
  }
}
function alreadyResumedError($this, proposedUpdate) {
  // Inline function 'kotlin.error' call
  var message = 'Already resumed, but proposed with update ' + toString_0(proposedUpdate);
  throw IllegalStateException_init_$Create$(toString(message));
}
function detachChildIfNonResuable($this) {
  if (!isReusable($this)) {
    $this.at();
  }
}
function CancellableContinuationImpl(delegate, resumeMode) {
  DispatchedTask.call(this, resumeMode);
  this.kq_1 = delegate;
  // Inline function 'kotlinx.coroutines.assert' call
  this.lq_1 = this.kq_1.i6();
  var tmp = this;
  // Inline function 'kotlinx.coroutines.decisionAndIndex' call
  var tmp$ret$0 = (0 << _get_DECISION_SHIFT_$accessor$2jt7ek_1tkg2i()) + 536870911 | 0;
  tmp.mq_1 = atomic$int$1(tmp$ret$0);
  this.nq_1 = atomic$ref$1(Active_instance);
  this.oq_1 = atomic$ref$1(null);
}
protoOf(CancellableContinuationImpl).bt = function () {
  return this.kq_1;
};
protoOf(CancellableContinuationImpl).i6 = function () {
  return this.lq_1;
};
protoOf(CancellableContinuationImpl).pn = function () {
  return this.nq_1.kotlinx$atomicfu$value;
};
protoOf(CancellableContinuationImpl).qn = function () {
  var tmp = this.pn();
  return !(!(tmp == null) ? isInterface(tmp, NotCompleted) : false);
};
protoOf(CancellableContinuationImpl).rr = function () {
  var tmp = this.pn();
  return tmp instanceof CancelledContinuation;
};
protoOf(CancellableContinuationImpl).pq = function () {
  var tmp0_elvis_lhs = installParentHandle(this);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return Unit_instance;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var handle = tmp;
  if (this.qn()) {
    handle.mp();
    this.oq_1.kotlinx$atomicfu$value = NonDisposableHandle_instance;
  }
};
protoOf(CancellableContinuationImpl).ds = function () {
  // Inline function 'kotlinx.coroutines.assert' call
  // Inline function 'kotlinx.coroutines.assert' call
  var state = this.nq_1.kotlinx$atomicfu$value;
  // Inline function 'kotlinx.coroutines.assert' call
  var tmp;
  if (state instanceof CompletedContinuation) {
    tmp = !(state.ps_1 == null);
  } else {
    tmp = false;
  }
  if (tmp) {
    this.at();
    return false;
  }
  var tmp_0 = this.mq_1;
  // Inline function 'kotlinx.coroutines.decisionAndIndex' call
  tmp_0.kotlinx$atomicfu$value = (0 << _get_DECISION_SHIFT_$accessor$2jt7ek_1tkg2i()) + 536870911 | 0;
  this.nq_1.kotlinx$atomicfu$value = Active_instance;
  return true;
};
protoOf(CancellableContinuationImpl).ct = function () {
  return this.pn();
};
protoOf(CancellableContinuationImpl).dt = function (takenState, cause) {
  var this_0 = this.nq_1;
  while (true) {
    // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.cancelCompletedResult.<anonymous>' call
    var state = this_0.kotlinx$atomicfu$value;
    if (!(state == null) ? isInterface(state, NotCompleted) : false) {
      // Inline function 'kotlin.error' call
      var message = 'Not completed';
      throw IllegalStateException_init_$Create$(toString(message));
    } else {
      if (state instanceof CompletedExceptionally)
        return Unit_instance;
      else {
        if (state instanceof CompletedContinuation) {
          // Inline function 'kotlin.check' call
          // Inline function 'kotlin.contracts.contract' call
          if (!!state.ss()) {
            // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.cancelCompletedResult.<anonymous>.<anonymous>' call
            var message_0 = 'Must be called at most once';
            throw IllegalStateException_init_$Create$(toString(message_0));
          }
          var update = state.ts(VOID, VOID, VOID, VOID, cause);
          if (this.nq_1.atomicfu$compareAndSet(state, update)) {
            state.et(this, cause);
            return Unit_instance;
          }
        } else {
          if (this.nq_1.atomicfu$compareAndSet(state, new CompletedContinuation(state, VOID, VOID, VOID, cause))) {
            return Unit_instance;
          }
        }
      }
    }
  }
  return Unit_instance;
};
protoOf(CancellableContinuationImpl).ft = function (cause) {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = this.nq_1;
  while (true) {
    $l$block: {
      // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.cancel.<anonymous>' call
      var state = this_0.kotlinx$atomicfu$value;
      if (!(!(state == null) ? isInterface(state, NotCompleted) : false))
        return false;
      var tmp;
      if (state instanceof CancelHandler) {
        tmp = true;
      } else {
        tmp = state instanceof Segment;
      }
      var update = new CancelledContinuation(this, cause, tmp);
      if (!this.nq_1.atomicfu$compareAndSet(state, update)) {
        break $l$block;
      }
      if (state instanceof CancelHandler) {
        this.rs(state, cause);
      } else {
        if (state instanceof Segment) {
          callSegmentOnCancellation(this, state, cause);
        }
      }
      detachChildIfNonResuable(this);
      dispatchResume(this, this.fs_1);
      return true;
    }
  }
};
protoOf(CancellableContinuationImpl).gt = function (cause) {
  if (cancelLater(this, cause))
    return Unit_instance;
  this.ft(cause);
  detachChildIfNonResuable(this);
};
protoOf(CancellableContinuationImpl).rs = function (handler, cause) {
  var tmp;
  try {
    handler.invoke(cause);
    tmp = Unit_instance;
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Error) {
      var ex = $p;
      handleCoroutineException(this.i6(), new CompletionHandlerException('Exception in invokeOnCancellation handler for ' + this, ex));
      tmp_0 = Unit_instance;
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(CancellableContinuationImpl).vs = function (onCancellation, cause) {
  try {
    onCancellation(cause);
  } catch ($p) {
    if ($p instanceof Error) {
      var ex = $p;
      handleCoroutineException(this.i6(), new CompletionHandlerException('Exception in resume onCancellation handler for ' + this, ex));
    } else {
      throw $p;
    }
  }
};
protoOf(CancellableContinuationImpl).ht = function (parent) {
  return parent.tn();
};
protoOf(CancellableContinuationImpl).rq = function () {
  var isReusable_0 = isReusable(this);
  if (trySuspend(this)) {
    if (_get_parentHandle__f8dcex(this) == null) {
      installParentHandle(this);
    }
    if (isReusable_0) {
      this.it();
    }
    return get_COROUTINE_SUSPENDED();
  }
  if (isReusable_0) {
    this.it();
  }
  var state = this.pn();
  if (state instanceof CompletedExceptionally)
    throw recoverStackTrace(state.an_1, this);
  if (get_isCancellableMode(this.fs_1)) {
    var job = this.i6().pc(Key_instance_3);
    if (!(job == null) ? !job.vm() : false) {
      var cause = job.tn();
      this.dt(state, cause);
      throw recoverStackTrace(cause, this);
    }
  }
  return this.jt(state);
};
protoOf(CancellableContinuationImpl).it = function () {
  var tmp = this.kq_1;
  var tmp0_safe_receiver = tmp instanceof DispatchedContinuation ? tmp : null;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.kt(this);
  var tmp_0;
  if (tmp1_elvis_lhs == null) {
    return Unit_instance;
  } else {
    tmp_0 = tmp1_elvis_lhs;
  }
  var cancellationCause = tmp_0;
  this.at();
  this.ft(cancellationCause);
};
protoOf(CancellableContinuationImpl).j6 = function (result) {
  return resumeImpl$default(this, toState(result, this), this.fs_1);
};
protoOf(CancellableContinuationImpl).ur = function (value, onCancellation) {
  return resumeImpl(this, value, this.fs_1, onCancellation);
};
protoOf(CancellableContinuationImpl).lt = function (segment, index) {
  $l$block: {
    // Inline function 'kotlinx.atomicfu.update' call
    var this_0 = this.mq_1;
    while (true) {
      var cur = this_0.kotlinx$atomicfu$value;
      // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.invokeOnCancellation.<anonymous>' call
      // Inline function 'kotlin.check' call
      // Inline function 'kotlinx.coroutines.index' call
      // Inline function 'kotlin.contracts.contract' call
      if (!((cur & 536870911) === 536870911)) {
        // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.invokeOnCancellation.<anonymous>.<anonymous>' call
        var message = 'invokeOnCancellation should be called at most once';
        throw IllegalStateException_init_$Create$(toString(message));
      }
      // Inline function 'kotlinx.coroutines.decisionAndIndex' call
      // Inline function 'kotlinx.coroutines.decision' call
      var upd = (cur >> _get_DECISION_SHIFT_$accessor$2jt7ek_1tkg2i() << _get_DECISION_SHIFT_$accessor$2jt7ek_1tkg2i()) + index | 0;
      if (this_0.atomicfu$compareAndSet(cur, upd)) {
        break $l$block;
      }
    }
  }
  invokeOnCancellationImpl(this, segment);
};
protoOf(CancellableContinuationImpl).qq = function (handler) {
  var cancelHandler = makeCancelHandler(this, handler);
  invokeOnCancellationImpl(this, cancelHandler);
};
protoOf(CancellableContinuationImpl).at = function () {
  var tmp0_elvis_lhs = _get_parentHandle__f8dcex(this);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return Unit_instance;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var handle = tmp;
  handle.mp();
  this.oq_1.kotlinx$atomicfu$value = NonDisposableHandle_instance;
};
protoOf(CancellableContinuationImpl).sr = function (value, idempotent, onCancellation) {
  return tryResumeImpl(this, value, idempotent, onCancellation);
};
protoOf(CancellableContinuationImpl).tp = function (exception) {
  return tryResumeImpl(this, new CompletedExceptionally(exception), null, null);
};
protoOf(CancellableContinuationImpl).up = function (token) {
  // Inline function 'kotlinx.coroutines.assert' call
  dispatchResume(this, this.fs_1);
};
protoOf(CancellableContinuationImpl).tr = function (_this__u8e3s4, value) {
  var tmp = this.kq_1;
  var dc = tmp instanceof DispatchedContinuation ? tmp : null;
  var tmp_0;
  if ((dc == null ? null : dc.xr_1) === _this__u8e3s4) {
    tmp_0 = get_MODE_UNDISPATCHED();
  } else {
    tmp_0 = this.fs_1;
  }
  resumeImpl$default(this, value, tmp_0);
};
protoOf(CancellableContinuationImpl).jt = function (state) {
  var tmp;
  if (state instanceof CompletedContinuation) {
    var tmp_0 = state.ms_1;
    tmp = (tmp_0 == null ? true : !(tmp_0 == null)) ? tmp_0 : THROW_CCE();
  } else {
    tmp = (state == null ? true : !(state == null)) ? state : THROW_CCE();
  }
  return tmp;
};
protoOf(CancellableContinuationImpl).mt = function (state) {
  var tmp0_safe_receiver = protoOf(DispatchedTask).mt.call(this, state);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.getExceptionalResult.<anonymous>' call
    tmp = recoverStackTrace(tmp0_safe_receiver, this.kq_1);
  }
  return tmp;
};
protoOf(CancellableContinuationImpl).toString = function () {
  return this.hn() + '(' + toDebugString(this.kq_1) + '){' + _get_stateDebugRepresentation__bf18u4(this) + '}@' + get_hexAddress(this);
};
protoOf(CancellableContinuationImpl).hn = function () {
  return 'CancellableContinuation';
};
function NotCompleted() {
}
function CancelHandler() {
  CancelHandlerBase.call(this);
}
function Active() {
}
protoOf(Active).toString = function () {
  return 'Active';
};
var Active_instance;
function Active_getInstance() {
  return Active_instance;
}
function CompletedContinuation(result, cancelHandler, onCancellation, idempotentResume, cancelCause) {
  cancelHandler = cancelHandler === VOID ? null : cancelHandler;
  onCancellation = onCancellation === VOID ? null : onCancellation;
  idempotentResume = idempotentResume === VOID ? null : idempotentResume;
  cancelCause = cancelCause === VOID ? null : cancelCause;
  this.ms_1 = result;
  this.ns_1 = cancelHandler;
  this.os_1 = onCancellation;
  this.ps_1 = idempotentResume;
  this.qs_1 = cancelCause;
}
protoOf(CompletedContinuation).ss = function () {
  return !(this.qs_1 == null);
};
protoOf(CompletedContinuation).et = function (cont, cause) {
  var tmp0_safe_receiver = this.ns_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    cont.rs(tmp0_safe_receiver, cause);
  }
  var tmp1_safe_receiver = this.os_1;
  if (tmp1_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    cont.vs(tmp1_safe_receiver, cause);
  }
};
protoOf(CompletedContinuation).pt = function (result, cancelHandler, onCancellation, idempotentResume, cancelCause) {
  return new CompletedContinuation(result, cancelHandler, onCancellation, idempotentResume, cancelCause);
};
protoOf(CompletedContinuation).ts = function (result, cancelHandler, onCancellation, idempotentResume, cancelCause, $super) {
  result = result === VOID ? this.ms_1 : result;
  cancelHandler = cancelHandler === VOID ? this.ns_1 : cancelHandler;
  onCancellation = onCancellation === VOID ? this.os_1 : onCancellation;
  idempotentResume = idempotentResume === VOID ? this.ps_1 : idempotentResume;
  cancelCause = cancelCause === VOID ? this.qs_1 : cancelCause;
  return $super === VOID ? this.pt(result, cancelHandler, onCancellation, idempotentResume, cancelCause) : $super.pt.call(this, result, cancelHandler, onCancellation, idempotentResume, cancelCause);
};
protoOf(CompletedContinuation).toString = function () {
  return 'CompletedContinuation(result=' + toString_0(this.ms_1) + ', cancelHandler=' + this.ns_1 + ', onCancellation=' + this.os_1 + ', idempotentResume=' + toString_0(this.ps_1) + ', cancelCause=' + this.qs_1 + ')';
};
protoOf(CompletedContinuation).hashCode = function () {
  var result = this.ms_1 == null ? 0 : hashCode(this.ms_1);
  result = imul(result, 31) + (this.ns_1 == null ? 0 : hashCode(this.ns_1)) | 0;
  result = imul(result, 31) + (this.os_1 == null ? 0 : hashCode(this.os_1)) | 0;
  result = imul(result, 31) + (this.ps_1 == null ? 0 : hashCode(this.ps_1)) | 0;
  result = imul(result, 31) + (this.qs_1 == null ? 0 : hashCode(this.qs_1)) | 0;
  return result;
};
protoOf(CompletedContinuation).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof CompletedContinuation))
    return false;
  var tmp0_other_with_cast = other instanceof CompletedContinuation ? other : THROW_CCE();
  if (!equals(this.ms_1, tmp0_other_with_cast.ms_1))
    return false;
  if (!equals(this.ns_1, tmp0_other_with_cast.ns_1))
    return false;
  if (!equals(this.os_1, tmp0_other_with_cast.os_1))
    return false;
  if (!equals(this.ps_1, tmp0_other_with_cast.ps_1))
    return false;
  if (!equals(this.qs_1, tmp0_other_with_cast.qs_1))
    return false;
  return true;
};
function InvokeOnCancel(handler) {
  CancelHandler.call(this);
  this.qt_1 = handler;
}
protoOf(InvokeOnCancel).np = function (cause) {
  this.qt_1(cause);
};
protoOf(InvokeOnCancel).invoke = function (cause) {
  return this.np(cause);
};
protoOf(InvokeOnCancel).toString = function () {
  return 'InvokeOnCancel[' + get_classSimpleName(this.qt_1) + '@' + get_hexAddress(this) + ']';
};
function _get_DECISION_SHIFT_$accessor$2jt7ek_1tkg2i() {
  _init_properties_CancellableContinuationImpl_kt__6rrtdd();
  return 29;
}
var properties_initialized_CancellableContinuationImpl_kt_xtzb03;
function _init_properties_CancellableContinuationImpl_kt__6rrtdd() {
  if (!properties_initialized_CancellableContinuationImpl_kt_xtzb03) {
    properties_initialized_CancellableContinuationImpl_kt_xtzb03 = true;
    RESUME_TOKEN = new Symbol('RESUME_TOKEN');
  }
}
function CompletableDeferred(parent) {
  parent = parent === VOID ? null : parent;
  return new CompletableDeferredImpl(parent);
}
function $awaitCOROUTINE$2(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.zt_1 = _this__u8e3s4;
}
protoOf($awaitCOROUTINE$2).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.zt_1.po(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          return (suspendResult == null ? true : !(suspendResult == null)) ? suspendResult : THROW_CCE();
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function CompletableDeferredImpl(parent) {
  JobSupport.call(this, true);
  this.qm(parent);
}
protoOf(CompletableDeferredImpl).ao = function () {
  return true;
};
protoOf(CompletableDeferredImpl).sp = function () {
  var tmp = this.oo();
  return (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
};
protoOf(CompletableDeferredImpl).mr = function ($completion) {
  var tmp = new $awaitCOROUTINE$2(this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(CompletableDeferredImpl).cu = function (value) {
  return this.du(value);
};
protoOf(CompletableDeferredImpl).eu = function (exception) {
  return this.du(new CompletedExceptionally(exception));
};
function CompletableJob() {
}
function CompletedExceptionally(cause, handled) {
  handled = handled === VOID ? false : handled;
  this.an_1 = cause;
  this.bn_1 = atomic$boolean$1(handled);
}
protoOf(CompletedExceptionally).cn = function () {
  return this.bn_1.kotlinx$atomicfu$value;
};
protoOf(CompletedExceptionally).us = function () {
  return this.bn_1.atomicfu$compareAndSet(false, true);
};
protoOf(CompletedExceptionally).toString = function () {
  return get_classSimpleName(this) + '[' + this.an_1 + ']';
};
function CancelledContinuation(continuation, cause, handled) {
  CompletedExceptionally.call(this, cause == null ? CancellationException_init_$Create$('Continuation ' + continuation + ' was cancelled normally') : cause, handled);
  this.ys_1 = atomic$boolean$1(false);
}
protoOf(CancelledContinuation).zs = function () {
  return this.ys_1.atomicfu$compareAndSet(false, true);
};
function toState(_this__u8e3s4, caller) {
  // Inline function 'kotlin.fold' call
  // Inline function 'kotlin.contracts.contract' call
  var exception = Result__exceptionOrNull_impl_p6xea9(_this__u8e3s4);
  var tmp;
  if (exception == null) {
    // Inline function 'kotlinx.coroutines.toState.<anonymous>' call
    var tmp_0 = _Result___get_value__impl__bjfvqg(_this__u8e3s4);
    tmp = (tmp_0 == null ? true : !(tmp_0 == null)) ? tmp_0 : THROW_CCE();
  } else {
    // Inline function 'kotlinx.coroutines.toState.<anonymous>' call
    tmp = new CompletedExceptionally(recoverStackTrace(exception, caller));
  }
  return tmp;
}
function toState_0(_this__u8e3s4, onCancellation) {
  onCancellation = onCancellation === VOID ? null : onCancellation;
  // Inline function 'kotlin.fold' call
  // Inline function 'kotlin.contracts.contract' call
  var exception = Result__exceptionOrNull_impl_p6xea9(_this__u8e3s4);
  var tmp;
  if (exception == null) {
    // Inline function 'kotlinx.coroutines.toState.<anonymous>' call
    var tmp_0 = _Result___get_value__impl__bjfvqg(_this__u8e3s4);
    var it = (tmp_0 == null ? true : !(tmp_0 == null)) ? tmp_0 : THROW_CCE();
    tmp = !(onCancellation == null) ? new CompletedWithCancellation(it, onCancellation) : it;
  } else {
    // Inline function 'kotlinx.coroutines.toState.<anonymous>' call
    tmp = new CompletedExceptionally(exception);
  }
  return tmp;
}
function CompletedWithCancellation(result, onCancellation) {
  this.hu_1 = result;
  this.iu_1 = onCancellation;
}
protoOf(CompletedWithCancellation).toString = function () {
  return 'CompletedWithCancellation(result=' + toString_0(this.hu_1) + ', onCancellation=' + this.iu_1 + ')';
};
protoOf(CompletedWithCancellation).hashCode = function () {
  var result = this.hu_1 == null ? 0 : hashCode(this.hu_1);
  result = imul(result, 31) + hashCode(this.iu_1) | 0;
  return result;
};
protoOf(CompletedWithCancellation).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof CompletedWithCancellation))
    return false;
  var tmp0_other_with_cast = other instanceof CompletedWithCancellation ? other : THROW_CCE();
  if (!equals(this.hu_1, tmp0_other_with_cast.hu_1))
    return false;
  if (!equals(this.iu_1, tmp0_other_with_cast.iu_1))
    return false;
  return true;
};
function CoroutineDispatcher$Key$_init_$lambda_akl8b5(it) {
  return it instanceof CoroutineDispatcher ? it : null;
}
function Key() {
  Key_instance_0 = this;
  var tmp = Key_instance;
  AbstractCoroutineContextKey.call(this, tmp, CoroutineDispatcher$Key$_init_$lambda_akl8b5);
}
var Key_instance_0;
function Key_getInstance() {
  if (Key_instance_0 == null)
    new Key();
  return Key_instance_0;
}
function CoroutineDispatcher() {
  Key_getInstance();
  AbstractCoroutineContextElement.call(this, Key_instance);
}
protoOf(CoroutineDispatcher).ku = function (context) {
  return true;
};
protoOf(CoroutineDispatcher).sc = function (continuation) {
  return new DispatchedContinuation(this, continuation);
};
protoOf(CoroutineDispatcher).qc = function (continuation) {
  var dispatched = continuation instanceof DispatchedContinuation ? continuation : THROW_CCE();
  dispatched.mu();
};
protoOf(CoroutineDispatcher).toString = function () {
  return get_classSimpleName(this) + '@' + get_hexAddress(this);
};
function handleCoroutineException(context, exception) {
  try {
    var tmp0_safe_receiver = context.pc(Key_instance_1);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.contracts.contract' call
      tmp0_safe_receiver.nu(context, exception);
      return Unit_instance;
    }
  } catch ($p) {
    if ($p instanceof Error) {
      var t = $p;
      handleUncaughtCoroutineException(context, handlerException(exception, t));
      return Unit_instance;
    } else {
      throw $p;
    }
  }
  handleUncaughtCoroutineException(context, exception);
}
function Key_0() {
}
var Key_instance_1;
function Key_getInstance_0() {
  return Key_instance_1;
}
function handlerException(originalException, thrownException) {
  if (originalException === thrownException)
    return originalException;
  // Inline function 'kotlin.apply' call
  var this_0 = RuntimeException_init_$Create$('Exception while trying to handle coroutine exception', thrownException);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.handlerException.<anonymous>' call
  addSuppressed(this_0, originalException);
  return this_0;
}
function Key_1() {
}
var Key_instance_2;
function Key_getInstance_1() {
  return Key_instance_2;
}
function CoroutineName(name) {
  AbstractCoroutineContextElement.call(this, Key_instance_2);
  this.pu_1 = name;
}
protoOf(CoroutineName).toString = function () {
  return 'CoroutineName(' + this.pu_1 + ')';
};
protoOf(CoroutineName).hashCode = function () {
  return getStringHashCode(this.pu_1);
};
protoOf(CoroutineName).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof CoroutineName))
    return false;
  var tmp0_other_with_cast = other instanceof CoroutineName ? other : THROW_CCE();
  if (!(this.pu_1 === tmp0_other_with_cast.pu_1))
    return false;
  return true;
};
function cancel(_this__u8e3s4, cause) {
  cause = cause === VOID ? null : cause;
  var tmp0_elvis_lhs = _this__u8e3s4.um().pc(Key_instance_3);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var message = 'Scope cannot be cancelled because it does not have a job: ' + _this__u8e3s4;
    throw IllegalStateException_init_$Create$(toString(message));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var job = tmp;
  job.bo(cause);
}
function CoroutineScope() {
}
function cancel_0(_this__u8e3s4, message, cause) {
  cause = cause === VOID ? null : cause;
  return cancel(_this__u8e3s4, CancellationException_init_$Create$_0(message, cause));
}
function GlobalScope() {
}
protoOf(GlobalScope).um = function () {
  return EmptyCoroutineContext_getInstance();
};
var GlobalScope_instance;
function GlobalScope_getInstance() {
  return GlobalScope_instance;
}
function CoroutineScope_0(context) {
  return new ContextScope(!(context.pc(Key_instance_3) == null) ? context : context.nf(Job_0()));
}
function get_isActive(_this__u8e3s4) {
  var tmp0_safe_receiver = _this__u8e3s4.um().pc(Key_instance_3);
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.vm();
  return tmp1_elvis_lhs == null ? true : tmp1_elvis_lhs;
}
var CoroutineStart_DEFAULT_instance;
var CoroutineStart_LAZY_instance;
var CoroutineStart_ATOMIC_instance;
var CoroutineStart_UNDISPATCHED_instance;
var CoroutineStart_entriesInitialized;
function CoroutineStart_initEntries() {
  if (CoroutineStart_entriesInitialized)
    return Unit_instance;
  CoroutineStart_entriesInitialized = true;
  CoroutineStart_DEFAULT_instance = new CoroutineStart('DEFAULT', 0);
  CoroutineStart_LAZY_instance = new CoroutineStart('LAZY', 1);
  CoroutineStart_ATOMIC_instance = new CoroutineStart('ATOMIC', 2);
  CoroutineStart_UNDISPATCHED_instance = new CoroutineStart('UNDISPATCHED', 3);
}
function CoroutineStart(name, ordinal) {
  Enum.call(this, name, ordinal);
}
protoOf(CoroutineStart).ln = function (block, receiver, completion) {
  var tmp;
  switch (this.aa_1) {
    case 0:
      startCoroutineCancellable_0(block, receiver, completion);
      tmp = Unit_instance;
      break;
    case 2:
      startCoroutine(block, receiver, completion);
      tmp = Unit_instance;
      break;
    case 3:
      startCoroutineUndispatched(block, receiver, completion);
      tmp = Unit_instance;
      break;
    case 1:
      tmp = Unit_instance;
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
};
protoOf(CoroutineStart).sq = function () {
  return this === CoroutineStart_LAZY_getInstance();
};
function CoroutineStart_DEFAULT_getInstance() {
  CoroutineStart_initEntries();
  return CoroutineStart_DEFAULT_instance;
}
function CoroutineStart_LAZY_getInstance() {
  CoroutineStart_initEntries();
  return CoroutineStart_LAZY_instance;
}
function Delay() {
}
function get_delay(_this__u8e3s4) {
  var tmp = _this__u8e3s4.pc(Key_instance);
  var tmp0_elvis_lhs = (!(tmp == null) ? isInterface(tmp, Delay) : false) ? tmp : null;
  return tmp0_elvis_lhs == null ? get_DefaultDelay() : tmp0_elvis_lhs;
}
function delay(timeMillis, $completion) {
  if (timeMillis.o6(new Long(0, 0)) <= 0)
    return Unit_instance;
  // Inline function 'kotlinx.coroutines.suspendCancellableCoroutine.<anonymous>' call
  var cancellable = new CancellableContinuationImpl(intercepted($completion), get_MODE_CANCELLABLE());
  cancellable.pq();
  // Inline function 'kotlinx.coroutines.delay.<anonymous>' call
  Companion_getInstance();
  if (timeMillis.o6(new Long(-1, 2147483647)) < 0) {
    get_delay(cancellable.i6()).qu(timeMillis, cancellable);
  }
  return cancellable.rq();
}
function delta($this, unconfined) {
  return unconfined ? new Long(0, 1) : new Long(1, 0);
}
function EventLoop() {
  CoroutineDispatcher.call(this);
  this.su_1 = new Long(0, 0);
  this.tu_1 = false;
  this.uu_1 = null;
}
protoOf(EventLoop).vu = function () {
  var tmp0_elvis_lhs = this.uu_1;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return false;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var queue = tmp;
  var tmp1_elvis_lhs = queue.ae();
  var tmp_0;
  if (tmp1_elvis_lhs == null) {
    return false;
  } else {
    tmp_0 = tmp1_elvis_lhs;
  }
  var task = tmp_0;
  task.nt();
  return true;
};
protoOf(EventLoop).wu = function (task) {
  var tmp0_elvis_lhs = this.uu_1;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlin.also' call
    var this_0 = ArrayDeque_init_$Create$();
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.coroutines.EventLoop.dispatchUnconfined.<anonymous>' call
    this.uu_1 = this_0;
    tmp = this_0;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var queue = tmp;
  queue.yd(task);
};
protoOf(EventLoop).xu = function () {
  return this.su_1.o6(delta(this, true)) >= 0;
};
protoOf(EventLoop).yu = function () {
  var tmp0_safe_receiver = this.uu_1;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.b1();
  return tmp1_elvis_lhs == null ? true : tmp1_elvis_lhs;
};
protoOf(EventLoop).zu = function (unconfined) {
  this.su_1 = this.su_1.lb(delta(this, unconfined));
  if (!unconfined)
    this.tu_1 = true;
};
protoOf(EventLoop).av = function (unconfined) {
  this.su_1 = this.su_1.mb(delta(this, unconfined));
  if (this.su_1.o6(new Long(0, 0)) > 0)
    return Unit_instance;
  // Inline function 'kotlinx.coroutines.assert' call
  if (this.tu_1) {
    this.bv();
  }
};
protoOf(EventLoop).bv = function () {
};
function ThreadLocalEventLoop() {
  ThreadLocalEventLoop_instance = this;
  this.cv_1 = commonThreadLocal(new Symbol('ThreadLocalEventLoop'));
}
protoOf(ThreadLocalEventLoop).dv = function () {
  var tmp0_elvis_lhs = this.cv_1.fv();
  var tmp;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlin.also' call
    var this_0 = createEventLoop();
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.coroutines.ThreadLocalEventLoop.<get-eventLoop>.<anonymous>' call
    ThreadLocalEventLoop_getInstance().cv_1.gv(this_0);
    tmp = this_0;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
var ThreadLocalEventLoop_instance;
function ThreadLocalEventLoop_getInstance() {
  if (ThreadLocalEventLoop_instance == null)
    new ThreadLocalEventLoop();
  return ThreadLocalEventLoop_instance;
}
function CompletionHandlerException(message, cause) {
  RuntimeException_init_$Init$(message, cause, this);
  captureStack(this, CompletionHandlerException);
}
function CoroutinesInternalError(message, cause) {
  Error_init_$Init$(message, cause, this);
  captureStack(this, CoroutinesInternalError);
}
function Key_2() {
}
var Key_instance_3;
function Key_getInstance_2() {
  return Key_instance_3;
}
function Job() {
}
function ParentJob() {
}
function ChildHandle() {
}
function NonDisposableHandle() {
}
protoOf(NonDisposableHandle).on = function () {
  return null;
};
protoOf(NonDisposableHandle).mp = function () {
};
protoOf(NonDisposableHandle).fo = function (cause) {
  return false;
};
protoOf(NonDisposableHandle).toString = function () {
  return 'NonDisposableHandle';
};
var NonDisposableHandle_instance;
function NonDisposableHandle_getInstance() {
  return NonDisposableHandle_instance;
}
function ensureActive(_this__u8e3s4) {
  var tmp0_safe_receiver = _this__u8e3s4.pc(Key_instance_3);
  if (tmp0_safe_receiver == null)
    null;
  else {
    ensureActive_0(tmp0_safe_receiver);
  }
}
function ensureActive_0(_this__u8e3s4) {
  if (!_this__u8e3s4.vm())
    throw _this__u8e3s4.tn();
}
function cancel_1(_this__u8e3s4, message, cause) {
  cause = cause === VOID ? null : cause;
  return _this__u8e3s4.bo(CancellationException_init_$Create$_0(message, cause));
}
function Job_0(parent) {
  parent = parent === VOID ? null : parent;
  return new JobImpl(parent);
}
function get_job(_this__u8e3s4) {
  var tmp0_elvis_lhs = _this__u8e3s4.pc(Key_instance_3);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var message = "Current context doesn't contain Job in it: " + _this__u8e3s4;
    throw IllegalStateException_init_$Create$(toString(message));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function cancel_2(_this__u8e3s4, cause) {
  cause = cause === VOID ? null : cause;
  var tmp0_safe_receiver = _this__u8e3s4.pc(Key_instance_3);
  if (tmp0_safe_receiver == null)
    null;
  else {
    tmp0_safe_receiver.bo(cause);
  }
}
function get_COMPLETING_ALREADY() {
  _init_properties_JobSupport_kt__68f172();
  return COMPLETING_ALREADY;
}
var COMPLETING_ALREADY;
function get_COMPLETING_WAITING_CHILDREN() {
  _init_properties_JobSupport_kt__68f172();
  return COMPLETING_WAITING_CHILDREN;
}
var COMPLETING_WAITING_CHILDREN;
function get_COMPLETING_RETRY() {
  _init_properties_JobSupport_kt__68f172();
  return COMPLETING_RETRY;
}
var COMPLETING_RETRY;
function get_TOO_LATE_TO_CANCEL() {
  _init_properties_JobSupport_kt__68f172();
  return TOO_LATE_TO_CANCEL;
}
var TOO_LATE_TO_CANCEL;
function get_SEALED() {
  _init_properties_JobSupport_kt__68f172();
  return SEALED;
}
var SEALED;
function get_EMPTY_NEW() {
  _init_properties_JobSupport_kt__68f172();
  return EMPTY_NEW;
}
var EMPTY_NEW;
function get_EMPTY_ACTIVE() {
  _init_properties_JobSupport_kt__68f172();
  return EMPTY_ACTIVE;
}
var EMPTY_ACTIVE;
function Empty(isActive) {
  this.hv_1 = isActive;
}
protoOf(Empty).vm = function () {
  return this.hv_1;
};
protoOf(Empty).aq = function () {
  return null;
};
protoOf(Empty).toString = function () {
  return 'Empty{' + (this.hv_1 ? 'Active' : 'New') + '}';
};
function Incomplete() {
}
function NodeList() {
  LinkedListHead.call(this);
}
protoOf(NodeList).vm = function () {
  return true;
};
protoOf(NodeList).aq = function () {
  return this;
};
protoOf(NodeList).lv = function (state) {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder_init_$Create$();
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.NodeList.getString.<anonymous>' call
  this_0.n5('List{');
  this_0.n5(state);
  this_0.n5('}[');
  var first = true;
  // Inline function 'kotlinx.coroutines.internal.LinkedListHead.forEach' call
  var cur = this.bq_1;
  while (!equals(cur, this)) {
    if (cur instanceof JobNode) {
      // Inline function 'kotlinx.coroutines.NodeList.getString.<anonymous>.<anonymous>' call
      var node = cur;
      if (first)
        first = false;
      else {
        this_0.n5(', ');
      }
      this_0.m5(node);
    }
    cur = cur.bq_1;
  }
  this_0.n5(']');
  return this_0.toString();
};
protoOf(NodeList).toString = function () {
  return get_DEBUG() ? this.lv('Active') : protoOf(LinkedListHead).toString.call(this);
};
function JobNode() {
  CompletionHandlerBase.call(this);
}
protoOf(JobNode).zp = function () {
  var tmp = this.yp_1;
  if (!(tmp == null))
    return tmp;
  else {
    throwUninitializedPropertyAccessException('job');
  }
};
protoOf(JobNode).vm = function () {
  return true;
};
protoOf(JobNode).aq = function () {
  return null;
};
protoOf(JobNode).mp = function () {
  return this.zp().zn(this);
};
protoOf(JobNode).toString = function () {
  return get_classSimpleName(this) + '@' + get_hexAddress(this) + '[job@' + get_hexAddress(this.zp()) + ']';
};
function _set_exceptionsHolder__tqm22h($this, value) {
  $this.sv_1.kotlinx$atomicfu$value = value;
}
function _get_exceptionsHolder__nhszp($this) {
  return $this.sv_1.kotlinx$atomicfu$value;
}
function allocateList($this) {
  return ArrayList_init_$Create$(4);
}
function finalizeFinishingState($this, state, proposedUpdate) {
  // Inline function 'kotlinx.coroutines.assert' call
  // Inline function 'kotlinx.coroutines.assert' call
  // Inline function 'kotlinx.coroutines.assert' call
  var tmp0_safe_receiver = proposedUpdate instanceof CompletedExceptionally ? proposedUpdate : null;
  var proposedException = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.an_1;
  var wasCancelling;
  // Inline function 'kotlinx.coroutines.internal.synchronized' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
  // Inline function 'kotlinx.coroutines.JobSupport.finalizeFinishingState.<anonymous>' call
  wasCancelling = state.tv();
  var exceptions = state.uv(proposedException);
  var finalCause = getFinalRootCause($this, state, exceptions);
  if (!(finalCause == null)) {
    addSuppressedExceptions($this, finalCause, exceptions);
  }
  var finalException = finalCause;
  var finalState = finalException == null ? proposedUpdate : finalException === proposedException ? proposedUpdate : new CompletedExceptionally(finalException);
  if (!(finalException == null)) {
    var handled = cancelParent($this, finalException) ? true : $this.mo(finalException);
    if (handled) {
      (finalState instanceof CompletedExceptionally ? finalState : THROW_CCE()).us();
    }
  }
  if (!wasCancelling) {
    $this.jo(finalException);
  }
  $this.zm(finalState);
  var casSuccess = $this.om_1.atomicfu$compareAndSet(state, boxIncomplete(finalState));
  // Inline function 'kotlinx.coroutines.assert' call
  completeStateFinalization($this, state, finalState);
  return finalState;
}
function getFinalRootCause($this, state, exceptions) {
  if (exceptions.b1()) {
    if (state.tv()) {
      // Inline function 'kotlinx.coroutines.JobSupport.defaultCancellationException' call
      return new JobCancellationException(null == null ? $this.ym() : null, null, $this);
    }
    return null;
  }
  var tmp$ret$2;
  $l$block: {
    // Inline function 'kotlin.collections.firstOrNull' call
    var tmp0_iterator = exceptions.u();
    while (tmp0_iterator.v()) {
      var element = tmp0_iterator.w();
      // Inline function 'kotlinx.coroutines.JobSupport.getFinalRootCause.<anonymous>' call
      if (!(element instanceof CancellationException)) {
        tmp$ret$2 = element;
        break $l$block;
      }
    }
    tmp$ret$2 = null;
  }
  var firstNonCancellation = tmp$ret$2;
  if (!(firstNonCancellation == null))
    return firstNonCancellation;
  var first = exceptions.f1(0);
  if (first instanceof TimeoutCancellationException) {
    var tmp$ret$4;
    $l$block_0: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var tmp0_iterator_0 = exceptions.u();
      while (tmp0_iterator_0.v()) {
        var element_0 = tmp0_iterator_0.w();
        // Inline function 'kotlinx.coroutines.JobSupport.getFinalRootCause.<anonymous>' call
        var tmp;
        if (!(element_0 === first)) {
          tmp = element_0 instanceof TimeoutCancellationException;
        } else {
          tmp = false;
        }
        if (tmp) {
          tmp$ret$4 = element_0;
          break $l$block_0;
        }
      }
      tmp$ret$4 = null;
    }
    var detailedTimeoutException = tmp$ret$4;
    if (!(detailedTimeoutException == null))
      return detailedTimeoutException;
  }
  return first;
}
function addSuppressedExceptions($this, rootCause, exceptions) {
  if (exceptions.n() <= 1)
    return Unit_instance;
  var seenExceptions = identitySet(exceptions.n());
  var unwrappedCause = unwrap(rootCause);
  var tmp0_iterator = exceptions.u();
  while (tmp0_iterator.v()) {
    var exception = tmp0_iterator.w();
    var unwrapped = unwrap(exception);
    var tmp;
    var tmp_0;
    if (!(unwrapped === rootCause) ? !(unwrapped === unwrappedCause) : false) {
      tmp_0 = !(unwrapped instanceof CancellationException);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = seenExceptions.r(unwrapped);
    } else {
      tmp = false;
    }
    if (tmp) {
      addSuppressed(rootCause, unwrapped);
    }
  }
}
function tryFinalizeSimpleState($this, state, update) {
  // Inline function 'kotlinx.coroutines.assert' call
  // Inline function 'kotlinx.coroutines.assert' call
  if (!$this.om_1.atomicfu$compareAndSet(state, boxIncomplete(update)))
    return false;
  $this.jo(null);
  $this.zm(update);
  completeStateFinalization($this, state, update);
  return true;
}
function completeStateFinalization($this, state, update) {
  var tmp0_safe_receiver = $this.nn();
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    tmp0_safe_receiver.mp();
    $this.mn(NonDisposableHandle_instance);
  }
  var tmp1_safe_receiver = update instanceof CompletedExceptionally ? update : null;
  var cause = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.an_1;
  if (state instanceof JobNode) {
    try {
      state.invoke(cause);
    } catch ($p) {
      if ($p instanceof Error) {
        var ex = $p;
        $this.gn(new CompletionHandlerException('Exception in completion handler ' + state + ' for ' + $this, ex));
      } else {
        throw $p;
      }
    }
  } else {
    var tmp2_safe_receiver = state.aq();
    if (tmp2_safe_receiver == null)
      null;
    else {
      notifyCompletion(tmp2_safe_receiver, $this, cause);
    }
  }
}
function notifyCancelling($this, list, cause) {
  $this.jo(cause);
  // Inline function 'kotlinx.coroutines.JobSupport.notifyHandlers' call
  var exception = null;
  // Inline function 'kotlinx.coroutines.internal.LinkedListHead.forEach' call
  var cur = list.bq_1;
  while (!equals(cur, list)) {
    if (cur instanceof JobCancellingNode) {
      // Inline function 'kotlinx.coroutines.JobSupport.notifyHandlers.<anonymous>' call
      var node = cur;
      try {
        node.invoke(cause);
      } catch ($p) {
        if ($p instanceof Error) {
          var ex = $p;
          var tmp0_safe_receiver = exception;
          var tmp;
          if (tmp0_safe_receiver == null) {
            tmp = null;
          } else {
            // Inline function 'kotlin.apply' call
            // Inline function 'kotlin.contracts.contract' call
            // Inline function 'kotlinx.coroutines.JobSupport.notifyHandlers.<anonymous>.<anonymous>' call
            addSuppressed(tmp0_safe_receiver, ex);
            tmp = tmp0_safe_receiver;
          }
          if (tmp == null) {
            // Inline function 'kotlin.run' call
            // Inline function 'kotlin.contracts.contract' call
            exception = new CompletionHandlerException('Exception in completion handler ' + node + ' for ' + $this, ex);
          }
        } else {
          throw $p;
        }
      }
    }
    cur = cur.bq_1;
  }
  var tmp0_safe_receiver_0 = exception;
  if (tmp0_safe_receiver_0 == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    $this.gn(tmp0_safe_receiver_0);
  }
  cancelParent($this, cause);
}
function cancelParent($this, cause) {
  if ($this.ko())
    return true;
  var isCancellation = cause instanceof CancellationException;
  var parent = $this.nn();
  if (parent === null ? true : parent === NonDisposableHandle_instance) {
    return isCancellation;
  }
  return parent.fo(cause) ? true : isCancellation;
}
function notifyCompletion(_this__u8e3s4, $this, cause) {
  var exception = null;
  // Inline function 'kotlinx.coroutines.internal.LinkedListHead.forEach' call
  var cur = _this__u8e3s4.bq_1;
  while (!equals(cur, _this__u8e3s4)) {
    if (cur instanceof JobNode) {
      // Inline function 'kotlinx.coroutines.JobSupport.notifyHandlers.<anonymous>' call
      var node = cur;
      try {
        node.invoke(cause);
      } catch ($p) {
        if ($p instanceof Error) {
          var ex = $p;
          var tmp0_safe_receiver = exception;
          var tmp;
          if (tmp0_safe_receiver == null) {
            tmp = null;
          } else {
            // Inline function 'kotlin.apply' call
            // Inline function 'kotlin.contracts.contract' call
            // Inline function 'kotlinx.coroutines.JobSupport.notifyHandlers.<anonymous>.<anonymous>' call
            addSuppressed(tmp0_safe_receiver, ex);
            tmp = tmp0_safe_receiver;
          }
          if (tmp == null) {
            // Inline function 'kotlin.run' call
            // Inline function 'kotlin.contracts.contract' call
            exception = new CompletionHandlerException('Exception in completion handler ' + node + ' for ' + $this, ex);
          }
        } else {
          throw $p;
        }
      }
    }
    cur = cur.bq_1;
  }
  var tmp0_safe_receiver_0 = exception;
  if (tmp0_safe_receiver_0 == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    $this.gn(tmp0_safe_receiver_0);
  }
  return Unit_instance;
}
function startInternal($this, state) {
  if (state instanceof Empty) {
    if (state.hv_1)
      return 0;
    if (!$this.om_1.atomicfu$compareAndSet(state, get_EMPTY_ACTIVE()))
      return -1;
    $this.sn();
    return 1;
  } else {
    if (state instanceof InactiveNodeList) {
      if (!$this.om_1.atomicfu$compareAndSet(state, state.vv_1))
        return -1;
      $this.sn();
      return 1;
    } else {
      return 0;
    }
  }
}
function makeNode($this, handler, onCancelling) {
  var tmp;
  if (onCancelling) {
    var tmp0_elvis_lhs = handler instanceof JobCancellingNode ? handler : null;
    tmp = tmp0_elvis_lhs == null ? new InvokeOnCancelling(handler) : tmp0_elvis_lhs;
  } else {
    var tmp1_safe_receiver = handler instanceof JobNode ? handler : null;
    var tmp_0;
    if (tmp1_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.also' call
      // Inline function 'kotlin.contracts.contract' call
      // Inline function 'kotlinx.coroutines.JobSupport.makeNode.<anonymous>' call
      // Inline function 'kotlinx.coroutines.assert' call
      tmp_0 = tmp1_safe_receiver;
    }
    var tmp2_elvis_lhs = tmp_0;
    tmp = tmp2_elvis_lhs == null ? new InvokeOnCompletion(handler) : tmp2_elvis_lhs;
  }
  var node = tmp;
  node.yp_1 = $this;
  return node;
}
function addLastAtomic($this, expect, list, node) {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlinx.coroutines.internal.LinkedListNode.addLastIf' call
    // Inline function 'kotlinx.coroutines.JobSupport.addLastAtomic.<anonymous>' call
    if (!($this.pn() === expect)) {
      tmp$ret$1 = false;
      break $l$block;
    }
    list.eq(node);
    tmp$ret$1 = true;
  }
  return tmp$ret$1;
}
function promoteEmptyToNodeList($this, state) {
  var list = new NodeList();
  var update = state.hv_1 ? list : new InactiveNodeList(list);
  $this.om_1.atomicfu$compareAndSet(state, update);
}
function promoteSingleToNodeList($this, state) {
  state.hq(new NodeList());
  // Inline function 'kotlinx.coroutines.internal.LinkedListNode.nextNode' call
  var list = state.bq_1;
  $this.om_1.atomicfu$compareAndSet(state, list);
}
function joinInternal($this) {
  // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
  while (true) {
    // Inline function 'kotlinx.coroutines.JobSupport.joinInternal.<anonymous>' call
    var state = $this.pn();
    if (!(!(state == null) ? isInterface(state, Incomplete) : false))
      return false;
    if (startInternal($this, state) >= 0)
      return true;
  }
}
function joinSuspend($this, $completion) {
  // Inline function 'kotlinx.coroutines.suspendCancellableCoroutine.<anonymous>' call
  var cancellable = new CancellableContinuationImpl(intercepted($completion), get_MODE_CANCELLABLE());
  cancellable.pq();
  // Inline function 'kotlinx.coroutines.JobSupport.joinSuspend.<anonymous>' call
  // Inline function 'kotlinx.coroutines.asHandler' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$1 = new ResumeOnCompletion(cancellable);
  disposeOnCancellation(cancellable, $this.wn(tmp$ret$1));
  return cancellable.rq();
}
function cancelMakeCompleting($this, cause) {
  // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
  while (true) {
    // Inline function 'kotlinx.coroutines.JobSupport.cancelMakeCompleting.<anonymous>' call
    var state = $this.pn();
    var tmp;
    if (!(!(state == null) ? isInterface(state, Incomplete) : false)) {
      tmp = true;
    } else {
      var tmp_0;
      if (state instanceof Finishing) {
        tmp_0 = state.wv();
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    }
    if (tmp) {
      return get_COMPLETING_ALREADY();
    }
    var proposedUpdate = new CompletedExceptionally(createCauseException($this, cause));
    var finalState = tryMakeCompleting($this, state, proposedUpdate);
    if (!(finalState === get_COMPLETING_RETRY()))
      return finalState;
  }
}
function createCauseException($this, cause) {
  var tmp;
  if (cause == null ? true : cause instanceof Error) {
    var tmp_0;
    if (cause == null) {
      // Inline function 'kotlinx.coroutines.JobSupport.defaultCancellationException' call
      tmp_0 = new JobCancellationException(null == null ? $this.ym() : null, null, $this);
    } else {
      tmp_0 = cause;
    }
    tmp = tmp_0;
  } else {
    tmp = ((!(cause == null) ? isInterface(cause, ParentJob) : false) ? cause : THROW_CCE()).ho();
  }
  return tmp;
}
function makeCancelling($this, cause) {
  var causeExceptionCache = null;
  // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
  while (true) {
    $l$block: {
      // Inline function 'kotlinx.coroutines.JobSupport.makeCancelling.<anonymous>' call
      var state = $this.pn();
      if (state instanceof Finishing) {
        // Inline function 'kotlinx.coroutines.internal.synchronized' call
        // Inline function 'kotlin.contracts.contract' call
        // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
        // Inline function 'kotlinx.coroutines.JobSupport.makeCancelling.<anonymous>.<anonymous>' call
        if (state.xv())
          return get_TOO_LATE_TO_CANCEL();
        var wasCancelling = state.tv();
        if (!(cause == null) ? true : !wasCancelling) {
          var tmp0_elvis_lhs = causeExceptionCache;
          var tmp;
          if (tmp0_elvis_lhs == null) {
            // Inline function 'kotlin.also' call
            var this_0 = createCauseException($this, cause);
            // Inline function 'kotlin.contracts.contract' call
            // Inline function 'kotlinx.coroutines.JobSupport.makeCancelling.<anonymous>.<anonymous>.<anonymous>' call
            causeExceptionCache = this_0;
            tmp = this_0;
          } else {
            tmp = tmp0_elvis_lhs;
          }
          var causeException = tmp;
          state.yv(causeException);
        }
        // Inline function 'kotlin.takeIf' call
        var this_1 = state.zv();
        // Inline function 'kotlin.contracts.contract' call
        var tmp_0;
        // Inline function 'kotlinx.coroutines.JobSupport.makeCancelling.<anonymous>.<anonymous>.<anonymous>' call
        if (!wasCancelling) {
          tmp_0 = this_1;
        } else {
          tmp_0 = null;
        }
        var notifyRootCause = tmp_0;
        if (notifyRootCause == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          // Inline function 'kotlin.contracts.contract' call
          notifyCancelling($this, state.pv_1, notifyRootCause);
        }
        return get_COMPLETING_ALREADY();
      } else {
        if (!(state == null) ? isInterface(state, Incomplete) : false) {
          var tmp2_elvis_lhs = causeExceptionCache;
          var tmp_1;
          if (tmp2_elvis_lhs == null) {
            // Inline function 'kotlin.also' call
            var this_2 = createCauseException($this, cause);
            // Inline function 'kotlin.contracts.contract' call
            // Inline function 'kotlinx.coroutines.JobSupport.makeCancelling.<anonymous>.<anonymous>' call
            causeExceptionCache = this_2;
            tmp_1 = this_2;
          } else {
            tmp_1 = tmp2_elvis_lhs;
          }
          var causeException_0 = tmp_1;
          if (state.vm()) {
            if (tryMakeCancelling($this, state, causeException_0))
              return get_COMPLETING_ALREADY();
          } else {
            var finalState = tryMakeCompleting($this, state, new CompletedExceptionally(causeException_0));
            if (finalState === get_COMPLETING_ALREADY()) {
              // Inline function 'kotlin.error' call
              var message = 'Cannot happen in ' + toString_0(state);
              throw IllegalStateException_init_$Create$(toString(message));
            } else if (finalState === get_COMPLETING_RETRY()) {
              break $l$block;
            } else
              return finalState;
          }
        } else {
          return get_TOO_LATE_TO_CANCEL();
        }
      }
    }
  }
}
function getOrPromoteCancellingList($this, state) {
  var tmp1_elvis_lhs = state.aq();
  var tmp;
  if (tmp1_elvis_lhs == null) {
    var tmp_0;
    if (state instanceof Empty) {
      tmp_0 = new NodeList();
    } else {
      if (state instanceof JobNode) {
        promoteSingleToNodeList($this, state);
        tmp_0 = null;
      } else {
        var message = 'State should have list: ' + state;
        throw IllegalStateException_init_$Create$(toString(message));
      }
    }
    tmp = tmp_0;
  } else {
    tmp = tmp1_elvis_lhs;
  }
  return tmp;
}
function tryMakeCancelling($this, state, rootCause) {
  // Inline function 'kotlinx.coroutines.assert' call
  // Inline function 'kotlinx.coroutines.assert' call
  var tmp0_elvis_lhs = getOrPromoteCancellingList($this, state);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return false;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var list = tmp;
  var cancelling = new Finishing(list, false, rootCause);
  if (!$this.om_1.atomicfu$compareAndSet(state, cancelling))
    return false;
  notifyCancelling($this, list, rootCause);
  return true;
}
function tryMakeCompleting($this, state, proposedUpdate) {
  if (!(!(state == null) ? isInterface(state, Incomplete) : false))
    return get_COMPLETING_ALREADY();
  var tmp;
  var tmp_0;
  var tmp_1;
  if (state instanceof Empty) {
    tmp_1 = true;
  } else {
    tmp_1 = state instanceof JobNode;
  }
  if (tmp_1) {
    tmp_0 = !(state instanceof ChildHandleNode);
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = !(proposedUpdate instanceof CompletedExceptionally);
  } else {
    tmp = false;
  }
  if (tmp) {
    if (tryFinalizeSimpleState($this, state, proposedUpdate)) {
      return proposedUpdate;
    }
    return get_COMPLETING_RETRY();
  }
  return tryMakeCompletingSlowPath($this, state, proposedUpdate);
}
function tryMakeCompletingSlowPath($this, state, proposedUpdate) {
  var tmp0_elvis_lhs = getOrPromoteCancellingList($this, state);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return get_COMPLETING_RETRY();
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var list = tmp;
  var tmp1_elvis_lhs = state instanceof Finishing ? state : null;
  var finishing = tmp1_elvis_lhs == null ? new Finishing(list, false, null) : tmp1_elvis_lhs;
  var notifyRootCause = null;
  // Inline function 'kotlinx.coroutines.internal.synchronized' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
  if (finishing.wv())
    return get_COMPLETING_ALREADY();
  finishing.aw(true);
  if (!(finishing === state)) {
    if (!$this.om_1.atomicfu$compareAndSet(state, finishing))
      return get_COMPLETING_RETRY();
  }
  // Inline function 'kotlinx.coroutines.assert' call
  var wasCancelling = finishing.tv();
  var tmp0_safe_receiver = proposedUpdate instanceof CompletedExceptionally ? proposedUpdate : null;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    finishing.yv(tmp0_safe_receiver.an_1);
  }
  // Inline function 'kotlin.takeIf' call
  var this_0 = finishing.zv();
  // Inline function 'kotlin.contracts.contract' call
  var tmp_0;
  // Inline function 'kotlinx.coroutines.JobSupport.tryMakeCompletingSlowPath.<anonymous>.<anonymous>' call
  if (!wasCancelling) {
    tmp_0 = this_0;
  } else {
    tmp_0 = null;
  }
  notifyRootCause = tmp_0;
  var tmp2_safe_receiver = notifyRootCause;
  if (tmp2_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    notifyCancelling($this, list, tmp2_safe_receiver);
  }
  var child = firstChild($this, state);
  if (!(child == null) ? tryWaitForChild($this, finishing, child, proposedUpdate) : false)
    return get_COMPLETING_WAITING_CHILDREN();
  return finalizeFinishingState($this, finishing, proposedUpdate);
}
function _get_exceptionOrNull__b3j7js(_this__u8e3s4, $this) {
  var tmp0_safe_receiver = _this__u8e3s4 instanceof CompletedExceptionally ? _this__u8e3s4 : null;
  return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.an_1;
}
function firstChild($this, state) {
  var tmp1_elvis_lhs = state instanceof ChildHandleNode ? state : null;
  var tmp;
  if (tmp1_elvis_lhs == null) {
    var tmp0_safe_receiver = state.aq();
    tmp = tmp0_safe_receiver == null ? null : nextChild(tmp0_safe_receiver, $this);
  } else {
    tmp = tmp1_elvis_lhs;
  }
  return tmp;
}
function tryWaitForChild($this, state, child, proposedUpdate) {
  var $this_0 = $this;
  var state_0 = state;
  var child_0 = child;
  var proposedUpdate_0 = proposedUpdate;
  $l$1: do {
    $l$0: do {
      var tmp = child_0.fw_1;
      // Inline function 'kotlinx.coroutines.asHandler' call
      // Inline function 'kotlin.js.asDynamic' call
      var tmp$ret$1 = new ChildCompletion($this_0, state_0, child_0, proposedUpdate_0);
      var handle = tmp.yn(VOID, false, tmp$ret$1);
      if (!(handle === NonDisposableHandle_instance))
        return true;
      var tmp0_elvis_lhs = nextChild(child_0, $this_0);
      var tmp_0;
      if (tmp0_elvis_lhs == null) {
        return false;
      } else {
        tmp_0 = tmp0_elvis_lhs;
      }
      var nextChild_0 = tmp_0;
      $this_0 = $this_0;
      state_0 = state_0;
      child_0 = nextChild_0;
      proposedUpdate_0 = proposedUpdate_0;
      continue $l$0;
    }
     while (false);
  }
   while (true);
}
function continueCompleting($this, state, lastChild, proposedUpdate) {
  // Inline function 'kotlinx.coroutines.assert' call
  var waitChild = nextChild(lastChild, $this);
  if (!(waitChild == null) ? tryWaitForChild($this, state, waitChild, proposedUpdate) : false)
    return Unit_instance;
  var finalState = finalizeFinishingState($this, state, proposedUpdate);
  $this.fn(finalState);
}
function nextChild(_this__u8e3s4, $this) {
  var cur = _this__u8e3s4;
  $l$loop: while (true) {
    // Inline function 'kotlinx.coroutines.internal.LinkedListNode.isRemoved' call
    if (!cur.dq_1) {
      break $l$loop;
    }
    // Inline function 'kotlinx.coroutines.internal.LinkedListNode.prevNode' call
    cur = cur.cq_1;
  }
  $l$loop_0: while (true) {
    // Inline function 'kotlinx.coroutines.internal.LinkedListNode.nextNode' call
    cur = cur.bq_1;
    // Inline function 'kotlinx.coroutines.internal.LinkedListNode.isRemoved' call
    if (cur.dq_1)
      continue $l$loop_0;
    if (cur instanceof ChildHandleNode)
      return cur;
    if (cur instanceof NodeList)
      return null;
  }
}
function stateString($this, state) {
  var tmp;
  if (state instanceof Finishing) {
    tmp = state.tv() ? 'Cancelling' : state.wv() ? 'Completing' : 'Active';
  } else {
    if (!(state == null) ? isInterface(state, Incomplete) : false) {
      tmp = state.vm() ? 'Active' : 'New';
    } else {
      if (state instanceof CompletedExceptionally) {
        tmp = 'Cancelled';
      } else {
        tmp = 'Completed';
      }
    }
  }
  return tmp;
}
function Finishing(list, isCompleting, rootCause) {
  SynchronizedObject.call(this);
  this.pv_1 = list;
  this.qv_1 = atomic$boolean$1(isCompleting);
  this.rv_1 = atomic$ref$1(rootCause);
  this.sv_1 = atomic$ref$1(null);
}
protoOf(Finishing).aq = function () {
  return this.pv_1;
};
protoOf(Finishing).aw = function (value) {
  this.qv_1.kotlinx$atomicfu$value = value;
};
protoOf(Finishing).wv = function () {
  return this.qv_1.kotlinx$atomicfu$value;
};
protoOf(Finishing).gw = function (value) {
  this.rv_1.kotlinx$atomicfu$value = value;
};
protoOf(Finishing).zv = function () {
  return this.rv_1.kotlinx$atomicfu$value;
};
protoOf(Finishing).xv = function () {
  return _get_exceptionsHolder__nhszp(this) === get_SEALED();
};
protoOf(Finishing).tv = function () {
  return !(this.zv() == null);
};
protoOf(Finishing).vm = function () {
  return this.zv() == null;
};
protoOf(Finishing).uv = function (proposedException) {
  var eh = _get_exceptionsHolder__nhszp(this);
  var tmp;
  if (eh == null) {
    tmp = allocateList(this);
  } else {
    if (eh instanceof Error) {
      // Inline function 'kotlin.also' call
      var this_0 = allocateList(this);
      // Inline function 'kotlin.contracts.contract' call
      // Inline function 'kotlinx.coroutines.Finishing.sealLocked.<anonymous>' call
      this_0.r(eh);
      tmp = this_0;
    } else {
      if (eh instanceof ArrayList) {
        tmp = eh instanceof ArrayList ? eh : THROW_CCE();
      } else {
        var message = 'State is ' + toString_0(eh);
        throw IllegalStateException_init_$Create$(toString(message));
      }
    }
  }
  var list = tmp;
  var rootCause = this.zv();
  if (rootCause == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    list.r1(0, rootCause);
  }
  if (!(proposedException == null) ? !equals(proposedException, rootCause) : false) {
    list.r(proposedException);
  }
  _set_exceptionsHolder__tqm22h(this, get_SEALED());
  return list;
};
protoOf(Finishing).yv = function (exception) {
  var rootCause = this.zv();
  if (rootCause == null) {
    this.gw(exception);
    return Unit_instance;
  }
  if (exception === rootCause)
    return Unit_instance;
  var eh = _get_exceptionsHolder__nhszp(this);
  if (eh == null) {
    _set_exceptionsHolder__tqm22h(this, exception);
  } else {
    if (eh instanceof Error) {
      if (exception === eh)
        return Unit_instance;
      // Inline function 'kotlin.apply' call
      var this_0 = allocateList(this);
      // Inline function 'kotlin.contracts.contract' call
      // Inline function 'kotlinx.coroutines.Finishing.addExceptionLocked.<anonymous>' call
      this_0.r(eh);
      this_0.r(exception);
      _set_exceptionsHolder__tqm22h(this, this_0);
    } else {
      if (eh instanceof ArrayList) {
        (eh instanceof ArrayList ? eh : THROW_CCE()).r(exception);
      } else {
        var message = 'State is ' + toString_0(eh);
        throw IllegalStateException_init_$Create$(toString(message));
      }
    }
  }
};
protoOf(Finishing).toString = function () {
  return 'Finishing[cancelling=' + this.tv() + ', completing=' + this.wv() + ', rootCause=' + this.zv() + ', exceptions=' + toString_0(_get_exceptionsHolder__nhszp(this)) + ', list=' + this.pv_1 + ']';
};
function ChildCompletion(parent, state, child, proposedUpdate) {
  JobNode.call(this);
  this.lw_1 = parent;
  this.mw_1 = state;
  this.nw_1 = child;
  this.ow_1 = proposedUpdate;
}
protoOf(ChildCompletion).np = function (cause) {
  continueCompleting(this.lw_1, this.mw_1, this.nw_1, this.ow_1);
};
protoOf(ChildCompletion).invoke = function (cause) {
  return this.np(cause);
};
function AwaitContinuation(delegate, job) {
  CancellableContinuationImpl.call(this, delegate, get_MODE_CANCELLABLE());
  this.vw_1 = job;
}
protoOf(AwaitContinuation).ht = function (parent) {
  var state = this.vw_1.pn();
  if (state instanceof Finishing) {
    var tmp0_safe_receiver = state.zv();
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.contracts.contract' call
      return tmp0_safe_receiver;
    }
  }
  if (state instanceof CompletedExceptionally)
    return state.an_1;
  return parent.tn();
};
protoOf(AwaitContinuation).hn = function () {
  return 'AwaitContinuation';
};
function awaitSuspend($this, $completion) {
  // Inline function 'kotlinx.coroutines.JobSupport.awaitSuspend.<anonymous>' call
  var cont = new AwaitContinuation(intercepted($completion), $this);
  cont.pq();
  // Inline function 'kotlinx.coroutines.asHandler' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$1 = new ResumeAwaitOnCompletion(cont);
  disposeOnCancellation(cont, $this.wn(tmp$ret$1));
  return cont.rq();
}
function JobSupport(active) {
  this.om_1 = atomic$ref$1(active ? get_EMPTY_ACTIVE() : get_EMPTY_NEW());
  this.pm_1 = atomic$ref$1(null);
}
protoOf(JobSupport).k2 = function () {
  return Key_instance_3;
};
protoOf(JobSupport).mn = function (value) {
  this.pm_1.kotlinx$atomicfu$value = value;
};
protoOf(JobSupport).nn = function () {
  return this.pm_1.kotlinx$atomicfu$value;
};
protoOf(JobSupport).on = function () {
  var tmp0_safe_receiver = this.nn();
  return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.on();
};
protoOf(JobSupport).qm = function (parent) {
  // Inline function 'kotlinx.coroutines.assert' call
  if (parent == null) {
    this.mn(NonDisposableHandle_instance);
    return Unit_instance;
  }
  parent.rn();
  var handle = parent.io(this);
  this.mn(handle);
  if (this.qn()) {
    handle.mp();
    this.mn(NonDisposableHandle_instance);
  }
};
protoOf(JobSupport).pn = function () {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = this.om_1;
  while (true) {
    // Inline function 'kotlinx.coroutines.JobSupport.<get-state>.<anonymous>' call
    var state = this_0.kotlinx$atomicfu$value;
    if (!(state instanceof OpDescriptor))
      return state;
    state.ww(this);
  }
};
protoOf(JobSupport).vm = function () {
  var state = this.pn();
  var tmp;
  if (!(state == null) ? isInterface(state, Incomplete) : false) {
    tmp = state.vm();
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(JobSupport).qn = function () {
  var tmp = this.pn();
  return !(!(tmp == null) ? isInterface(tmp, Incomplete) : false);
};
protoOf(JobSupport).rn = function () {
  // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
  while (true) {
    // Inline function 'kotlinx.coroutines.JobSupport.start.<anonymous>' call
    var state = this.pn();
    var tmp0_subject = startInternal(this, state);
    if (tmp0_subject === 0)
      return false;
    else if (tmp0_subject === 1)
      return true;
  }
};
protoOf(JobSupport).sn = function () {
};
protoOf(JobSupport).tn = function () {
  var state = this.pn();
  var tmp;
  if (state instanceof Finishing) {
    var tmp0_safe_receiver = state.zv();
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : this.un(tmp0_safe_receiver, get_classSimpleName(this) + ' is cancelling');
    var tmp_0;
    if (tmp1_elvis_lhs == null) {
      var message = 'Job is still new or active: ' + this;
      throw IllegalStateException_init_$Create$(toString(message));
    } else {
      tmp_0 = tmp1_elvis_lhs;
    }
    tmp = tmp_0;
  } else {
    if (!(state == null) ? isInterface(state, Incomplete) : false) {
      var message_0 = 'Job is still new or active: ' + this;
      throw IllegalStateException_init_$Create$(toString(message_0));
    } else {
      if (state instanceof CompletedExceptionally) {
        tmp = this.vn(state.an_1);
      } else {
        tmp = new JobCancellationException(get_classSimpleName(this) + ' has completed normally', null, this);
      }
    }
  }
  return tmp;
};
protoOf(JobSupport).un = function (_this__u8e3s4, message) {
  var tmp0_elvis_lhs = _this__u8e3s4 instanceof CancellationException ? _this__u8e3s4 : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlinx.coroutines.JobSupport.defaultCancellationException' call
    tmp = new JobCancellationException(message == null ? this.ym() : message, _this__u8e3s4, this);
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
};
protoOf(JobSupport).vn = function (_this__u8e3s4, message, $super) {
  message = message === VOID ? null : message;
  return $super === VOID ? this.un(_this__u8e3s4, message) : $super.un.call(this, _this__u8e3s4, message);
};
protoOf(JobSupport).wn = function (handler) {
  return this.xn(false, true, handler);
};
protoOf(JobSupport).xn = function (onCancelling, invokeImmediately, handler) {
  var node = makeNode(this, handler, onCancelling);
  // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
  while (true) {
    $l$block: {
      // Inline function 'kotlinx.coroutines.JobSupport.invokeOnCompletion.<anonymous>' call
      var state = this.pn();
      if (state instanceof Empty) {
        if (state.hv_1) {
          if (this.om_1.atomicfu$compareAndSet(state, node))
            return node;
        } else {
          promoteEmptyToNodeList(this, state);
        }
      } else {
        if (!(state == null) ? isInterface(state, Incomplete) : false) {
          var list = state.aq();
          if (list == null) {
            promoteSingleToNodeList(this, state instanceof JobNode ? state : THROW_CCE());
          } else {
            var rootCause = null;
            var handle = NonDisposableHandle_instance;
            var tmp;
            if (onCancelling) {
              tmp = state instanceof Finishing;
            } else {
              tmp = false;
            }
            if (tmp) {
              // Inline function 'kotlinx.coroutines.internal.synchronized' call
              // Inline function 'kotlin.contracts.contract' call
              // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
              rootCause = state.zv();
              var tmp_0;
              var tmp_1;
              if (rootCause == null) {
                tmp_1 = true;
              } else {
                var tmp_2;
                // Inline function 'kotlinx.coroutines.isHandlerOf' call
                if (handler instanceof ChildHandleNode) {
                  tmp_2 = !state.wv();
                } else {
                  tmp_2 = false;
                }
                tmp_1 = tmp_2;
              }
              if (tmp_1) {
                if (!addLastAtomic(this, state, list, node)) {
                  break $l$block;
                }
                if (rootCause == null)
                  return node;
                handle = node;
                tmp_0 = Unit_instance;
              }
            }
            if (!(rootCause == null)) {
              if (invokeImmediately) {
                invokeIt(handler, rootCause);
              }
              return handle;
            } else {
              if (addLastAtomic(this, state, list, node))
                return node;
            }
          }
        } else {
          if (invokeImmediately) {
            var tmp1_safe_receiver = state instanceof CompletedExceptionally ? state : null;
            invokeIt(handler, tmp1_safe_receiver == null ? null : tmp1_safe_receiver.an_1);
          }
          return NonDisposableHandle_instance;
        }
      }
    }
  }
};
protoOf(JobSupport).gu = function ($completion) {
  if (!joinInternal(this)) {
    // Inline function 'kotlin.js.getCoroutineContext' call
    var tmp$ret$0 = $completion.i6();
    ensureActive(tmp$ret$0);
    return Unit_instance;
  }
  return joinSuspend(this, $completion);
};
protoOf(JobSupport).zn = function (node) {
  // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
  while (true) {
    // Inline function 'kotlinx.coroutines.JobSupport.removeNode.<anonymous>' call
    var state = this.pn();
    if (state instanceof JobNode) {
      if (!(state === node))
        return Unit_instance;
      if (this.om_1.atomicfu$compareAndSet(state, get_EMPTY_ACTIVE()))
        return Unit_instance;
    } else {
      if (!(state == null) ? isInterface(state, Incomplete) : false) {
        if (!(state.aq() == null)) {
          node.fq();
        }
        return Unit_instance;
      } else {
        return Unit_instance;
      }
    }
  }
};
protoOf(JobSupport).ao = function () {
  return false;
};
protoOf(JobSupport).bo = function (cause) {
  var tmp;
  if (cause == null) {
    // Inline function 'kotlinx.coroutines.JobSupport.defaultCancellationException' call
    tmp = new JobCancellationException(null == null ? this.ym() : null, null, this);
  } else {
    tmp = cause;
  }
  this.do(tmp);
};
protoOf(JobSupport).ym = function () {
  return 'Job was cancelled';
};
protoOf(JobSupport).do = function (cause) {
  this.go(cause);
};
protoOf(JobSupport).eo = function (parentJob) {
  this.go(parentJob);
};
protoOf(JobSupport).fo = function (cause) {
  if (cause instanceof CancellationException)
    return true;
  return this.go(cause) ? this.lo() : false;
};
protoOf(JobSupport).go = function (cause) {
  var finalState = get_COMPLETING_ALREADY();
  if (this.ao()) {
    finalState = cancelMakeCompleting(this, cause);
    if (finalState === get_COMPLETING_WAITING_CHILDREN())
      return true;
  }
  if (finalState === get_COMPLETING_ALREADY()) {
    finalState = makeCancelling(this, cause);
  }
  var tmp;
  if (finalState === get_COMPLETING_ALREADY()) {
    tmp = true;
  } else if (finalState === get_COMPLETING_WAITING_CHILDREN()) {
    tmp = true;
  } else if (finalState === get_TOO_LATE_TO_CANCEL()) {
    tmp = false;
  } else {
    this.fn(finalState);
    tmp = true;
  }
  return tmp;
};
protoOf(JobSupport).ho = function () {
  var state = this.pn();
  var tmp;
  if (state instanceof Finishing) {
    tmp = state.zv();
  } else {
    if (state instanceof CompletedExceptionally) {
      tmp = state.an_1;
    } else {
      if (!(state == null) ? isInterface(state, Incomplete) : false) {
        var message = 'Cannot be cancelling child in this state: ' + toString_0(state);
        throw IllegalStateException_init_$Create$(toString(message));
      } else {
        tmp = null;
      }
    }
  }
  var rootCause = tmp;
  var tmp1_elvis_lhs = rootCause instanceof CancellationException ? rootCause : null;
  return tmp1_elvis_lhs == null ? new JobCancellationException('Parent job is ' + stateString(this, state), rootCause, this) : tmp1_elvis_lhs;
};
protoOf(JobSupport).du = function (proposedUpdate) {
  // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
  while (true) {
    $l$block: {
      // Inline function 'kotlinx.coroutines.JobSupport.makeCompleting.<anonymous>' call
      var state = this.pn();
      var finalState = tryMakeCompleting(this, state, proposedUpdate);
      if (finalState === get_COMPLETING_ALREADY())
        return false;
      else if (finalState === get_COMPLETING_WAITING_CHILDREN())
        return true;
      else if (finalState === get_COMPLETING_RETRY()) {
        break $l$block;
      } else {
        this.fn(finalState);
        return true;
      }
    }
  }
};
protoOf(JobSupport).dn = function (proposedUpdate) {
  // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
  while (true) {
    $l$block: {
      // Inline function 'kotlinx.coroutines.JobSupport.makeCompletingOnce.<anonymous>' call
      var state = this.pn();
      var finalState = tryMakeCompleting(this, state, proposedUpdate);
      if (finalState === get_COMPLETING_ALREADY())
        throw IllegalStateException_init_$Create$_0('Job ' + this + ' is already complete or completing, ' + ('but is being completed with ' + toString_0(proposedUpdate)), _get_exceptionOrNull__b3j7js(proposedUpdate, this));
      else if (finalState === get_COMPLETING_RETRY()) {
        break $l$block;
      } else
        return finalState;
    }
  }
};
protoOf(JobSupport).io = function (child) {
  // Inline function 'kotlinx.coroutines.asHandler' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$1 = new ChildHandleNode(child);
  var tmp = this.yn(true, VOID, tmp$ret$1);
  return isInterface(tmp, ChildHandle) ? tmp : THROW_CCE();
};
protoOf(JobSupport).gn = function (exception) {
  throw exception;
};
protoOf(JobSupport).jo = function (cause) {
};
protoOf(JobSupport).ko = function () {
  return false;
};
protoOf(JobSupport).lo = function () {
  return true;
};
protoOf(JobSupport).mo = function (exception) {
  return false;
};
protoOf(JobSupport).zm = function (state) {
};
protoOf(JobSupport).fn = function (state) {
};
protoOf(JobSupport).toString = function () {
  return this.no() + '@' + get_hexAddress(this);
};
protoOf(JobSupport).no = function () {
  return this.hn() + '{' + stateString(this, this.pn()) + '}';
};
protoOf(JobSupport).hn = function () {
  return get_classSimpleName(this);
};
protoOf(JobSupport).oo = function () {
  var state = this.pn();
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!(!(state == null) ? isInterface(state, Incomplete) : false)) {
    // Inline function 'kotlinx.coroutines.JobSupport.getCompletedInternal.<anonymous>' call
    var message = 'This job has not completed yet';
    throw IllegalStateException_init_$Create$(toString(message));
  }
  if (state instanceof CompletedExceptionally)
    throw state.an_1;
  return unboxState(state);
};
protoOf(JobSupport).po = function ($completion) {
  $l$loop: while (true) {
    var state = this.pn();
    if (!(!(state == null) ? isInterface(state, Incomplete) : false)) {
      if (state instanceof CompletedExceptionally) {
        // Inline function 'kotlinx.coroutines.internal.recoverAndThrow' call
        throw state.an_1;
      }
      return unboxState(state);
    }
    if (startInternal(this, state) >= 0)
      break $l$loop;
  }
  return awaitSuspend(this, $completion);
};
function boxIncomplete(_this__u8e3s4) {
  _init_properties_JobSupport_kt__68f172();
  var tmp;
  if (!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Incomplete) : false) {
    tmp = new IncompleteStateBox(_this__u8e3s4);
  } else {
    tmp = _this__u8e3s4;
  }
  return tmp;
}
function JobCancellingNode() {
  JobNode.call(this);
}
function InactiveNodeList(list) {
  this.vv_1 = list;
}
protoOf(InactiveNodeList).aq = function () {
  return this.vv_1;
};
protoOf(InactiveNodeList).vm = function () {
  return false;
};
protoOf(InactiveNodeList).toString = function () {
  return get_DEBUG() ? this.vv_1.lv('New') : anyToString(this);
};
function ChildHandleNode(childJob) {
  JobCancellingNode.call(this);
  this.fw_1 = childJob;
}
protoOf(ChildHandleNode).on = function () {
  return this.zp();
};
protoOf(ChildHandleNode).np = function (cause) {
  return this.fw_1.eo(this.zp());
};
protoOf(ChildHandleNode).invoke = function (cause) {
  return this.np(cause);
};
protoOf(ChildHandleNode).fo = function (cause) {
  return this.zp().fo(cause);
};
function InvokeOnCancelling(handler) {
  JobCancellingNode.call(this);
  this.bx_1 = handler;
  this.cx_1 = atomic$int$1(0);
}
protoOf(InvokeOnCancelling).np = function (cause) {
  if (this.cx_1.atomicfu$compareAndSet(0, 1))
    this.bx_1(cause);
};
protoOf(InvokeOnCancelling).invoke = function (cause) {
  return this.np(cause);
};
function InvokeOnCompletion(handler) {
  JobNode.call(this);
  this.hx_1 = handler;
}
protoOf(InvokeOnCompletion).np = function (cause) {
  return this.hx_1(cause);
};
protoOf(InvokeOnCompletion).invoke = function (cause) {
  return this.np(cause);
};
function ResumeOnCompletion(continuation) {
  JobNode.call(this);
  this.mx_1 = continuation;
}
protoOf(ResumeOnCompletion).np = function (cause) {
  // Inline function 'kotlin.coroutines.resume' call
  var this_0 = this.mx_1;
  // Inline function 'kotlin.Companion.success' call
  var tmp$ret$0 = _Result___init__impl__xyqfz8(Unit_instance);
  this_0.j6(tmp$ret$0);
  return Unit_instance;
};
protoOf(ResumeOnCompletion).invoke = function (cause) {
  return this.np(cause);
};
function unboxState(_this__u8e3s4) {
  _init_properties_JobSupport_kt__68f172();
  var tmp0_safe_receiver = _this__u8e3s4 instanceof IncompleteStateBox ? _this__u8e3s4 : null;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.nx_1;
  return tmp1_elvis_lhs == null ? _this__u8e3s4 : tmp1_elvis_lhs;
}
function ResumeAwaitOnCompletion(continuation) {
  JobNode.call(this);
  this.sx_1 = continuation;
}
protoOf(ResumeAwaitOnCompletion).np = function (cause) {
  var state = this.zp().pn();
  // Inline function 'kotlinx.coroutines.assert' call
  if (state instanceof CompletedExceptionally) {
    // Inline function 'kotlin.coroutines.resumeWithException' call
    var this_0 = this.sx_1;
    // Inline function 'kotlin.Companion.failure' call
    var exception = state.an_1;
    var tmp$ret$0 = _Result___init__impl__xyqfz8(createFailure(exception));
    this_0.j6(tmp$ret$0);
  } else {
    // Inline function 'kotlin.coroutines.resume' call
    var this_1 = this.sx_1;
    var tmp = unboxState(state);
    // Inline function 'kotlin.Companion.success' call
    var value = (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
    var tmp$ret$2 = _Result___init__impl__xyqfz8(value);
    this_1.j6(tmp$ret$2);
  }
};
protoOf(ResumeAwaitOnCompletion).invoke = function (cause) {
  return this.np(cause);
};
function IncompleteStateBox(state) {
  this.nx_1 = state;
}
function ChildContinuation(child) {
  JobCancellingNode.call(this);
  this.xx_1 = child;
}
protoOf(ChildContinuation).np = function (cause) {
  this.xx_1.gt(this.xx_1.ht(this.zp()));
};
protoOf(ChildContinuation).invoke = function (cause) {
  return this.np(cause);
};
function handlesException($this) {
  var tmp = $this.nn();
  var tmp0_safe_receiver = tmp instanceof ChildHandleNode ? tmp : null;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.zp();
  var tmp_0;
  if (tmp1_elvis_lhs == null) {
    return false;
  } else {
    tmp_0 = tmp1_elvis_lhs;
  }
  var parentJob = tmp_0;
  while (true) {
    if (parentJob.lo())
      return true;
    var tmp_1 = parentJob.nn();
    var tmp2_safe_receiver = tmp_1 instanceof ChildHandleNode ? tmp_1 : null;
    var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.zp();
    var tmp_2;
    if (tmp3_elvis_lhs == null) {
      return false;
    } else {
      tmp_2 = tmp3_elvis_lhs;
    }
    parentJob = tmp_2;
  }
}
function JobImpl(parent) {
  JobSupport.call(this, true);
  this.qm(parent);
  this.ay_1 = handlesException(this);
}
protoOf(JobImpl).ao = function () {
  return true;
};
protoOf(JobImpl).lo = function () {
  return this.ay_1;
};
protoOf(JobImpl).fu = function () {
  return this.du(Unit_instance);
};
protoOf(JobImpl).eu = function (exception) {
  return this.du(new CompletedExceptionally(exception));
};
var properties_initialized_JobSupport_kt_5iq8a4;
function _init_properties_JobSupport_kt__68f172() {
  if (!properties_initialized_JobSupport_kt_5iq8a4) {
    properties_initialized_JobSupport_kt_5iq8a4 = true;
    COMPLETING_ALREADY = new Symbol('COMPLETING_ALREADY');
    COMPLETING_WAITING_CHILDREN = new Symbol('COMPLETING_WAITING_CHILDREN');
    COMPLETING_RETRY = new Symbol('COMPLETING_RETRY');
    TOO_LATE_TO_CANCEL = new Symbol('TOO_LATE_TO_CANCEL');
    SEALED = new Symbol('SEALED');
    EMPTY_NEW = new Empty(false);
    EMPTY_ACTIVE = new Empty(true);
  }
}
function MainCoroutineDispatcher() {
  CoroutineDispatcher.call(this);
}
protoOf(MainCoroutineDispatcher).toString = function () {
  var tmp0_elvis_lhs = this.dy();
  return tmp0_elvis_lhs == null ? get_classSimpleName(this) + '@' + get_hexAddress(this) : tmp0_elvis_lhs;
};
protoOf(MainCoroutineDispatcher).dy = function () {
  var main = Dispatchers_getInstance().iy();
  if (this === main)
    return 'Dispatchers.Main';
  var tmp;
  try {
    tmp = main.cy();
  } catch ($p) {
    var tmp_0;
    if ($p instanceof UnsupportedOperationException) {
      var e = $p;
      tmp_0 = null;
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  var immediate = tmp;
  if (this === immediate)
    return 'Dispatchers.Main.immediate';
  return null;
};
function SupervisorJob(parent) {
  parent = parent === VOID ? null : parent;
  return new SupervisorJobImpl(parent);
}
function SupervisorJobImpl(parent) {
  JobImpl.call(this, parent);
}
protoOf(SupervisorJobImpl).fo = function (cause) {
  return false;
};
function TimeoutCancellationException() {
}
function Unconfined() {
  Unconfined_instance = this;
  CoroutineDispatcher.call(this);
}
protoOf(Unconfined).ku = function (context) {
  return false;
};
protoOf(Unconfined).lu = function (context, block) {
  var yieldContext = context.pc(Key_instance_4);
  if (!(yieldContext == null)) {
    yieldContext.oy_1 = true;
    return Unit_instance;
  }
  throw UnsupportedOperationException_init_$Create$('Dispatchers.Unconfined.dispatch function can only be used by the yield function. If you wrap Unconfined dispatcher in your code, make sure you properly delegate isDispatchNeeded and dispatch calls.');
};
protoOf(Unconfined).toString = function () {
  return 'Dispatchers.Unconfined';
};
var Unconfined_instance;
function Unconfined_getInstance() {
  if (Unconfined_instance == null)
    new Unconfined();
  return Unconfined_instance;
}
function Key_3() {
}
var Key_instance_4;
function Key_getInstance_3() {
  return Key_instance_4;
}
function Waiter() {
}
var BufferOverflow_SUSPEND_instance;
var BufferOverflow_DROP_OLDEST_instance;
var BufferOverflow_DROP_LATEST_instance;
var BufferOverflow_entriesInitialized;
function BufferOverflow_initEntries() {
  if (BufferOverflow_entriesInitialized)
    return Unit_instance;
  BufferOverflow_entriesInitialized = true;
  BufferOverflow_SUSPEND_instance = new BufferOverflow('SUSPEND', 0);
  BufferOverflow_DROP_OLDEST_instance = new BufferOverflow('DROP_OLDEST', 1);
  BufferOverflow_DROP_LATEST_instance = new BufferOverflow('DROP_LATEST', 2);
}
function BufferOverflow(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function BufferOverflow_SUSPEND_getInstance() {
  BufferOverflow_initEntries();
  return BufferOverflow_SUSPEND_instance;
}
function BufferOverflow_DROP_OLDEST_getInstance() {
  BufferOverflow_initEntries();
  return BufferOverflow_DROP_OLDEST_instance;
}
function BufferOverflow_DROP_LATEST_getInstance() {
  BufferOverflow_initEntries();
  return BufferOverflow_DROP_LATEST_instance;
}
function get_NULL_SEGMENT() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return NULL_SEGMENT;
}
var NULL_SEGMENT;
function get_SEGMENT_SIZE() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return SEGMENT_SIZE;
}
var SEGMENT_SIZE;
function get_EXPAND_BUFFER_COMPLETION_WAIT_ITERATIONS() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return EXPAND_BUFFER_COMPLETION_WAIT_ITERATIONS;
}
var EXPAND_BUFFER_COMPLETION_WAIT_ITERATIONS;
function get_BUFFERED() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return BUFFERED;
}
var BUFFERED;
function get_IN_BUFFER() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return IN_BUFFER;
}
var IN_BUFFER;
function get_RESUMING_BY_RCV() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return RESUMING_BY_RCV;
}
var RESUMING_BY_RCV;
function get_RESUMING_BY_EB() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return RESUMING_BY_EB;
}
var RESUMING_BY_EB;
function get_POISONED() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return POISONED;
}
var POISONED;
function get_DONE_RCV() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return DONE_RCV;
}
var DONE_RCV;
function get_INTERRUPTED_SEND() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return INTERRUPTED_SEND;
}
var INTERRUPTED_SEND;
function get_INTERRUPTED_RCV() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return INTERRUPTED_RCV;
}
var INTERRUPTED_RCV;
function get_CHANNEL_CLOSED() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return CHANNEL_CLOSED;
}
var CHANNEL_CLOSED;
function get_SUSPEND() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return SUSPEND;
}
var SUSPEND;
function get_SUSPEND_NO_WAITER() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return SUSPEND_NO_WAITER;
}
var SUSPEND_NO_WAITER;
function get_FAILED() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return FAILED;
}
var FAILED;
function get_NO_RECEIVE_RESULT() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return NO_RECEIVE_RESULT;
}
var NO_RECEIVE_RESULT;
function get_CLOSE_HANDLER_CLOSED() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return CLOSE_HANDLER_CLOSED;
}
var CLOSE_HANDLER_CLOSED;
function get_CLOSE_HANDLER_INVOKED() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return CLOSE_HANDLER_INVOKED;
}
var CLOSE_HANDLER_INVOKED;
function get_NO_CLOSE_CAUSE() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return NO_CLOSE_CAUSE;
}
var NO_CLOSE_CAUSE;
function setElementLazy($this, index, value) {
  // Inline function 'kotlinx.atomicfu.AtomicRef.lazySet' call
  $this.uy_1.atomicfu$get(imul(index, 2)).kotlinx$atomicfu$value = value;
}
function ChannelSegment(id, prev, channel, pointers) {
  Segment.call(this, id, prev, pointers);
  this.ty_1 = channel;
  this.uy_1 = atomicfu$AtomicRefArray$ofNulls(imul(get_SEGMENT_SIZE(), 2));
}
protoOf(ChannelSegment).vy = function () {
  return ensureNotNull(this.ty_1);
};
protoOf(ChannelSegment).wy = function () {
  return get_SEGMENT_SIZE();
};
protoOf(ChannelSegment).xy = function (index, element) {
  setElementLazy(this, index, element);
};
protoOf(ChannelSegment).yy = function (index) {
  var tmp = this.uy_1.atomicfu$get(imul(index, 2)).kotlinx$atomicfu$value;
  return (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
};
protoOf(ChannelSegment).zy = function (index) {
  // Inline function 'kotlin.also' call
  var this_0 = this.yy(index);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.channels.ChannelSegment.retrieveElement.<anonymous>' call
  this.az(index);
  return this_0;
};
protoOf(ChannelSegment).az = function (index) {
  setElementLazy(this, index, null);
};
protoOf(ChannelSegment).bz = function (index) {
  return this.uy_1.atomicfu$get(imul(index, 2) + 1 | 0).kotlinx$atomicfu$value;
};
protoOf(ChannelSegment).cz = function (index, value) {
  this.uy_1.atomicfu$get(imul(index, 2) + 1 | 0).kotlinx$atomicfu$value = value;
};
protoOf(ChannelSegment).dz = function (index, from, to) {
  return this.uy_1.atomicfu$get(imul(index, 2) + 1 | 0).atomicfu$compareAndSet(from, to);
};
protoOf(ChannelSegment).ez = function (index, update) {
  return this.uy_1.atomicfu$get(imul(index, 2) + 1 | 0).atomicfu$getAndSet(update);
};
protoOf(ChannelSegment).ls = function (index, cause, context) {
  var isSender = index >= get_SEGMENT_SIZE();
  var index_0 = isSender ? index - get_SEGMENT_SIZE() | 0 : index;
  var element = this.yy(index_0);
  $l$loop: while (true) {
    var cur = this.bz(index_0);
    var tmp;
    if (!(cur == null) ? isInterface(cur, Waiter) : false) {
      tmp = true;
    } else {
      tmp = cur instanceof WaiterEB;
    }
    if (tmp) {
      var update = isSender ? get_INTERRUPTED_SEND() : get_INTERRUPTED_RCV();
      if (this.dz(index_0, cur, update)) {
        this.az(index_0);
        this.rz(index_0, !isSender);
        if (isSender) {
          var tmp0_safe_receiver = this.vy().gz_1;
          if (tmp0_safe_receiver == null)
            null;
          else {
            callUndeliveredElement(tmp0_safe_receiver, element, context);
          }
        }
        return Unit_instance;
      }
    } else {
      if (cur === get_INTERRUPTED_SEND() ? true : cur === get_INTERRUPTED_RCV()) {
        this.az(index_0);
        if (isSender) {
          var tmp1_safe_receiver = this.vy().gz_1;
          if (tmp1_safe_receiver == null)
            null;
          else {
            callUndeliveredElement(tmp1_safe_receiver, element, context);
          }
        }
        return Unit_instance;
      } else {
        if (cur === get_RESUMING_BY_EB() ? true : cur === get_RESUMING_BY_RCV())
          continue $l$loop;
        else {
          if (cur === get_DONE_RCV() ? true : cur === get_BUFFERED())
            return Unit_instance;
          else {
            if (cur === get_CHANNEL_CLOSED())
              return Unit_instance;
            else {
              var message = 'unexpected state: ' + toString_0(cur);
              throw IllegalStateException_init_$Create$(toString(message));
            }
          }
        }
      }
    }
  }
};
protoOf(ChannelSegment).rz = function (index, receiver) {
  if (receiver) {
    var tmp = this.vy();
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.times' call
    var this_0 = this.js_1;
    var other = get_SEGMENT_SIZE();
    var tmp$ret$1 = this_0.da(toLong(other)).lb(toLong(index));
    tmp.sz(tmp$ret$1);
  }
  this.tz();
};
function onClosedHasNext($this) {
  $this.f10_1 = get_CHANNEL_CLOSED();
  var tmp0_elvis_lhs = $this.h10_1.i10();
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return false;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var cause = tmp;
  throw recoverStackTrace_0(cause);
}
function hasNextOnNoWaiterSuspend($this, segment, index, r, $completion) {
  // Inline function 'kotlinx.coroutines.suspendCancellableCoroutineReusable.<anonymous>' call
  var cancellable = getOrCreateCancellableContinuation(intercepted($completion));
  try {
    // Inline function 'kotlinx.coroutines.channels.BufferedChannelIterator.hasNextOnNoWaiterSuspend.<anonymous>' call
    $this.g10_1 = cancellable;
    // Inline function 'kotlinx.coroutines.channels.BufferedChannel.receiveImplOnNoWaiter' call
    var this_0 = $this.h10_1;
    var updCellResult = updateCellReceive(this_0, segment, index, r, $this);
    if (updCellResult === _get_SUSPEND_$accessor$yt74tm_ccb8g1()) {
      prepareReceiverForSuspension($this, this_0, segment, index);
    } else if (updCellResult === _get_FAILED_$accessor$yt74tm_h47uk8()) {
      if (r.o6(this_0.j10()) < 0) {
        segment.d10();
      }
      $l$block_0: {
        // Inline function 'kotlinx.coroutines.channels.BufferedChannel.receiveImpl' call
        var segment_0 = this_0.mz_1.kotlinx$atomicfu$value;
        $l$loop_0: while (true) {
          if (this_0.k10()) {
            onClosedHasNextNoWaiterSuspend($this);
            break $l$block_0;
          }
          var r_0 = this_0.iz_1.atomicfu$getAndIncrement$long();
          // Inline function 'kotlin.Long.div' call
          var other = get_SEGMENT_SIZE();
          var id = r_0.ca(toLong(other));
          // Inline function 'kotlin.Long.rem' call
          var other_0 = get_SEGMENT_SIZE();
          var i = r_0.nb(toLong(other_0)).ra();
          if (!segment_0.js_1.equals(id)) {
            var tmp0_elvis_lhs = findSegmentReceive(this_0, id, segment_0);
            var tmp;
            if (tmp0_elvis_lhs == null) {
              continue $l$loop_0;
            } else {
              tmp = tmp0_elvis_lhs;
            }
            segment_0 = tmp;
          }
          var updCellResult_0 = updateCellReceive(this_0, segment_0, i, r_0, $this);
          var tmp_0;
          if (updCellResult_0 === _get_SUSPEND_$accessor$yt74tm_ccb8g1()) {
            var tmp1_safe_receiver = (!($this == null) ? isInterface($this, Waiter) : false) ? $this : null;
            if (tmp1_safe_receiver == null)
              null;
            else {
              prepareReceiverForSuspension(tmp1_safe_receiver, this_0, segment_0, i);
            }
            // Inline function 'kotlinx.coroutines.channels.BufferedChannel.receiveImplOnNoWaiter.<anonymous>' call
            tmp_0 = Unit_instance;
          } else if (updCellResult_0 === _get_FAILED_$accessor$yt74tm_h47uk8()) {
            if (r_0.o6(this_0.j10()) < 0) {
              segment_0.d10();
            }
            continue $l$loop_0;
          } else if (updCellResult_0 === _get_SUSPEND_NO_WAITER_$accessor$yt74tm_n6n1ky()) {
            // Inline function 'kotlinx.coroutines.channels.BufferedChannel.receiveImpl.<anonymous>' call
            var message = 'unexpected';
            throw IllegalStateException_init_$Create$(toString(message));
          } else {
            segment_0.d10();
            var element = (updCellResult_0 == null ? true : !(updCellResult_0 == null)) ? updCellResult_0 : THROW_CCE();
            $this.f10_1 = element;
            $this.g10_1 = null;
            var tmp0_safe_receiver = $this.h10_1.gz_1;
            cancellable.ur(true, tmp0_safe_receiver == null ? null : bindCancellationFun(tmp0_safe_receiver, element, cancellable.i6()));
            tmp_0 = Unit_instance;
          }
          break $l$block_0;
        }
      }
    } else {
      segment.d10();
      // Inline function 'kotlinx.coroutines.channels.BufferedChannelIterator.hasNextOnNoWaiterSuspend.<anonymous>.<anonymous>' call
      var element_0 = (updCellResult == null ? true : !(updCellResult == null)) ? updCellResult : THROW_CCE();
      $this.f10_1 = element_0;
      $this.g10_1 = null;
      var tmp0_safe_receiver_0 = $this.h10_1.gz_1;
      cancellable.ur(true, tmp0_safe_receiver_0 == null ? null : bindCancellationFun(tmp0_safe_receiver_0, element_0, cancellable.i6()));
    }
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
      cancellable.it();
      throw e;
    } else {
      throw $p;
    }
  }
  return cancellable.rq();
}
function onClosedHasNextNoWaiterSuspend($this) {
  var cont = ensureNotNull($this.g10_1);
  $this.g10_1 = null;
  $this.f10_1 = get_CHANNEL_CLOSED();
  var cause = $this.h10_1.i10();
  if (cause == null) {
    // Inline function 'kotlin.coroutines.resume' call
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(false);
    cont.j6(tmp$ret$0);
  } else {
    // Inline function 'kotlin.coroutines.resumeWithException' call
    // Inline function 'kotlin.Companion.failure' call
    var exception = recoverStackTrace(cause, cont);
    var tmp$ret$2 = _Result___init__impl__xyqfz8(createFailure(exception));
    cont.j6(tmp$ret$2);
  }
}
function $hasNextCOROUTINE$6(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.t10_1 = _this__u8e3s4;
}
protoOf($hasNextCOROUTINE$6).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 8;
          this.ic_1 = 1;
          continue $sm;
        case 1:
          var tmp_0 = this;
          tmp_0.v10_1 = this.t10_1.h10_1;
          var tmp_1 = this;
          tmp_1.w10_1 = null;
          this.x10_1 = this.v10_1.mz_1.kotlinx$atomicfu$value;
          this.ic_1 = 2;
          continue $sm;
        case 2:
          if (!true) {
            this.ic_1 = 9;
            continue $sm;
          }

          if (this.v10_1.k10()) {
            var tmp_2 = this;
            tmp_2.u10_1 = onClosedHasNext(this.t10_1);
            this.ic_1 = 10;
            continue $sm;
          } else {
            this.ic_1 = 3;
            continue $sm;
          }

        case 3:
          this.y10_1 = this.v10_1.iz_1.atomicfu$getAndIncrement$long();
          var tmp_3 = this;
          var this_0 = this.y10_1;
          var other = get_SEGMENT_SIZE();
          tmp_3.z10_1 = this_0.ca(toLong(other));
          var tmp_4 = this;
          var this_1 = this.y10_1;
          var other_0 = get_SEGMENT_SIZE();
          tmp_4.a11_1 = this_1.nb(toLong(other_0)).ra();
          if (!this.x10_1.js_1.equals(this.z10_1)) {
            this.b11_1 = findSegmentReceive(this.v10_1, this.z10_1, this.x10_1);
            if (this.b11_1 == null) {
              this.ic_1 = 2;
              var tmp_5 = this;
              continue $sm;
            } else {
              this.c11_1 = this.b11_1;
              this.ic_1 = 4;
              continue $sm;
            }
          } else {
            this.ic_1 = 5;
            continue $sm;
          }

        case 4:
          this.x10_1 = this.c11_1;
          this.ic_1 = 5;
          continue $sm;
        case 5:
          this.d11_1 = updateCellReceive(this.v10_1, this.x10_1, this.a11_1, this.y10_1, this.w10_1);
          if (this.d11_1 === _get_SUSPEND_$accessor$yt74tm_ccb8g1()) {
            var tmp_6 = this;
            var tmp_7 = this.w10_1;
            var tmp1_safe_receiver = (!(tmp_7 == null) ? isInterface(tmp_7, Waiter) : false) ? tmp_7 : null;
            if (tmp1_safe_receiver == null)
              null;
            else {
              prepareReceiverForSuspension(tmp1_safe_receiver, this.v10_1, this.x10_1, this.a11_1);
            }
            this.x10_1;
            this.a11_1;
            this.y10_1;
            var message = 'unreachable';
            throw IllegalStateException_init_$Create$(toString(message));
          } else {
            if (this.d11_1 === _get_FAILED_$accessor$yt74tm_h47uk8()) {
              if (this.y10_1.o6(this.v10_1.j10()) < 0) {
                this.x10_1.d10();
              }
              this.ic_1 = 2;
              var tmp_8 = this;
              continue $sm;
            } else {
              if (this.d11_1 === _get_SUSPEND_NO_WAITER_$accessor$yt74tm_n6n1ky()) {
                var tmp_9 = this;
                tmp_9.f11_1 = this.x10_1;
                var tmp_10 = this;
                tmp_10.g11_1 = this.a11_1;
                var tmp_11 = this;
                tmp_11.h11_1 = this.y10_1;
                this.ic_1 = 6;
                suspendResult = hasNextOnNoWaiterSuspend(this.t10_1, this.f11_1, this.g11_1, this.h11_1, this);
                if (suspendResult === get_COROUTINE_SUSPENDED()) {
                  return suspendResult;
                }
                continue $sm;
              } else {
                var tmp_12 = this;
                this.x10_1.d10();
                var tmp_13 = this.d11_1;
                var element = (tmp_13 == null ? true : !(tmp_13 == null)) ? tmp_13 : THROW_CCE();
                this.t10_1.f10_1 = element;
                tmp_12.e11_1 = true;
                this.ic_1 = 7;
                continue $sm;
              }
            }
          }

        case 6:
          var tmp_14 = this;
          return suspendResult;
        case 7:
          this.u10_1 = this.e11_1;
          this.ic_1 = 10;
          continue $sm;
        case 8:
          throw this.lc_1;
        case 9:
          if (false) {
            this.ic_1 = 1;
            continue $sm;
          }

          this.ic_1 = 10;
          continue $sm;
        case 10:
          return this.u10_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 8) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function _get_bufferEndCounter__2d4hee($this) {
  return $this.jz_1.kotlinx$atomicfu$value;
}
function _get_isRendezvousOrUnlimited__3mdufi($this) {
  // Inline function 'kotlin.let' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.channels.BufferedChannel.<get-isRendezvousOrUnlimited>.<anonymous>' call
  var it = _get_bufferEndCounter__2d4hee($this);
  return it.equals(new Long(0, 0)) ? true : it.equals(new Long(-1, 2147483647));
}
function prepareSenderForSuspension(_this__u8e3s4, $this, segment, index) {
  _this__u8e3s4.lt(segment, index + get_SEGMENT_SIZE() | 0);
}
function SendBroadcast() {
}
function updateCellSend($this, segment, index, element, s, waiter, closed) {
  segment.xy(index, element);
  if (closed)
    return updateCellSendSlow($this, segment, index, element, s, waiter, closed);
  var state = segment.bz(index);
  if (state === null) {
    if (bufferOrRendezvousSend($this, s)) {
      if (segment.dz(index, null, get_BUFFERED())) {
        return _get_RESULT_BUFFERED_$accessor$yt74tm_quor5m();
      }
    } else {
      if (waiter == null) {
        return _get_RESULT_SUSPEND_NO_WAITER_$accessor$yt74tm_cvzv8m();
      } else {
        if (segment.dz(index, null, waiter))
          return _get_RESULT_SUSPEND_$accessor$yt74tm_cjypnf();
      }
    }
  } else {
    if (!(state == null) ? isInterface(state, Waiter) : false) {
      segment.az(index);
      var tmp;
      if (tryResumeReceiver(state, $this, element)) {
        segment.cz(index, get_DONE_RCV());
        $this.i11();
        tmp = _get_RESULT_RENDEZVOUS_$accessor$yt74tm_3irwt8();
      } else {
        if (!(segment.ez(index, get_INTERRUPTED_RCV()) === get_INTERRUPTED_RCV())) {
          segment.rz(index, true);
        }
        tmp = _get_RESULT_FAILED_$accessor$yt74tm_vo1zj0();
      }
      return tmp;
    }
  }
  return updateCellSendSlow($this, segment, index, element, s, waiter, closed);
}
function updateCellSendSlow($this, segment, index, element, s, waiter, closed) {
  while (true) {
    var state = segment.bz(index);
    if (state === null) {
      if (bufferOrRendezvousSend($this, s) ? !closed : false) {
        if (segment.dz(index, null, get_BUFFERED())) {
          return _get_RESULT_BUFFERED_$accessor$yt74tm_quor5m();
        }
      } else {
        if (closed) {
          if (segment.dz(index, null, get_INTERRUPTED_SEND())) {
            segment.rz(index, false);
            return _get_RESULT_CLOSED_$accessor$yt74tm_10v48j();
          }
        } else if (waiter == null)
          return _get_RESULT_SUSPEND_NO_WAITER_$accessor$yt74tm_cvzv8m();
        else if (segment.dz(index, null, waiter))
          return _get_RESULT_SUSPEND_$accessor$yt74tm_cjypnf();
      }
    } else if (state === get_IN_BUFFER()) {
      if (segment.dz(index, state, get_BUFFERED())) {
        return _get_RESULT_BUFFERED_$accessor$yt74tm_quor5m();
      }
    } else if (state === get_INTERRUPTED_RCV()) {
      segment.az(index);
      return _get_RESULT_FAILED_$accessor$yt74tm_vo1zj0();
    } else if (state === get_POISONED()) {
      segment.az(index);
      return _get_RESULT_FAILED_$accessor$yt74tm_vo1zj0();
    } else if (state === get_CHANNEL_CLOSED()) {
      segment.az(index);
      completeCloseOrCancel($this);
      return _get_RESULT_CLOSED_$accessor$yt74tm_10v48j();
    } else {
      // Inline function 'kotlinx.coroutines.assert' call
      segment.az(index);
      var tmp;
      if (state instanceof WaiterEB) {
        tmp = state.j11_1;
      } else {
        tmp = state;
      }
      var receiver = tmp;
      var tmp_0;
      if (tryResumeReceiver(receiver, $this, element)) {
        segment.cz(index, get_DONE_RCV());
        $this.i11();
        tmp_0 = _get_RESULT_RENDEZVOUS_$accessor$yt74tm_3irwt8();
      } else {
        if (!(segment.ez(index, get_INTERRUPTED_RCV()) === get_INTERRUPTED_RCV())) {
          segment.rz(index, true);
        }
        tmp_0 = _get_RESULT_FAILED_$accessor$yt74tm_vo1zj0();
      }
      return tmp_0;
    }
  }
}
function shouldSendSuspend($this, curSendersAndCloseStatus) {
  if (_get_isClosedForSend0__kxgf9m(curSendersAndCloseStatus, $this))
    return false;
  // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
  var tmp$ret$0 = curSendersAndCloseStatus.wb(new Long(-1, 268435455));
  return !bufferOrRendezvousSend($this, tmp$ret$0);
}
function bufferOrRendezvousSend($this, curSenders) {
  var tmp;
  if (curSenders.o6(_get_bufferEndCounter__2d4hee($this)) < 0) {
    tmp = true;
  } else {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = $this.k11();
    var other = $this.fz_1;
    var tmp$ret$0 = this_0.lb(toLong(other));
    tmp = curSenders.o6(tmp$ret$0) < 0;
  }
  return tmp;
}
function tryResumeReceiver(_this__u8e3s4, $this, element) {
  var tmp;
  if (isInterface(_this__u8e3s4, SelectInstance)) {
    tmp = _this__u8e3s4.p11($this, element);
  } else {
    if (_this__u8e3s4 instanceof ReceiveCatching) {
      if (!(_this__u8e3s4 instanceof ReceiveCatching))
        THROW_CCE();
      var tmp_0 = Companion_getInstance_0().n11(element);
      var tmp1_safe_receiver = $this.gz_1;
      tmp = tryResume0(_this__u8e3s4.o11_1, new ChannelResult(tmp_0), tmp1_safe_receiver == null ? null : bindCancellationFun(tmp1_safe_receiver, element, _this__u8e3s4.o11_1.i6()));
    } else {
      if (_this__u8e3s4 instanceof BufferedChannelIterator) {
        if (!(_this__u8e3s4 instanceof BufferedChannelIterator))
          THROW_CCE();
        tmp = _this__u8e3s4.l11(element);
      } else {
        if (isInterface(_this__u8e3s4, CancellableContinuation)) {
          if (!isInterface(_this__u8e3s4, CancellableContinuation))
            THROW_CCE();
          var tmp2_safe_receiver = $this.gz_1;
          tmp = tryResume0(_this__u8e3s4, element, tmp2_safe_receiver == null ? null : bindCancellationFun(tmp2_safe_receiver, element, _this__u8e3s4.i6()));
        } else {
          var message = 'Unexpected receiver type: ' + toString(_this__u8e3s4);
          throw IllegalStateException_init_$Create$(toString(message));
        }
      }
    }
  }
  return tmp;
}
function prepareReceiverForSuspension(_this__u8e3s4, $this, segment, index) {
  $this.q11();
  _this__u8e3s4.lt(segment, index);
}
function updateCellReceive($this, segment, index, r, waiter) {
  var state = segment.bz(index);
  if (state === null) {
    // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
    var senders = $this.hz_1.kotlinx$atomicfu$value.wb(new Long(-1, 268435455));
    if (r.o6(senders) >= 0) {
      if (waiter === null) {
        return _get_SUSPEND_NO_WAITER_$accessor$yt74tm_n6n1ky();
      }
      if (segment.dz(index, state, waiter)) {
        expandBuffer($this);
        return _get_SUSPEND_$accessor$yt74tm_ccb8g1();
      }
    }
  } else if (state === get_BUFFERED())
    if (segment.dz(index, state, get_DONE_RCV())) {
      expandBuffer($this);
      return segment.zy(index);
    }
  return updateCellReceiveSlow($this, segment, index, r, waiter);
}
function updateCellReceiveSlow($this, segment, index, r, waiter) {
  $l$loop: while (true) {
    var state = segment.bz(index);
    if (state === null ? true : state === get_IN_BUFFER()) {
      // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
      var senders = $this.hz_1.kotlinx$atomicfu$value.wb(new Long(-1, 268435455));
      if (r.o6(senders) < 0) {
        if (segment.dz(index, state, get_POISONED())) {
          expandBuffer($this);
          return _get_FAILED_$accessor$yt74tm_h47uk8();
        }
      } else {
        if (waiter === null) {
          return _get_SUSPEND_NO_WAITER_$accessor$yt74tm_n6n1ky();
        }
        if (segment.dz(index, state, waiter)) {
          expandBuffer($this);
          return _get_SUSPEND_$accessor$yt74tm_ccb8g1();
        }
      }
    } else if (state === get_BUFFERED()) {
      if (segment.dz(index, state, get_DONE_RCV())) {
        expandBuffer($this);
        return segment.zy(index);
      }
    } else if (state === get_INTERRUPTED_SEND())
      return _get_FAILED_$accessor$yt74tm_h47uk8();
    else if (state === get_POISONED())
      return _get_FAILED_$accessor$yt74tm_h47uk8();
    else if (state === get_CHANNEL_CLOSED()) {
      expandBuffer($this);
      return _get_FAILED_$accessor$yt74tm_h47uk8();
    } else if (state === get_RESUMING_BY_EB())
      continue $l$loop;
    else {
      if (segment.dz(index, state, get_RESUMING_BY_RCV())) {
        var helpExpandBuffer = state instanceof WaiterEB;
        var tmp;
        if (state instanceof WaiterEB) {
          tmp = state.j11_1;
        } else {
          tmp = state;
        }
        var sender = tmp;
        var tmp_0;
        if (tryResumeSender(sender, $this, segment, index)) {
          segment.cz(index, get_DONE_RCV());
          expandBuffer($this);
          tmp_0 = segment.zy(index);
        } else {
          segment.cz(index, get_INTERRUPTED_SEND());
          segment.rz(index, false);
          if (helpExpandBuffer) {
            expandBuffer($this);
          }
          tmp_0 = _get_FAILED_$accessor$yt74tm_h47uk8();
        }
        return tmp_0;
      }
    }
  }
}
function tryResumeSender(_this__u8e3s4, $this, segment, index) {
  var tmp;
  if (isInterface(_this__u8e3s4, CancellableContinuation)) {
    if (!isInterface(_this__u8e3s4, CancellableContinuation))
      THROW_CCE();
    tmp = tryResume0(_this__u8e3s4, Unit_instance);
  } else {
    if (isInterface(_this__u8e3s4, SelectInstance)) {
      if (!(_this__u8e3s4 instanceof SelectImplementation))
        THROW_CCE();
      var trySelectResult = _this__u8e3s4.v11($this, Unit_instance);
      if (trySelectResult === TrySelectDetailedResult_REREGISTER_getInstance()) {
        segment.az(index);
      }
      tmp = trySelectResult === TrySelectDetailedResult_SUCCESSFUL_getInstance();
    } else {
      if (_this__u8e3s4 instanceof SendBroadcast) {
        tmp = tryResume0(_this__u8e3s4.r11_1, true);
      } else {
        var message = 'Unexpected waiter: ' + toString(_this__u8e3s4);
        throw IllegalStateException_init_$Create$(toString(message));
      }
    }
  }
  return tmp;
}
function expandBuffer($this) {
  if (_get_isRendezvousOrUnlimited__3mdufi($this))
    return Unit_instance;
  var segment = $this.nz_1.kotlinx$atomicfu$value;
  try_again: while (true) {
    var b = $this.jz_1.atomicfu$getAndIncrement$long();
    // Inline function 'kotlin.Long.div' call
    var other = get_SEGMENT_SIZE();
    var id = b.ca(toLong(other));
    var s = $this.j10();
    if (s.o6(b) <= 0) {
      if (segment.js_1.o6(id) < 0 ? !(segment.zz() == null) : false) {
        moveSegmentBufferEndToSpecifiedOrLast($this, id, segment);
      }
      incCompletedExpandBufferAttempts$default($this);
      return Unit_instance;
    }
    if (!segment.js_1.equals(id)) {
      var tmp0_elvis_lhs = findSegmentBufferEnd($this, id, segment, b);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        continue try_again;
      } else {
        tmp = tmp0_elvis_lhs;
      }
      segment = tmp;
    }
    // Inline function 'kotlin.Long.rem' call
    var other_0 = get_SEGMENT_SIZE();
    var i = b.nb(toLong(other_0)).ra();
    if (updateCellExpandBuffer($this, segment, i, b)) {
      incCompletedExpandBufferAttempts$default($this);
      return Unit_instance;
    } else {
      incCompletedExpandBufferAttempts$default($this);
      continue try_again;
    }
  }
}
function updateCellExpandBuffer($this, segment, index, b) {
  var state = segment.bz(index);
  if (!(state == null) ? isInterface(state, Waiter) : false) {
    if (b.o6($this.iz_1.kotlinx$atomicfu$value) >= 0) {
      if (segment.dz(index, state, get_RESUMING_BY_EB())) {
        var tmp;
        if (tryResumeSender(state, $this, segment, index)) {
          segment.cz(index, get_BUFFERED());
          tmp = true;
        } else {
          segment.cz(index, get_INTERRUPTED_SEND());
          segment.rz(index, false);
          tmp = false;
        }
        return tmp;
      }
    }
  }
  return updateCellExpandBufferSlow($this, segment, index, b);
}
function updateCellExpandBufferSlow($this, segment, index, b) {
  $l$loop: while (true) {
    var state = segment.bz(index);
    if (!(state == null) ? isInterface(state, Waiter) : false) {
      if (b.o6($this.iz_1.kotlinx$atomicfu$value) < 0) {
        if (segment.dz(index, state, new WaiterEB(state)))
          return true;
      } else {
        if (segment.dz(index, state, get_RESUMING_BY_EB())) {
          var tmp;
          if (tryResumeSender(state, $this, segment, index)) {
            segment.cz(index, get_BUFFERED());
            tmp = true;
          } else {
            segment.cz(index, get_INTERRUPTED_SEND());
            segment.rz(index, false);
            tmp = false;
          }
          return tmp;
        }
      }
    } else {
      if (state === get_INTERRUPTED_SEND())
        return false;
      else {
        if (state === null) {
          if (segment.dz(index, state, get_IN_BUFFER()))
            return true;
        } else {
          if (state === get_BUFFERED())
            return true;
          else {
            if ((state === get_POISONED() ? true : state === get_DONE_RCV()) ? true : state === get_INTERRUPTED_RCV())
              return true;
            else {
              if (state === get_CHANNEL_CLOSED())
                return true;
              else {
                if (state === get_RESUMING_BY_RCV())
                  continue $l$loop;
                else {
                  var message = 'Unexpected cell state: ' + toString_0(state);
                  throw IllegalStateException_init_$Create$(toString(message));
                }
              }
            }
          }
        }
      }
    }
  }
}
function incCompletedExpandBufferAttempts($this, nAttempts) {
  // Inline function 'kotlin.also' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.channels.BufferedChannel.incCompletedExpandBufferAttempts.<anonymous>' call
  // Inline function 'kotlinx.coroutines.channels.ebPauseExpandBuffers' call
  if (!$this.kz_1.atomicfu$addAndGet$long(nAttempts).wb(new Long(0, 1073741824)).equals(new Long(0, 0))) {
    $l$loop: while (true) {
      // Inline function 'kotlinx.coroutines.channels.ebPauseExpandBuffers' call
      if (!!$this.kz_1.kotlinx$atomicfu$value.wb(new Long(0, 1073741824)).equals(new Long(0, 0))) {
        break $l$loop;
      }
    }
  }
}
function incCompletedExpandBufferAttempts$default($this, nAttempts, $super) {
  nAttempts = nAttempts === VOID ? new Long(1, 0) : nAttempts;
  return incCompletedExpandBufferAttempts($this, nAttempts);
}
function BufferedChannelIterator($outer) {
  this.h10_1 = $outer;
  this.f10_1 = get_NO_RECEIVE_RESULT();
  this.g10_1 = null;
}
protoOf(BufferedChannelIterator).w11 = function ($completion) {
  var tmp = new $hasNextCOROUTINE$6(this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(BufferedChannelIterator).lt = function (segment, index) {
  var tmp0_safe_receiver = this.g10_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    tmp0_safe_receiver.lt(segment, index);
  }
};
protoOf(BufferedChannelIterator).w = function () {
  var result = this.f10_1;
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!(result === get_NO_RECEIVE_RESULT())) {
    // Inline function 'kotlinx.coroutines.channels.BufferedChannelIterator.next.<anonymous>' call
    var message = '`hasNext()` has not been invoked';
    throw IllegalStateException_init_$Create$(toString(message));
  }
  this.f10_1 = get_NO_RECEIVE_RESULT();
  if (result === get_CHANNEL_CLOSED())
    throw recoverStackTrace_0(_get_receiveException__foorc1(this.h10_1));
  return (result == null ? true : !(result == null)) ? result : THROW_CCE();
};
protoOf(BufferedChannelIterator).l11 = function (element) {
  var cont = ensureNotNull(this.g10_1);
  this.g10_1 = null;
  this.f10_1 = element;
  var tmp0_safe_receiver = this.h10_1.gz_1;
  return tryResume0(cont, true, tmp0_safe_receiver == null ? null : bindCancellationFun(tmp0_safe_receiver, element, cont.i6()));
};
protoOf(BufferedChannelIterator).x11 = function () {
  var cont = ensureNotNull(this.g10_1);
  this.g10_1 = null;
  this.f10_1 = get_CHANNEL_CLOSED();
  var cause = this.h10_1.i10();
  if (cause == null) {
    // Inline function 'kotlin.coroutines.resume' call
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(false);
    cont.j6(tmp$ret$0);
  } else {
    // Inline function 'kotlin.coroutines.resumeWithException' call
    // Inline function 'kotlin.Companion.failure' call
    var exception = recoverStackTrace(cause, cont);
    var tmp$ret$2 = _Result___init__impl__xyqfz8(createFailure(exception));
    cont.j6(tmp$ret$2);
  }
};
function _get_receiveException__foorc1($this) {
  var tmp0_elvis_lhs = $this.i10();
  return tmp0_elvis_lhs == null ? new ClosedReceiveChannelException(get_DEFAULT_CLOSE_MESSAGE()) : tmp0_elvis_lhs;
}
function invokeCloseHandler($this) {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlinx.atomicfu.getAndUpdate' call
    var this_0 = $this.qz_1;
    while (true) {
      var cur = this_0.kotlinx$atomicfu$value;
      // Inline function 'kotlinx.coroutines.channels.BufferedChannel.invokeCloseHandler.<anonymous>' call
      var tmp;
      if (cur === null) {
        tmp = get_CLOSE_HANDLER_CLOSED();
      } else {
        tmp = get_CLOSE_HANDLER_INVOKED();
      }
      var upd = tmp;
      if (this_0.atomicfu$compareAndSet(cur, upd)) {
        tmp$ret$1 = cur;
        break $l$block;
      }
    }
  }
  var tmp0_elvis_lhs = tmp$ret$1;
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    return Unit_instance;
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var closeHandler = tmp_0;
  if (typeof closeHandler !== 'function')
    THROW_CCE();
  closeHandler($this.i10());
}
function markClosed($this) {
  var tmp$ret$4;
  $l$block: {
    // Inline function 'kotlinx.atomicfu.update' call
    var this_0 = $this.hz_1;
    while (true) {
      var cur = this_0.kotlinx$atomicfu$value;
      // Inline function 'kotlinx.coroutines.channels.BufferedChannel.markClosed.<anonymous>' call
      // Inline function 'kotlinx.coroutines.channels.sendersCloseStatus' call
      var tmp;
      switch (cur.ub(60).ra()) {
        case 0:
          // Inline function 'kotlinx.coroutines.channels.sendersCounter' call

          var tmp$ret$1 = cur.wb(new Long(-1, 268435455));
          tmp = constructSendersAndCloseStatus(tmp$ret$1, 2);
          break;
        case 1:
          // Inline function 'kotlinx.coroutines.channels.sendersCounter' call

          var tmp$ret$2 = cur.wb(new Long(-1, 268435455));
          tmp = constructSendersAndCloseStatus(tmp$ret$2, 3);
          break;
        default:
          return Unit_instance;
      }
      var upd = tmp;
      if (this_0.atomicfu$compareAndSet(cur, upd)) {
        tmp$ret$4 = Unit_instance;
        break $l$block;
      }
    }
  }
  return tmp$ret$4;
}
function markCancelled($this) {
  var tmp$ret$2;
  $l$block: {
    // Inline function 'kotlinx.atomicfu.update' call
    var this_0 = $this.hz_1;
    while (true) {
      var cur = this_0.kotlinx$atomicfu$value;
      // Inline function 'kotlinx.coroutines.channels.BufferedChannel.markCancelled.<anonymous>' call
      // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
      var tmp$ret$0 = cur.wb(new Long(-1, 268435455));
      var upd = constructSendersAndCloseStatus(tmp$ret$0, 3);
      if (this_0.atomicfu$compareAndSet(cur, upd)) {
        tmp$ret$2 = Unit_instance;
        break $l$block;
      }
    }
  }
  return tmp$ret$2;
}
function markCancellationStarted($this) {
  var tmp$ret$3;
  $l$block: {
    // Inline function 'kotlinx.atomicfu.update' call
    var this_0 = $this.hz_1;
    while (true) {
      var cur = this_0.kotlinx$atomicfu$value;
      // Inline function 'kotlinx.coroutines.channels.BufferedChannel.markCancellationStarted.<anonymous>' call
      var tmp;
      // Inline function 'kotlinx.coroutines.channels.sendersCloseStatus' call
      if (cur.ub(60).ra() === 0) {
        // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
        var tmp$ret$1 = cur.wb(new Long(-1, 268435455));
        tmp = constructSendersAndCloseStatus(tmp$ret$1, 1);
      } else {
        return Unit_instance;
      }
      var upd = tmp;
      if (this_0.atomicfu$compareAndSet(cur, upd)) {
        tmp$ret$3 = Unit_instance;
        break $l$block;
      }
    }
  }
  return tmp$ret$3;
}
function completeCloseOrCancel($this) {
  $this.y11();
}
function completeClose($this, sendersCur) {
  var lastSegment = closeLinkedList($this);
  if ($this.a12()) {
    var lastBufferedCellGlobalIndex = markAllEmptyCellsAsClosed($this, lastSegment);
    if (!lastBufferedCellGlobalIndex.equals(new Long(-1, -1))) {
      $this.z11(lastBufferedCellGlobalIndex);
    }
  }
  cancelSuspendedReceiveRequests($this, lastSegment, sendersCur);
  return lastSegment;
}
function completeCancel($this, sendersCur) {
  var lastSegment = completeClose($this, sendersCur);
  removeUnprocessedElements($this, lastSegment);
}
function closeLinkedList($this) {
  var lastSegment = $this.nz_1.kotlinx$atomicfu$value;
  // Inline function 'kotlin.let' call
  // Inline function 'kotlin.contracts.contract' call
  var it = $this.lz_1.kotlinx$atomicfu$value;
  var tmp;
  if (it.js_1.o6(lastSegment.js_1) > 0) {
    lastSegment = it;
    tmp = Unit_instance;
  }
  // Inline function 'kotlin.let' call
  // Inline function 'kotlin.contracts.contract' call
  var it_0 = $this.mz_1.kotlinx$atomicfu$value;
  var tmp_0;
  if (it_0.js_1.o6(lastSegment.js_1) > 0) {
    lastSegment = it_0;
    tmp_0 = Unit_instance;
  }
  return close(lastSegment);
}
function markAllEmptyCellsAsClosed($this, lastSegment) {
  var segment = lastSegment;
  while (true) {
    var inductionVariable = get_SEGMENT_SIZE() - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        // Inline function 'kotlin.Long.plus' call
        // Inline function 'kotlin.Long.times' call
        var this_0 = segment.js_1;
        var other = get_SEGMENT_SIZE();
        var globalIndex = this_0.da(toLong(other)).lb(toLong(index));
        if (globalIndex.o6($this.k11()) < 0)
          return new Long(-1, -1);
        cell_update: while (true) {
          var state = segment.bz(index);
          if (state === null ? true : state === get_IN_BUFFER()) {
            if (segment.dz(index, state, get_CHANNEL_CLOSED())) {
              segment.tz();
              break cell_update;
            }
          } else if (state === get_BUFFERED())
            return globalIndex;
          else
            break cell_update;
        }
      }
       while (0 <= inductionVariable);
    var tmp1_elvis_lhs = segment.c10();
    var tmp;
    if (tmp1_elvis_lhs == null) {
      return new Long(-1, -1);
    } else {
      tmp = tmp1_elvis_lhs;
    }
    segment = tmp;
  }
}
function removeUnprocessedElements($this, lastSegment) {
  var onUndeliveredElement = $this.gz_1;
  var undeliveredElementException = null;
  var suspendedSenders = _InlineList___init__impl__z8n56();
  var segment = lastSegment;
  process_segments: while (true) {
    var inductionVariable = get_SEGMENT_SIZE() - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        // Inline function 'kotlin.Long.plus' call
        // Inline function 'kotlin.Long.times' call
        var this_0 = segment.js_1;
        var other = get_SEGMENT_SIZE();
        var globalIndex = this_0.da(toLong(other)).lb(toLong(index));
        update_cell: while (true) {
          var state = segment.bz(index);
          if (state === get_DONE_RCV())
            break process_segments;
          else {
            if (state === get_BUFFERED()) {
              if (globalIndex.o6($this.k11()) < 0)
                break process_segments;
              if (segment.dz(index, state, get_CHANNEL_CLOSED())) {
                if (!(onUndeliveredElement == null)) {
                  var element = segment.yy(index);
                  undeliveredElementException = callUndeliveredElementCatchingException(onUndeliveredElement, element, undeliveredElementException);
                }
                segment.az(index);
                segment.tz();
                break update_cell;
              }
            } else {
              if (state === get_IN_BUFFER() ? true : state === null) {
                if (segment.dz(index, state, get_CHANNEL_CLOSED())) {
                  segment.tz();
                  break update_cell;
                }
              } else {
                var tmp;
                if (!(state == null) ? isInterface(state, Waiter) : false) {
                  tmp = true;
                } else {
                  tmp = state instanceof WaiterEB;
                }
                if (tmp) {
                  if (globalIndex.o6($this.k11()) < 0)
                    break process_segments;
                  var tmp_0;
                  if (state instanceof WaiterEB) {
                    tmp_0 = state.j11_1;
                  } else {
                    tmp_0 = (!(state == null) ? isInterface(state, Waiter) : false) ? state : THROW_CCE();
                  }
                  var sender = tmp_0;
                  if (segment.dz(index, state, get_CHANNEL_CLOSED())) {
                    if (!(onUndeliveredElement == null)) {
                      var element_0 = segment.yy(index);
                      undeliveredElementException = callUndeliveredElementCatchingException(onUndeliveredElement, element_0, undeliveredElementException);
                    }
                    suspendedSenders = InlineList__plus_impl_nuetvo(suspendedSenders, sender);
                    segment.az(index);
                    segment.tz();
                    break update_cell;
                  }
                } else {
                  if (state === get_RESUMING_BY_EB() ? true : state === get_RESUMING_BY_RCV())
                    break process_segments;
                  else {
                    if (state === get_RESUMING_BY_EB())
                      continue update_cell;
                    else {
                      break update_cell;
                    }
                  }
                }
              }
            }
          }
        }
      }
       while (0 <= inductionVariable);
    var tmp1_elvis_lhs = segment.c10();
    var tmp_1;
    if (tmp1_elvis_lhs == null) {
      break process_segments;
    } else {
      tmp_1 = tmp1_elvis_lhs;
    }
    segment = tmp_1;
  }
  $l$block: {
    // Inline function 'kotlinx.coroutines.internal.InlineList.forEachReversed' call
    var this_1 = suspendedSenders;
    var tmp0_subject = _get_holder__f6h5pd(this_1);
    if (tmp0_subject == null) {
      break $l$block;
    } else {
      if (!(tmp0_subject instanceof ArrayList)) {
        // Inline function 'kotlinx.coroutines.channels.BufferedChannel.removeUnprocessedElements.<anonymous>' call
        var tmp_2 = _get_holder__f6h5pd(this_1);
        var it = (tmp_2 == null ? true : !(tmp_2 == null)) ? tmp_2 : THROW_CCE();
        resumeSenderOnCancelledChannel(it, $this);
      } else {
        var tmp_3 = _get_holder__f6h5pd(this_1);
        var list = tmp_3 instanceof ArrayList ? tmp_3 : THROW_CCE();
        var inductionVariable_0 = list.n() - 1 | 0;
        if (0 <= inductionVariable_0)
          do {
            var i = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + -1 | 0;
            // Inline function 'kotlinx.coroutines.channels.BufferedChannel.removeUnprocessedElements.<anonymous>' call
            var it_0 = list.f1(i);
            resumeSenderOnCancelledChannel(it_0, $this);
          }
           while (0 <= inductionVariable_0);
      }
    }
  }
  var tmp2_safe_receiver = undeliveredElementException;
  if (tmp2_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    throw tmp2_safe_receiver;
  }
}
function cancelSuspendedReceiveRequests($this, lastSegment, sendersCounter) {
  var suspendedReceivers = _InlineList___init__impl__z8n56();
  var segment = lastSegment;
  process_segments: while (!(segment == null)) {
    var inductionVariable = get_SEGMENT_SIZE() - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        // Inline function 'kotlin.Long.plus' call
        // Inline function 'kotlin.Long.times' call
        var this_0 = segment.js_1;
        var other = get_SEGMENT_SIZE();
        if (this_0.da(toLong(other)).lb(toLong(index)).o6(sendersCounter) < 0)
          break process_segments;
        cell_update: while (true) {
          var state = segment.bz(index);
          if (state === null ? true : state === get_IN_BUFFER()) {
            if (segment.dz(index, state, get_CHANNEL_CLOSED())) {
              segment.tz();
              break cell_update;
            }
          } else {
            if (state instanceof WaiterEB) {
              if (segment.dz(index, state, get_CHANNEL_CLOSED())) {
                suspendedReceivers = InlineList__plus_impl_nuetvo(suspendedReceivers, state.j11_1);
                segment.rz(index, true);
                break cell_update;
              }
            } else {
              if (!(state == null) ? isInterface(state, Waiter) : false) {
                if (segment.dz(index, state, get_CHANNEL_CLOSED())) {
                  suspendedReceivers = InlineList__plus_impl_nuetvo(suspendedReceivers, state);
                  segment.rz(index, true);
                  break cell_update;
                }
              } else {
                break cell_update;
              }
            }
          }
        }
      }
       while (0 <= inductionVariable);
    segment = segment.c10();
  }
  $l$block: {
    // Inline function 'kotlinx.coroutines.internal.InlineList.forEachReversed' call
    var this_1 = suspendedReceivers;
    var tmp0_subject = _get_holder__f6h5pd(this_1);
    if (tmp0_subject == null) {
      break $l$block;
    } else {
      if (!(tmp0_subject instanceof ArrayList)) {
        // Inline function 'kotlinx.coroutines.channels.BufferedChannel.cancelSuspendedReceiveRequests.<anonymous>' call
        var tmp = _get_holder__f6h5pd(this_1);
        var it = (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
        resumeReceiverOnClosedChannel(it, $this);
      } else {
        var tmp_0 = _get_holder__f6h5pd(this_1);
        var list = tmp_0 instanceof ArrayList ? tmp_0 : THROW_CCE();
        var inductionVariable_0 = list.n() - 1 | 0;
        if (0 <= inductionVariable_0)
          do {
            var i = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + -1 | 0;
            // Inline function 'kotlinx.coroutines.channels.BufferedChannel.cancelSuspendedReceiveRequests.<anonymous>' call
            var it_0 = list.f1(i);
            resumeReceiverOnClosedChannel(it_0, $this);
          }
           while (0 <= inductionVariable_0);
      }
    }
  }
}
function resumeReceiverOnClosedChannel(_this__u8e3s4, $this) {
  return resumeWaiterOnClosedChannel(_this__u8e3s4, $this, true);
}
function resumeSenderOnCancelledChannel(_this__u8e3s4, $this) {
  return resumeWaiterOnClosedChannel(_this__u8e3s4, $this, false);
}
function resumeWaiterOnClosedChannel(_this__u8e3s4, $this, receiver) {
  if (_this__u8e3s4 instanceof SendBroadcast) {
    // Inline function 'kotlin.coroutines.resume' call
    var this_0 = _this__u8e3s4.r11_1;
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(false);
    this_0.j6(tmp$ret$0);
  } else {
    if (isInterface(_this__u8e3s4, CancellableContinuation)) {
      // Inline function 'kotlin.coroutines.resumeWithException' call
      // Inline function 'kotlin.Companion.failure' call
      var exception = receiver ? _get_receiveException__foorc1($this) : $this.c12();
      var tmp$ret$2 = _Result___init__impl__xyqfz8(createFailure(exception));
      _this__u8e3s4.j6(tmp$ret$2);
    } else {
      if (_this__u8e3s4 instanceof ReceiveCatching) {
        // Inline function 'kotlin.coroutines.resume' call
        var this_1 = _this__u8e3s4.o11_1;
        // Inline function 'kotlin.Companion.success' call
        var value = new ChannelResult(Companion_getInstance_0().b12($this.i10()));
        var tmp$ret$4 = _Result___init__impl__xyqfz8(value);
        this_1.j6(tmp$ret$4);
      } else {
        if (_this__u8e3s4 instanceof BufferedChannelIterator) {
          _this__u8e3s4.x11();
        } else {
          if (isInterface(_this__u8e3s4, SelectInstance)) {
            _this__u8e3s4.p11($this, get_CHANNEL_CLOSED());
          } else {
            var message = 'Unexpected waiter: ' + _this__u8e3s4;
            throw IllegalStateException_init_$Create$(toString(message));
          }
        }
      }
    }
  }
}
function _get_isClosedForSend0__kxgf9m(_this__u8e3s4, $this) {
  return isClosed($this, _this__u8e3s4, false);
}
function _get_isClosedForReceive0__f7qknl(_this__u8e3s4, $this) {
  return isClosed($this, _this__u8e3s4, true);
}
function isClosed($this, sendersAndCloseStatusCur, isClosedForReceive) {
  // Inline function 'kotlinx.coroutines.channels.sendersCloseStatus' call
  var tmp;
  switch (sendersAndCloseStatusCur.ub(60).ra()) {
    case 0:
      tmp = false;
      break;
    case 1:
      tmp = false;
      break;
    case 2:
      // Inline function 'kotlinx.coroutines.channels.sendersCounter' call

      var tmp$ret$1 = sendersAndCloseStatusCur.wb(new Long(-1, 268435455));
      completeClose($this, tmp$ret$1);
      tmp = isClosedForReceive ? !$this.d12() : true;
      break;
    case 3:
      // Inline function 'kotlinx.coroutines.channels.sendersCounter' call

      var tmp$ret$2 = sendersAndCloseStatusCur.wb(new Long(-1, 268435455));
      completeCancel($this, tmp$ret$2);
      tmp = true;
      break;
    default:
      // Inline function 'kotlinx.coroutines.channels.sendersCloseStatus' call

      var message = 'unexpected close status: ' + sendersAndCloseStatusCur.ub(60).ra();
      throw IllegalStateException_init_$Create$(toString(message));
  }
  return tmp;
}
function isCellNonEmpty($this, segment, index, globalIndex) {
  while (true) {
    var state = segment.bz(index);
    if (state === null ? true : state === get_IN_BUFFER()) {
      if (segment.dz(index, state, get_POISONED())) {
        expandBuffer($this);
        return false;
      }
    } else if (state === get_BUFFERED())
      return true;
    else if (state === get_INTERRUPTED_SEND())
      return false;
    else if (state === get_CHANNEL_CLOSED())
      return false;
    else if (state === get_DONE_RCV())
      return false;
    else if (state === get_POISONED())
      return false;
    else if (state === get_RESUMING_BY_EB())
      return true;
    else if (state === get_RESUMING_BY_RCV())
      return false;
    else
      return globalIndex.equals($this.k11());
  }
}
function findSegmentSend($this, id, startFrom) {
  // Inline function 'kotlin.let' call
  var tmp$ret$1;
  $l$block_2: {
    // Inline function 'kotlinx.coroutines.internal.findSegmentAndMoveForward' call
    var this_0 = $this.lz_1;
    var createNewSegment = createSegmentFunction();
    while (true) {
      var s = findSegmentInternal(startFrom, id, createNewSegment);
      var tmp;
      if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(s)) {
        tmp = true;
      } else {
        var tmp$ret$0;
        $l$block_1: {
          // Inline function 'kotlinx.coroutines.internal.moveForward' call
          var to = _SegmentOrClosed___get_segment__impl__jvcr9l(s);
          while (true) {
            // Inline function 'kotlinx.coroutines.internal.moveForward.<anonymous>' call
            var cur = this_0.kotlinx$atomicfu$value;
            if (cur.js_1.o6(to.js_1) >= 0) {
              tmp$ret$0 = true;
              break $l$block_1;
            }
            if (!to.vz()) {
              tmp$ret$0 = false;
              break $l$block_1;
            }
            if (this_0.atomicfu$compareAndSet(cur, to)) {
              if (cur.wz()) {
                cur.y();
              }
              tmp$ret$0 = true;
              break $l$block_1;
            }
            if (to.wz()) {
              to.y();
            }
          }
          tmp$ret$0 = Unit_instance;
        }
        tmp = tmp$ret$0;
      }
      if (tmp) {
        tmp$ret$1 = s;
        break $l$block_2;
      }
    }
  }
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.channels.BufferedChannel.findSegmentSend.<anonymous>' call
  var it = tmp$ret$1;
  var tmp_0;
  if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(it)) {
    completeCloseOrCancel($this);
    // Inline function 'kotlin.Long.times' call
    var this_1 = startFrom.js_1;
    var other = get_SEGMENT_SIZE();
    if (this_1.da(toLong(other)).o6($this.k11()) < 0) {
      startFrom.d10();
    }
    tmp_0 = null;
  } else {
    var segment = _SegmentOrClosed___get_segment__impl__jvcr9l(it);
    var tmp_1;
    if (segment.js_1.o6(id) > 0) {
      // Inline function 'kotlin.Long.times' call
      var this_2 = segment.js_1;
      var other_0 = get_SEGMENT_SIZE();
      var tmp$ret$3 = this_2.da(toLong(other_0));
      updateSendersCounterIfLower($this, tmp$ret$3);
      // Inline function 'kotlin.Long.times' call
      var this_3 = segment.js_1;
      var other_1 = get_SEGMENT_SIZE();
      if (this_3.da(toLong(other_1)).o6($this.k11()) < 0) {
        segment.d10();
      }
      tmp_1 = null;
    } else {
      // Inline function 'kotlinx.coroutines.assert' call
      tmp_1 = segment;
    }
    tmp_0 = tmp_1;
  }
  return tmp_0;
}
function findSegmentReceive($this, id, startFrom) {
  // Inline function 'kotlin.let' call
  var tmp$ret$1;
  $l$block_2: {
    // Inline function 'kotlinx.coroutines.internal.findSegmentAndMoveForward' call
    var this_0 = $this.mz_1;
    var createNewSegment = createSegmentFunction();
    while (true) {
      var s = findSegmentInternal(startFrom, id, createNewSegment);
      var tmp;
      if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(s)) {
        tmp = true;
      } else {
        var tmp$ret$0;
        $l$block_1: {
          // Inline function 'kotlinx.coroutines.internal.moveForward' call
          var to = _SegmentOrClosed___get_segment__impl__jvcr9l(s);
          while (true) {
            // Inline function 'kotlinx.coroutines.internal.moveForward.<anonymous>' call
            var cur = this_0.kotlinx$atomicfu$value;
            if (cur.js_1.o6(to.js_1) >= 0) {
              tmp$ret$0 = true;
              break $l$block_1;
            }
            if (!to.vz()) {
              tmp$ret$0 = false;
              break $l$block_1;
            }
            if (this_0.atomicfu$compareAndSet(cur, to)) {
              if (cur.wz()) {
                cur.y();
              }
              tmp$ret$0 = true;
              break $l$block_1;
            }
            if (to.wz()) {
              to.y();
            }
          }
          tmp$ret$0 = Unit_instance;
        }
        tmp = tmp$ret$0;
      }
      if (tmp) {
        tmp$ret$1 = s;
        break $l$block_2;
      }
    }
  }
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.channels.BufferedChannel.findSegmentReceive.<anonymous>' call
  var it = tmp$ret$1;
  var tmp_0;
  if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(it)) {
    completeCloseOrCancel($this);
    // Inline function 'kotlin.Long.times' call
    var this_1 = startFrom.js_1;
    var other = get_SEGMENT_SIZE();
    if (this_1.da(toLong(other)).o6($this.j10()) < 0) {
      startFrom.d10();
    }
    tmp_0 = null;
  } else {
    var segment = _SegmentOrClosed___get_segment__impl__jvcr9l(it);
    var tmp_1;
    if (!_get_isRendezvousOrUnlimited__3mdufi($this)) {
      // Inline function 'kotlin.Long.div' call
      var this_2 = _get_bufferEndCounter__2d4hee($this);
      var other_0 = get_SEGMENT_SIZE();
      var tmp$ret$3 = this_2.ca(toLong(other_0));
      tmp_1 = id.o6(tmp$ret$3) <= 0;
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      $l$block_5: {
        // Inline function 'kotlinx.coroutines.internal.moveForward' call
        var this_3 = $this.nz_1;
        while (true) {
          // Inline function 'kotlinx.coroutines.internal.moveForward.<anonymous>' call
          var cur_0 = this_3.kotlinx$atomicfu$value;
          if (cur_0.js_1.o6(segment.js_1) >= 0) {
            break $l$block_5;
          }
          if (!segment.vz()) {
            break $l$block_5;
          }
          if (this_3.atomicfu$compareAndSet(cur_0, segment)) {
            if (cur_0.wz()) {
              cur_0.y();
            }
            break $l$block_5;
          }
          if (segment.wz()) {
            segment.y();
          }
        }
      }
    }
    var tmp_2;
    if (segment.js_1.o6(id) > 0) {
      // Inline function 'kotlin.Long.times' call
      var this_4 = segment.js_1;
      var other_1 = get_SEGMENT_SIZE();
      var tmp$ret$5 = this_4.da(toLong(other_1));
      updateReceiversCounterIfLower($this, tmp$ret$5);
      // Inline function 'kotlin.Long.times' call
      var this_5 = segment.js_1;
      var other_2 = get_SEGMENT_SIZE();
      if (this_5.da(toLong(other_2)).o6($this.j10()) < 0) {
        segment.d10();
      }
      tmp_2 = null;
    } else {
      // Inline function 'kotlinx.coroutines.assert' call
      tmp_2 = segment;
    }
    tmp_0 = tmp_2;
  }
  return tmp_0;
}
function findSegmentBufferEnd($this, id, startFrom, currentBufferEndCounter) {
  // Inline function 'kotlin.let' call
  var tmp$ret$1;
  $l$block_2: {
    // Inline function 'kotlinx.coroutines.internal.findSegmentAndMoveForward' call
    var this_0 = $this.nz_1;
    var createNewSegment = createSegmentFunction();
    while (true) {
      var s = findSegmentInternal(startFrom, id, createNewSegment);
      var tmp;
      if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(s)) {
        tmp = true;
      } else {
        var tmp$ret$0;
        $l$block_1: {
          // Inline function 'kotlinx.coroutines.internal.moveForward' call
          var to = _SegmentOrClosed___get_segment__impl__jvcr9l(s);
          while (true) {
            // Inline function 'kotlinx.coroutines.internal.moveForward.<anonymous>' call
            var cur = this_0.kotlinx$atomicfu$value;
            if (cur.js_1.o6(to.js_1) >= 0) {
              tmp$ret$0 = true;
              break $l$block_1;
            }
            if (!to.vz()) {
              tmp$ret$0 = false;
              break $l$block_1;
            }
            if (this_0.atomicfu$compareAndSet(cur, to)) {
              if (cur.wz()) {
                cur.y();
              }
              tmp$ret$0 = true;
              break $l$block_1;
            }
            if (to.wz()) {
              to.y();
            }
          }
          tmp$ret$0 = Unit_instance;
        }
        tmp = tmp$ret$0;
      }
      if (tmp) {
        tmp$ret$1 = s;
        break $l$block_2;
      }
    }
  }
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.channels.BufferedChannel.findSegmentBufferEnd.<anonymous>' call
  var it = tmp$ret$1;
  var tmp_0;
  if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(it)) {
    completeCloseOrCancel($this);
    moveSegmentBufferEndToSpecifiedOrLast($this, id, startFrom);
    incCompletedExpandBufferAttempts$default($this);
    tmp_0 = null;
  } else {
    var segment = _SegmentOrClosed___get_segment__impl__jvcr9l(it);
    var tmp_1;
    if (segment.js_1.o6(id) > 0) {
      // Inline function 'kotlin.Long.plus' call
      var tmp_2 = currentBufferEndCounter.lb(toLong(1));
      // Inline function 'kotlin.Long.times' call
      var this_1 = segment.js_1;
      var other = get_SEGMENT_SIZE();
      var tmp$ret$3 = this_1.da(toLong(other));
      if ($this.jz_1.atomicfu$compareAndSet(tmp_2, tmp$ret$3)) {
        // Inline function 'kotlin.Long.times' call
        var this_2 = segment.js_1;
        var other_0 = get_SEGMENT_SIZE();
        var tmp$ret$4 = this_2.da(toLong(other_0));
        incCompletedExpandBufferAttempts($this, tmp$ret$4.mb(currentBufferEndCounter));
      } else {
        incCompletedExpandBufferAttempts$default($this);
      }
      tmp_1 = null;
    } else {
      // Inline function 'kotlinx.coroutines.assert' call
      tmp_1 = segment;
    }
    tmp_0 = tmp_1;
  }
  return tmp_0;
}
function moveSegmentBufferEndToSpecifiedOrLast($this, id, startFrom) {
  var segment = startFrom;
  $l$loop: while (segment.js_1.o6(id) < 0) {
    var tmp0_elvis_lhs = segment.zz();
    var tmp;
    if (tmp0_elvis_lhs == null) {
      break $l$loop;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    segment = tmp;
  }
  while (true) {
    $l$loop_0: while (segment.uz()) {
      var tmp1_elvis_lhs = segment.zz();
      var tmp_0;
      if (tmp1_elvis_lhs == null) {
        break $l$loop_0;
      } else {
        tmp_0 = tmp1_elvis_lhs;
      }
      segment = tmp_0;
    }
    var tmp$ret$0;
    $l$block_1: {
      // Inline function 'kotlinx.coroutines.internal.moveForward' call
      var this_0 = $this.nz_1;
      var to = segment;
      while (true) {
        // Inline function 'kotlinx.coroutines.internal.moveForward.<anonymous>' call
        var cur = this_0.kotlinx$atomicfu$value;
        if (cur.js_1.o6(to.js_1) >= 0) {
          tmp$ret$0 = true;
          break $l$block_1;
        }
        if (!to.vz()) {
          tmp$ret$0 = false;
          break $l$block_1;
        }
        if (this_0.atomicfu$compareAndSet(cur, to)) {
          if (cur.wz()) {
            cur.y();
          }
          tmp$ret$0 = true;
          break $l$block_1;
        }
        if (to.wz()) {
          to.y();
        }
      }
      tmp$ret$0 = Unit_instance;
    }
    if (tmp$ret$0)
      return Unit_instance;
  }
}
function updateSendersCounterIfLower($this, value) {
  var this_0 = $this.hz_1;
  while (true) {
    // Inline function 'kotlinx.coroutines.channels.BufferedChannel.updateSendersCounterIfLower.<anonymous>' call
    var cur = this_0.kotlinx$atomicfu$value;
    // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
    var curCounter = cur.wb(new Long(-1, 268435455));
    if (curCounter.o6(value) >= 0)
      return Unit_instance;
    // Inline function 'kotlinx.coroutines.channels.sendersCloseStatus' call
    var tmp$ret$1 = cur.ub(60).ra();
    var update = constructSendersAndCloseStatus(curCounter, tmp$ret$1);
    if ($this.hz_1.atomicfu$compareAndSet(cur, update))
      return Unit_instance;
  }
  return Unit_instance;
}
function updateReceiversCounterIfLower($this, value) {
  var this_0 = $this.iz_1;
  while (true) {
    // Inline function 'kotlinx.coroutines.channels.BufferedChannel.updateReceiversCounterIfLower.<anonymous>' call
    var cur = this_0.kotlinx$atomicfu$value;
    if (cur.o6(value) >= 0)
      return Unit_instance;
    if ($this.iz_1.atomicfu$compareAndSet(cur, value))
      return Unit_instance;
  }
  return Unit_instance;
}
function BufferedChannel$onUndeliveredElementReceiveCancellationConstructor$lambda$lambda($element, this$0, $select) {
  return function (it) {
    var tmp;
    if (!($element === get_CHANNEL_CLOSED())) {
      callUndeliveredElement(this$0.gz_1, ($element == null ? true : !($element == null)) ? $element : THROW_CCE(), $select.i6());
      tmp = Unit_instance;
    }
    return Unit_instance;
  };
}
function BufferedChannel$onUndeliveredElementReceiveCancellationConstructor$lambda(this$0) {
  return function (select, _anonymous_parameter_1__qggqgd, element) {
    return BufferedChannel$onUndeliveredElementReceiveCancellationConstructor$lambda$lambda(element, this$0, select);
  };
}
function BufferedChannel(capacity, onUndeliveredElement) {
  onUndeliveredElement = onUndeliveredElement === VOID ? null : onUndeliveredElement;
  this.fz_1 = capacity;
  this.gz_1 = onUndeliveredElement;
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(this.fz_1 >= 0)) {
    // Inline function 'kotlinx.coroutines.channels.BufferedChannel.<anonymous>' call
    var message = 'Invalid channel capacity: ' + this.fz_1 + ', should be >=0';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  this.hz_1 = atomic$long$1(new Long(0, 0));
  this.iz_1 = atomic$long$1(new Long(0, 0));
  this.jz_1 = atomic$long$1(initialBufferEnd(this.fz_1));
  this.kz_1 = atomic$long$1(_get_bufferEndCounter__2d4hee(this));
  var firstSegment = new ChannelSegment(new Long(0, 0), null, this, 3);
  this.lz_1 = atomic$ref$1(firstSegment);
  this.mz_1 = atomic$ref$1(firstSegment);
  var tmp = this;
  var tmp_0;
  if (_get_isRendezvousOrUnlimited__3mdufi(this)) {
    var tmp_1 = get_NULL_SEGMENT();
    tmp_0 = tmp_1 instanceof ChannelSegment ? tmp_1 : THROW_CCE();
  } else {
    tmp_0 = firstSegment;
  }
  tmp.nz_1 = atomic$ref$1(tmp_0);
  var tmp_2 = this;
  var tmp_3;
  if (this.gz_1 == null) {
    tmp_3 = null;
  } else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.coroutines.channels.BufferedChannel.onUndeliveredElementReceiveCancellationConstructor.<anonymous>' call
    tmp_3 = BufferedChannel$onUndeliveredElementReceiveCancellationConstructor$lambda(this);
  }
  tmp_2.oz_1 = tmp_3;
  this.pz_1 = atomic$ref$1(get_NO_CLOSE_CAUSE());
  this.qz_1 = atomic$ref$1(null);
}
protoOf(BufferedChannel).j10 = function () {
  // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
  return this.hz_1.kotlinx$atomicfu$value.wb(new Long(-1, 268435455));
};
protoOf(BufferedChannel).k11 = function () {
  return this.iz_1.kotlinx$atomicfu$value;
};
protoOf(BufferedChannel).f12 = function (element) {
  if (shouldSendSuspend(this, this.hz_1.kotlinx$atomicfu$value))
    return Companion_getInstance_0().g12();
  var tmp$ret$4;
  $l$block_5: {
    // Inline function 'kotlinx.coroutines.channels.BufferedChannel.sendImpl' call
    var waiter = get_INTERRUPTED_SEND();
    var segment = this.lz_1.kotlinx$atomicfu$value;
    $l$loop_0: while (true) {
      var sendersAndCloseStatusCur = this.hz_1.atomicfu$getAndIncrement$long();
      // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
      var s = sendersAndCloseStatusCur.wb(new Long(-1, 268435455));
      var closed = _get_isClosedForSend0__kxgf9m(sendersAndCloseStatusCur, this);
      // Inline function 'kotlin.Long.div' call
      var other = get_SEGMENT_SIZE();
      var id = s.ca(toLong(other));
      // Inline function 'kotlin.Long.rem' call
      var other_0 = get_SEGMENT_SIZE();
      var i = s.nb(toLong(other_0)).ra();
      if (!segment.js_1.equals(id)) {
        var tmp0_elvis_lhs = findSegmentSend(this, id, segment);
        var tmp;
        if (tmp0_elvis_lhs == null) {
          var tmp_0;
          if (closed) {
            // Inline function 'kotlinx.coroutines.channels.BufferedChannel.trySend.<anonymous>' call
            tmp$ret$4 = Companion_getInstance_0().b12(this.c12());
            break $l$block_5;
          } else {
            continue $l$loop_0;
          }
        } else {
          tmp = tmp0_elvis_lhs;
        }
        segment = tmp;
      }
      var tmp1_subject = updateCellSend(this, segment, i, element, s, waiter, closed);
      if (tmp1_subject === _get_RESULT_RENDEZVOUS_$accessor$yt74tm_3irwt8()) {
        segment.d10();
        // Inline function 'kotlinx.coroutines.channels.BufferedChannel.trySend.<anonymous>' call
        tmp$ret$4 = Companion_getInstance_0().n11(Unit_instance);
        break $l$block_5;
      } else if (tmp1_subject === _get_RESULT_BUFFERED_$accessor$yt74tm_quor5m()) {
        // Inline function 'kotlinx.coroutines.channels.BufferedChannel.trySend.<anonymous>' call
        tmp$ret$4 = Companion_getInstance_0().n11(Unit_instance);
        break $l$block_5;
      } else if (tmp1_subject === _get_RESULT_SUSPEND_$accessor$yt74tm_cjypnf()) {
        if (closed) {
          segment.tz();
          // Inline function 'kotlinx.coroutines.channels.BufferedChannel.trySend.<anonymous>' call
          tmp$ret$4 = Companion_getInstance_0().b12(this.c12());
          break $l$block_5;
        }
        var tmp2_safe_receiver = (!(waiter == null) ? isInterface(waiter, Waiter) : false) ? waiter : null;
        if (tmp2_safe_receiver == null)
          null;
        else {
          prepareSenderForSuspension(tmp2_safe_receiver, this, segment, i);
        }
        // Inline function 'kotlinx.coroutines.channels.BufferedChannel.trySend.<anonymous>' call
        segment.tz();
        tmp$ret$4 = Companion_getInstance_0().g12();
        break $l$block_5;
      } else if (tmp1_subject === _get_RESULT_CLOSED_$accessor$yt74tm_10v48j()) {
        if (s.o6(this.k11()) < 0) {
          segment.d10();
        }
        // Inline function 'kotlinx.coroutines.channels.BufferedChannel.trySend.<anonymous>' call
        tmp$ret$4 = Companion_getInstance_0().b12(this.c12());
        break $l$block_5;
      } else if (tmp1_subject === _get_RESULT_FAILED_$accessor$yt74tm_vo1zj0()) {
        segment.d10();
        continue $l$loop_0;
      } else if (tmp1_subject === _get_RESULT_SUSPEND_NO_WAITER_$accessor$yt74tm_cvzv8m()) {
        // Inline function 'kotlinx.coroutines.channels.BufferedChannel.sendImpl.<anonymous>' call
        var message = 'unexpected';
        throw IllegalStateException_init_$Create$(toString(message));
      }
    }
  }
  return tmp$ret$4;
};
protoOf(BufferedChannel).q11 = function () {
};
protoOf(BufferedChannel).i11 = function () {
};
protoOf(BufferedChannel).z11 = function (globalCellIndex) {
  // Inline function 'kotlinx.coroutines.assert' call
  var segment = this.mz_1.kotlinx$atomicfu$value;
  $l$loop_0: while (true) {
    var r = this.iz_1.kotlinx$atomicfu$value;
    // Inline function 'kotlin.math.max' call
    // Inline function 'kotlin.Long.plus' call
    var other = this.fz_1;
    var a = r.lb(toLong(other));
    var b = _get_bufferEndCounter__2d4hee(this);
    var tmp$ret$1 = a.o6(b) >= 0 ? a : b;
    if (globalCellIndex.o6(tmp$ret$1) < 0)
      return Unit_instance;
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$2 = r.lb(toLong(1));
    if (!this.iz_1.atomicfu$compareAndSet(r, tmp$ret$2))
      continue $l$loop_0;
    // Inline function 'kotlin.Long.div' call
    var other_0 = get_SEGMENT_SIZE();
    var id = r.ca(toLong(other_0));
    // Inline function 'kotlin.Long.rem' call
    var other_1 = get_SEGMENT_SIZE();
    var i = r.nb(toLong(other_1)).ra();
    if (!segment.js_1.equals(id)) {
      var tmp0_elvis_lhs = findSegmentReceive(this, id, segment);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        continue $l$loop_0;
      } else {
        tmp = tmp0_elvis_lhs;
      }
      segment = tmp;
    }
    var updCellResult = updateCellReceive(this, segment, i, r, null);
    if (updCellResult === _get_FAILED_$accessor$yt74tm_h47uk8()) {
      if (r.o6(this.j10()) < 0) {
        segment.d10();
      }
    } else {
      segment.d10();
      var tmp1_safe_receiver = this.gz_1;
      var tmp_0;
      if (tmp1_safe_receiver == null) {
        tmp_0 = null;
      } else {
        tmp_0 = callUndeliveredElementCatchingException(tmp1_safe_receiver, (updCellResult == null ? true : !(updCellResult == null)) ? updCellResult : THROW_CCE());
      }
      var tmp2_safe_receiver = tmp_0;
      if (tmp2_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        // Inline function 'kotlin.contracts.contract' call
        throw tmp2_safe_receiver;
      }
    }
  }
};
protoOf(BufferedChannel).sz = function (globalIndex) {
  if (_get_isRendezvousOrUnlimited__3mdufi(this))
    return Unit_instance;
  while (_get_bufferEndCounter__2d4hee(this).o6(globalIndex) <= 0) {
  }
  // Inline function 'kotlin.repeat' call
  var times = get_EXPAND_BUFFER_COMPLETION_WAIT_ITERATIONS();
  // Inline function 'kotlin.contracts.contract' call
  var inductionVariable = 0;
  if (inductionVariable < times)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlinx.coroutines.channels.BufferedChannel.waitExpandBufferCompletion.<anonymous>' call
      var b = _get_bufferEndCounter__2d4hee(this);
      // Inline function 'kotlinx.coroutines.channels.ebCompletedCounter' call
      var ebCompleted = this.kz_1.kotlinx$atomicfu$value.wb(new Long(-1, 1073741823));
      if (b.equals(ebCompleted) ? b.equals(_get_bufferEndCounter__2d4hee(this)) : false)
        return Unit_instance;
    }
     while (inductionVariable < times);
  $l$block: {
    // Inline function 'kotlinx.atomicfu.update' call
    var this_0 = this.kz_1;
    while (true) {
      var cur = this_0.kotlinx$atomicfu$value;
      // Inline function 'kotlinx.coroutines.channels.BufferedChannel.waitExpandBufferCompletion.<anonymous>' call
      // Inline function 'kotlinx.coroutines.channels.ebCompletedCounter' call
      var tmp$ret$1 = cur.wb(new Long(-1, 1073741823));
      var upd = constructEBCompletedAndPauseFlag(tmp$ret$1, true);
      if (this_0.atomicfu$compareAndSet(cur, upd)) {
        break $l$block;
      }
    }
  }
  while (true) {
    var b_0 = _get_bufferEndCounter__2d4hee(this);
    var ebCompletedAndBit = this.kz_1.kotlinx$atomicfu$value;
    // Inline function 'kotlinx.coroutines.channels.ebCompletedCounter' call
    var ebCompleted_0 = ebCompletedAndBit.wb(new Long(-1, 1073741823));
    // Inline function 'kotlinx.coroutines.channels.ebPauseExpandBuffers' call
    var pauseExpandBuffers = !ebCompletedAndBit.wb(new Long(0, 1073741824)).equals(new Long(0, 0));
    if (b_0.equals(ebCompleted_0) ? b_0.equals(_get_bufferEndCounter__2d4hee(this)) : false) {
      $l$block_0: {
        // Inline function 'kotlinx.atomicfu.update' call
        var this_1 = this.kz_1;
        while (true) {
          var cur_0 = this_1.kotlinx$atomicfu$value;
          // Inline function 'kotlinx.coroutines.channels.BufferedChannel.waitExpandBufferCompletion.<anonymous>' call
          // Inline function 'kotlinx.coroutines.channels.ebCompletedCounter' call
          var tmp$ret$6 = cur_0.wb(new Long(-1, 1073741823));
          var upd_0 = constructEBCompletedAndPauseFlag(tmp$ret$6, false);
          if (this_1.atomicfu$compareAndSet(cur_0, upd_0)) {
            break $l$block_0;
          }
        }
      }
      return Unit_instance;
    }
    if (!pauseExpandBuffers) {
      this.kz_1.atomicfu$compareAndSet(ebCompletedAndBit, constructEBCompletedAndPauseFlag(ebCompleted_0, true));
    }
  }
};
protoOf(BufferedChannel).u = function () {
  return new BufferedChannelIterator(this);
};
protoOf(BufferedChannel).i10 = function () {
  var tmp = this.pz_1.kotlinx$atomicfu$value;
  return (tmp == null ? true : tmp instanceof Error) ? tmp : THROW_CCE();
};
protoOf(BufferedChannel).c12 = function () {
  var tmp0_elvis_lhs = this.i10();
  return tmp0_elvis_lhs == null ? new ClosedSendChannelException(get_DEFAULT_CLOSE_MESSAGE()) : tmp0_elvis_lhs;
};
protoOf(BufferedChannel).h12 = function () {
};
protoOf(BufferedChannel).i12 = function (cause) {
  return this.j12(cause, false);
};
protoOf(BufferedChannel).bo = function (cause) {
  this.l12(cause);
};
protoOf(BufferedChannel).l12 = function (cause) {
  return this.j12(cause == null ? CancellationException_init_$Create$('Channel was cancelled') : cause, true);
};
protoOf(BufferedChannel).j12 = function (cause, cancel) {
  if (cancel) {
    markCancellationStarted(this);
  }
  var closedByThisOperation = this.pz_1.atomicfu$compareAndSet(get_NO_CLOSE_CAUSE(), cause);
  if (cancel) {
    markCancelled(this);
  } else {
    markClosed(this);
  }
  completeCloseOrCancel(this);
  // Inline function 'kotlin.also' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.channels.BufferedChannel.closeOrCancelImpl.<anonymous>' call
  this.h12();
  if (closedByThisOperation) {
    invokeCloseHandler(this);
  }
  return closedByThisOperation;
};
protoOf(BufferedChannel).a12 = function () {
  return false;
};
protoOf(BufferedChannel).y11 = function () {
  return _get_isClosedForSend0__kxgf9m(this.hz_1.kotlinx$atomicfu$value, this);
};
protoOf(BufferedChannel).k10 = function () {
  return _get_isClosedForReceive0__f7qknl(this.hz_1.kotlinx$atomicfu$value, this);
};
protoOf(BufferedChannel).d12 = function () {
  $l$loop: while (true) {
    var segment = this.mz_1.kotlinx$atomicfu$value;
    var r = this.k11();
    var s = this.j10();
    if (s.o6(r) <= 0)
      return false;
    // Inline function 'kotlin.Long.div' call
    var other = get_SEGMENT_SIZE();
    var id = r.ca(toLong(other));
    if (!segment.js_1.equals(id)) {
      var tmp0_elvis_lhs = findSegmentReceive(this, id, segment);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        var tmp_0;
        if (this.mz_1.kotlinx$atomicfu$value.js_1.o6(id) < 0) {
          return false;
        } else {
          continue $l$loop;
        }
      } else {
        tmp = tmp0_elvis_lhs;
      }
      segment = tmp;
    }
    segment.d10();
    // Inline function 'kotlin.Long.rem' call
    var other_0 = get_SEGMENT_SIZE();
    var i = r.nb(toLong(other_0)).ra();
    if (isCellNonEmpty(this, segment, i, r))
      return true;
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$2 = r.lb(toLong(1));
    this.iz_1.atomicfu$compareAndSet(r, tmp$ret$2);
  }
};
protoOf(BufferedChannel).toString = function () {
  var sb = StringBuilder_init_$Create$();
  // Inline function 'kotlinx.coroutines.channels.sendersCloseStatus' call
  var tmp0_subject = this.hz_1.kotlinx$atomicfu$value.ub(60).ra();
  if (tmp0_subject === 2) {
    sb.n5('closed,');
  } else if (tmp0_subject === 3) {
    sb.n5('cancelled,');
  }
  sb.n5('capacity=' + this.fz_1 + ',');
  sb.n5('data=[');
  var tmp$ret$4;
  $l$block: {
    // Inline function 'kotlin.collections.minBy' call
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var this_0 = listOf([this.mz_1.kotlinx$atomicfu$value, this.lz_1.kotlinx$atomicfu$value, this.nz_1.kotlinx$atomicfu$value]);
    var destination = ArrayList_init_$Create$_0();
    var tmp0_iterator = this_0.u();
    while (tmp0_iterator.v()) {
      var element = tmp0_iterator.w();
      // Inline function 'kotlinx.coroutines.channels.BufferedChannel.toString.<anonymous>' call
      if (!(element === get_NULL_SEGMENT())) {
        destination.r(element);
      }
    }
    var iterator = destination.u();
    if (!iterator.v())
      throw NoSuchElementException_init_$Create$();
    var minElem = iterator.w();
    if (!iterator.v()) {
      tmp$ret$4 = minElem;
      break $l$block;
    }
    // Inline function 'kotlinx.coroutines.channels.BufferedChannel.toString.<anonymous>' call
    var minValue = minElem.js_1;
    do {
      var e = iterator.w();
      // Inline function 'kotlinx.coroutines.channels.BufferedChannel.toString.<anonymous>' call
      var v = e.js_1;
      if (compareTo(minValue, v) > 0) {
        minElem = e;
        minValue = v;
      }
    }
     while (iterator.v());
    tmp$ret$4 = minElem;
  }
  var firstSegment = tmp$ret$4;
  var r = this.k11();
  var s = this.j10();
  var segment = firstSegment;
  append_elements: while (true) {
    var inductionVariable = 0;
    var last_0 = get_SEGMENT_SIZE();
    if (inductionVariable < last_0)
      process_cell: do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.plus' call
        // Inline function 'kotlin.Long.times' call
        var this_1 = segment.js_1;
        var other = get_SEGMENT_SIZE();
        var globalCellIndex = this_1.da(toLong(other)).lb(toLong(i));
        if (globalCellIndex.o6(s) >= 0 ? globalCellIndex.o6(r) >= 0 : false)
          break append_elements;
        var cellState = segment.bz(i);
        var element_0 = segment.yy(i);
        var tmp;
        if (!(cellState == null) ? isInterface(cellState, CancellableContinuation) : false) {
          tmp = (globalCellIndex.o6(r) < 0 ? globalCellIndex.o6(s) >= 0 : false) ? 'receive' : (globalCellIndex.o6(s) < 0 ? globalCellIndex.o6(r) >= 0 : false) ? 'send' : 'cont';
        } else {
          if (!(cellState == null) ? isInterface(cellState, SelectInstance) : false) {
            tmp = (globalCellIndex.o6(r) < 0 ? globalCellIndex.o6(s) >= 0 : false) ? 'onReceive' : (globalCellIndex.o6(s) < 0 ? globalCellIndex.o6(r) >= 0 : false) ? 'onSend' : 'select';
          } else {
            if (cellState instanceof ReceiveCatching) {
              tmp = 'receiveCatching';
            } else {
              if (cellState instanceof SendBroadcast) {
                tmp = 'sendBroadcast';
              } else {
                if (cellState instanceof WaiterEB) {
                  tmp = 'EB(' + toString_0(cellState) + ')';
                } else {
                  if (equals(cellState, get_RESUMING_BY_RCV()) ? true : equals(cellState, get_RESUMING_BY_EB())) {
                    tmp = 'resuming_sender';
                  } else {
                    if ((((((cellState == null ? true : equals(cellState, get_IN_BUFFER())) ? true : equals(cellState, get_DONE_RCV())) ? true : equals(cellState, get_POISONED())) ? true : equals(cellState, get_INTERRUPTED_RCV())) ? true : equals(cellState, get_INTERRUPTED_SEND())) ? true : equals(cellState, get_CHANNEL_CLOSED())) {
                      continue process_cell;
                    } else {
                      tmp = toString(cellState);
                    }
                  }
                }
              }
            }
          }
        }
        var cellStateString = tmp;
        if (!(element_0 == null)) {
          sb.n5('(' + cellStateString + ',' + element_0 + '),');
        } else {
          sb.n5(cellStateString + ',');
        }
      }
       while (inductionVariable < last_0);
    var tmp3_elvis_lhs = segment.zz();
    var tmp_0;
    if (tmp3_elvis_lhs == null) {
      break append_elements;
    } else {
      tmp_0 = tmp3_elvis_lhs;
    }
    segment = tmp_0;
  }
  if (last(sb) === _Char___init__impl__6a9atx(44)) {
    sb.m8(sb.a() - 1 | 0);
  }
  sb.n5(']');
  return sb.toString();
};
function WaiterEB(waiter) {
  this.j11_1 = waiter;
}
protoOf(WaiterEB).toString = function () {
  return 'WaiterEB(' + this.j11_1 + ')';
};
function initialBufferEnd(capacity) {
  _init_properties_BufferedChannel_kt__d6uc4y();
  var tmp;
  Factory_getInstance();
  if (capacity === 0) {
    tmp = new Long(0, 0);
  } else {
    Factory_getInstance();
    if (capacity === 2147483647) {
      tmp = new Long(-1, 2147483647);
    } else {
      tmp = toLong(capacity);
    }
  }
  return tmp;
}
function ReceiveCatching() {
}
function tryResume0(_this__u8e3s4, value, onCancellation) {
  onCancellation = onCancellation === VOID ? null : onCancellation;
  _init_properties_BufferedChannel_kt__d6uc4y();
  // Inline function 'kotlin.let' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.channels.tryResume0.<anonymous>' call
  var token = _this__u8e3s4.sr(value, null, onCancellation);
  var tmp;
  if (!(token == null)) {
    _this__u8e3s4.up(token);
    tmp = true;
  } else {
    tmp = false;
  }
  return tmp;
}
function constructEBCompletedAndPauseFlag(counter, pauseEB) {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return (pauseEB ? new Long(0, 1073741824) : new Long(0, 0)).lb(counter);
}
function constructSendersAndCloseStatus(counter, closeStatus) {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return toLong(closeStatus).tb(60).lb(counter);
}
function createSegmentFunction() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return createSegment$ref();
}
function get_SENDERS_COUNTER_MASK() {
  return SENDERS_COUNTER_MASK;
}
var SENDERS_COUNTER_MASK;
function createSegment(id, prev) {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return new ChannelSegment(id, prev, prev.vy(), 0);
}
function _get_RESULT_SUSPEND_NO_WAITER_$accessor$yt74tm_cvzv8m() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return 3;
}
function _get_RESULT_RENDEZVOUS_$accessor$yt74tm_3irwt8() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return 0;
}
function _get_RESULT_BUFFERED_$accessor$yt74tm_quor5m() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return 1;
}
function _get_RESULT_SUSPEND_$accessor$yt74tm_cjypnf() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return 2;
}
function _get_RESULT_CLOSED_$accessor$yt74tm_10v48j() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return 4;
}
function _get_RESULT_FAILED_$accessor$yt74tm_vo1zj0() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return 5;
}
function _get_SUSPEND_NO_WAITER_$accessor$yt74tm_n6n1ky() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return get_SUSPEND_NO_WAITER();
}
function _get_SUSPEND_$accessor$yt74tm_ccb8g1() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return get_SUSPEND();
}
function _get_FAILED_$accessor$yt74tm_h47uk8() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return get_FAILED();
}
function createSegment$ref() {
  var l = function (p0, p1) {
    return createSegment(p0, p1);
  };
  l.callableName = 'createSegment';
  return l;
}
var properties_initialized_BufferedChannel_kt_58tjvw;
function _init_properties_BufferedChannel_kt__d6uc4y() {
  if (!properties_initialized_BufferedChannel_kt_58tjvw) {
    properties_initialized_BufferedChannel_kt_58tjvw = true;
    NULL_SEGMENT = new ChannelSegment(new Long(-1, -1), null, null, 0);
    SEGMENT_SIZE = systemProp('kotlinx.coroutines.bufferedChannel.segmentSize', 32);
    EXPAND_BUFFER_COMPLETION_WAIT_ITERATIONS = systemProp('kotlinx.coroutines.bufferedChannel.expandBufferCompletionWaitIterations', 10000);
    BUFFERED = new Symbol('BUFFERED');
    IN_BUFFER = new Symbol('SHOULD_BUFFER');
    RESUMING_BY_RCV = new Symbol('S_RESUMING_BY_RCV');
    RESUMING_BY_EB = new Symbol('RESUMING_BY_EB');
    POISONED = new Symbol('POISONED');
    DONE_RCV = new Symbol('DONE_RCV');
    INTERRUPTED_SEND = new Symbol('INTERRUPTED_SEND');
    INTERRUPTED_RCV = new Symbol('INTERRUPTED_RCV');
    CHANNEL_CLOSED = new Symbol('CHANNEL_CLOSED');
    SUSPEND = new Symbol('SUSPEND');
    SUSPEND_NO_WAITER = new Symbol('SUSPEND_NO_WAITER');
    FAILED = new Symbol('FAILED');
    NO_RECEIVE_RESULT = new Symbol('NO_RECEIVE_RESULT');
    CLOSE_HANDLER_CLOSED = new Symbol('CLOSE_HANDLER_CLOSED');
    CLOSE_HANDLER_INVOKED = new Symbol('CLOSE_HANDLER_INVOKED');
    NO_CLOSE_CAUSE = new Symbol('NO_CLOSE_CAUSE');
  }
}
function Factory() {
  Factory_instance = this;
  this.n12_1 = 2147483647;
  this.o12_1 = 0;
  this.p12_1 = -1;
  this.q12_1 = -2;
  this.r12_1 = -3;
  this.s12_1 = 'kotlinx.coroutines.channels.defaultBuffer';
  this.t12_1 = systemProp('kotlinx.coroutines.channels.defaultBuffer', 64, 1, 2147483646);
}
var Factory_instance;
function Factory_getInstance() {
  if (Factory_instance == null)
    new Factory();
  return Factory_instance;
}
function _ChannelResult___init__impl__siwsuf(holder) {
  return holder;
}
function _ChannelResult___get_holder__impl__pm9gzw($this) {
  return $this;
}
function _ChannelResult___get_isSuccess__impl__odq1z9($this) {
  var tmp = _ChannelResult___get_holder__impl__pm9gzw($this);
  return !(tmp instanceof Failed);
}
function _ChannelResult___get_isClosed__impl__mg7kuu($this) {
  var tmp = _ChannelResult___get_holder__impl__pm9gzw($this);
  return tmp instanceof Closed;
}
function Failed() {
}
protoOf(Failed).toString = function () {
  return 'Failed';
};
function Closed(cause) {
  Failed.call(this);
  this.u12_1 = cause;
}
protoOf(Closed).equals = function (other) {
  var tmp;
  if (other instanceof Closed) {
    tmp = equals(this.u12_1, other.u12_1);
  } else {
    tmp = false;
  }
  return tmp;
};
protoOf(Closed).hashCode = function () {
  // Inline function 'kotlin.hashCode' call
  var tmp0_safe_receiver = this.u12_1;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
  return tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
};
protoOf(Closed).toString = function () {
  return 'Closed(' + this.u12_1 + ')';
};
function Companion() {
  Companion_instance_0 = this;
  this.m11_1 = new Failed();
}
protoOf(Companion).n11 = function (value) {
  return _ChannelResult___init__impl__siwsuf(value);
};
protoOf(Companion).g12 = function () {
  return _ChannelResult___init__impl__siwsuf(this.m11_1);
};
protoOf(Companion).b12 = function (cause) {
  return _ChannelResult___init__impl__siwsuf(new Closed(cause));
};
var Companion_instance_0;
function Companion_getInstance_0() {
  if (Companion_instance_0 == null)
    new Companion();
  return Companion_instance_0;
}
function ChannelResult__toString_impl_rrcqu7($this) {
  var tmp;
  if (_ChannelResult___get_holder__impl__pm9gzw($this) instanceof Closed) {
    tmp = toString(_ChannelResult___get_holder__impl__pm9gzw($this));
  } else {
    tmp = 'Value(' + toString_0(_ChannelResult___get_holder__impl__pm9gzw($this)) + ')';
  }
  return tmp;
}
function ChannelResult__hashCode_impl_lilec2($this) {
  return $this == null ? 0 : hashCode($this);
}
function ChannelResult__equals_impl_f471ri($this, other) {
  if (!(other instanceof ChannelResult))
    return false;
  var tmp0_other_with_cast = other instanceof ChannelResult ? other.v12_1 : THROW_CCE();
  if (!equals($this, tmp0_other_with_cast))
    return false;
  return true;
}
function ChannelResult(holder) {
  Companion_getInstance_0();
  this.v12_1 = holder;
}
protoOf(ChannelResult).toString = function () {
  return ChannelResult__toString_impl_rrcqu7(this.v12_1);
};
protoOf(ChannelResult).hashCode = function () {
  return ChannelResult__hashCode_impl_lilec2(this.v12_1);
};
protoOf(ChannelResult).equals = function (other) {
  return ChannelResult__equals_impl_f471ri(this.v12_1, other);
};
function ClosedSendChannelException(message) {
  IllegalStateException_init_$Init$(message, this);
  captureStack(this, ClosedSendChannelException);
}
function ClosedReceiveChannelException(message) {
  NoSuchElementException_init_$Init$(message, this);
  captureStack(this, ClosedReceiveChannelException);
}
function SendChannel() {
}
function ReceiveChannel() {
}
function Channel(capacity, onBufferOverflow, onUndeliveredElement) {
  capacity = capacity === VOID ? 0 : capacity;
  onBufferOverflow = onBufferOverflow === VOID ? BufferOverflow_SUSPEND_getInstance() : onBufferOverflow;
  onUndeliveredElement = onUndeliveredElement === VOID ? null : onUndeliveredElement;
  var tmp;
  switch (capacity) {
    case 0:
      tmp = onBufferOverflow.equals(BufferOverflow_SUSPEND_getInstance()) ? new BufferedChannel(0, onUndeliveredElement) : new ConflatedBufferedChannel(1, onBufferOverflow, onUndeliveredElement);
      break;
    case -1:
      // Inline function 'kotlin.require' call

      // Inline function 'kotlin.contracts.contract' call

      if (!onBufferOverflow.equals(BufferOverflow_SUSPEND_getInstance())) {
        // Inline function 'kotlinx.coroutines.channels.Channel.<anonymous>' call
        var message = 'CONFLATED capacity cannot be used with non-default onBufferOverflow';
        throw IllegalArgumentException_init_$Create$(toString(message));
      }

      tmp = new ConflatedBufferedChannel(1, BufferOverflow_DROP_OLDEST_getInstance(), onUndeliveredElement);
      break;
    case 2147483647:
      tmp = new BufferedChannel(2147483647, onUndeliveredElement);
      break;
    case -2:
      tmp = onBufferOverflow.equals(BufferOverflow_SUSPEND_getInstance()) ? new BufferedChannel(Factory_getInstance().t12_1, onUndeliveredElement) : new ConflatedBufferedChannel(1, onBufferOverflow, onUndeliveredElement);
      break;
    default:
      tmp = onBufferOverflow === BufferOverflow_SUSPEND_getInstance() ? new BufferedChannel(capacity, onUndeliveredElement) : new ConflatedBufferedChannel(capacity, onBufferOverflow, onUndeliveredElement);
      break;
  }
  return tmp;
}
function get_DEFAULT_CLOSE_MESSAGE() {
  return DEFAULT_CLOSE_MESSAGE;
}
var DEFAULT_CLOSE_MESSAGE;
function cancelConsumed(_this__u8e3s4, cause) {
  var tmp;
  if (cause == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.coroutines.channels.cancelConsumed.<anonymous>' call
    var tmp0_elvis_lhs = cause instanceof CancellationException ? cause : null;
    tmp = tmp0_elvis_lhs == null ? CancellationException_init_$Create$_0('Channel was consumed, consumer had failed', cause) : tmp0_elvis_lhs;
  }
  _this__u8e3s4.bo(tmp);
}
function trySendImpl($this, element, isSendOp) {
  return $this.j13_1 === BufferOverflow_DROP_LATEST_getInstance() ? trySendDropLatest($this, element, isSendOp) : trySendDropOldest($this, element);
}
function trySendDropLatest($this, element, isSendOp) {
  var result = protoOf(BufferedChannel).f12.call($this, element);
  if (_ChannelResult___get_isSuccess__impl__odq1z9(result) ? true : _ChannelResult___get_isClosed__impl__mg7kuu(result))
    return result;
  if (isSendOp) {
    var tmp0_safe_receiver = $this.gz_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : callUndeliveredElementCatchingException(tmp0_safe_receiver, element);
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.contracts.contract' call
      throw tmp1_safe_receiver;
    }
  }
  return Companion_getInstance_0().n11(Unit_instance);
}
function trySendDropOldest($this, element) {
  var tmp$ret$3;
  $l$block: {
    // Inline function 'kotlinx.coroutines.channels.BufferedChannel.sendImpl' call
    var waiter = get_BUFFERED();
    var segment = $this.lz_1.kotlinx$atomicfu$value;
    $l$loop_0: while (true) {
      var sendersAndCloseStatusCur = $this.hz_1.atomicfu$getAndIncrement$long();
      // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
      var s = sendersAndCloseStatusCur.wb(get_SENDERS_COUNTER_MASK());
      var closed = _get_isClosedForSend0__kxgf9m(sendersAndCloseStatusCur, $this);
      // Inline function 'kotlin.Long.div' call
      var other = get_SEGMENT_SIZE();
      var id = s.ca(toLong(other));
      // Inline function 'kotlin.Long.rem' call
      var other_0 = get_SEGMENT_SIZE();
      var i = s.nb(toLong(other_0)).ra();
      if (!segment.js_1.equals(id)) {
        var tmp0_elvis_lhs = findSegmentSend($this, id, segment);
        var tmp;
        if (tmp0_elvis_lhs == null) {
          var tmp_0;
          if (closed) {
            return Companion_getInstance_0().b12($this.c12());
          } else {
            continue $l$loop_0;
          }
        } else {
          tmp = tmp0_elvis_lhs;
        }
        segment = tmp;
      }
      var tmp1_subject = updateCellSend($this, segment, i, element, s, waiter, closed);
      if (tmp1_subject === _get_RESULT_RENDEZVOUS_$accessor$yt74tm_3irwt8()) {
        segment.d10();
        return Companion_getInstance_0().n11(Unit_instance);
      } else if (tmp1_subject === _get_RESULT_BUFFERED_$accessor$yt74tm_quor5m()) {
        return Companion_getInstance_0().n11(Unit_instance);
      } else if (tmp1_subject === _get_RESULT_SUSPEND_$accessor$yt74tm_cjypnf()) {
        if (closed) {
          segment.tz();
          return Companion_getInstance_0().b12($this.c12());
        }
        var tmp2_safe_receiver = (!(waiter == null) ? isInterface(waiter, Waiter) : false) ? waiter : null;
        if (tmp2_safe_receiver == null)
          null;
        else {
          prepareSenderForSuspension(tmp2_safe_receiver, $this, segment, i);
        }
        // Inline function 'kotlin.Long.plus' call
        // Inline function 'kotlin.Long.times' call
        var this_0 = segment.js_1;
        var other_1 = get_SEGMENT_SIZE();
        var tmp$ret$5 = this_0.da(toLong(other_1)).lb(toLong(i));
        $this.z11(tmp$ret$5);
        return Companion_getInstance_0().n11(Unit_instance);
      } else if (tmp1_subject === _get_RESULT_CLOSED_$accessor$yt74tm_10v48j()) {
        if (s.o6($this.k11()) < 0) {
          segment.d10();
        }
        return Companion_getInstance_0().b12($this.c12());
      } else if (tmp1_subject === _get_RESULT_FAILED_$accessor$yt74tm_vo1zj0()) {
        segment.d10();
        continue $l$loop_0;
      } else if (tmp1_subject === _get_RESULT_SUSPEND_NO_WAITER_$accessor$yt74tm_cvzv8m()) {
        // Inline function 'kotlinx.coroutines.channels.BufferedChannel.sendImpl.<anonymous>' call
        var message = 'unexpected';
        throw IllegalStateException_init_$Create$(toString(message));
      }
    }
  }
  return tmp$ret$3;
}
function ConflatedBufferedChannel(capacity, onBufferOverflow, onUndeliveredElement) {
  onUndeliveredElement = onUndeliveredElement === VOID ? null : onUndeliveredElement;
  BufferedChannel.call(this, capacity, onUndeliveredElement);
  this.i13_1 = capacity;
  this.j13_1 = onBufferOverflow;
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!(this.j13_1 === BufferOverflow_SUSPEND_getInstance())) {
    // Inline function 'kotlinx.coroutines.channels.ConflatedBufferedChannel.<anonymous>' call
    var message = 'This implementation does not support suspension for senders, use ' + getKClass(BufferedChannel).s6() + ' instead';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(this.i13_1 >= 1)) {
    // Inline function 'kotlinx.coroutines.channels.ConflatedBufferedChannel.<anonymous>' call
    var message_0 = 'Buffered channel capacity must be at least 1, but ' + this.i13_1 + ' was specified';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
}
protoOf(ConflatedBufferedChannel).a12 = function () {
  return this.j13_1.equals(BufferOverflow_DROP_OLDEST_getInstance());
};
protoOf(ConflatedBufferedChannel).f12 = function (element) {
  return trySendImpl(this, element, false);
};
function asFlow(_this__u8e3s4) {
  // Inline function 'kotlinx.coroutines.flow.internal.unsafeFlow' call
  return new _no_name_provided__qut3iv(_this__u8e3s4);
}
function $collectCOROUTINE$10(_this__u8e3s4, collector, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.s13_1 = _this__u8e3s4;
  this.t13_1 = collector;
}
protoOf($collectCOROUTINE$10).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 4;
          var tmp_0 = this;
          tmp_0.u13_1 = this.t13_1;
          var tmp_1 = this;
          tmp_1.v13_1 = this.s13_1.z13_1;
          this.w13_1 = this.v13_1.u();
          this.ic_1 = 1;
          continue $sm;
        case 1:
          if (!this.w13_1.v()) {
            this.ic_1 = 3;
            continue $sm;
          }

          this.x13_1 = this.w13_1.w();
          var tmp_2 = this;
          tmp_2.y13_1 = this.x13_1;
          this.ic_1 = 2;
          suspendResult = this.u13_1.a14(this.y13_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          this.ic_1 = 1;
          continue $sm;
        case 3:
          return Unit_instance;
        case 4:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 4) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function _no_name_provided__qut3iv($this_asFlow) {
  this.z13_1 = $this_asFlow;
}
protoOf(_no_name_provided__qut3iv).b14 = function (collector, $completion) {
  var tmp = new $collectCOROUTINE$10(this, collector, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
var NO_VALUE;
function _get_head__d7jo8b($this) {
  // Inline function 'kotlin.comparisons.minOf' call
  var a = $this.l14_1;
  var b = $this.k14_1;
  return a.o6(b) <= 0 ? a : b;
}
function _get_replaySize__dxgnb1($this) {
  // Inline function 'kotlin.Long.plus' call
  var this_0 = _get_head__d7jo8b($this);
  var other = $this.m14_1;
  return this_0.lb(toLong(other)).mb($this.k14_1).ra();
}
function _get_totalSize__xhdb3o($this) {
  return $this.m14_1 + $this.n14_1 | 0;
}
function _get_bufferEndIndex__d2rk18($this) {
  // Inline function 'kotlin.Long.plus' call
  var this_0 = _get_head__d7jo8b($this);
  var other = $this.m14_1;
  return this_0.lb(toLong(other));
}
function _get_queueEndIndex__4m025l($this) {
  // Inline function 'kotlin.Long.plus' call
  // Inline function 'kotlin.Long.plus' call
  var this_0 = _get_head__d7jo8b($this);
  var other = $this.m14_1;
  var this_1 = this_0.lb(toLong(other));
  var other_0 = $this.n14_1;
  return this_1.lb(toLong(other_0));
}
function tryEmitLocked($this, value) {
  if ($this.p14_1 === 0)
    return tryEmitNoCollectorsLocked($this, value);
  if ($this.m14_1 >= $this.h14_1 ? $this.l14_1.o6($this.k14_1) <= 0 : false) {
    switch ($this.i14_1.aa_1) {
      case 0:
        return false;
      case 2:
        return true;
      case 1:
        break;
    }
  }
  enqueueLocked($this, value);
  $this.m14_1 = $this.m14_1 + 1 | 0;
  if ($this.m14_1 > $this.h14_1) {
    dropOldestLocked($this);
  }
  if (_get_replaySize__dxgnb1($this) > $this.g14_1) {
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$0 = $this.k14_1.lb(toLong(1));
    updateBufferLocked($this, tmp$ret$0, $this.l14_1, _get_bufferEndIndex__d2rk18($this), _get_queueEndIndex__4m025l($this));
  }
  return true;
}
function tryEmitNoCollectorsLocked($this, value) {
  // Inline function 'kotlinx.coroutines.assert' call
  if ($this.g14_1 === 0)
    return true;
  enqueueLocked($this, value);
  $this.m14_1 = $this.m14_1 + 1 | 0;
  if ($this.m14_1 > $this.g14_1) {
    dropOldestLocked($this);
  }
  var tmp = $this;
  // Inline function 'kotlin.Long.plus' call
  var this_0 = _get_head__d7jo8b($this);
  var other = $this.m14_1;
  tmp.l14_1 = this_0.lb(toLong(other));
  return true;
}
function dropOldestLocked($this) {
  setBufferAt(ensureNotNull($this.j14_1), _get_head__d7jo8b($this), null);
  $this.m14_1 = $this.m14_1 - 1 | 0;
  // Inline function 'kotlin.Long.plus' call
  var newHead = _get_head__d7jo8b($this).lb(toLong(1));
  if ($this.k14_1.o6(newHead) < 0)
    $this.k14_1 = newHead;
  if ($this.l14_1.o6(newHead) < 0) {
    correctCollectorIndexesOnDropOldest($this, newHead);
  }
  // Inline function 'kotlinx.coroutines.assert' call
}
function correctCollectorIndexesOnDropOldest($this, newHead) {
  $l$block: {
    // Inline function 'kotlinx.coroutines.flow.internal.AbstractSharedFlow.forEachSlotLocked' call
    if ($this.p14_1 === 0) {
      break $l$block;
    }
    var tmp0_safe_receiver = $this.o14_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.collections.forEach' call
      var inductionVariable = 0;
      var last = tmp0_safe_receiver.length;
      while (inductionVariable < last) {
        var element = tmp0_safe_receiver[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlinx.coroutines.flow.internal.AbstractSharedFlow.forEachSlotLocked.<anonymous>' call
        if (!(element == null)) {
          // Inline function 'kotlinx.coroutines.flow.SharedFlowImpl.correctCollectorIndexesOnDropOldest.<anonymous>' call
          if (element.s14_1.o6(new Long(0, 0)) >= 0 ? element.s14_1.o6(newHead) < 0 : false) {
            element.s14_1 = newHead;
          }
        }
      }
    }
  }
  $this.l14_1 = newHead;
}
function enqueueLocked($this, item) {
  var curSize = _get_totalSize__xhdb3o($this);
  var curBuffer = $this.j14_1;
  var buffer = curBuffer == null ? growBuffer($this, null, 0, 2) : curSize >= curBuffer.length ? growBuffer($this, curBuffer, curSize, imul(curBuffer.length, 2)) : curBuffer;
  // Inline function 'kotlin.Long.plus' call
  var tmp$ret$0 = _get_head__d7jo8b($this).lb(toLong(curSize));
  setBufferAt(buffer, tmp$ret$0, item);
}
function growBuffer($this, curBuffer, curSize, newSize) {
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(newSize > 0)) {
    // Inline function 'kotlinx.coroutines.flow.SharedFlowImpl.growBuffer.<anonymous>' call
    var message = 'Buffer size overflow';
    throw IllegalStateException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.also' call
  // Inline function 'kotlin.arrayOfNulls' call
  var this_0 = fillArrayVal(Array(newSize), null);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.flow.SharedFlowImpl.growBuffer.<anonymous>' call
  $this.j14_1 = this_0;
  var newBuffer = this_0;
  if (curBuffer == null)
    return newBuffer;
  var head = _get_head__d7jo8b($this);
  var inductionVariable = 0;
  if (inductionVariable < curSize)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.Long.plus' call
      var tmp = head.lb(toLong(i));
      // Inline function 'kotlin.Long.plus' call
      var tmp$ret$4 = head.lb(toLong(i));
      setBufferAt(newBuffer, tmp, getBufferAt(curBuffer, tmp$ret$4));
    }
     while (inductionVariable < curSize);
  return newBuffer;
}
function updateBufferLocked($this, newReplayIndex, newMinCollectorIndex, newBufferEndIndex, newQueueEndIndex) {
  // Inline function 'kotlin.comparisons.minOf' call
  var newHead = newMinCollectorIndex.o6(newReplayIndex) <= 0 ? newMinCollectorIndex : newReplayIndex;
  // Inline function 'kotlinx.coroutines.assert' call
  var inductionVariable = _get_head__d7jo8b($this);
  if (inductionVariable.o6(newHead) < 0)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable.lb(new Long(1, 0));
      setBufferAt(ensureNotNull($this.j14_1), index, null);
    }
     while (inductionVariable.o6(newHead) < 0);
  $this.k14_1 = newReplayIndex;
  $this.l14_1 = newMinCollectorIndex;
  $this.m14_1 = newBufferEndIndex.mb(newHead).ra();
  $this.n14_1 = newQueueEndIndex.mb(newBufferEndIndex).ra();
  // Inline function 'kotlinx.coroutines.assert' call
  // Inline function 'kotlinx.coroutines.assert' call
  // Inline function 'kotlinx.coroutines.assert' call
}
function tryPeekLocked($this, slot) {
  var index = slot.s14_1;
  if (index.o6(_get_bufferEndIndex__d2rk18($this)) < 0)
    return index;
  if ($this.h14_1 > 0)
    return new Long(-1, -1);
  if (index.o6(_get_head__d7jo8b($this)) > 0)
    return new Long(-1, -1);
  if ($this.n14_1 === 0)
    return new Long(-1, -1);
  return index;
}
function findSlotsToResumeLocked($this, resumesIn) {
  var resumes = resumesIn;
  var resumeCount = resumesIn.length;
  $l$block: {
    // Inline function 'kotlinx.coroutines.flow.internal.AbstractSharedFlow.forEachSlotLocked' call
    if ($this.p14_1 === 0) {
      break $l$block;
    }
    var tmp0_safe_receiver = $this.o14_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.collections.forEach' call
      var inductionVariable = 0;
      var last = tmp0_safe_receiver.length;
      while (inductionVariable < last) {
        var element = tmp0_safe_receiver[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlinx.coroutines.flow.internal.AbstractSharedFlow.forEachSlotLocked.<anonymous>' call
        if (!(element == null)) {
          $l$block_1: {
            // Inline function 'kotlinx.coroutines.flow.SharedFlowImpl.findSlotsToResumeLocked.<anonymous>' call
            var tmp0_elvis_lhs = element.t14_1;
            var tmp;
            if (tmp0_elvis_lhs == null) {
              break $l$block_1;
            } else {
              tmp = tmp0_elvis_lhs;
            }
            var cont = tmp;
            if (tryPeekLocked($this, element).o6(new Long(0, 0)) < 0) {
              break $l$block_1;
            }
            if (resumeCount >= resumes.length) {
              var tmp_0 = resumes;
              // Inline function 'kotlin.comparisons.maxOf' call
              var b = imul(2, resumes.length);
              var tmp$ret$2 = Math.max(2, b);
              resumes = copyOf(tmp_0, tmp$ret$2);
            }
            var tmp_1 = resumes;
            var tmp1 = resumeCount;
            resumeCount = tmp1 + 1 | 0;
            tmp_1[tmp1] = cont;
            element.t14_1 = null;
          }
        }
      }
    }
  }
  return resumes;
}
function getBufferAt(_this__u8e3s4, index) {
  _init_properties_SharedFlow_kt__umasnn();
  return _this__u8e3s4[index.ra() & (_this__u8e3s4.length - 1 | 0)];
}
function setBufferAt(_this__u8e3s4, index, item) {
  _init_properties_SharedFlow_kt__umasnn();
  return _this__u8e3s4[index.ra() & (_this__u8e3s4.length - 1 | 0)] = item;
}
var properties_initialized_SharedFlow_kt_tmefor;
function _init_properties_SharedFlow_kt__umasnn() {
  if (!properties_initialized_SharedFlow_kt_tmefor) {
    properties_initialized_SharedFlow_kt_tmefor = true;
    NO_VALUE = new Symbol('NO_VALUE');
  }
}
function get_NONE() {
  _init_properties_StateFlow_kt__eu9yi5();
  return NONE;
}
var NONE;
function get_PENDING() {
  _init_properties_StateFlow_kt__eu9yi5();
  return PENDING;
}
var PENDING;
function MutableStateFlow(value) {
  _init_properties_StateFlow_kt__eu9yi5();
  return new StateFlowImpl(value == null ? get_NULL() : value);
}
function updateState($this, expectedState, newState) {
  var curSequence;
  var curSlots;
  // Inline function 'kotlinx.coroutines.internal.synchronized' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
  var oldState = $this.y14_1.kotlinx$atomicfu$value;
  if (!(expectedState == null) ? !equals(oldState, expectedState) : false)
    return false;
  if (equals(oldState, newState))
    return true;
  $this.y14_1.kotlinx$atomicfu$value = newState;
  curSequence = $this.z14_1;
  if ((curSequence & 1) === 0) {
    curSequence = curSequence + 1 | 0;
    $this.z14_1 = curSequence;
  } else {
    $this.z14_1 = curSequence + 2 | 0;
    return true;
  }
  curSlots = $this.o14_1;
  while (true) {
    var tmp0_safe_receiver = curSlots;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.collections.forEach' call
      var inductionVariable = 0;
      var last = tmp0_safe_receiver.length;
      while (inductionVariable < last) {
        var element = tmp0_safe_receiver[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlinx.coroutines.flow.StateFlowImpl.updateState.<anonymous>' call
        if (element == null)
          null;
        else {
          element.b15();
        }
      }
    }
    // Inline function 'kotlinx.coroutines.internal.synchronized' call
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
    if ($this.z14_1 === curSequence) {
      $this.z14_1 = curSequence + 1 | 0;
      return true;
    }
    curSequence = $this.z14_1;
    curSlots = $this.o14_1;
  }
}
function $collectCOROUTINE$13(_this__u8e3s4, collector, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.k15_1 = _this__u8e3s4;
  this.l15_1 = collector;
}
protoOf($collectCOROUTINE$13).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 12;
          this.m15_1 = this.k15_1.r15();
          this.ic_1 = 1;
          continue $sm;
        case 1:
          this.jc_1 = 11;
          var tmp_0 = this.l15_1;
          if (tmp_0 instanceof SubscribedFlowCollector) {
            this.ic_1 = 2;
            suspendResult = this.l15_1.u15(this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 3;
            continue $sm;
          }

        case 2:
          this.ic_1 = 3;
          continue $sm;
        case 3:
          var tmp_1 = this;
          tmp_1.o15_1 = this.i6().pc(Key_instance_3);
          this.p15_1 = null;
          this.ic_1 = 4;
          continue $sm;
        case 4:
          if (!true) {
            this.ic_1 = 9;
            continue $sm;
          }

          this.q15_1 = this.k15_1.y14_1.kotlinx$atomicfu$value;
          var tmp0_safe_receiver = this.o15_1;
          if (tmp0_safe_receiver == null)
            null;
          else {
            ensureActive_0(tmp0_safe_receiver);
          }

          if (this.p15_1 == null ? true : !equals(this.p15_1, this.q15_1)) {
            this.ic_1 = 5;
            var this_0 = get_NULL();
            var value = this.q15_1;
            var tmp_2;
            if (value === this_0) {
              tmp_2 = (null == null ? true : !(null == null)) ? null : THROW_CCE();
            } else {
              tmp_2 = (value == null ? true : !(value == null)) ? value : THROW_CCE();
            }
            suspendResult = this.l15_1.a14(tmp_2, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 6;
            continue $sm;
          }

        case 5:
          this.p15_1 = this.q15_1;
          this.ic_1 = 6;
          continue $sm;
        case 6:
          if (!this.m15_1.w15()) {
            this.ic_1 = 7;
            suspendResult = this.m15_1.v15(this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 8;
            continue $sm;
          }

        case 7:
          this.ic_1 = 8;
          continue $sm;
        case 8:
          this.ic_1 = 4;
          continue $sm;
        case 9:
          this.n15_1 = Unit_instance;
          this.jc_1 = 12;
          this.ic_1 = 10;
          continue $sm;
        case 10:
          this.jc_1 = 12;
          this.k15_1.x15(this.m15_1);
          return Unit_instance;
        case 11:
          this.jc_1 = 12;
          var t = this.lc_1;
          this.k15_1.x15(this.m15_1);
          throw t;
        case 12:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 12) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function StateFlowImpl(initialState) {
  AbstractSharedFlow.call(this);
  this.y14_1 = atomic$ref$1(initialState);
  this.z14_1 = 0;
}
protoOf(StateFlowImpl).y15 = function (value) {
  updateState(this, null, value == null ? get_NULL() : value);
};
protoOf(StateFlowImpl).l2 = function () {
  // Inline function 'kotlinx.coroutines.internal.Symbol.unbox' call
  var this_0 = get_NULL();
  var value = this.y14_1.kotlinx$atomicfu$value;
  var tmp;
  if (value === this_0) {
    tmp = (null == null ? true : !(null == null)) ? null : THROW_CCE();
  } else {
    tmp = (value == null ? true : !(value == null)) ? value : THROW_CCE();
  }
  return tmp;
};
protoOf(StateFlowImpl).a14 = function (value, $completion) {
  this.y15(value);
  return Unit_instance;
};
protoOf(StateFlowImpl).z15 = function (collector, $completion) {
  var tmp = new $collectCOROUTINE$13(this, collector, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(StateFlowImpl).b14 = function (collector, $completion) {
  return this.z15(collector, $completion);
};
protoOf(StateFlowImpl).a16 = function () {
  return new StateFlowSlot();
};
protoOf(StateFlowImpl).b16 = function (size) {
  // Inline function 'kotlin.arrayOfNulls' call
  return fillArrayVal(Array(size), null);
};
function StateFlowSlot() {
  AbstractSharedFlowSlot.call(this);
  this.a15_1 = atomic$ref$1(null);
}
protoOf(StateFlowSlot).c16 = function (flow) {
  if (!(this.a15_1.kotlinx$atomicfu$value == null))
    return false;
  this.a15_1.kotlinx$atomicfu$value = get_NONE();
  return true;
};
protoOf(StateFlowSlot).d16 = function (flow) {
  return this.c16(flow instanceof StateFlowImpl ? flow : THROW_CCE());
};
protoOf(StateFlowSlot).e16 = function (flow) {
  this.a15_1.kotlinx$atomicfu$value = null;
  return get_EMPTY_RESUMES();
};
protoOf(StateFlowSlot).f16 = function (flow) {
  return this.e16(flow instanceof StateFlowImpl ? flow : THROW_CCE());
};
protoOf(StateFlowSlot).b15 = function () {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = this.a15_1;
  while (true) {
    // Inline function 'kotlinx.coroutines.flow.StateFlowSlot.makePending.<anonymous>' call
    var state = this_0.kotlinx$atomicfu$value;
    if (state == null)
      return Unit_instance;
    else if (state === get_PENDING())
      return Unit_instance;
    else if (state === get_NONE()) {
      if (this.a15_1.atomicfu$compareAndSet(state, get_PENDING()))
        return Unit_instance;
    } else {
      if (this.a15_1.atomicfu$compareAndSet(state, get_NONE())) {
        // Inline function 'kotlin.coroutines.resume' call
        var this_1 = state instanceof CancellableContinuationImpl ? state : THROW_CCE();
        // Inline function 'kotlin.Companion.success' call
        var tmp$ret$0 = _Result___init__impl__xyqfz8(Unit_instance);
        this_1.j6(tmp$ret$0);
        return Unit_instance;
      }
    }
  }
};
protoOf(StateFlowSlot).w15 = function () {
  // Inline function 'kotlin.let' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.assert' call
  return ensureNotNull(this.a15_1.atomicfu$getAndSet(get_NONE())) === get_PENDING();
};
protoOf(StateFlowSlot).v15 = function ($completion) {
  // Inline function 'kotlinx.coroutines.suspendCancellableCoroutine.<anonymous>' call
  var cancellable = new CancellableContinuationImpl(intercepted($completion), get_MODE_CANCELLABLE());
  cancellable.pq();
  $l$block: {
    // Inline function 'kotlinx.coroutines.flow.StateFlowSlot.awaitPending.<anonymous>' call
    // Inline function 'kotlinx.coroutines.assert' call
    if (this.a15_1.atomicfu$compareAndSet(get_NONE(), cancellable)) {
      break $l$block;
    }
    // Inline function 'kotlinx.coroutines.assert' call
    // Inline function 'kotlin.coroutines.resume' call
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$1 = _Result___init__impl__xyqfz8(Unit_instance);
    cancellable.j6(tmp$ret$1);
  }
  return cancellable.rq();
};
var properties_initialized_StateFlow_kt_nsqikx;
function _init_properties_StateFlow_kt__eu9yi5() {
  if (!properties_initialized_StateFlow_kt_nsqikx) {
    properties_initialized_StateFlow_kt_nsqikx = true;
    NONE = new Symbol('NONE');
    PENDING = new Symbol('PENDING');
  }
}
function get_EMPTY_RESUMES() {
  _init_properties_AbstractSharedFlow_kt__h2xygb();
  return EMPTY_RESUMES;
}
var EMPTY_RESUMES;
function AbstractSharedFlow() {
  SynchronizedObject.call(this);
  this.o14_1 = null;
  this.p14_1 = 0;
  this.q14_1 = 0;
  this.r14_1 = null;
}
protoOf(AbstractSharedFlow).r15 = function () {
  var subscriptionCount;
  // Inline function 'kotlinx.coroutines.internal.synchronized' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
  // Inline function 'kotlinx.coroutines.flow.internal.AbstractSharedFlow.allocateSlot.<anonymous>' call
  var curSlots = this.o14_1;
  var tmp;
  if (curSlots == null) {
    // Inline function 'kotlin.also' call
    var this_0 = this.b16(2);
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.coroutines.flow.internal.AbstractSharedFlow.allocateSlot.<anonymous>.<anonymous>' call
    this.o14_1 = this_0;
    tmp = this_0;
  } else {
    var tmp_0;
    if (this.p14_1 >= curSlots.length) {
      // Inline function 'kotlin.also' call
      var this_1 = copyOf(curSlots, imul(2, curSlots.length));
      // Inline function 'kotlin.contracts.contract' call
      // Inline function 'kotlinx.coroutines.flow.internal.AbstractSharedFlow.allocateSlot.<anonymous>.<anonymous>' call
      this.o14_1 = this_1;
      tmp_0 = this_1;
    } else {
      tmp_0 = curSlots;
    }
    tmp = tmp_0;
  }
  var slots = tmp;
  var index = this.q14_1;
  var slot;
  $l$loop: while (true) {
    var tmp0_elvis_lhs = slots[index];
    var tmp_1;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.also' call
      var this_2 = this.a16();
      // Inline function 'kotlin.contracts.contract' call
      // Inline function 'kotlinx.coroutines.flow.internal.AbstractSharedFlow.allocateSlot.<anonymous>.<anonymous>' call
      slots[index] = this_2;
      tmp_1 = this_2;
    } else {
      tmp_1 = tmp0_elvis_lhs;
    }
    slot = tmp_1;
    index = index + 1 | 0;
    if (index >= slots.length)
      index = 0;
    if ((slot instanceof AbstractSharedFlowSlot ? slot : THROW_CCE()).d16(this))
      break $l$loop;
  }
  this.q14_1 = index;
  this.p14_1 = this.p14_1 + 1 | 0;
  subscriptionCount = this.r14_1;
  var slot_0 = slot;
  if (subscriptionCount == null)
    null;
  else
    subscriptionCount.s16(1);
  return slot_0;
};
protoOf(AbstractSharedFlow).x15 = function (slot) {
  var subscriptionCount;
  // Inline function 'kotlinx.coroutines.internal.synchronized' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
  // Inline function 'kotlinx.coroutines.flow.internal.AbstractSharedFlow.freeSlot.<anonymous>' call
  this.p14_1 = this.p14_1 - 1 | 0;
  subscriptionCount = this.r14_1;
  if (this.p14_1 === 0)
    this.q14_1 = 0;
  var resumes = (slot instanceof AbstractSharedFlowSlot ? slot : THROW_CCE()).f16(this);
  var inductionVariable = 0;
  var last = resumes.length;
  while (inductionVariable < last) {
    var cont = resumes[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    if (cont == null)
      null;
    else {
      // Inline function 'kotlin.coroutines.resume' call
      // Inline function 'kotlin.Companion.success' call
      var tmp$ret$3 = _Result___init__impl__xyqfz8(Unit_instance);
      cont.j6(tmp$ret$3);
    }
  }
  if (subscriptionCount == null)
    null;
  else
    subscriptionCount.s16(-1);
};
function AbstractSharedFlowSlot() {
}
var properties_initialized_AbstractSharedFlow_kt_2mpafr;
function _init_properties_AbstractSharedFlow_kt__h2xygb() {
  if (!properties_initialized_AbstractSharedFlow_kt_2mpafr) {
    properties_initialized_AbstractSharedFlow_kt_2mpafr = true;
    // Inline function 'kotlin.arrayOfNulls' call
    EMPTY_RESUMES = fillArrayVal(Array(0), null);
  }
}
function checkOwnership(_this__u8e3s4, owner) {
  if (!(_this__u8e3s4.t16_1 === owner))
    throw _this__u8e3s4;
}
function get_NULL() {
  _init_properties_NullSurrogate_kt__n2yti9();
  return NULL;
}
var NULL;
var UNINITIALIZED;
var DONE;
var properties_initialized_NullSurrogate_kt_39v8bl;
function _init_properties_NullSurrogate_kt__n2yti9() {
  if (!properties_initialized_NullSurrogate_kt_39v8bl) {
    properties_initialized_NullSurrogate_kt_39v8bl = true;
    NULL = new Symbol('NULL');
    UNINITIALIZED = new Symbol('UNINITIALIZED');
    DONE = new Symbol('DONE');
  }
}
function checkContext(_this__u8e3s4, currentContext) {
  var result = currentContext.mf(0, checkContext$lambda(_this__u8e3s4));
  if (!(result === _this__u8e3s4.w16_1)) {
    // Inline function 'kotlin.error' call
    var message = 'Flow invariant is violated:\n' + ('\t\tFlow was collected in ' + _this__u8e3s4.v16_1 + ',\n') + ('\t\tbut emission happened in ' + currentContext + '.\n') + "\t\tPlease refer to 'flow' documentation or use 'flowOn' instead";
    throw IllegalStateException_init_$Create$(toString(message));
  }
}
function transitiveCoroutineParent(_this__u8e3s4, collectJob) {
  var $this = _this__u8e3s4;
  var collectJob_0 = collectJob;
  $l$1: do {
    $l$0: do {
      if ($this === null)
        return null;
      if ($this === collectJob_0)
        return $this;
      if (!($this instanceof ScopeCoroutine))
        return $this;
      $this = $this.on();
      collectJob_0 = collectJob_0;
      continue $l$0;
    }
     while (false);
  }
   while (true);
}
function checkContext$lambda($this_checkContext) {
  return function (count, element) {
    var key = element.k2();
    var collectElement = $this_checkContext.v16_1.pc(key);
    var tmp;
    if (!(key === Key_instance_3)) {
      return !(element === collectElement) ? IntCompanionObject_instance.MIN_VALUE : count + 1 | 0;
    }
    var collectJob = (collectElement == null ? true : isInterface(collectElement, Job)) ? collectElement : THROW_CCE();
    var emissionParentJob = transitiveCoroutineParent(isInterface(element, Job) ? element : THROW_CCE(), collectJob);
    var tmp_0;
    if (!(emissionParentJob === collectJob)) {
      var message = 'Flow invariant is violated:\n\t\tEmission from another coroutine is detected.\n' + ('\t\tChild of ' + emissionParentJob + ', expected child of ' + collectJob + '.\n') + '\t\tFlowCollector is not thread-safe and concurrent emissions are prohibited.\n' + "\t\tTo mitigate this restriction please use 'channelFlow' builder instead of 'flow'";
      throw IllegalStateException_init_$Create$(toString(message));
    }
    return collectJob == null ? count : count + 1 | 0;
  };
}
function asStateFlow(_this__u8e3s4) {
  return new ReadonlyStateFlow(_this__u8e3s4, null);
}
function $onSubscriptionCOROUTINE$18(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.g17_1 = _this__u8e3s4;
}
protoOf($onSubscriptionCOROUTINE$18).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 7;
          var tmp_0 = this;
          tmp_0.h17_1 = new SafeCollector(this.g17_1.s15_1, this.i6());
          this.ic_1 = 1;
          continue $sm;
        case 1:
          this.jc_1 = 6;
          this.ic_1 = 2;
          suspendResult = this.g17_1.t15_1(this.h17_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          this.i17_1 = suspendResult;
          this.jc_1 = 7;
          this.ic_1 = 3;
          continue $sm;
        case 3:
          this.jc_1 = 7;
          this.h17_1.j17();
          var tmp_1 = this.g17_1.s15_1;
          if (tmp_1 instanceof SubscribedFlowCollector) {
            this.ic_1 = 4;
            suspendResult = this.g17_1.s15_1.u15(this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 5;
            continue $sm;
          }

        case 4:
          this.ic_1 = 5;
          continue $sm;
        case 5:
          return Unit_instance;
        case 6:
          this.jc_1 = 7;
          var t = this.lc_1;
          this.h17_1.j17();
          throw t;
        case 7:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 7) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function SubscribedFlowCollector() {
}
protoOf(SubscribedFlowCollector).u15 = function ($completion) {
  var tmp = new $onSubscriptionCOROUTINE$18(this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
function $collectCOROUTINE$19(_this__u8e3s4, collector, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.s17_1 = _this__u8e3s4;
  this.t17_1 = collector;
}
protoOf($collectCOROUTINE$19).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.s17_1.v17_1.z15(this.t17_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          throwKotlinNothingValueException();
          break;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function ReadonlyStateFlow(flow, job) {
  this.u17_1 = job;
  this.v17_1 = flow;
}
protoOf(ReadonlyStateFlow).z15 = function (collector, $completion) {
  var tmp = new $collectCOROUTINE$19(this, collector, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ReadonlyStateFlow).b14 = function (collector, $completion) {
  return this.z15(collector, $completion);
};
function firstOrNull(_this__u8e3s4, predicate, $completion) {
  var tmp = new $firstOrNullCOROUTINE$21(_this__u8e3s4, predicate, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function $emitCOROUTINE$22(_this__u8e3s4, value, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.r18_1 = _this__u8e3s4;
  this.s18_1 = value;
}
protoOf($emitCOROUTINE$22).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 4;
          var tmp_0 = this;
          tmp_0.t18_1 = this.s18_1;
          this.ic_1 = 1;
          suspendResult = this.r18_1.v18_1(this.t18_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          if (suspendResult) {
            var tmp_1 = this;
            this.r18_1.w18_1._v = this.t18_1;
            tmp_1.u18_1 = false;
            this.ic_1 = 2;
            continue $sm;
          } else {
            var tmp_2 = this;
            tmp_2.u18_1 = true;
            this.ic_1 = 2;
            continue $sm;
          }

        case 2:
          var ARGUMENT = this.u18_1;
          if (!ARGUMENT) {
            throw new AbortFlowException(this.r18_1);
          } else {
            this.ic_1 = 3;
            continue $sm;
          }

        case 3:
          return Unit_instance;
        case 4:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 4) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function _no_name_provided__qut3iv_0($predicate, $result) {
  this.v18_1 = $predicate;
  this.w18_1 = $result;
}
protoOf(_no_name_provided__qut3iv_0).a14 = function (value, $completion) {
  var tmp = new $emitCOROUTINE$22(this, value, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
function $firstOrNullCOROUTINE$21(_this__u8e3s4, predicate, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.e18_1 = _this__u8e3s4;
  this.f18_1 = predicate;
}
protoOf($firstOrNullCOROUTINE$21).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 4;
          this.g18_1 = {_v: null};
          var tmp_0 = this;
          tmp_0.h18_1 = this.e18_1;
          var tmp_1 = this;
          tmp_1.i18_1 = new _no_name_provided__qut3iv_0(this.f18_1, this.g18_1);
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.h18_1.b14(this.i18_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.jc_1 = 4;
          this.ic_1 = 3;
          continue $sm;
        case 2:
          this.jc_1 = 4;
          var tmp_2 = this.lc_1;
          if (tmp_2 instanceof AbortFlowException) {
            var e = this.lc_1;
            checkOwnership(e, this.i18_1);
            this.ic_1 = 3;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 3:
          this.jc_1 = 4;
          return this.g18_1._v;
        case 4:
          throw this.lc_1;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 4) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
function OpDescriptor() {
}
function get_CLOSED() {
  _init_properties_ConcurrentLinkedList_kt__5gcgzy();
  return CLOSED;
}
var CLOSED;
function Segment(id, prev, pointers) {
  ConcurrentLinkedListNode.call(this, prev);
  this.js_1 = id;
  this.ks_1 = atomic$int$1(pointers << 16);
}
protoOf(Segment).uz = function () {
  return this.ks_1.kotlinx$atomicfu$value === this.wy() ? !this.b10() : false;
};
protoOf(Segment).vz = function () {
  var tmp$ret$1;
  $l$block_0: {
    // Inline function 'kotlinx.coroutines.internal.addConditionally' call
    var this_0 = this.ks_1;
    while (true) {
      var cur = this_0.kotlinx$atomicfu$value;
      // Inline function 'kotlinx.coroutines.internal.Segment.tryIncPointers.<anonymous>' call
      if (!(!(cur === this.wy()) ? true : this.b10())) {
        tmp$ret$1 = false;
        break $l$block_0;
      }
      if (this_0.atomicfu$compareAndSet(cur, cur + 65536 | 0)) {
        tmp$ret$1 = true;
        break $l$block_0;
      }
    }
  }
  return tmp$ret$1;
};
protoOf(Segment).wz = function () {
  return this.ks_1.atomicfu$addAndGet(-65536) === this.wy() ? !this.b10() : false;
};
protoOf(Segment).tz = function () {
  if (this.ks_1.atomicfu$incrementAndGet() === this.wy()) {
    this.y();
  }
};
function close(_this__u8e3s4) {
  _init_properties_ConcurrentLinkedList_kt__5gcgzy();
  var cur = _this__u8e3s4;
  while (true) {
    // Inline function 'kotlinx.coroutines.internal.ConcurrentLinkedListNode.nextOrIfClosed' call
    var this_0 = cur;
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.coroutines.internal.ConcurrentLinkedListNode.nextOrIfClosed.<anonymous>' call
    var it = _get_nextOrClosed__w0gmuv(this_0);
    var tmp;
    if (it === get_CLOSED()) {
      return cur;
    } else {
      tmp = (it == null ? true : it instanceof ConcurrentLinkedListNode) ? it : THROW_CCE();
    }
    var next = tmp;
    if (next === null) {
      if (cur.e10())
        return cur;
    } else {
      cur = next;
    }
  }
}
function _SegmentOrClosed___init__impl__jnexvb(value) {
  return value;
}
function _get_value__a43j40($this) {
  return $this;
}
function _SegmentOrClosed___get_isClosed__impl__qmxmlo($this) {
  return _get_value__a43j40($this) === get_CLOSED();
}
function _SegmentOrClosed___get_segment__impl__jvcr9l($this) {
  var tmp;
  if (_get_value__a43j40($this) === get_CLOSED()) {
    var message = 'Does not contain segment';
    throw IllegalStateException_init_$Create$(toString(message));
  } else {
    var tmp_0 = _get_value__a43j40($this);
    tmp = tmp_0 instanceof Segment ? tmp_0 : THROW_CCE();
  }
  return tmp;
}
function SegmentOrClosed__toString_impl_pzb2an($this) {
  return 'SegmentOrClosed(value=' + toString_0($this) + ')';
}
function SegmentOrClosed__hashCode_impl_4855hs($this) {
  return $this == null ? 0 : hashCode($this);
}
function SegmentOrClosed__equals_impl_6erq1g($this, other) {
  if (!(other instanceof SegmentOrClosed))
    return false;
  var tmp0_other_with_cast = other instanceof SegmentOrClosed ? other.e12_1 : THROW_CCE();
  if (!equals($this, tmp0_other_with_cast))
    return false;
  return true;
}
function SegmentOrClosed(value) {
  this.e12_1 = value;
}
protoOf(SegmentOrClosed).toString = function () {
  return SegmentOrClosed__toString_impl_pzb2an(this.e12_1);
};
protoOf(SegmentOrClosed).hashCode = function () {
  return SegmentOrClosed__hashCode_impl_4855hs(this.e12_1);
};
protoOf(SegmentOrClosed).equals = function (other) {
  return SegmentOrClosed__equals_impl_6erq1g(this.e12_1, other);
};
function _get_nextOrClosed__w0gmuv($this) {
  return $this.xz_1.kotlinx$atomicfu$value;
}
function _get_aliveSegmentLeft__mr4ndu($this) {
  var cur = $this.c10();
  while (!(cur === null) ? cur.uz() : false)
    cur = cur.yz_1.kotlinx$atomicfu$value;
  return cur;
}
function _get_aliveSegmentRight__7ulr0b($this) {
  // Inline function 'kotlinx.coroutines.assert' call
  var cur = ensureNotNull($this.zz());
  while (cur.uz()) {
    var tmp0_elvis_lhs = cur.zz();
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return cur;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    cur = tmp;
  }
  return cur;
}
function ConcurrentLinkedListNode(prev) {
  this.xz_1 = atomic$ref$1(null);
  this.yz_1 = atomic$ref$1(prev);
}
protoOf(ConcurrentLinkedListNode).zz = function () {
  // Inline function 'kotlinx.coroutines.internal.ConcurrentLinkedListNode.nextOrIfClosed' call
  // Inline function 'kotlin.let' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlinx.coroutines.internal.ConcurrentLinkedListNode.nextOrIfClosed.<anonymous>' call
  var it = _get_nextOrClosed__w0gmuv(this);
  var tmp;
  if (it === get_CLOSED()) {
    return null;
  } else {
    tmp = (it == null ? true : it instanceof ConcurrentLinkedListNode) ? it : THROW_CCE();
  }
  return tmp;
};
protoOf(ConcurrentLinkedListNode).a10 = function (value) {
  return this.xz_1.atomicfu$compareAndSet(null, value);
};
protoOf(ConcurrentLinkedListNode).b10 = function () {
  return this.zz() == null;
};
protoOf(ConcurrentLinkedListNode).c10 = function () {
  return this.yz_1.kotlinx$atomicfu$value;
};
protoOf(ConcurrentLinkedListNode).d10 = function () {
  // Inline function 'kotlinx.atomicfu.AtomicRef.lazySet' call
  this.yz_1.kotlinx$atomicfu$value = null;
};
protoOf(ConcurrentLinkedListNode).e10 = function () {
  return this.xz_1.atomicfu$compareAndSet(null, get_CLOSED());
};
protoOf(ConcurrentLinkedListNode).y = function () {
  // Inline function 'kotlinx.coroutines.assert' call
  if (this.b10())
    return Unit_instance;
  $l$loop_0: while (true) {
    var prev = _get_aliveSegmentLeft__mr4ndu(this);
    var next = _get_aliveSegmentRight__7ulr0b(this);
    $l$block: {
      // Inline function 'kotlinx.atomicfu.update' call
      var this_0 = next.yz_1;
      while (true) {
        var cur = this_0.kotlinx$atomicfu$value;
        // Inline function 'kotlinx.coroutines.internal.ConcurrentLinkedListNode.remove.<anonymous>' call
        var upd = cur === null ? null : prev;
        if (this_0.atomicfu$compareAndSet(cur, upd)) {
          break $l$block;
        }
      }
    }
    if (!(prev === null))
      prev.xz_1.kotlinx$atomicfu$value = next;
    if (next.uz() ? !next.b10() : false)
      continue $l$loop_0;
    if (!(prev === null) ? prev.uz() : false)
      continue $l$loop_0;
    return Unit_instance;
  }
};
function findSegmentInternal(_this__u8e3s4, id, createNewSegment) {
  _init_properties_ConcurrentLinkedList_kt__5gcgzy();
  var cur = _this__u8e3s4;
  $l$loop: while (cur.js_1.o6(id) < 0 ? true : cur.uz()) {
    // Inline function 'kotlinx.coroutines.internal.ConcurrentLinkedListNode.nextOrIfClosed' call
    var this_0 = cur;
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.coroutines.internal.ConcurrentLinkedListNode.nextOrIfClosed.<anonymous>' call
    var it = _get_nextOrClosed__w0gmuv(this_0);
    var tmp;
    if (it === get_CLOSED()) {
      return _SegmentOrClosed___init__impl__jnexvb(get_CLOSED());
    } else {
      tmp = (it == null ? true : it instanceof ConcurrentLinkedListNode) ? it : THROW_CCE();
    }
    var next = tmp;
    if (!(next == null)) {
      cur = next;
      continue $l$loop;
    }
    // Inline function 'kotlin.Long.plus' call
    var newTail = createNewSegment(cur.js_1.lb(toLong(1)), cur);
    if (cur.a10(newTail)) {
      if (cur.uz()) {
        cur.y();
      }
      cur = newTail;
    }
  }
  return _SegmentOrClosed___init__impl__jnexvb(cur);
}
var properties_initialized_ConcurrentLinkedList_kt_kwt434;
function _init_properties_ConcurrentLinkedList_kt__5gcgzy() {
  if (!properties_initialized_ConcurrentLinkedList_kt_kwt434) {
    properties_initialized_ConcurrentLinkedList_kt_kwt434 = true;
    CLOSED = new Symbol('CLOSED');
  }
}
function handleUncaughtCoroutineException(context, exception) {
  var tmp0_iterator = get_platformExceptionHandlers().u();
  while (tmp0_iterator.v()) {
    var handler = tmp0_iterator.w();
    try {
      handler.nu(context, exception);
    } catch ($p) {
      if ($p instanceof ExceptionSuccessfullyProcessed) {
        var _ = $p;
        return Unit_instance;
      } else {
        if ($p instanceof Error) {
          var t = $p;
          propagateExceptionFinalResort(handlerException(exception, t));
        } else {
          throw $p;
        }
      }
    }
  }
  try {
    addSuppressed(exception, new DiagnosticCoroutineContextException(context));
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
    } else {
      throw $p;
    }
  }
  propagateExceptionFinalResort(exception);
}
function ExceptionSuccessfullyProcessed() {
}
function get_UNDEFINED() {
  _init_properties_DispatchedContinuation_kt__tnmqc0();
  return UNDEFINED;
}
var UNDEFINED;
function get_REUSABLE_CLAIMED() {
  _init_properties_DispatchedContinuation_kt__tnmqc0();
  return REUSABLE_CLAIMED;
}
var REUSABLE_CLAIMED;
function _get_reusableCancellableContinuation__9qex09($this) {
  var tmp = $this.bs_1.kotlinx$atomicfu$value;
  return tmp instanceof CancellableContinuationImpl ? tmp : null;
}
function DispatchedContinuation(dispatcher, continuation) {
  DispatchedTask.call(this, get_MODE_UNINITIALIZED());
  this.xr_1 = dispatcher;
  this.yr_1 = continuation;
  this.zr_1 = get_UNDEFINED();
  this.as_1 = threadContextElements(this.i6());
  this.bs_1 = atomic$ref$1(null);
}
protoOf(DispatchedContinuation).i6 = function () {
  return this.yr_1.i6();
};
protoOf(DispatchedContinuation).es = function () {
  return !(this.bs_1.kotlinx$atomicfu$value == null);
};
protoOf(DispatchedContinuation).x18 = function () {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = this.bs_1;
  while (true) {
    // Inline function 'kotlinx.coroutines.internal.DispatchedContinuation.awaitReusability.<anonymous>' call
    if (!(this_0.kotlinx$atomicfu$value === get_REUSABLE_CLAIMED()))
      return Unit_instance;
  }
};
protoOf(DispatchedContinuation).mu = function () {
  this.x18();
  var tmp0_safe_receiver = _get_reusableCancellableContinuation__9qex09(this);
  if (tmp0_safe_receiver == null)
    null;
  else {
    tmp0_safe_receiver.at();
  }
};
protoOf(DispatchedContinuation).cs = function () {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = this.bs_1;
  while (true) {
    // Inline function 'kotlinx.coroutines.internal.DispatchedContinuation.claimReusableCancellableContinuation.<anonymous>' call
    var state = this_0.kotlinx$atomicfu$value;
    if (state === null) {
      this.bs_1.kotlinx$atomicfu$value = get_REUSABLE_CLAIMED();
      return null;
    } else {
      if (state instanceof CancellableContinuationImpl) {
        if (this.bs_1.atomicfu$compareAndSet(state, get_REUSABLE_CLAIMED())) {
          return state instanceof CancellableContinuationImpl ? state : THROW_CCE();
        }
      } else {
        if (state !== get_REUSABLE_CLAIMED()) {
          if (!(state instanceof Error)) {
            var message = 'Inconsistent state ' + toString_0(state);
            throw IllegalStateException_init_$Create$(toString(message));
          }
        }
      }
    }
  }
};
protoOf(DispatchedContinuation).kt = function (continuation) {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = this.bs_1;
  while (true) {
    // Inline function 'kotlinx.coroutines.internal.DispatchedContinuation.tryReleaseClaimedContinuation.<anonymous>' call
    var state = this_0.kotlinx$atomicfu$value;
    if (state === get_REUSABLE_CLAIMED()) {
      if (this.bs_1.atomicfu$compareAndSet(get_REUSABLE_CLAIMED(), continuation))
        return null;
    } else {
      if (state instanceof Error) {
        // Inline function 'kotlin.require' call
        // Inline function 'kotlin.contracts.contract' call
        // Inline function 'kotlin.require' call
        // Inline function 'kotlin.contracts.contract' call
        if (!this.bs_1.atomicfu$compareAndSet(state, null)) {
          // Inline function 'kotlin.require.<anonymous>' call
          var message = 'Failed requirement.';
          throw IllegalArgumentException_init_$Create$(toString(message));
        }
        return state;
      } else {
        var message_0 = 'Inconsistent state ' + toString_0(state);
        throw IllegalStateException_init_$Create$(toString(message_0));
      }
    }
  }
};
protoOf(DispatchedContinuation).gs = function (cause) {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = this.bs_1;
  while (true) {
    // Inline function 'kotlinx.coroutines.internal.DispatchedContinuation.postponeCancellation.<anonymous>' call
    var state = this_0.kotlinx$atomicfu$value;
    if (equals(state, get_REUSABLE_CLAIMED())) {
      if (this.bs_1.atomicfu$compareAndSet(get_REUSABLE_CLAIMED(), cause))
        return true;
    } else {
      if (state instanceof Error)
        return true;
      else {
        if (this.bs_1.atomicfu$compareAndSet(state, null))
          return false;
      }
    }
  }
};
protoOf(DispatchedContinuation).ct = function () {
  var state = this.zr_1;
  // Inline function 'kotlinx.coroutines.assert' call
  this.zr_1 = get_UNDEFINED();
  return state;
};
protoOf(DispatchedContinuation).bt = function () {
  return this;
};
protoOf(DispatchedContinuation).j6 = function (result) {
  var context = this.yr_1.i6();
  var state = toState_0(result);
  if (this.xr_1.ku(context)) {
    this.zr_1 = state;
    this.fs_1 = get_MODE_ATOMIC();
    this.xr_1.lu(context, this);
  } else {
    $l$block: {
      // Inline function 'kotlinx.coroutines.internal.executeUnconfined' call
      var mode = get_MODE_ATOMIC();
      // Inline function 'kotlinx.coroutines.assert' call
      var eventLoop = ThreadLocalEventLoop_getInstance().dv();
      if (false ? eventLoop.yu() : false) {
        break $l$block;
      }
      var tmp;
      if (eventLoop.xu()) {
        this.zr_1 = state;
        this.fs_1 = mode;
        eventLoop.wu(this);
        tmp = true;
      } else {
        // Inline function 'kotlinx.coroutines.runUnconfinedEventLoop' call
        eventLoop.zu(true);
        try {
          // Inline function 'kotlinx.coroutines.internal.DispatchedContinuation.resumeWith.<anonymous>' call
          // Inline function 'kotlinx.coroutines.withCoroutineContext' call
          this.i6();
          this.as_1;
          this.yr_1.j6(result);
          $l$loop: while (eventLoop.vu()) {
          }
        } catch ($p) {
          if ($p instanceof Error) {
            var e = $p;
            this.ot(e, null);
          } else {
            throw $p;
          }
        }
        finally {
          eventLoop.av(true);
        }
        tmp = false;
      }
    }
  }
};
protoOf(DispatchedContinuation).dt = function (takenState, cause) {
  if (takenState instanceof CompletedWithCancellation) {
    takenState.iu_1(cause);
  }
};
protoOf(DispatchedContinuation).toString = function () {
  return 'DispatchedContinuation[' + this.xr_1 + ', ' + toDebugString(this.yr_1) + ']';
};
function resumeCancellableWith(_this__u8e3s4, result, onCancellation) {
  onCancellation = onCancellation === VOID ? null : onCancellation;
  _init_properties_DispatchedContinuation_kt__tnmqc0();
  var tmp;
  if (_this__u8e3s4 instanceof DispatchedContinuation) {
    var state = toState_0(result, onCancellation);
    var tmp_0;
    if (_this__u8e3s4.xr_1.ku(_this__u8e3s4.i6())) {
      _this__u8e3s4.zr_1 = state;
      _this__u8e3s4.fs_1 = get_MODE_CANCELLABLE();
      _this__u8e3s4.xr_1.lu(_this__u8e3s4.i6(), _this__u8e3s4);
      tmp_0 = Unit_instance;
    } else {
      $l$block: {
        // Inline function 'kotlinx.coroutines.internal.executeUnconfined' call
        var mode = get_MODE_CANCELLABLE();
        // Inline function 'kotlinx.coroutines.assert' call
        var eventLoop = ThreadLocalEventLoop_getInstance().dv();
        if (false ? eventLoop.yu() : false) {
          break $l$block;
        }
        var tmp_1;
        if (eventLoop.xu()) {
          _this__u8e3s4.zr_1 = state;
          _this__u8e3s4.fs_1 = mode;
          eventLoop.wu(_this__u8e3s4);
          tmp_1 = true;
        } else {
          // Inline function 'kotlinx.coroutines.runUnconfinedEventLoop' call
          eventLoop.zu(true);
          try {
            // Inline function 'kotlinx.coroutines.internal.DispatchedContinuation.resumeCancellableWith.<anonymous>' call
            var tmp$ret$3;
            $l$block_0: {
              // Inline function 'kotlinx.coroutines.internal.DispatchedContinuation.resumeCancelled' call
              var job = _this__u8e3s4.i6().pc(Key_instance_3);
              if (!(job == null) ? !job.vm() : false) {
                var cause = job.tn();
                _this__u8e3s4.dt(state, cause);
                // Inline function 'kotlin.coroutines.resumeWithException' call
                // Inline function 'kotlin.Companion.failure' call
                var tmp$ret$1 = _Result___init__impl__xyqfz8(createFailure(cause));
                _this__u8e3s4.j6(tmp$ret$1);
                tmp$ret$3 = true;
                break $l$block_0;
              }
              tmp$ret$3 = false;
            }
            if (!tmp$ret$3) {
              // Inline function 'kotlinx.coroutines.internal.DispatchedContinuation.resumeUndispatchedWith' call
              // Inline function 'kotlinx.coroutines.withContinuationContext' call
              _this__u8e3s4.yr_1;
              _this__u8e3s4.as_1;
              _this__u8e3s4.yr_1.j6(result);
            }
            $l$loop: while (eventLoop.vu()) {
            }
          } catch ($p) {
            if ($p instanceof Error) {
              var e = $p;
              _this__u8e3s4.ot(e, null);
            } else {
              throw $p;
            }
          }
          finally {
            eventLoop.av(true);
          }
          tmp_1 = false;
        }
      }
      tmp_0 = Unit_instance;
    }
    tmp = tmp_0;
  } else {
    _this__u8e3s4.j6(result);
    tmp = Unit_instance;
  }
  return tmp;
}
var properties_initialized_DispatchedContinuation_kt_2siadq;
function _init_properties_DispatchedContinuation_kt__tnmqc0() {
  if (!properties_initialized_DispatchedContinuation_kt_2siadq) {
    properties_initialized_DispatchedContinuation_kt_2siadq = true;
    UNDEFINED = new Symbol('UNDEFINED');
    REUSABLE_CLAIMED = new Symbol('REUSABLE_CLAIMED');
  }
}
function get_MODE_CANCELLABLE() {
  return MODE_CANCELLABLE;
}
var MODE_CANCELLABLE;
function get_MODE_CANCELLABLE_REUSABLE() {
  return MODE_CANCELLABLE_REUSABLE;
}
var MODE_CANCELLABLE_REUSABLE;
function DispatchedTask(resumeMode) {
  SchedulerTask.call(this);
  this.fs_1 = resumeMode;
}
protoOf(DispatchedTask).dt = function (takenState, cause) {
};
protoOf(DispatchedTask).jt = function (state) {
  return (state == null ? true : !(state == null)) ? state : THROW_CCE();
};
protoOf(DispatchedTask).mt = function (state) {
  var tmp0_safe_receiver = state instanceof CompletedExceptionally ? state : null;
  return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.an_1;
};
protoOf(DispatchedTask).nt = function () {
  // Inline function 'kotlinx.coroutines.assert' call
  var taskContext = get_taskContext(this);
  var fatalException = null;
  try {
    var tmp = this.bt();
    var delegate = tmp instanceof DispatchedContinuation ? tmp : THROW_CCE();
    var continuation = delegate.yr_1;
    // Inline function 'kotlinx.coroutines.withContinuationContext' call
    delegate.as_1;
    var context = continuation.i6();
    var state = this.ct();
    var exception = this.mt(state);
    var job = (exception == null ? get_isCancellableMode(this.fs_1) : false) ? context.pc(Key_instance_3) : null;
    var tmp_0;
    if (!(job == null) ? !job.vm() : false) {
      var cause = job.tn();
      this.dt(state, cause);
      // Inline function 'kotlin.Companion.failure' call
      var exception_0 = recoverStackTrace(cause, continuation);
      var tmp$ret$0 = _Result___init__impl__xyqfz8(createFailure(exception_0));
      continuation.j6(tmp$ret$0);
      tmp_0 = Unit_instance;
    } else {
      var tmp_1;
      if (!(exception == null)) {
        // Inline function 'kotlin.coroutines.resumeWithException' call
        // Inline function 'kotlin.Companion.failure' call
        var tmp$ret$1 = _Result___init__impl__xyqfz8(createFailure(exception));
        continuation.j6(tmp$ret$1);
        tmp_1 = Unit_instance;
      } else {
        // Inline function 'kotlin.coroutines.resume' call
        // Inline function 'kotlin.Companion.success' call
        var value = this.jt(state);
        var tmp$ret$3 = _Result___init__impl__xyqfz8(value);
        continuation.j6(tmp$ret$3);
        tmp_1 = Unit_instance;
      }
      tmp_0 = tmp_1;
    }
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
      fatalException = e;
    } else {
      throw $p;
    }
  }
  finally {
    // Inline function 'kotlin.runCatching' call
    var tmp_2;
    try {
      // Inline function 'kotlin.Companion.success' call
      // Inline function 'kotlinx.coroutines.DispatchedTask.run.<anonymous>' call
      // Inline function 'kotlinx.coroutines.afterTask' call
      tmp_2 = _Result___init__impl__xyqfz8(Unit_instance);
    } catch ($p) {
      var tmp_3;
      if ($p instanceof Error) {
        var e_0 = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_3 = _Result___init__impl__xyqfz8(createFailure(e_0));
      } else {
        throw $p;
      }
      tmp_2 = tmp_3;
    }
    var result = tmp_2;
    this.ot(fatalException, Result__exceptionOrNull_impl_p6xea9(result));
  }
};
protoOf(DispatchedTask).ot = function (exception, finallyException) {
  if (exception === null ? finallyException === null : false)
    return Unit_instance;
  if (!(exception === null) ? !(finallyException === null) : false) {
    addSuppressed(exception, finallyException);
  }
  var cause = exception == null ? finallyException : exception;
  var reason = new CoroutinesInternalError('Fatal exception in coroutines machinery for ' + this + '. ' + "Please read KDoc to 'handleFatalException' method and report this incident to maintainers", ensureNotNull(cause));
  handleCoroutineException(this.bt().i6(), reason);
};
function get_MODE_UNINITIALIZED() {
  return MODE_UNINITIALIZED;
}
var MODE_UNINITIALIZED;
function get_isReusableMode(_this__u8e3s4) {
  return _this__u8e3s4 === 2;
}
function get_isCancellableMode(_this__u8e3s4) {
  return _this__u8e3s4 === 1 ? true : _this__u8e3s4 === 2;
}
function dispatch(_this__u8e3s4, mode) {
  // Inline function 'kotlinx.coroutines.assert' call
  var delegate = _this__u8e3s4.bt();
  var undispatched = mode === 4;
  var tmp;
  var tmp_0;
  if (!undispatched) {
    tmp_0 = delegate instanceof DispatchedContinuation;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = get_isCancellableMode(mode) === get_isCancellableMode(_this__u8e3s4.fs_1);
  } else {
    tmp = false;
  }
  if (tmp) {
    var dispatcher = delegate.xr_1;
    var context = delegate.i6();
    if (dispatcher.ku(context)) {
      dispatcher.lu(context, _this__u8e3s4);
    } else {
      resumeUnconfined(_this__u8e3s4);
    }
  } else {
    resume(_this__u8e3s4, delegate, undispatched);
  }
}
function get_MODE_UNDISPATCHED() {
  return MODE_UNDISPATCHED;
}
var MODE_UNDISPATCHED;
function resumeUnconfined(_this__u8e3s4) {
  var eventLoop = ThreadLocalEventLoop_getInstance().dv();
  if (eventLoop.xu()) {
    eventLoop.wu(_this__u8e3s4);
  } else {
    // Inline function 'kotlinx.coroutines.runUnconfinedEventLoop' call
    eventLoop.zu(true);
    try {
      // Inline function 'kotlinx.coroutines.resumeUnconfined.<anonymous>' call
      resume(_this__u8e3s4, _this__u8e3s4.bt(), true);
      $l$loop: while (eventLoop.vu()) {
      }
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        _this__u8e3s4.ot(e, null);
      } else {
        throw $p;
      }
    }
    finally {
      eventLoop.av(true);
    }
  }
}
function resume(_this__u8e3s4, delegate, undispatched) {
  var state = _this__u8e3s4.ct();
  var exception = _this__u8e3s4.mt(state);
  var tmp;
  if (!(exception == null)) {
    // Inline function 'kotlin.Companion.failure' call
    tmp = _Result___init__impl__xyqfz8(createFailure(exception));
  } else {
    // Inline function 'kotlin.Companion.success' call
    var value = _this__u8e3s4.jt(state);
    tmp = _Result___init__impl__xyqfz8(value);
  }
  var result = tmp;
  if (undispatched) {
    // Inline function 'kotlinx.coroutines.internal.DispatchedContinuation.resumeUndispatchedWith' call
    var this_0 = delegate instanceof DispatchedContinuation ? delegate : THROW_CCE();
    // Inline function 'kotlinx.coroutines.withContinuationContext' call
    this_0.yr_1;
    this_0.as_1;
    this_0.yr_1.j6(result);
  } else {
    delegate.j6(result);
  }
}
function get_MODE_ATOMIC() {
  return MODE_ATOMIC;
}
var MODE_ATOMIC;
function _InlineList___init__impl__z8n56(holder) {
  holder = holder === VOID ? null : holder;
  return holder;
}
function _get_holder__f6h5pd($this) {
  return $this;
}
function InlineList__plus_impl_nuetvo($this, element) {
  // Inline function 'kotlinx.coroutines.assert' call
  var tmp0_subject = _get_holder__f6h5pd($this);
  var tmp;
  if (tmp0_subject == null) {
    tmp = _InlineList___init__impl__z8n56(element);
  } else {
    if (tmp0_subject instanceof ArrayList) {
      var tmp_0 = _get_holder__f6h5pd($this);
      (tmp_0 instanceof ArrayList ? tmp_0 : THROW_CCE()).r(element);
      tmp = _InlineList___init__impl__z8n56(_get_holder__f6h5pd($this));
    } else {
      var list = ArrayList_init_$Create$(4);
      var tmp_1 = _get_holder__f6h5pd($this);
      list.r((tmp_1 == null ? true : !(tmp_1 == null)) ? tmp_1 : THROW_CCE());
      list.r(element);
      tmp = _InlineList___init__impl__z8n56(list);
    }
  }
  return tmp;
}
function callUndeliveredElement(_this__u8e3s4, element, context) {
  var tmp0_safe_receiver = callUndeliveredElementCatchingException(_this__u8e3s4, element, null);
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    handleCoroutineException(context, tmp0_safe_receiver);
  }
}
function UndeliveredElementException(message, cause) {
  RuntimeException_init_$Init$(message, cause, this);
  captureStack(this, UndeliveredElementException);
}
function callUndeliveredElementCatchingException(_this__u8e3s4, element, undeliveredElementException) {
  undeliveredElementException = undeliveredElementException === VOID ? null : undeliveredElementException;
  try {
    _this__u8e3s4(element);
  } catch ($p) {
    if ($p instanceof Error) {
      var ex = $p;
      if (!(undeliveredElementException == null) ? !(undeliveredElementException.cause === ex) : false) {
        addSuppressed(undeliveredElementException, ex);
      } else {
        return new UndeliveredElementException('Exception in undelivered element handler for ' + element, ex);
      }
    } else {
      throw $p;
    }
  }
  return undeliveredElementException;
}
function bindCancellationFun(_this__u8e3s4, element, context) {
  return bindCancellationFun$lambda(_this__u8e3s4, element, context);
}
function bindCancellationFun$lambda($this_bindCancellationFun, $element, $context) {
  return function (_anonymous_parameter_0__qggqh8) {
    callUndeliveredElement($this_bindCancellationFun, $element, $context);
    return Unit_instance;
  };
}
function ContextScope(context) {
  this.y18_1 = context;
}
protoOf(ContextScope).um = function () {
  return this.y18_1;
};
protoOf(ContextScope).toString = function () {
  return 'CoroutineScope(coroutineContext=' + this.y18_1 + ')';
};
function ScopeCoroutine() {
}
function Symbol(symbol) {
  this.z18_1 = symbol;
}
protoOf(Symbol).toString = function () {
  return '<' + this.z18_1 + '>';
};
function systemProp(propertyName, defaultValue, minValue, maxValue) {
  minValue = minValue === VOID ? 1 : minValue;
  maxValue = maxValue === VOID ? IntCompanionObject_instance.MAX_VALUE : maxValue;
  return systemProp_0(propertyName, toLong(defaultValue), toLong(minValue), toLong(maxValue)).ra();
}
function systemProp_0(propertyName, defaultValue, minValue, maxValue) {
  minValue = minValue === VOID ? new Long(1, 0) : minValue;
  var tmp;
  if (maxValue === VOID) {
    Companion_getInstance();
    tmp = new Long(-1, 2147483647);
  } else {
    tmp = maxValue;
  }
  maxValue = tmp;
  var tmp0_elvis_lhs = systemProp_1(propertyName);
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    return defaultValue;
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var value = tmp_0;
  var tmp1_elvis_lhs = toLongOrNull(value);
  var tmp_1;
  if (tmp1_elvis_lhs == null) {
    var message = "System property '" + propertyName + "' has unrecognized value '" + value + "'";
    throw IllegalStateException_init_$Create$(toString(message));
  } else {
    tmp_1 = tmp1_elvis_lhs;
  }
  var parsed = tmp_1;
  if (!(minValue.o6(parsed) <= 0 ? parsed.o6(maxValue) <= 0 : false)) {
    // Inline function 'kotlin.error' call
    var message_0 = "System property '" + propertyName + "' should be in range " + minValue.toString() + '..' + maxValue.toString() + ", but is '" + parsed.toString() + "'";
    throw IllegalStateException_init_$Create$(toString(message_0));
  }
  return parsed;
}
function startCoroutineCancellable(_this__u8e3s4, fatalCompletion) {
  var tmp;
  try {
    var tmp_0 = intercepted(_this__u8e3s4);
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(Unit_instance);
    resumeCancellableWith(tmp_0, tmp$ret$0);
    tmp = Unit_instance;
  } catch ($p) {
    var tmp_1;
    if ($p instanceof Error) {
      var e = $p;
      dispatcherFailure$accessor$glj1hg(fatalCompletion, e);
      tmp_1 = Unit_instance;
    } else {
      throw $p;
    }
    tmp = tmp_1;
  }
  return tmp;
}
function startCoroutineCancellable_0(_this__u8e3s4, receiver, completion, onCancellation) {
  onCancellation = onCancellation === VOID ? null : onCancellation;
  var tmp;
  try {
    var tmp_0 = intercepted(createCoroutineUnintercepted(_this__u8e3s4, receiver, completion));
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(Unit_instance);
    resumeCancellableWith(tmp_0, tmp$ret$0, onCancellation);
    tmp = Unit_instance;
  } catch ($p) {
    var tmp_1;
    if ($p instanceof Error) {
      var e = $p;
      dispatcherFailure$accessor$glj1hg(completion, e);
      tmp_1 = Unit_instance;
    } else {
      throw $p;
    }
    tmp = tmp_1;
  }
  return tmp;
}
function dispatcherFailure(completion, e) {
  // Inline function 'kotlin.Companion.failure' call
  var tmp$ret$0 = _Result___init__impl__xyqfz8(createFailure(e));
  completion.j6(tmp$ret$0);
  throw e;
}
function dispatcherFailure$accessor$glj1hg(completion, e) {
  return dispatcherFailure(completion, e);
}
function startCoroutineUndispatched(_this__u8e3s4, receiver, completion) {
  $l$block: {
    // Inline function 'kotlinx.coroutines.intrinsics.startDirect' call
    // Inline function 'kotlinx.coroutines.internal.probeCoroutineCreated' call
    var actualCompletion = completion;
    var tmp;
    try {
      // Inline function 'kotlinx.coroutines.intrinsics.startCoroutineUndispatched.<anonymous>' call
      // Inline function 'kotlinx.coroutines.withCoroutineContext' call
      completion.i6();
      // Inline function 'kotlinx.coroutines.intrinsics.startCoroutineUndispatched.<anonymous>.<anonymous>' call
      // Inline function 'kotlin.coroutines.intrinsics.startCoroutineUninterceptedOrReturn' call
      // Inline function 'kotlin.js.asDynamic' call
      var a = _this__u8e3s4;
      tmp = typeof a === 'function' ? a(receiver, actualCompletion) : _this__u8e3s4.gd(receiver, actualCompletion);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.coroutines.resumeWithException' call
        // Inline function 'kotlin.Companion.failure' call
        var tmp$ret$6 = _Result___init__impl__xyqfz8(createFailure(e));
        actualCompletion.j6(tmp$ret$6);
        break $l$block;
      } else {
        throw $p;
      }
    }
    var value = tmp;
    if (!(value === get_COROUTINE_SUSPENDED())) {
      // Inline function 'kotlin.coroutines.resume' call
      // Inline function 'kotlin.Companion.success' call
      var value_0 = (value == null ? true : !(value == null)) ? value : THROW_CCE();
      var tmp$ret$9 = _Result___init__impl__xyqfz8(value_0);
      actualCompletion.j6(tmp$ret$9);
    }
  }
}
var DUMMY_PROCESS_RESULT_FUNCTION;
function get_STATE_REG() {
  _init_properties_Select_kt__zhm2jg();
  return STATE_REG;
}
var STATE_REG;
function get_STATE_COMPLETED() {
  _init_properties_Select_kt__zhm2jg();
  return STATE_COMPLETED;
}
var STATE_COMPLETED;
function get_STATE_CANCELLED() {
  _init_properties_Select_kt__zhm2jg();
  return STATE_CANCELLED;
}
var STATE_CANCELLED;
function get_NO_RESULT() {
  _init_properties_Select_kt__zhm2jg();
  return NO_RESULT;
}
var NO_RESULT;
var PARAM_CLAUSE_0;
function SelectInstance() {
}
function trySelectInternal($this, clauseObject, internalResult) {
  $l$loop: while (true) {
    var curState = $this.s11_1.kotlinx$atomicfu$value;
    if (isInterface(curState, CancellableContinuation)) {
      var tmp0_elvis_lhs = findClause($this, clauseObject);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        continue $l$loop;
      } else {
        tmp = tmp0_elvis_lhs;
      }
      var clause = tmp;
      var onCancellation = clause.e19($this, internalResult);
      if ($this.s11_1.atomicfu$compareAndSet(curState, clause)) {
        var cont = isInterface(curState, CancellableContinuation) ? curState : THROW_CCE();
        $this.u11_1 = internalResult;
        if (tryResume_0(cont, onCancellation))
          return 0;
        $this.u11_1 = get_NO_RESULT();
        return 2;
      }
    } else {
      var tmp_0;
      if (equals(curState, get_STATE_COMPLETED())) {
        tmp_0 = true;
      } else {
        tmp_0 = curState instanceof ClauseData;
      }
      if (tmp_0)
        return 3;
      else {
        if (equals(curState, get_STATE_CANCELLED()))
          return 2;
        else {
          if (equals(curState, get_STATE_REG())) {
            if ($this.s11_1.atomicfu$compareAndSet(curState, listOf_0(clauseObject)))
              return 1;
          } else {
            if (isInterface(curState, List)) {
              if ($this.s11_1.atomicfu$compareAndSet(curState, plus_0(curState, clauseObject)))
                return 1;
            } else {
              var message = 'Unexpected state: ' + toString(curState);
              throw IllegalStateException_init_$Create$(toString(message));
            }
          }
        }
      }
    }
  }
}
function findClause($this, clauseObject) {
  var tmp0_elvis_lhs = $this.t11_1;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var clauses = tmp;
  // Inline function 'kotlin.collections.find' call
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.collections.firstOrNull' call
    var tmp0_iterator = clauses.u();
    while (tmp0_iterator.v()) {
      var element = tmp0_iterator.w();
      // Inline function 'kotlinx.coroutines.selects.SelectImplementation.findClause.<anonymous>' call
      if (element.b19_1 === clauseObject) {
        tmp$ret$1 = element;
        break $l$block;
      }
    }
    tmp$ret$1 = null;
  }
  var tmp1_elvis_lhs = tmp$ret$1;
  var tmp_0;
  if (tmp1_elvis_lhs == null) {
    var message = 'Clause with object ' + toString(clauseObject) + ' is not found';
    throw IllegalStateException_init_$Create$(toString(message));
  } else {
    tmp_0 = tmp1_elvis_lhs;
  }
  return tmp_0;
}
function ClauseData() {
}
protoOf(ClauseData).e19 = function (select, internalResult) {
  var tmp0_safe_receiver = this.d19_1;
  return tmp0_safe_receiver == null ? null : tmp0_safe_receiver(select, this.c19_1, internalResult);
};
function SelectImplementation() {
}
protoOf(SelectImplementation).v11 = function (clauseObject, result) {
  return TrySelectDetailedResult_0(trySelectInternal(this, clauseObject, result));
};
var TrySelectDetailedResult_SUCCESSFUL_instance;
var TrySelectDetailedResult_REREGISTER_instance;
var TrySelectDetailedResult_CANCELLED_instance;
var TrySelectDetailedResult_ALREADY_SELECTED_instance;
var TrySelectDetailedResult_entriesInitialized;
function TrySelectDetailedResult_initEntries() {
  if (TrySelectDetailedResult_entriesInitialized)
    return Unit_instance;
  TrySelectDetailedResult_entriesInitialized = true;
  TrySelectDetailedResult_SUCCESSFUL_instance = new TrySelectDetailedResult('SUCCESSFUL', 0);
  TrySelectDetailedResult_REREGISTER_instance = new TrySelectDetailedResult('REREGISTER', 1);
  TrySelectDetailedResult_CANCELLED_instance = new TrySelectDetailedResult('CANCELLED', 2);
  TrySelectDetailedResult_ALREADY_SELECTED_instance = new TrySelectDetailedResult('ALREADY_SELECTED', 3);
}
function TrySelectDetailedResult(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function TrySelectDetailedResult_0(trySelectInternalResult) {
  _init_properties_Select_kt__zhm2jg();
  var tmp;
  switch (trySelectInternalResult) {
    case 0:
      tmp = TrySelectDetailedResult_SUCCESSFUL_getInstance();
      break;
    case 1:
      tmp = TrySelectDetailedResult_REREGISTER_getInstance();
      break;
    case 2:
      tmp = TrySelectDetailedResult_CANCELLED_getInstance();
      break;
    case 3:
      tmp = TrySelectDetailedResult_ALREADY_SELECTED_getInstance();
      break;
    default:
      var message = 'Unexpected internal result: ' + trySelectInternalResult;
      throw IllegalStateException_init_$Create$(toString(message));
  }
  return tmp;
}
function tryResume_0(_this__u8e3s4, onCancellation) {
  _init_properties_Select_kt__zhm2jg();
  var tmp0_elvis_lhs = _this__u8e3s4.sr(Unit_instance, null, onCancellation);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return false;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var token = tmp;
  _this__u8e3s4.up(token);
  return true;
}
function DUMMY_PROCESS_RESULT_FUNCTION$lambda(_anonymous_parameter_0__qggqh8, _anonymous_parameter_1__qggqgd, _anonymous_parameter_2__qggqfi) {
  _init_properties_Select_kt__zhm2jg();
  return null;
}
function TrySelectDetailedResult_SUCCESSFUL_getInstance() {
  TrySelectDetailedResult_initEntries();
  return TrySelectDetailedResult_SUCCESSFUL_instance;
}
function TrySelectDetailedResult_REREGISTER_getInstance() {
  TrySelectDetailedResult_initEntries();
  return TrySelectDetailedResult_REREGISTER_instance;
}
function TrySelectDetailedResult_CANCELLED_getInstance() {
  TrySelectDetailedResult_initEntries();
  return TrySelectDetailedResult_CANCELLED_instance;
}
function TrySelectDetailedResult_ALREADY_SELECTED_getInstance() {
  TrySelectDetailedResult_initEntries();
  return TrySelectDetailedResult_ALREADY_SELECTED_instance;
}
var properties_initialized_Select_kt_7rpl36;
function _init_properties_Select_kt__zhm2jg() {
  if (!properties_initialized_Select_kt_7rpl36) {
    properties_initialized_Select_kt_7rpl36 = true;
    DUMMY_PROCESS_RESULT_FUNCTION = DUMMY_PROCESS_RESULT_FUNCTION$lambda;
    STATE_REG = new Symbol('STATE_REG');
    STATE_COMPLETED = new Symbol('STATE_COMPLETED');
    STATE_CANCELLED = new Symbol('STATE_CANCELLED');
    NO_RESULT = new Symbol('NO_RESULT');
    PARAM_CLAUSE_0 = new Symbol('PARAM_CLAUSE_0');
  }
}
function get_NO_OWNER() {
  _init_properties_Mutex_kt__jod56b();
  return NO_OWNER;
}
var NO_OWNER;
var ON_LOCK_ALREADY_LOCKED_BY_OWNER;
function Mutex(locked) {
  locked = locked === VOID ? false : locked;
  _init_properties_Mutex_kt__jod56b();
  return new MutexImpl(locked);
}
function MutexImpl$CancellableContinuationWithOwner$tryResume$lambda(this$0, this$1) {
  return function (it) {
    this$0.m19_1.kotlinx$atomicfu$value = this$1.p19_1;
    this$0.r19(this$1.p19_1);
    return Unit_instance;
  };
}
function MutexImpl$CancellableContinuationWithOwner$resume$lambda(this$0, this$1) {
  return function (it) {
    this$0.r19(this$1.p19_1);
    return Unit_instance;
  };
}
function holdsLockImpl($this, owner) {
  $l$loop: while (true) {
    if (!$this.s19())
      return 0;
    var curOwner = $this.m19_1.kotlinx$atomicfu$value;
    if (curOwner === get_NO_OWNER())
      continue $l$loop;
    return curOwner === owner ? 1 : 2;
  }
}
function lockSuspend($this, owner, $completion) {
  // Inline function 'kotlinx.coroutines.suspendCancellableCoroutineReusable.<anonymous>' call
  var cancellable = getOrCreateCancellableContinuation(intercepted($completion));
  try {
    // Inline function 'kotlinx.coroutines.sync.MutexImpl.lockSuspend.<anonymous>' call
    var contWithOwner = new CancellableContinuationWithOwner($this, cancellable, owner);
    $this.acquireCont(contWithOwner);
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
      cancellable.it();
      throw e;
    } else {
      throw $p;
    }
  }
  return cancellable.rq();
}
function tryLockImpl($this, owner) {
  $l$loop: while (true) {
    if ($this.a1a()) {
      // Inline function 'kotlinx.coroutines.assert' call
      $this.m19_1.kotlinx$atomicfu$value = owner;
      return 0;
    } else {
      if (owner == null)
        return 1;
      switch (holdsLockImpl($this, owner)) {
        case 1:
          return 2;
        case 2:
          return 1;
        case 0:
          continue $l$loop;
      }
    }
  }
}
function CancellableContinuationWithOwner($outer, cont, owner) {
  this.q19_1 = $outer;
  this.o19_1 = cont;
  this.p19_1 = owner;
}
protoOf(CancellableContinuationWithOwner).i6 = function () {
  return this.o19_1.i6();
};
protoOf(CancellableContinuationWithOwner).rr = function () {
  return this.o19_1.rr();
};
protoOf(CancellableContinuationWithOwner).qn = function () {
  return this.o19_1.qn();
};
protoOf(CancellableContinuationWithOwner).up = function (token) {
  this.o19_1.up(token);
};
protoOf(CancellableContinuationWithOwner).qq = function (handler) {
  this.o19_1.qq(handler);
};
protoOf(CancellableContinuationWithOwner).b1a = function (result) {
  this.o19_1.j6(result);
};
protoOf(CancellableContinuationWithOwner).j6 = function (result) {
  return this.b1a(result);
};
protoOf(CancellableContinuationWithOwner).tp = function (exception) {
  return this.o19_1.tp(exception);
};
protoOf(CancellableContinuationWithOwner).c1a = function (_this__u8e3s4, value) {
  this.o19_1.tr(_this__u8e3s4, Unit_instance);
};
protoOf(CancellableContinuationWithOwner).tr = function (_this__u8e3s4, value) {
  return this.c1a(_this__u8e3s4, value instanceof Unit ? value : THROW_CCE());
};
protoOf(CancellableContinuationWithOwner).lt = function (segment, index) {
  this.o19_1.lt(segment, index);
};
protoOf(CancellableContinuationWithOwner).d1a = function (value, idempotent, onCancellation) {
  // Inline function 'kotlinx.coroutines.assert' call
  var token = this.o19_1.sr(Unit_instance, idempotent, MutexImpl$CancellableContinuationWithOwner$tryResume$lambda(this.q19_1, this));
  if (!(token == null)) {
    // Inline function 'kotlinx.coroutines.assert' call
    this.q19_1.m19_1.kotlinx$atomicfu$value = this.p19_1;
  }
  return token;
};
protoOf(CancellableContinuationWithOwner).sr = function (value, idempotent, onCancellation) {
  return this.d1a(value instanceof Unit ? value : THROW_CCE(), idempotent, onCancellation);
};
protoOf(CancellableContinuationWithOwner).e1a = function (value, onCancellation) {
  // Inline function 'kotlinx.coroutines.assert' call
  this.q19_1.m19_1.kotlinx$atomicfu$value = this.p19_1;
  this.o19_1.ur(Unit_instance, MutexImpl$CancellableContinuationWithOwner$resume$lambda(this.q19_1, this));
};
protoOf(CancellableContinuationWithOwner).ur = function (value, onCancellation) {
  return this.e1a(value instanceof Unit ? value : THROW_CCE(), onCancellation);
};
function MutexImpl$onSelectCancellationUnlockConstructor$lambda$lambda(this$0, $owner) {
  return function (it) {
    this$0.r19($owner);
    return Unit_instance;
  };
}
function MutexImpl$onSelectCancellationUnlockConstructor$lambda(this$0) {
  return function (_anonymous_parameter_0__qggqh8, owner, _anonymous_parameter_2__qggqfi) {
    return MutexImpl$onSelectCancellationUnlockConstructor$lambda$lambda(this$0, owner);
  };
}
function MutexImpl(locked) {
  SemaphoreImpl.call(this, 1, locked ? 1 : 0);
  this.m19_1 = atomic$ref$1(locked ? null : get_NO_OWNER());
  var tmp = this;
  tmp.n19_1 = MutexImpl$onSelectCancellationUnlockConstructor$lambda(this);
}
protoOf(MutexImpl).s19 = function () {
  return this.f1a() === 0;
};
protoOf(MutexImpl).g1a = function (owner, $completion) {
  if (this.h1a(owner))
    return Unit_instance;
  return lockSuspend(this, owner, $completion);
};
protoOf(MutexImpl).h1a = function (owner) {
  var tmp;
  switch (tryLockImpl(this, owner)) {
    case 0:
      tmp = true;
      break;
    case 1:
      tmp = false;
      break;
    case 2:
      var message = 'This mutex is already locked by the specified owner: ' + toString_0(owner);
      throw IllegalStateException_init_$Create$(toString(message));
    default:
      var message_0 = 'unexpected';
      throw IllegalStateException_init_$Create$(toString(message_0));
  }
  return tmp;
};
protoOf(MutexImpl).r19 = function (owner) {
  $l$loop_0: while (true) {
    // Inline function 'kotlin.check' call
    // Inline function 'kotlin.contracts.contract' call
    if (!this.s19()) {
      // Inline function 'kotlinx.coroutines.sync.MutexImpl.unlock.<anonymous>' call
      var message = 'This mutex is not locked';
      throw IllegalStateException_init_$Create$(toString(message));
    }
    var curOwner = this.m19_1.kotlinx$atomicfu$value;
    if (curOwner === get_NO_OWNER())
      continue $l$loop_0;
    // Inline function 'kotlin.check' call
    // Inline function 'kotlin.contracts.contract' call
    if (!(curOwner === owner ? true : owner == null)) {
      // Inline function 'kotlinx.coroutines.sync.MutexImpl.unlock.<anonymous>' call
      var message_0 = 'This mutex is locked by ' + toString_0(curOwner) + ', but ' + toString_0(owner) + ' is expected';
      throw IllegalStateException_init_$Create$(toString(message_0));
    }
    if (!this.m19_1.atomicfu$compareAndSet(curOwner, get_NO_OWNER()))
      continue $l$loop_0;
    this.mu();
    return Unit_instance;
  }
};
protoOf(MutexImpl).toString = function () {
  return 'Mutex@' + get_hexAddress(this) + '[isLocked=' + this.s19() + ',owner=' + toString_0(this.m19_1.kotlinx$atomicfu$value) + ']';
};
var properties_initialized_Mutex_kt_yv4p3j;
function _init_properties_Mutex_kt__jod56b() {
  if (!properties_initialized_Mutex_kt_yv4p3j) {
    properties_initialized_Mutex_kt_yv4p3j = true;
    NO_OWNER = new Symbol('NO_OWNER');
    ON_LOCK_ALREADY_LOCKED_BY_OWNER = new Symbol('ALREADY_LOCKED_BY_OWNER');
  }
}
function get_MAX_SPIN_CYCLES() {
  _init_properties_Semaphore_kt__t514r6();
  return MAX_SPIN_CYCLES;
}
var MAX_SPIN_CYCLES;
function get_PERMIT() {
  _init_properties_Semaphore_kt__t514r6();
  return PERMIT;
}
var PERMIT;
function get_TAKEN() {
  _init_properties_Semaphore_kt__t514r6();
  return TAKEN;
}
var TAKEN;
function get_BROKEN() {
  _init_properties_Semaphore_kt__t514r6();
  return BROKEN;
}
var BROKEN;
function get_CANCELLED() {
  _init_properties_Semaphore_kt__t514r6();
  return CANCELLED;
}
var CANCELLED;
function get_SEGMENT_SIZE_0() {
  _init_properties_Semaphore_kt__t514r6();
  return SEGMENT_SIZE_0;
}
var SEGMENT_SIZE_0;
function decPermits($this) {
  $l$loop: while (true) {
    var p = $this.y19_1.atomicfu$getAndDecrement();
    if (p > $this.t19_1)
      continue $l$loop;
    return p;
  }
}
function coerceAvailablePermitsAtMaximum($this) {
  $l$loop_0: while (true) {
    var cur = $this.y19_1.kotlinx$atomicfu$value;
    if (cur <= $this.t19_1)
      break $l$loop_0;
    if ($this.y19_1.atomicfu$compareAndSet(cur, $this.t19_1))
      break $l$loop_0;
  }
}
function addAcquireToQueue($this, waiter) {
  var curTail = $this.w19_1.kotlinx$atomicfu$value;
  var enqIdx = $this.x19_1.atomicfu$getAndIncrement$long();
  var createNewSegment = createSegment$ref_0();
  var tmp$ret$2;
  $l$block_2: {
    // Inline function 'kotlinx.coroutines.internal.findSegmentAndMoveForward' call
    var this_0 = $this.w19_1;
    // Inline function 'kotlin.Long.div' call
    var other = get_SEGMENT_SIZE_0();
    var id = enqIdx.ca(toLong(other));
    while (true) {
      var s = findSegmentInternal(curTail, id, createNewSegment);
      var tmp;
      if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(s)) {
        tmp = true;
      } else {
        var tmp$ret$1;
        $l$block_1: {
          // Inline function 'kotlinx.coroutines.internal.moveForward' call
          var to = _SegmentOrClosed___get_segment__impl__jvcr9l(s);
          while (true) {
            // Inline function 'kotlinx.coroutines.internal.moveForward.<anonymous>' call
            var cur = this_0.kotlinx$atomicfu$value;
            if (cur.js_1.o6(to.js_1) >= 0) {
              tmp$ret$1 = true;
              break $l$block_1;
            }
            if (!to.vz()) {
              tmp$ret$1 = false;
              break $l$block_1;
            }
            if (this_0.atomicfu$compareAndSet(cur, to)) {
              if (cur.wz()) {
                cur.y();
              }
              tmp$ret$1 = true;
              break $l$block_1;
            }
            if (to.wz()) {
              to.y();
            }
          }
          tmp$ret$1 = Unit_instance;
        }
        tmp = tmp$ret$1;
      }
      if (tmp) {
        tmp$ret$2 = s;
        break $l$block_2;
      }
    }
  }
  var segment = _SegmentOrClosed___get_segment__impl__jvcr9l(tmp$ret$2);
  // Inline function 'kotlin.Long.rem' call
  var other_0 = get_SEGMENT_SIZE_0();
  var i = enqIdx.nb(toLong(other_0)).ra();
  // Inline function 'kotlinx.coroutines.sync.SemaphoreSegment.cas' call
  if (segment.m1a_1.atomicfu$get(i).atomicfu$compareAndSet(null, waiter)) {
    waiter.lt(segment, i);
    return true;
  }
  // Inline function 'kotlinx.coroutines.sync.SemaphoreSegment.cas' call
  var expected = get_PERMIT();
  var value = get_TAKEN();
  if (segment.m1a_1.atomicfu$get(i).atomicfu$compareAndSet(expected, value)) {
    if (isInterface(waiter, CancellableContinuation)) {
      if (!isInterface(waiter, CancellableContinuation))
        THROW_CCE();
      waiter.ur(Unit_instance, $this.z19_1);
    } else {
      if (isInterface(waiter, SelectInstance)) {
        waiter.a19(Unit_instance);
      } else {
        var message = 'unexpected: ' + waiter;
        throw IllegalStateException_init_$Create$(toString(message));
      }
    }
    return true;
  }
  // Inline function 'kotlinx.coroutines.assert' call
  return false;
}
function tryResumeNextFromQueue($this) {
  var curHead = $this.u19_1.kotlinx$atomicfu$value;
  var deqIdx = $this.v19_1.atomicfu$getAndIncrement$long();
  // Inline function 'kotlin.Long.div' call
  var other = get_SEGMENT_SIZE_0();
  var id = deqIdx.ca(toLong(other));
  var createNewSegment = createSegment$ref_1();
  var tmp$ret$2;
  $l$block_2: {
    // Inline function 'kotlinx.coroutines.internal.findSegmentAndMoveForward' call
    var this_0 = $this.u19_1;
    while (true) {
      var s = findSegmentInternal(curHead, id, createNewSegment);
      var tmp;
      if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(s)) {
        tmp = true;
      } else {
        var tmp$ret$1;
        $l$block_1: {
          // Inline function 'kotlinx.coroutines.internal.moveForward' call
          var to = _SegmentOrClosed___get_segment__impl__jvcr9l(s);
          while (true) {
            // Inline function 'kotlinx.coroutines.internal.moveForward.<anonymous>' call
            var cur = this_0.kotlinx$atomicfu$value;
            if (cur.js_1.o6(to.js_1) >= 0) {
              tmp$ret$1 = true;
              break $l$block_1;
            }
            if (!to.vz()) {
              tmp$ret$1 = false;
              break $l$block_1;
            }
            if (this_0.atomicfu$compareAndSet(cur, to)) {
              if (cur.wz()) {
                cur.y();
              }
              tmp$ret$1 = true;
              break $l$block_1;
            }
            if (to.wz()) {
              to.y();
            }
          }
          tmp$ret$1 = Unit_instance;
        }
        tmp = tmp$ret$1;
      }
      if (tmp) {
        tmp$ret$2 = s;
        break $l$block_2;
      }
    }
  }
  var segment = _SegmentOrClosed___get_segment__impl__jvcr9l(tmp$ret$2);
  segment.d10();
  if (segment.js_1.o6(id) > 0)
    return false;
  // Inline function 'kotlin.Long.rem' call
  var other_0 = get_SEGMENT_SIZE_0();
  var i = deqIdx.nb(toLong(other_0)).ra();
  // Inline function 'kotlinx.coroutines.sync.SemaphoreSegment.getAndSet' call
  var value = get_PERMIT();
  var cellState = segment.m1a_1.atomicfu$get(i).atomicfu$getAndSet(value);
  if (cellState === null) {
    // Inline function 'kotlin.repeat' call
    var times = get_MAX_SPIN_CYCLES();
    // Inline function 'kotlin.contracts.contract' call
    var inductionVariable = 0;
    if (inductionVariable < times)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlinx.coroutines.sync.SemaphoreImpl.tryResumeNextFromQueue.<anonymous>' call
        // Inline function 'kotlinx.coroutines.sync.SemaphoreSegment.get' call
        if (segment.m1a_1.atomicfu$get(i).kotlinx$atomicfu$value === get_TAKEN())
          return true;
      }
       while (inductionVariable < times);
    // Inline function 'kotlinx.coroutines.sync.SemaphoreSegment.cas' call
    var expected = get_PERMIT();
    var value_0 = get_BROKEN();
    return !segment.m1a_1.atomicfu$get(i).atomicfu$compareAndSet(expected, value_0);
  } else if (cellState === get_CANCELLED())
    return false;
  else
    return tryResumeAcquire(cellState, $this);
}
function tryResumeAcquire(_this__u8e3s4, $this) {
  var tmp;
  if (isInterface(_this__u8e3s4, CancellableContinuation)) {
    if (!isInterface(_this__u8e3s4, CancellableContinuation))
      THROW_CCE();
    var token = _this__u8e3s4.sr(Unit_instance, null, $this.z19_1);
    var tmp_0;
    if (!(token == null)) {
      _this__u8e3s4.up(token);
      tmp_0 = true;
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    if (isInterface(_this__u8e3s4, SelectInstance)) {
      tmp = _this__u8e3s4.p11($this, Unit_instance);
    } else {
      var message = 'unexpected: ' + toString(_this__u8e3s4);
      throw IllegalStateException_init_$Create$(toString(message));
    }
  }
  return tmp;
}
function SemaphoreImpl$onCancellationRelease$lambda(this$0) {
  return function (_anonymous_parameter_0__qggqh8) {
    this$0.mu();
    return Unit_instance;
  };
}
function createSegment$ref_0() {
  var l = function (p0, p1) {
    return createSegment_0(p0, p1);
  };
  l.callableName = 'createSegment';
  return l;
}
function createSegment$ref_1() {
  var l = function (p0, p1) {
    return createSegment_0(p0, p1);
  };
  l.callableName = 'createSegment';
  return l;
}
function SemaphoreImpl(permits, acquiredPermits) {
  this.t19_1 = permits;
  this.v19_1 = atomic$long$1(new Long(0, 0));
  this.x19_1 = atomic$long$1(new Long(0, 0));
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(this.t19_1 > 0)) {
    // Inline function 'kotlinx.coroutines.sync.SemaphoreImpl.<anonymous>' call
    var message = 'Semaphore should have at least 1 permit, but had ' + this.t19_1;
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(0 <= acquiredPermits ? acquiredPermits <= this.t19_1 : false)) {
    // Inline function 'kotlinx.coroutines.sync.SemaphoreImpl.<anonymous>' call
    var message_0 = 'The number of acquired permits should be in 0..' + this.t19_1;
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  var s = new SemaphoreSegment(new Long(0, 0), null, 2);
  this.u19_1 = atomic$ref$1(s);
  this.w19_1 = atomic$ref$1(s);
  this.y19_1 = atomic$int$1(this.t19_1 - acquiredPermits | 0);
  var tmp = this;
  tmp.z19_1 = SemaphoreImpl$onCancellationRelease$lambda(this);
}
protoOf(SemaphoreImpl).f1a = function () {
  // Inline function 'kotlin.math.max' call
  var a = this.y19_1.kotlinx$atomicfu$value;
  return Math.max(a, 0);
};
protoOf(SemaphoreImpl).a1a = function () {
  $l$loop: while (true) {
    var p = this.y19_1.kotlinx$atomicfu$value;
    if (p > this.t19_1) {
      coerceAvailablePermitsAtMaximum(this);
      continue $l$loop;
    }
    if (p <= 0)
      return false;
    if (this.y19_1.atomicfu$compareAndSet(p, p - 1 | 0))
      return true;
  }
};
protoOf(SemaphoreImpl).acquireCont = function (waiter) {
  var tmp$ret$0;
  $l$block_0: {
    // Inline function 'kotlinx.coroutines.sync.SemaphoreImpl.acquire' call
    while (true) {
      var p = decPermits(this);
      if (p > 0) {
        // Inline function 'kotlinx.coroutines.sync.SemaphoreImpl.acquire.<anonymous>' call
        waiter.ur(Unit_instance, this.z19_1);
        tmp$ret$0 = Unit_instance;
        break $l$block_0;
      }
      // Inline function 'kotlinx.coroutines.sync.SemaphoreImpl.acquire.<anonymous>' call
      if (addAcquireToQueue(this, isInterface(waiter, Waiter) ? waiter : THROW_CCE())) {
        tmp$ret$0 = Unit_instance;
        break $l$block_0;
      }
    }
  }
  return tmp$ret$0;
};
protoOf(SemaphoreImpl).mu = function () {
  while (true) {
    var p = this.y19_1.atomicfu$getAndIncrement();
    if (p >= this.t19_1) {
      coerceAvailablePermitsAtMaximum(this);
      // Inline function 'kotlin.error' call
      var message = 'The number of released permits cannot be greater than ' + this.t19_1;
      throw IllegalStateException_init_$Create$(toString(message));
    }
    if (p >= 0)
      return Unit_instance;
    if (tryResumeNextFromQueue(this))
      return Unit_instance;
  }
};
function SemaphoreSegment(id, prev, pointers) {
  Segment.call(this, id, prev, pointers);
  this.m1a_1 = atomicfu$AtomicRefArray$ofNulls(get_SEGMENT_SIZE_0());
}
protoOf(SemaphoreSegment).wy = function () {
  return get_SEGMENT_SIZE_0();
};
protoOf(SemaphoreSegment).ls = function (index, cause, context) {
  // Inline function 'kotlinx.coroutines.sync.SemaphoreSegment.set' call
  var value = get_CANCELLED();
  this.m1a_1.atomicfu$get(index).kotlinx$atomicfu$value = value;
  this.tz();
};
protoOf(SemaphoreSegment).toString = function () {
  return 'SemaphoreSegment[id=' + this.js_1.toString() + ', hashCode=' + hashCode(this) + ']';
};
function createSegment_0(id, prev) {
  _init_properties_Semaphore_kt__t514r6();
  return new SemaphoreSegment(id, prev, 0);
}
var properties_initialized_Semaphore_kt_uqcwok;
function _init_properties_Semaphore_kt__t514r6() {
  if (!properties_initialized_Semaphore_kt_uqcwok) {
    properties_initialized_Semaphore_kt_uqcwok = true;
    MAX_SPIN_CYCLES = systemProp('kotlinx.coroutines.semaphore.maxSpinCycles', 100);
    PERMIT = new Symbol('PERMIT');
    TAKEN = new Symbol('TAKEN');
    BROKEN = new Symbol('BROKEN');
    CANCELLED = new Symbol('CANCELLED');
    SEGMENT_SIZE_0 = systemProp('kotlinx.coroutines.semaphore.segmentSize', 16);
  }
}
function CompletionHandlerBase() {
  LinkedListNode.call(this);
}
function invokeIt(_this__u8e3s4, cause) {
  if (typeof _this__u8e3s4 === 'function')
    _this__u8e3s4(cause);
  else {
    // Inline function 'kotlin.js.asDynamic' call
    _this__u8e3s4.invoke(cause);
  }
}
function CancelHandlerBase() {
}
function toDebugString(_this__u8e3s4) {
  return toString(_this__u8e3s4);
}
function get_DefaultDelay() {
  var tmp = Dispatchers_getInstance().ey_1;
  return isInterface(tmp, Delay) ? tmp : THROW_CCE();
}
function createDefaultDispatcher() {
  var tmp;
  if (isJsdom()) {
    tmp = NodeDispatcher_getInstance();
  } else {
    var tmp_0;
    var tmp_1;
    if (!(typeof window === 'undefined')) {
      // Inline function 'kotlin.js.asDynamic' call
      tmp_1 = window != null;
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      // Inline function 'kotlin.js.asDynamic' call
      tmp_0 = !(typeof window.addEventListener === 'undefined');
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = asCoroutineDispatcher(window);
    } else {
      if (typeof process === 'undefined' ? true : typeof process.nextTick === 'undefined') {
        tmp = SetTimeoutDispatcher_getInstance();
      } else {
        tmp = NodeDispatcher_getInstance();
      }
    }
  }
  return tmp;
}
function isJsdom() {
  return ((((!(typeof navigator === 'undefined') ? navigator != null : false) ? navigator.userAgent != null : false) ? !(typeof navigator.userAgent === 'undefined') : false) ? !(typeof navigator.userAgent.match === 'undefined') : false) ? navigator.userAgent.match('\\bjsdom\\b') : false;
}
function newCoroutineContext(_this__u8e3s4, context) {
  var combined = _this__u8e3s4.um().nf(context);
  return (!(combined === Dispatchers_getInstance().ey_1) ? combined.pc(Key_instance) == null : false) ? combined.nf(Dispatchers_getInstance().ey_1) : combined;
}
function get_coroutineName(_this__u8e3s4) {
  return null;
}
var counter;
function get_DEBUG() {
  return DEBUG;
}
var DEBUG;
function get_classSimpleName(_this__u8e3s4) {
  var tmp0_elvis_lhs = getKClassFromExpression(_this__u8e3s4).s6();
  return tmp0_elvis_lhs == null ? 'Unknown' : tmp0_elvis_lhs;
}
function get_hexAddress(_this__u8e3s4) {
  // Inline function 'kotlin.js.asDynamic' call
  var result = _this__u8e3s4.__debug_counter;
  if (!(typeof result === 'number')) {
    counter = counter + 1 | 0;
    result = counter;
    // Inline function 'kotlin.js.asDynamic' call
    _this__u8e3s4.__debug_counter = result;
  }
  return ((!(result == null) ? typeof result === 'number' : false) ? result : THROW_CCE()).toString();
}
function NodeDispatcher() {
  NodeDispatcher_instance = this;
  SetTimeoutBasedDispatcher.call(this);
}
protoOf(NodeDispatcher).p1a = function () {
  process.nextTick(this.w1a_1.u1a_1);
};
var NodeDispatcher_instance;
function NodeDispatcher_getInstance() {
  if (NodeDispatcher_instance == null)
    new NodeDispatcher();
  return NodeDispatcher_instance;
}
function ScheduledMessageQueue$processQueue$lambda(this$0) {
  return function () {
    this$0.a1b();
    return Unit_instance;
  };
}
function ScheduledMessageQueue(dispatcher) {
  MessageQueue.call(this);
  this.t1a_1 = dispatcher;
  var tmp = this;
  tmp.u1a_1 = ScheduledMessageQueue$processQueue$lambda(this);
}
protoOf(ScheduledMessageQueue).b1b = function () {
  this.t1a_1.p1a();
};
protoOf(ScheduledMessageQueue).c1b = function () {
  setTimeout(this.u1a_1, 0);
};
protoOf(ScheduledMessageQueue).d1b = function (timeout) {
  setTimeout(this.u1a_1, timeout);
};
function w3cSetTimeout(handler, timeout) {
  return setTimeout(handler, timeout);
}
function WindowMessageQueue$lambda(this$0) {
  return function (event) {
    var tmp;
    if (event.source == this$0.p1b_1 ? event.data == this$0.q1b_1 : false) {
      event.stopPropagation();
      this$0.a1b();
      tmp = Unit_instance;
    }
    return Unit_instance;
  };
}
function WindowMessageQueue$schedule$lambda(this$0) {
  return function (it) {
    this$0.a1b();
    return Unit_instance;
  };
}
function WindowMessageQueue(window_0) {
  MessageQueue.call(this);
  this.p1b_1 = window_0;
  this.q1b_1 = 'dispatchCoroutine';
  this.p1b_1.addEventListener('message', WindowMessageQueue$lambda(this), true);
}
protoOf(WindowMessageQueue).b1b = function () {
  var tmp = Promise.resolve(Unit_instance);
  tmp.then(WindowMessageQueue$schedule$lambda(this));
};
protoOf(WindowMessageQueue).c1b = function () {
  this.p1b_1.postMessage(this.q1b_1, '*');
};
function w3cSetTimeout_0(window_0, handler, timeout) {
  return setTimeout_0(window_0, handler, timeout);
}
function w3cClearTimeout(window_0, handle) {
  return window_0.clearTimeout(handle);
}
function w3cClearTimeout_0(handle) {
  return clearTimeout(handle);
}
function setTimeout_0(window_0, handler, timeout) {
  return window_0.setTimeout(handler, timeout);
}
function asCoroutineDispatcher(_this__u8e3s4) {
  // Inline function 'kotlin.js.asDynamic' call
  var tmp0_elvis_lhs = _this__u8e3s4.coroutineDispatcher;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlin.also' call
    var this_0 = new WindowDispatcher(_this__u8e3s4);
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'kotlinx.coroutines.asCoroutineDispatcher.<anonymous>' call
    // Inline function 'kotlin.js.asDynamic' call
    _this__u8e3s4.coroutineDispatcher = this_0;
    tmp = this_0;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function propagateExceptionFinalResort(exception) {
  console.error(exception.toString());
}
function Dispatchers() {
  Dispatchers_instance = this;
  this.ey_1 = createDefaultDispatcher();
  this.fy_1 = Unconfined_getInstance();
  this.gy_1 = new JsMainDispatcher(this.ey_1, false);
  this.hy_1 = null;
}
protoOf(Dispatchers).iy = function () {
  var tmp0_elvis_lhs = this.hy_1;
  return tmp0_elvis_lhs == null ? this.gy_1 : tmp0_elvis_lhs;
};
var Dispatchers_instance;
function Dispatchers_getInstance() {
  if (Dispatchers_instance == null)
    new Dispatchers();
  return Dispatchers_instance;
}
function JsMainDispatcher(delegate, invokeImmediately) {
  MainCoroutineDispatcher.call(this);
  this.s1b_1 = delegate;
  this.t1b_1 = invokeImmediately;
  this.u1b_1 = this.t1b_1 ? this : new JsMainDispatcher(this.s1b_1, true);
}
protoOf(JsMainDispatcher).cy = function () {
  return this.u1b_1;
};
protoOf(JsMainDispatcher).ku = function (context) {
  return !this.t1b_1;
};
protoOf(JsMainDispatcher).lu = function (context, block) {
  return this.s1b_1.lu(context, block);
};
protoOf(JsMainDispatcher).toString = function () {
  var tmp0_elvis_lhs = this.dy();
  return tmp0_elvis_lhs == null ? this.s1b_1.toString() : tmp0_elvis_lhs;
};
function createEventLoop() {
  return new UnconfinedEventLoop();
}
function UnconfinedEventLoop() {
  EventLoop.call(this);
}
protoOf(UnconfinedEventLoop).lu = function (context, block) {
  unsupported();
};
function unsupported() {
  throw UnsupportedOperationException_init_$Create$('runBlocking event loop is not supported');
}
function JobCancellationException(message, cause, job) {
  CancellationException_init_$Init$(message, cause, this);
  captureStack(this, JobCancellationException);
  this.z1b_1 = job;
}
protoOf(JobCancellationException).toString = function () {
  return protoOf(CancellationException).toString.call(this) + '; job=' + this.z1b_1;
};
protoOf(JobCancellationException).equals = function (other) {
  var tmp;
  if (other === this) {
    tmp = true;
  } else {
    var tmp_0;
    var tmp_1;
    var tmp_2;
    if (other instanceof JobCancellationException) {
      tmp_2 = other.message == this.message;
    } else {
      tmp_2 = false;
    }
    if (tmp_2) {
      tmp_1 = equals(other.z1b_1, this.z1b_1);
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = equals(other.cause, this.cause);
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(JobCancellationException).hashCode = function () {
  var tmp = imul(imul(getStringHashCode(ensureNotNull(this.message)), 31) + hashCode(this.z1b_1) | 0, 31);
  var tmp0_safe_receiver = this.cause;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
  return tmp + (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs) | 0;
};
function Runnable() {
}
function SchedulerTask() {
}
function get_taskContext(_this__u8e3s4) {
  return TaskContext_instance;
}
function TaskContext() {
}
var TaskContext_instance;
function TaskContext_getInstance() {
  return TaskContext_instance;
}
function AbortFlowException(owner) {
  CancellationException_init_$Init$_0('Flow was aborted, no more elements needed', this);
  captureStack(this, AbortFlowException);
  this.t16_1 = owner;
}
function SafeCollector$collectContextSize$lambda(count, _anonymous_parameter_1__qggqgd) {
  return count + 1 | 0;
}
function SafeCollector(collector, collectContext) {
  this.u16_1 = collector;
  this.v16_1 = collectContext;
  var tmp = this;
  tmp.w16_1 = this.v16_1.mf(0, SafeCollector$collectContextSize$lambda);
  this.x16_1 = null;
}
protoOf(SafeCollector).a14 = function (value, $completion) {
  // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
  // Inline function 'kotlin.js.getCoroutineContext' call
  var currentContext = $completion.i6();
  ensureActive(currentContext);
  if (!(this.x16_1 === currentContext)) {
    checkContext(this, currentContext);
    this.x16_1 = currentContext;
  }
  return this.u16_1.a14(value, $completion);
};
protoOf(SafeCollector).j17 = function () {
};
function identitySet(expectedSize) {
  return HashSet_init_$Create$(expectedSize);
}
function get_platformExceptionHandlers_() {
  _init_properties_CoroutineExceptionHandlerImpl_kt__37d7wf();
  return platformExceptionHandlers_;
}
var platformExceptionHandlers_;
function get_platformExceptionHandlers() {
  _init_properties_CoroutineExceptionHandlerImpl_kt__37d7wf();
  return get_platformExceptionHandlers_();
}
function DiagnosticCoroutineContextException(context) {
  RuntimeException_init_$Init$_0(toString(context), this);
  captureStack(this, DiagnosticCoroutineContextException);
}
var properties_initialized_CoroutineExceptionHandlerImpl_kt_qhrgvx;
function _init_properties_CoroutineExceptionHandlerImpl_kt__37d7wf() {
  if (!properties_initialized_CoroutineExceptionHandlerImpl_kt_qhrgvx) {
    properties_initialized_CoroutineExceptionHandlerImpl_kt_qhrgvx = true;
    // Inline function 'kotlin.collections.mutableSetOf' call
    platformExceptionHandlers_ = LinkedHashSet_init_$Create$();
  }
}
function SetTimeoutDispatcher() {
  SetTimeoutDispatcher_instance = this;
  SetTimeoutBasedDispatcher.call(this);
}
protoOf(SetTimeoutDispatcher).p1a = function () {
  this.w1a_1.d1b(0);
};
var SetTimeoutDispatcher_instance;
function SetTimeoutDispatcher_getInstance() {
  if (SetTimeoutDispatcher_instance == null)
    new SetTimeoutDispatcher();
  return SetTimeoutDispatcher_instance;
}
function SetTimeoutBasedDispatcher$scheduleResumeAfterDelay$lambda($continuation, this$0) {
  return function () {
    // Inline function 'kotlin.with' call
    // Inline function 'kotlin.contracts.contract' call
    $continuation.tr(this$0, Unit_instance);
    return Unit_instance;
  };
}
function SetTimeoutBasedDispatcher() {
  CoroutineDispatcher.call(this);
  this.w1a_1 = new ScheduledMessageQueue(this);
}
protoOf(SetTimeoutBasedDispatcher).lu = function (context, block) {
  this.w1a_1.l1b(block);
};
protoOf(SetTimeoutBasedDispatcher).qu = function (timeMillis, continuation) {
  var handle = w3cSetTimeout(SetTimeoutBasedDispatcher$scheduleResumeAfterDelay$lambda(continuation, this), delayToInt(timeMillis));
  // Inline function 'kotlinx.coroutines.asHandler' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$1 = new ClearTimeout(handle);
  continuation.qq(tmp$ret$1);
};
function MessageQueue() {
  this.x1a_1 = ArrayDeque_init_$Create$();
  this.y1a_1 = 16;
  this.z1a_1 = false;
}
protoOf(MessageQueue).n = function () {
  return this.x1a_1.ud_1;
};
protoOf(MessageQueue).e1b = function (index, element) {
  this.x1a_1.r1(index, element);
};
protoOf(MessageQueue).r1 = function (index, element) {
  return this.e1b(index, (!(element == null) ? isInterface(element, Runnable) : false) ? element : THROW_CCE());
};
protoOf(MessageQueue).f1b = function (element) {
  return this.x1a_1.r(element);
};
protoOf(MessageQueue).r = function (element) {
  return this.f1b((!(element == null) ? isInterface(element, Runnable) : false) ? element : THROW_CCE());
};
protoOf(MessageQueue).g1b = function (elements) {
  return this.x1a_1.s(elements);
};
protoOf(MessageQueue).s = function (elements) {
  return this.g1b(elements);
};
protoOf(MessageQueue).x = function () {
  this.x1a_1.x();
};
protoOf(MessageQueue).h1b = function (element) {
  return this.x1a_1.z(element);
};
protoOf(MessageQueue).z = function (element) {
  if (!(!(element == null) ? isInterface(element, Runnable) : false))
    return false;
  return this.h1b((!(element == null) ? isInterface(element, Runnable) : false) ? element : THROW_CCE());
};
protoOf(MessageQueue).i1b = function (elements) {
  return this.x1a_1.a1(elements);
};
protoOf(MessageQueue).a1 = function (elements) {
  return this.i1b(elements);
};
protoOf(MessageQueue).f1 = function (index) {
  return this.x1a_1.f1(index);
};
protoOf(MessageQueue).j1b = function (element) {
  return this.x1a_1.t1(element);
};
protoOf(MessageQueue).t1 = function (element) {
  if (!(!(element == null) ? isInterface(element, Runnable) : false))
    return -1;
  return this.j1b((!(element == null) ? isInterface(element, Runnable) : false) ? element : THROW_CCE());
};
protoOf(MessageQueue).b1 = function () {
  return this.x1a_1.b1();
};
protoOf(MessageQueue).u = function () {
  return this.x1a_1.u();
};
protoOf(MessageQueue).h1 = function (index) {
  return this.x1a_1.h1(index);
};
protoOf(MessageQueue).k1b = function (index, element) {
  return this.x1a_1.o(index, element);
};
protoOf(MessageQueue).o = function (index, element) {
  return this.k1b(index, (!(element == null) ? isInterface(element, Runnable) : false) ? element : THROW_CCE());
};
protoOf(MessageQueue).v1 = function (fromIndex, toIndex) {
  return this.x1a_1.v1(fromIndex, toIndex);
};
protoOf(MessageQueue).l1b = function (element) {
  this.f1b(element);
  if (!this.z1a_1) {
    this.z1a_1 = true;
    this.b1b();
  }
};
protoOf(MessageQueue).a1b = function () {
  try {
    // Inline function 'kotlin.repeat' call
    var times = this.y1a_1;
    // Inline function 'kotlin.contracts.contract' call
    var inductionVariable = 0;
    if (inductionVariable < times)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlinx.coroutines.MessageQueue.process.<anonymous>' call
        var tmp0_elvis_lhs = removeFirstOrNull(this);
        var tmp;
        if (tmp0_elvis_lhs == null) {
          return Unit_instance;
        } else {
          tmp = tmp0_elvis_lhs;
        }
        var element = tmp;
        element.nt();
      }
       while (inductionVariable < times);
  }finally {
    if (this.b1()) {
      this.z1a_1 = false;
    } else {
      this.c1b();
    }
  }
};
function WindowClearTimeout($outer, handle) {
  this.d1c_1 = $outer;
  ClearTimeout.call(this, handle);
}
protoOf(WindowClearTimeout).mp = function () {
  w3cClearTimeout(this.d1c_1.f1c_1, this.h1c_1);
};
function WindowDispatcher$scheduleResumeAfterDelay$lambda($continuation, this$0) {
  return function () {
    // Inline function 'kotlin.with' call
    // Inline function 'kotlin.contracts.contract' call
    $continuation.tr(this$0, Unit_instance);
    return Unit_instance;
  };
}
function WindowDispatcher(window_0) {
  CoroutineDispatcher.call(this);
  this.f1c_1 = window_0;
  this.g1c_1 = new WindowMessageQueue(this.f1c_1);
}
protoOf(WindowDispatcher).lu = function (context, block) {
  return this.g1c_1.l1b(block);
};
protoOf(WindowDispatcher).qu = function (timeMillis, continuation) {
  var handle = w3cSetTimeout_0(this.f1c_1, WindowDispatcher$scheduleResumeAfterDelay$lambda(continuation, this), delayToInt(timeMillis));
  // Inline function 'kotlinx.coroutines.asHandler' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$1 = new WindowClearTimeout(this, handle);
  continuation.qq(tmp$ret$1);
};
function delayToInt(timeMillis) {
  return coerceIn(timeMillis, new Long(0, 0), new Long(2147483647, 0)).ra();
}
function ClearTimeout(handle) {
  CancelHandler.call(this);
  this.h1c_1 = handle;
}
protoOf(ClearTimeout).mp = function () {
  w3cClearTimeout_0(this.h1c_1);
};
protoOf(ClearTimeout).np = function (cause) {
  this.mp();
};
protoOf(ClearTimeout).invoke = function (cause) {
  return this.np(cause);
};
protoOf(ClearTimeout).toString = function () {
  return 'ClearTimeout[' + this.h1c_1 + ']';
};
function LinkedListHead() {
  LinkedListNode.call(this);
}
protoOf(LinkedListHead).fq = function () {
  throw UnsupportedOperationException_init_$Create$_0();
};
function LinkedListNode() {
  this.bq_1 = this;
  this.cq_1 = this;
  this.dq_1 = false;
}
protoOf(LinkedListNode).eq = function (node) {
  var prev = this.cq_1;
  node.bq_1 = this;
  node.cq_1 = prev;
  prev.bq_1 = node;
  this.cq_1 = node;
};
protoOf(LinkedListNode).fq = function () {
  return this.gq();
};
protoOf(LinkedListNode).mp = function () {
  this.fq();
};
protoOf(LinkedListNode).gq = function () {
  if (this.dq_1)
    return false;
  var prev = this.cq_1;
  var next = this.bq_1;
  prev.bq_1 = next;
  next.cq_1 = prev;
  this.dq_1 = true;
  return true;
};
protoOf(LinkedListNode).hq = function (node) {
  if (!(this.bq_1 === this))
    return false;
  this.eq(node);
  return true;
};
function unwrap(exception) {
  return exception;
}
function recoverStackTrace(exception, continuation) {
  return exception;
}
function recoverStackTrace_0(exception) {
  return exception;
}
function SynchronizedObject() {
}
function systemProp_1(propertyName) {
  return null;
}
function threadContextElements(context) {
  return 0;
}
function CommonThreadLocal() {
  this.ev_1 = null;
}
protoOf(CommonThreadLocal).fv = function () {
  var tmp = this.ev_1;
  return (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
};
protoOf(CommonThreadLocal).gv = function (value) {
  this.ev_1 = value;
};
function commonThreadLocal(name) {
  return new CommonThreadLocal();
}
//region block: post-declaration
protoOf(JobSupport).yn = invokeOnCompletion$default;
protoOf(JobSupport).co = cancel$default;
protoOf(JobSupport).nf = plus;
protoOf(JobSupport).pc = get_0;
protoOf(JobSupport).mf = fold;
protoOf(JobSupport).lf = minusKey_0;
protoOf(CoroutineDispatcher).pc = get;
protoOf(CoroutineDispatcher).lf = minusKey;
protoOf(BufferedChannel).k12 = close$default;
protoOf(BufferedChannel).m12 = cancel$default_0;
//endregion
//region block: init
Active_instance = new Active();
Key_instance_1 = new Key_0();
Key_instance_2 = new Key_1();
GlobalScope_instance = new GlobalScope();
Key_instance_3 = new Key_2();
NonDisposableHandle_instance = new NonDisposableHandle();
Key_instance_4 = new Key_3();
SENDERS_COUNTER_MASK = new Long(-1, 268435455);
DEFAULT_CLOSE_MESSAGE = 'Channel was closed';
MODE_CANCELLABLE = 1;
MODE_CANCELLABLE_REUSABLE = 2;
MODE_UNINITIALIZED = -1;
MODE_UNDISPATCHED = 4;
MODE_ATOMIC = 0;
counter = 0;
DEBUG = false;
TaskContext_instance = new TaskContext();
//endregion
//region block: exports
export {
  firstOrNull as firstOrNull3jjcu7fygcopr,
  awaitAll as awaitAll3u8r91uegk3sa,
  delay as delayolwo40i9ucjz,
  cancel$default as cancel$default2y9qiqa2pd5sh,
  invokeOnCompletion$default as invokeOnCompletion$default32r7l1ykbkzvm,
  _ChannelResult___get_isSuccess__impl__odq1z9 as _ChannelResult___get_isSuccess__impl__odq1z912klyyef6kn9b,
  Factory_getInstance as Factory_getInstance11pxe45am9y7d,
  Key_getInstance as Key_getInstance2js7sv2agqob1,
  Key_instance_1 as Key_instance2ye2t23iqghop,
  Dispatchers_getInstance as Dispatchers_getInstanceitgtkvqfcnx3,
  GlobalScope_instance as GlobalScope_instance1sfulufhd2ijt,
  Key_instance_3 as Key_instance2tirv2rj82ml4,
  Channel as Channel3r72atmcithql,
  cancelConsumed as cancelConsumed2i0oizqhmljf6,
  MutableStateFlow as MutableStateFlow34bfoyvwu8czu,
  asFlow as asFlow3ngsnn5xpz8pw,
  asStateFlow as asStateFlow34rribx643ke5,
  LinkedListNode as LinkedListNode3tts9l6uzdsny,
  recoverStackTrace as recoverStackTrace2i3si2i8nvw1k,
  Mutex as Mutex16li1l0asjv17,
  CancellableContinuationImpl as CancellableContinuationImpl1cx201opicavg,
  CompletableDeferred as CompletableDeferred2lnqvsbvx74d3,
  CompletableJob as CompletableJob1w6swnu15iclo,
  CoroutineName as CoroutineName2g5zosw74tf0f,
  CoroutineScope_0 as CoroutineScopelux7s7zphw7e,
  CoroutineScope as CoroutineScopefcb5f5dwqcas,
  Job_0 as Job13y4jkazwjho0,
  Job as Job29shfjfygy86k,
  get_MODE_CANCELLABLE as get_MODE_CANCELLABLE3br9qqv7xeh9e,
  SupervisorJob as SupervisorJobythnfxkr3jxc,
  async as asyncz02dsa2nb2zt,
  cancel as cancel36mj9lv3a0whl,
  cancel_2 as cancel2en0dn4yvpufo,
  cancel_0 as cancel2ztysw4v4hav6,
  cancel_1 as cancel1xim2hrvjmwpn,
  get_isActive as get_isActivehakov5bm97hw,
  get_job as get_job2zvlvce9o9a29,
  launch as launch1c91vkjzdi9sd,
};
//endregion

//# sourceMappingURL=kotlinx-coroutines-core.mjs.map
