import {
  protoOf180f3jzyo7rfj as protoOf,
  interfaceMeta1u1l5puptm1ve as interfaceMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  VOID7hggqo3abtya as VOID,
  ArrayList_init_$Create$2qnngtk1et9r9 as ArrayList_init_$Create$,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  CoroutineImpl2sn3kjnwmfr10 as CoroutineImpl,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  isInterface3d6p8outrmvmk as isInterface,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  classMetawt99a3kyl3us as classMeta,
  toString1pkumu07cwy4m as toString,
  IllegalStateException_init_$Create$3ib9qa3pip8n4 as IllegalStateException_init_$Create$,
  IllegalArgumentException_init_$Create$310sysrobvll9 as IllegalArgumentException_init_$Create$,
  getKClassFromExpression3vpejubogshaw as getKClassFromExpression,
  Map140uvy3s5zad8 as Map,
  Setjrjc7fhfd6b9 as Set,
  firstOrNull1gk7vzkf4h3nq as firstOrNull,
  StringCompanionObject_instance3alxothmy382k as StringCompanionObject_instance,
  isArray1hxjqtqy632bc as isArray,
  List3hktaavzmj137 as List,
  filterNotNull3qfgcwmxhwfxe as filterNotNull,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  ArrayList_init_$Create$1s1wkrw82c0iw as ArrayList_init_$Create$_0,
  HashSet_init_$Create$1urd5csbv51lq as HashSet_init_$Create$,
  singleOrNullrknfaxokm1sl as singleOrNull,
  Collection1k04j3hzsbod0 as Collection,
  emptyList1g2z5xcrvp2zy as emptyList,
} from './kotlin-kotlin-stdlib.mjs';
import {
  KSerializerzf77vz1967fq as KSerializer,
  BinaryFormat3f3aelhmz0ro1 as BinaryFormat,
  StringFormat2r2ka8mzcb3mi as StringFormat,
  SerializationExceptioneqrdve3ts2n9 as SerializationException,
  serializerOrNull31x2b6nu6gruj as serializerOrNull,
  serializer1rka18p0rjk4x as serializer,
  MapSerializer11kmegt3g5c1g as MapSerializer,
  SetSerializert3lb0yy9iftr as SetSerializer,
  serializer1x79l67jvwntn as serializer_0,
  ListSerializer1hxuk9dx5n9du as ListSerializer,
  get_nullable197rfua9r7fsz as get_nullable,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
import {
  ByteArrayContent9zol65b22hp0 as ByteArrayContent,
  withCharsetIfNeeded3sz33ys0x9vfx as withCharsetIfNeeded,
  TextContent1rb6ftlpvl1d2 as TextContent,
  OutgoingContent3t2ohmyam9o76 as OutgoingContent,
} from './ktor-ktor-http.mjs';
import {
  asFlow3ngsnn5xpz8pw as asFlow,
  firstOrNull3jjcu7fygcopr as firstOrNull_0,
} from './kotlinx-coroutines-core.mjs';
import {
  discard2nktejhnnvzvk as discard,
  readBytes2b47ed7nra7rg as readBytes,
  readText3x4cv5p7hylp as readText,
} from './ktor-ktor-io.mjs';
import {
  JsonConvertExceptiongnc5x6xwaf77 as JsonConvertException,
  ContentConverteryzo4k0ursexh as ContentConverter,
} from './ktor-ktor-serialization.mjs';
//region block: imports
//endregion
//region block: pre-declaration
setMetadataFor(KotlinxSerializationExtension, 'KotlinxSerializationExtension', interfaceMeta, VOID, VOID, VOID, VOID, VOID, [4, 3]);
setMetadataFor(KotlinxSerializationConverter$serializeNullable$o$collect$slambda, 'KotlinxSerializationConverter$serializeNullable$o$collect$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor($collectCOROUTINE$2, '$collectCOROUTINE$2', classMeta, CoroutineImpl);
setMetadataFor(KotlinxSerializationConverter$deserialize$o$collect$slambda, 'KotlinxSerializationConverter$deserialize$o$collect$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor($collectCOROUTINE$3, '$collectCOROUTINE$3', classMeta, CoroutineImpl);
setMetadataFor(sam$kotlinx_coroutines_flow_FlowCollector$0, 'sam$kotlinx_coroutines_flow_FlowCollector$0', classMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(sam$kotlinx_coroutines_flow_FlowCollector$0_0, 'sam$kotlinx_coroutines_flow_FlowCollector$0', classMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(_no_name_provided__qut3iv, VOID, classMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(KotlinxSerializationConverter$serializeNullable$slambda, 'KotlinxSerializationConverter$serializeNullable$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(_no_name_provided__qut3iv_0, VOID, classMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(KotlinxSerializationConverter$deserialize$slambda, 'KotlinxSerializationConverter$deserialize$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor($serializeNullableCOROUTINE$0, '$serializeNullableCOROUTINE$0', classMeta, CoroutineImpl);
setMetadataFor($deserializeCOROUTINE$1, '$deserializeCOROUTINE$1', classMeta, CoroutineImpl);
setMetadataFor(KotlinxSerializationConverter, 'KotlinxSerializationConverter', classMeta, VOID, [ContentConverter], VOID, VOID, VOID, [4, 3]);
//endregion
function KotlinxSerializationExtension() {
}
function extensions(format) {
  // Inline function 'kotlin.collections.mapNotNull' call
  // Inline function 'kotlin.collections.mapNotNullTo' call
  var this_0 = get_providers();
  var destination = ArrayList_init_$Create$();
  // Inline function 'kotlin.collections.forEach' call
  var tmp0_iterator = this_0.u();
  while (tmp0_iterator.v()) {
    var element = tmp0_iterator.w();
    // Inline function 'kotlin.collections.mapNotNullTo.<anonymous>' call
    // Inline function 'io.ktor.serialization.kotlinx.extensions.<anonymous>' call
    var tmp0_safe_receiver = element.y4b(format);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.contracts.contract' call
      destination.r(tmp0_safe_receiver);
    }
  }
  return destination;
}
function serialization(_this__u8e3s4, contentType, format) {
  _this__u8e3s4.b2e(contentType, new KotlinxSerializationConverter(format));
}
function KotlinxSerializationConverter$serializeNullable$o$collect$slambda($$this$unsafeFlow, $contentType, $charset, $typeInfo, $value, resultContinuation) {
  this.h4c_1 = $$this$unsafeFlow;
  this.i4c_1 = $contentType;
  this.j4c_1 = $charset;
  this.k4c_1 = $typeInfo;
  this.l4c_1 = $value;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(KotlinxSerializationConverter$serializeNullable$o$collect$slambda).r4c = function (value, $completion) {
  var tmp = this.s4c(value, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(KotlinxSerializationConverter$serializeNullable$o$collect$slambda).gd = function (p1, $completion) {
  return this.r4c((!(p1 == null) ? isInterface(p1, KotlinxSerializationExtension) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(KotlinxSerializationConverter$serializeNullable$o$collect$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          var tmp_0 = this;
          tmp_0.n4c_1 = this.h4c_1;
          var tmp_1 = this;
          tmp_1.o4c_1 = this.m4c_1;
          var tmp_2 = this;
          tmp_2.p4c_1 = this.o4c_1;
          this.ic_1 = 1;
          suspendResult = this.p4c_1.x4b(this.i4c_1, this.j4c_1, this.k4c_1, this.l4c_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.q4c_1 = suspendResult;
          this.ic_1 = 2;
          suspendResult = this.n4c_1.a14(this.q4c_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          return Unit_instance;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
protoOf(KotlinxSerializationConverter$serializeNullable$o$collect$slambda).s4c = function (value, completion) {
  var i = new KotlinxSerializationConverter$serializeNullable$o$collect$slambda(this.h4c_1, this.i4c_1, this.j4c_1, this.k4c_1, this.l4c_1, completion);
  i.m4c_1 = value;
  return i;
};
function KotlinxSerializationConverter$serializeNullable$o$collect$slambda_0($$this$unsafeFlow, $contentType, $charset, $typeInfo, $value, resultContinuation) {
  var i = new KotlinxSerializationConverter$serializeNullable$o$collect$slambda($$this$unsafeFlow, $contentType, $charset, $typeInfo, $value, resultContinuation);
  var l = function (value, $completion) {
    return i.r4c(value, $completion);
  };
  l.$arity = 1;
  return l;
}
function $collectCOROUTINE$2(_this__u8e3s4, collector, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.b4d_1 = _this__u8e3s4;
  this.c4d_1 = collector;
}
protoOf($collectCOROUTINE$2).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          var tmp_0 = this;
          tmp_0.d4d_1 = this.c4d_1;
          this.ic_1 = 1;
          var tmp_1 = KotlinxSerializationConverter$serializeNullable$o$collect$slambda_0(this.d4d_1, this.b4d_1.f4d_1, this.b4d_1.g4d_1, this.b4d_1.h4d_1, this.b4d_1.i4d_1, null);
          suspendResult = this.b4d_1.e4d_1.b14(new sam$kotlinx_coroutines_flow_FlowCollector$0(tmp_1), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          return Unit_instance;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function KotlinxSerializationConverter$deserialize$o$collect$slambda($$this$unsafeFlow, $charset, $typeInfo, $content, resultContinuation) {
  this.r4d_1 = $$this$unsafeFlow;
  this.s4d_1 = $charset;
  this.t4d_1 = $typeInfo;
  this.u4d_1 = $content;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(KotlinxSerializationConverter$deserialize$o$collect$slambda).r4c = function (value, $completion) {
  var tmp = this.s4c(value, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(KotlinxSerializationConverter$deserialize$o$collect$slambda).gd = function (p1, $completion) {
  return this.r4c((!(p1 == null) ? isInterface(p1, KotlinxSerializationExtension) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(KotlinxSerializationConverter$deserialize$o$collect$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          var tmp_0 = this;
          tmp_0.w4d_1 = this.r4d_1;
          var tmp_1 = this;
          tmp_1.x4d_1 = this.v4d_1;
          var tmp_2 = this;
          tmp_2.y4d_1 = this.x4d_1;
          this.ic_1 = 1;
          suspendResult = this.y4d_1.e2e(this.s4d_1, this.t4d_1, this.u4d_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.z4d_1 = suspendResult;
          this.ic_1 = 2;
          suspendResult = this.w4d_1.a14(this.z4d_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          return Unit_instance;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
protoOf(KotlinxSerializationConverter$deserialize$o$collect$slambda).s4c = function (value, completion) {
  var i = new KotlinxSerializationConverter$deserialize$o$collect$slambda(this.r4d_1, this.s4d_1, this.t4d_1, this.u4d_1, completion);
  i.v4d_1 = value;
  return i;
};
function KotlinxSerializationConverter$deserialize$o$collect$slambda_0($$this$unsafeFlow, $charset, $typeInfo, $content, resultContinuation) {
  var i = new KotlinxSerializationConverter$deserialize$o$collect$slambda($$this$unsafeFlow, $charset, $typeInfo, $content, resultContinuation);
  var l = function (value, $completion) {
    return i.r4c(value, $completion);
  };
  l.$arity = 1;
  return l;
}
function $collectCOROUTINE$3(_this__u8e3s4, collector, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.i4e_1 = _this__u8e3s4;
  this.j4e_1 = collector;
}
protoOf($collectCOROUTINE$3).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          var tmp_0 = this;
          tmp_0.k4e_1 = this.j4e_1;
          this.ic_1 = 1;
          var tmp_1 = KotlinxSerializationConverter$deserialize$o$collect$slambda_0(this.k4e_1, this.i4e_1.m4e_1, this.i4e_1.n4e_1, this.i4e_1.o4e_1, null);
          suspendResult = this.i4e_1.l4e_1.b14(new sam$kotlinx_coroutines_flow_FlowCollector$0_0(tmp_1), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          return Unit_instance;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function serializeContent($this, serializer, format, value, contentType, charset) {
  var tmp;
  if (isInterface(format, StringFormat)) {
    var content = format.g3s(isInterface(serializer, KSerializer) ? serializer : THROW_CCE(), value);
    tmp = new TextContent(content, withCharsetIfNeeded(contentType, charset));
  } else {
    if (isInterface(format, BinaryFormat)) {
      var content_0 = format.i3s(isInterface(serializer, KSerializer) ? serializer : THROW_CCE(), value);
      tmp = new ByteArrayContent(content_0, contentType);
    } else {
      var message = 'Unsupported format ' + format;
      throw IllegalStateException_init_$Create$(toString(message));
    }
  }
  return tmp;
}
function sam$kotlinx_coroutines_flow_FlowCollector$0(function_0) {
  this.p4e_1 = function_0;
}
protoOf(sam$kotlinx_coroutines_flow_FlowCollector$0).a14 = function (value, $completion) {
  return this.p4e_1(value, $completion);
};
function sam$kotlinx_coroutines_flow_FlowCollector$0_0(function_0) {
  this.q4e_1 = function_0;
}
protoOf(sam$kotlinx_coroutines_flow_FlowCollector$0_0).a14 = function (value, $completion) {
  return this.q4e_1(value, $completion);
};
function _no_name_provided__qut3iv($this, $contentType, $charset, $typeInfo, $value) {
  this.e4d_1 = $this;
  this.f4d_1 = $contentType;
  this.g4d_1 = $charset;
  this.h4d_1 = $typeInfo;
  this.i4d_1 = $value;
}
protoOf(_no_name_provided__qut3iv).r4e = function (collector, $completion) {
  var tmp = new $collectCOROUTINE$2(this, collector, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(_no_name_provided__qut3iv).b14 = function (collector, $completion) {
  return this.r4e(collector, $completion);
};
function KotlinxSerializationConverter$serializeNullable$slambda(resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(KotlinxSerializationConverter$serializeNullable$slambda).b4f = function (it, $completion) {
  var tmp = this.c4f(it, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(KotlinxSerializationConverter$serializeNullable$slambda).gd = function (p1, $completion) {
  return this.b4f((p1 == null ? true : p1 instanceof OutgoingContent) ? p1 : THROW_CCE(), $completion);
};
protoOf(KotlinxSerializationConverter$serializeNullable$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      if (tmp === 0) {
        this.jc_1 = 1;
        return !(this.a4f_1 == null);
      } else if (tmp === 1) {
        throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      throw e;
    }
   while (true);
};
protoOf(KotlinxSerializationConverter$serializeNullable$slambda).c4f = function (it, completion) {
  var i = new KotlinxSerializationConverter$serializeNullable$slambda(completion);
  i.a4f_1 = it;
  return i;
};
function KotlinxSerializationConverter$serializeNullable$slambda_0(resultContinuation) {
  var i = new KotlinxSerializationConverter$serializeNullable$slambda(resultContinuation);
  var l = function (it, $completion) {
    return i.b4f(it, $completion);
  };
  l.$arity = 1;
  return l;
}
function _no_name_provided__qut3iv_0($this, $charset, $typeInfo, $content) {
  this.l4e_1 = $this;
  this.m4e_1 = $charset;
  this.n4e_1 = $typeInfo;
  this.o4e_1 = $content;
}
protoOf(_no_name_provided__qut3iv_0).a2g = function (collector, $completion) {
  var tmp = new $collectCOROUTINE$3(this, collector, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(_no_name_provided__qut3iv_0).b14 = function (collector, $completion) {
  return this.a2g(collector, $completion);
};
function KotlinxSerializationConverter$deserialize$slambda($content, resultContinuation) {
  this.l4f_1 = $content;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(KotlinxSerializationConverter$deserialize$slambda).l2g = function (it, $completion) {
  var tmp = this.m2g(it, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(KotlinxSerializationConverter$deserialize$slambda).gd = function (p1, $completion) {
  return this.l2g((p1 == null ? true : !(p1 == null)) ? p1 : THROW_CCE(), $completion);
};
protoOf(KotlinxSerializationConverter$deserialize$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      if (tmp === 0) {
        this.jc_1 = 1;
        return !(this.m4f_1 == null) ? true : this.l4f_1.h1f();
      } else if (tmp === 1) {
        throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      throw e;
    }
   while (true);
};
protoOf(KotlinxSerializationConverter$deserialize$slambda).m2g = function (it, completion) {
  var i = new KotlinxSerializationConverter$deserialize$slambda(this.l4f_1, completion);
  i.m4f_1 = it;
  return i;
};
function KotlinxSerializationConverter$deserialize$slambda_0($content, resultContinuation) {
  var i = new KotlinxSerializationConverter$deserialize$slambda($content, resultContinuation);
  var l = function (it, $completion) {
    return i.l2g(it, $completion);
  };
  l.$arity = 1;
  return l;
}
function $serializeNullableCOROUTINE$0(_this__u8e3s4, contentType, charset, typeInfo, value, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.v4f_1 = _this__u8e3s4;
  this.w4f_1 = contentType;
  this.x4f_1 = charset;
  this.y4f_1 = typeInfo;
  this.z4f_1 = value;
}
protoOf($serializeNullableCOROUTINE$0).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          var this_0 = asFlow(this.v4f_1.b4g_1);
          var tmp_0 = new _no_name_provided__qut3iv(this_0, this.w4f_1, this.x4f_1, this.y4f_1, this.z4f_1);
          suspendResult = firstOrNull_0(tmp_0, KotlinxSerializationConverter$serializeNullable$slambda_0(null), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var fromExtension = suspendResult;
          if (!(fromExtension == null))
            return fromExtension;
          var tmp_1;
          try {
            tmp_1 = serializerForTypeInfo(this.v4f_1.a4g_1.k3r(), this.y4f_1);
          } catch ($p) {
            var tmp_2;
            if ($p instanceof SerializationException) {
              var cause = $p;
              tmp_2 = guessSerializer(this.z4f_1, this.v4f_1.a4g_1.k3r());
            } else {
              throw $p;
            }
            tmp_1 = tmp_2;
          }

          var serializer = tmp_1;
          return serializeContent(this.v4f_1, serializer, this.v4f_1.a4g_1, this.z4f_1, this.w4f_1, this.x4f_1);
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $deserializeCOROUTINE$1(_this__u8e3s4, charset, typeInfo, content, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.k4g_1 = _this__u8e3s4;
  this.l4g_1 = charset;
  this.m4g_1 = typeInfo;
  this.n4g_1 = content;
}
protoOf($deserializeCOROUTINE$1).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 5;
          this.ic_1 = 1;
          var this_0 = asFlow(this.k4g_1.b4g_1);
          var tmp_0 = new _no_name_provided__qut3iv_0(this_0, this.l4g_1, this.m4g_1, this.n4g_1);
          suspendResult = firstOrNull_0(tmp_0, KotlinxSerializationConverter$deserialize$slambda_0(this.n4g_1, null), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.o4g_1 = suspendResult;
          var tmp_1;
          if (!this.k4g_1.b4g_1.b1()) {
            tmp_1 = !(this.o4g_1 == null) ? true : this.n4g_1.h1f();
          } else {
            tmp_1 = false;
          }

          if (tmp_1)
            return this.o4g_1;
          this.p4g_1 = serializerForTypeInfo(this.k4g_1.a4g_1.k3r(), this.m4g_1);
          this.ic_1 = 2;
          suspendResult = this.n4g_1.c1l(VOID, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          var contentPacket = suspendResult;
          this.jc_1 = 3;
          var tmp0_subject = this.k4g_1.a4g_1;
          var tmp_2;
          if (isInterface(tmp0_subject, StringFormat)) {
            tmp_2 = this.k4g_1.a4g_1.h3s(this.p4g_1, readText(contentPacket, this.l4g_1));
          } else {
            if (isInterface(tmp0_subject, BinaryFormat)) {
              tmp_2 = this.k4g_1.a4g_1.j3s(this.p4g_1, readBytes(contentPacket));
            } else {
              discard(contentPacket);
              var message = 'Unsupported format ' + this.k4g_1.a4g_1;
              throw IllegalStateException_init_$Create$(toString(message));
            }
          }

          return tmp_2;
        case 3:
          this.jc_1 = 5;
          var tmp_3 = this.lc_1;
          if (tmp_3 instanceof Error) {
            var cause = this.lc_1;
            throw new JsonConvertException('Illegal input: ' + cause.message, cause);
          } else {
            throw this.lc_1;
          }

        case 4:
          this.jc_1 = 5;
          return Unit_instance;
        case 5:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 5) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function KotlinxSerializationConverter(format) {
  this.a4g_1 = format;
  this.b4g_1 = extensions(this.a4g_1);
  // Inline function 'kotlin.require' call
  var tmp;
  var tmp_0 = this.a4g_1;
  if (isInterface(tmp_0, BinaryFormat)) {
    tmp = true;
  } else {
    var tmp_1 = this.a4g_1;
    tmp = isInterface(tmp_1, StringFormat);
  }
  // Inline function 'kotlin.contracts.contract' call
  if (!tmp) {
    // Inline function 'io.ktor.serialization.kotlinx.KotlinxSerializationConverter.<anonymous>' call
    var message = 'Only binary and string formats are supported, ' + this.a4g_1 + ' is not supported.';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
}
protoOf(KotlinxSerializationConverter).q4g = function (contentType, charset, typeInfo, value, $completion) {
  return this.r4g(contentType, charset, typeInfo, value, $completion);
};
protoOf(KotlinxSerializationConverter).c2e = function (contentType, charset, typeInfo, value, $completion) {
  return this.q4g(contentType, charset, typeInfo, value, $completion);
};
protoOf(KotlinxSerializationConverter).r4g = function (contentType, charset, typeInfo, value, $completion) {
  var tmp = new $serializeNullableCOROUTINE$0(this, contentType, charset, typeInfo, value, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(KotlinxSerializationConverter).d2e = function (contentType, charset, typeInfo, value, $completion) {
  return this.r4g(contentType, charset, typeInfo, value, $completion);
};
protoOf(KotlinxSerializationConverter).e2e = function (charset, typeInfo, content, $completion) {
  var tmp = new $deserializeCOROUTINE$1(this, charset, typeInfo, content, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
function serializerForTypeInfo(_this__u8e3s4, typeInfo) {
  var module_0 = _this__u8e3s4;
  var tmp0_safe_receiver = typeInfo.b21_1;
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'io.ktor.serialization.kotlinx.serializerForTypeInfo.<anonymous>' call
    var tmp_0;
    if (tmp0_safe_receiver.h7().b1()) {
      tmp_0 = null;
    } else {
      tmp_0 = serializerOrNull(module_0, tmp0_safe_receiver);
    }
    tmp = tmp_0;
  }
  var tmp2_elvis_lhs = tmp;
  var tmp_1;
  if (tmp2_elvis_lhs == null) {
    var tmp1_safe_receiver = module_0.l3s(typeInfo.z20_1);
    tmp_1 = tmp1_safe_receiver == null ? null : maybeNullable(tmp1_safe_receiver, typeInfo);
  } else {
    tmp_1 = tmp2_elvis_lhs;
  }
  var tmp3_elvis_lhs = tmp_1;
  return tmp3_elvis_lhs == null ? maybeNullable(serializer(typeInfo.z20_1), typeInfo) : tmp3_elvis_lhs;
}
function guessSerializer(value, module_0) {
  var tmp;
  if (value == null) {
    tmp = get_nullable(serializer_0(StringCompanionObject_instance));
  } else {
    if (!(value == null) ? isInterface(value, List) : false) {
      tmp = ListSerializer(elementSerializer(value, module_0));
    } else {
      if (!(value == null) ? isArray(value) : false) {
        var tmp1_safe_receiver = firstOrNull(value);
        var tmp_0;
        if (tmp1_safe_receiver == null) {
          tmp_0 = null;
        } else {
          // Inline function 'kotlin.let' call
          // Inline function 'kotlin.contracts.contract' call
          // Inline function 'io.ktor.serialization.kotlinx.guessSerializer.<anonymous>' call
          tmp_0 = guessSerializer(tmp1_safe_receiver, module_0);
        }
        var tmp2_elvis_lhs = tmp_0;
        tmp = tmp2_elvis_lhs == null ? ListSerializer(serializer_0(StringCompanionObject_instance)) : tmp2_elvis_lhs;
      } else {
        if (!(value == null) ? isInterface(value, Set) : false) {
          tmp = SetSerializer(elementSerializer(value, module_0));
        } else {
          if (!(value == null) ? isInterface(value, Map) : false) {
            var keySerializer = elementSerializer(value.f2(), module_0);
            var valueSerializer = elementSerializer(value.g2(), module_0);
            tmp = MapSerializer(keySerializer, valueSerializer);
          } else {
            var tmp3_elvis_lhs = module_0.l3s(getKClassFromExpression(value));
            tmp = tmp3_elvis_lhs == null ? serializer(getKClassFromExpression(value)) : tmp3_elvis_lhs;
          }
        }
      }
    }
  }
  var tmp_1 = tmp;
  return isInterface(tmp_1, KSerializer) ? tmp_1 : THROW_CCE();
}
function maybeNullable(_this__u8e3s4, typeInfo) {
  var tmp;
  var tmp0_safe_receiver = typeInfo.b21_1;
  if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i7()) === true) {
    tmp = get_nullable(_this__u8e3s4);
  } else {
    tmp = _this__u8e3s4;
  }
  return tmp;
}
function elementSerializer(_this__u8e3s4, module_0) {
  // Inline function 'kotlin.collections.distinctBy' call
  // Inline function 'kotlin.collections.map' call
  var this_0 = filterNotNull(_this__u8e3s4);
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
  var tmp0_iterator = this_0.u();
  while (tmp0_iterator.v()) {
    var item = tmp0_iterator.w();
    // Inline function 'io.ktor.serialization.kotlinx.elementSerializer.<anonymous>' call
    var tmp$ret$0 = guessSerializer(item, module_0);
    destination.r(tmp$ret$0);
  }
  var set = HashSet_init_$Create$();
  var list = ArrayList_init_$Create$();
  var tmp0_iterator_0 = destination.u();
  while (tmp0_iterator_0.v()) {
    var e = tmp0_iterator_0.w();
    // Inline function 'io.ktor.serialization.kotlinx.elementSerializer.<anonymous>' call
    var key = e.z3q().e3s();
    if (set.r(key)) {
      list.r(e);
    }
  }
  var serializers = list;
  if (serializers.n() > 1) {
    // Inline function 'kotlin.error' call
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList_init_$Create$_0(collectionSizeOrDefault(serializers, 10));
    var tmp0_iterator_1 = serializers.u();
    while (tmp0_iterator_1.v()) {
      var item_0 = tmp0_iterator_1.w();
      // Inline function 'io.ktor.serialization.kotlinx.elementSerializer.<anonymous>' call
      var tmp$ret$5 = item_0.z3q().e3s();
      destination_0.r(tmp$ret$5);
    }
    var message = 'Serializing collections of different element types is not yet supported. ' + ('Selected serializers: ' + destination_0);
    throw IllegalStateException_init_$Create$(toString(message));
  }
  var tmp0_elvis_lhs = singleOrNull(serializers);
  var selected = tmp0_elvis_lhs == null ? serializer_0(StringCompanionObject_instance) : tmp0_elvis_lhs;
  if (selected.z3q().o3s()) {
    return selected;
  }
  if (!isInterface(selected, KSerializer))
    THROW_CCE();
  var tmp$ret$8;
  $l$block_0: {
    // Inline function 'kotlin.collections.any' call
    var tmp;
    if (isInterface(_this__u8e3s4, Collection)) {
      tmp = _this__u8e3s4.b1();
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$8 = false;
      break $l$block_0;
    }
    var tmp0_iterator_2 = _this__u8e3s4.u();
    while (tmp0_iterator_2.v()) {
      var element = tmp0_iterator_2.w();
      // Inline function 'io.ktor.serialization.kotlinx.elementSerializer.<anonymous>' call
      if (element == null) {
        tmp$ret$8 = true;
        break $l$block_0;
      }
    }
    tmp$ret$8 = false;
  }
  if (tmp$ret$8) {
    return get_nullable(selected);
  }
  return selected;
}
function get_providers() {
  return emptyList();
}
//region block: exports
export {
  serialization as serialization1fpeds7cruos4,
};
//endregion

//# sourceMappingURL=ktor-ktor-serialization-kotlinx.mjs.map
