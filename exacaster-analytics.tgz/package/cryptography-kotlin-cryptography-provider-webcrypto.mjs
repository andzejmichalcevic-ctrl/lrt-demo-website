import {
  CryptographyProviderwgv0x40nzvjc as CryptographyProvider,
  Companion_getInstancevaj2z8x51da6 as Companion_getInstance,
  Companion_getInstance2zylk6n2349wv as Companion_getInstance_0,
  Companion_getInstance2i8jskmmt37cf as Companion_getInstance_1,
  Companion_getInstance2x3fgbv8b1la3 as Companion_getInstance_2,
  Companion_getInstance1ywh0s7eq8pl0 as Companion_getInstance_3,
  Companion_getInstancebj3noegw8gjz as Companion_getInstance_4,
  Companion_getInstance3pt1urg8szwx1 as Companion_getInstance_5,
  Companion_getInstance1s3szxah6qkop as Companion_getInstance_6,
  SHA512_getInstance3eirybrxxn6dy as SHA512_getInstance,
  SHA384_getInstanceua5kkti0hic6 as SHA384_getInstance,
  SHA256_getInstance1g7vhwtv2c9q6 as SHA256_getInstance,
  SHA1_getInstance933vkszebm50 as SHA1_getInstance,
  CryptographyAlgorithmhhdrgo7p9qei as CryptographyAlgorithm,
  EncodableKey3owe4xoj8bp0x as EncodableKey,
  _SymmetricKeySize___get_value__impl__5onst02nbox7pntj15p as _SymmetricKeySize___get_value__impl__5onst0,
  _BinarySize___get_inBits__impl__p3mjjl3bneoq3muenl as _BinarySize___get_inBits__impl__p3mjjl,
  Format1raquhpq7huoj as Format,
  cipher$default3mvigtlwssyws as cipher$default,
  Key27im5zl1nrqeu as Key,
  encrypt1trrg01763i60 as encrypt,
  encryptBlocking3po334xxmcrqg as encryptBlocking,
  Encryptortojc5f14qnuh as Encryptor,
  AuthenticatedEncryptor2ldwfpn9o9plz as AuthenticatedEncryptor,
  Format2yn75n0x2mr3i as Format_0,
  Format30qxrtk16tcc2 as Format_1,
  Format2m555m4ve3n4i as Format_2,
  PKCS1_getInstance22jyqulei7kzu as PKCS1_getInstance,
  PKCS1_getInstance1sd1u0thrynjr as PKCS1_getInstance_0,
  Generic_getInstance2qaeeyfix4aer as Generic_getInstance,
  Generic_getInstance1nwvav7eaksaz as Generic_getInstance_0,
  JWK_getInstanceie2pfvrk0skx as JWK_getInstance,
  Formatjuylyuzzxlus as Format_3,
  PKCS1_getInstance5oarcfrkdwwl as PKCS1_getInstance_1,
  PKCS1_getInstance3jkizp9v5g9u3 as PKCS1_getInstance_2,
  Generic_getInstance20xurpmr65ip4 as Generic_getInstance_1,
  Generic_getInstance3nxwrmkv2k619 as Generic_getInstance_2,
  JWK_getInstance2jxaz7zr8af3p as JWK_getInstance_0,
  Format2zvh6c91yrmkr as Format_4,
  CryptographyException_init_$Create$hph28sq0hoyt as CryptographyException_init_$Create$,
  KeyDecoder1aj9ibfkm03tn as KeyDecoder,
  KeyGeneratoreiz70b6fmxez as KeyGenerator,
  Registry_getInstance7l0ygmh568in as Registry_getInstance,
} from './cryptography-kotlin-cryptography-core.mjs';
import {
  equals2au1ep9vhcato as equals,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  isInterface3d6p8outrmvmk as isInterface,
  protoOf180f3jzyo7rfj as protoOf,
  objectMeta213120oau977m as objectMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  lazy2hsh8ze7j6ikd as lazy,
  classMetawt99a3kyl3us as classMeta,
  VOID7hggqo3abtya as VOID,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  CoroutineImpl2sn3kjnwmfr10 as CoroutineImpl,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  primitiveArrayConcatwxgknw08pmlb as primitiveArrayConcat,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  toString1pkumu07cwy4m as toString,
  IllegalStateException_init_$Create$3ib9qa3pip8n4 as IllegalStateException_init_$Create$,
  encodeToByteArray1onwao0uakjfh as encodeToByteArray,
  decodeToString1x4faah2liw2p as decodeToString,
  Companion_instance2oawqq9qiaris as Companion_instance,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  intercepted2ogpsikxxj4u0 as intercepted,
  SafeContinuation_init_$Create$3bz2d44qqz71w as SafeContinuation_init_$Create$,
  returnIfSuspendedqak8u4r448cu as returnIfSuspended,
} from './kotlin-kotlin-stdlib.mjs';
import { Default_getInstance3i7clpznr2ox9 as Default_getInstance } from './cryptography-kotlin-cryptography-random.mjs';
import {
  Companion_getInstance189lo0154tya6 as Companion_getInstance_7,
  PEM_instance1x9y0i69w08s3 as PEM_instance,
  ensurePemLabel270qhcv8ps8sl as ensurePemLabel,
  PemContent61i58fspvc2p as PemContent,
} from './cryptography-kotlin-cryptography-serialization-pem.mjs';
import {
  RsaKeyAlgorithmIdentifier_instance2u9y4u3euyfj4 as RsaKeyAlgorithmIdentifier_instance,
  get_RSA30ci1l0u72mkd as get_RSA,
  Companion_getInstance3ld3jdhb4r99r as Companion_getInstance_8,
  SubjectPublicKeyInfo1tner6n57cb2l as SubjectPublicKeyInfo,
  Companion_getInstancefp1mml3gm8u5 as Companion_getInstance_9,
  PrivateKeyInfou42ielkmgvu2 as PrivateKeyInfo,
} from './cryptography-kotlin-cryptography-serialization-asn1-modules.mjs';
import {
  Companion_instance1lybiqv5r9a9w as Companion_instance_0,
  Default_getInstance2lxyd89gwu0mk as Default_getInstance_0,
  BitArray3ibxegq42amh4 as BitArray,
  _ObjectIdentifier___get_value__impl__wqzjw3smbbvmgbuky3 as _ObjectIdentifier___get_value__impl__wqzjw3,
  ObjectIdentifierz6uf0uceu1gm as ObjectIdentifier,
} from './cryptography-kotlin-cryptography-serialization-asn1.mjs';
//region block: imports
//endregion
//region block: pre-declaration
setMetadataFor(WebCryptoCryptographyProvider, 'WebCryptoCryptographyProvider', objectMeta, CryptographyProvider);
setMetadataFor(WebCryptoEncodableKey, 'WebCryptoEncodableKey', classMeta, VOID, [EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(AesKey, 'AesKey', classMeta, WebCryptoEncodableKey, [WebCryptoEncodableKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(WebCryptoAes, 'WebCryptoAes', classMeta, VOID, [CryptographyAlgorithm]);
setMetadataFor(WebCryptoKeyProcessor, 'WebCryptoKeyProcessor', classMeta);
setMetadataFor(AesKeyProcessor, 'AesKeyProcessor', objectMeta, WebCryptoKeyProcessor);
setMetadataFor(AesCbcKey, 'AesCbcKey', classMeta, AesKey, [AesKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(WebCryptoAesCbc, 'WebCryptoAesCbc', objectMeta, WebCryptoAes, [WebCryptoAes, CryptographyAlgorithm]);
setMetadataFor(AesCtrKey, 'AesCtrKey', classMeta, AesKey, [AesKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(WebCryptoAesCtr, 'WebCryptoAesCtr', objectMeta, WebCryptoAes, [WebCryptoAes, CryptographyAlgorithm]);
setMetadataFor(AesGcmKey, 'AesGcmKey', classMeta, AesKey, [AesKey, Key], VOID, VOID, VOID, [1]);
setMetadataFor(WebCryptoAesGcm, 'WebCryptoAesGcm', objectMeta, WebCryptoAes, [WebCryptoAes, CryptographyAlgorithm]);
setMetadataFor($encryptCOROUTINE$2, '$encryptCOROUTINE$2', classMeta, CoroutineImpl);
setMetadataFor(AesGcmCipher, 'AesGcmCipher', classMeta, VOID, [Encryptor, AuthenticatedEncryptor], VOID, VOID, VOID, [2, 1]);
setMetadataFor(Companion, 'Companion', objectMeta);
setMetadataFor(WebCryptoDigest, 'WebCryptoDigest', classMeta, VOID, [CryptographyAlgorithm], VOID, VOID, VOID, [1]);
setMetadataFor(EcPublicKey, 'EcPublicKey', classMeta, WebCryptoEncodableKey, [WebCryptoEncodableKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(EcPrivateKey, 'EcPrivateKey', classMeta, WebCryptoEncodableKey, [WebCryptoEncodableKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(WebCryptoEc, 'WebCryptoEc', classMeta, VOID, [CryptographyAlgorithm]);
setMetadataFor(EcPublicKeyProcessor, 'EcPublicKeyProcessor', objectMeta, WebCryptoKeyProcessor);
setMetadataFor(EcPrivateKeyProcessor, 'EcPrivateKeyProcessor', objectMeta, WebCryptoKeyProcessor);
setMetadataFor(EcdsaKeyPair, 'EcdsaKeyPair', classMeta);
setMetadataFor(EcdsaPublicKey, 'EcdsaPublicKey', classMeta, EcPublicKey, [EcPublicKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(EcdsaPrivateKey, 'EcdsaPrivateKey', classMeta, EcPrivateKey, [EcPrivateKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(WebCryptoEcdsa, 'WebCryptoEcdsa', objectMeta, WebCryptoEc, [WebCryptoEc, CryptographyAlgorithm]);
setMetadataFor(HmacKey, 'HmacKey', classMeta, WebCryptoEncodableKey, [WebCryptoEncodableKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(WebCryptoHmac, 'WebCryptoHmac', objectMeta, VOID, [CryptographyAlgorithm]);
setMetadataFor(HmacKeyProcessor, 'HmacKeyProcessor', objectMeta, WebCryptoKeyProcessor);
setMetadataFor(RsaPublicKey, 'RsaPublicKey', classMeta, WebCryptoEncodableKey, [WebCryptoEncodableKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(RsaPrivateKey, 'RsaPrivateKey', classMeta, WebCryptoEncodableKey, [WebCryptoEncodableKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(WebCryptoRsa, 'WebCryptoRsa', classMeta, VOID, [CryptographyAlgorithm]);
setMetadataFor(RsaPublicKeyProcessor, 'RsaPublicKeyProcessor', objectMeta, WebCryptoKeyProcessor);
setMetadataFor(RsaPrivateKeyProcessor, 'RsaPrivateKeyProcessor', objectMeta, WebCryptoKeyProcessor);
setMetadataFor(RsaOaepKeyPair, 'RsaOaepKeyPair', classMeta);
setMetadataFor(RsaOaepPublicKey, 'RsaOaepPublicKey', classMeta, RsaPublicKey, [RsaPublicKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(RsaOaepPrivateKey, 'RsaOaepPrivateKey', classMeta, RsaPrivateKey, [RsaPrivateKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(WebCryptoRsaOaep, 'WebCryptoRsaOaep', objectMeta, WebCryptoRsa, [WebCryptoRsa, CryptographyAlgorithm]);
setMetadataFor(RsaOaepEncryptor, 'RsaOaepEncryptor', classMeta, VOID, [AuthenticatedEncryptor], VOID, VOID, VOID, [2, 1]);
setMetadataFor(RsaPkcs1KeyPair, 'RsaPkcs1KeyPair', classMeta);
setMetadataFor(RsaPkcs1PublicKey, 'RsaPkcs1PublicKey', classMeta, RsaPublicKey, [RsaPublicKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(RsaPkcs1PrivateKey, 'RsaPkcs1PrivateKey', classMeta, RsaPrivateKey, [RsaPrivateKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(WebCryptoRsaPkcs1, 'WebCryptoRsaPkcs1', objectMeta, WebCryptoRsa, [WebCryptoRsa, CryptographyAlgorithm]);
setMetadataFor(RsaPssKeyPair, 'RsaPssKeyPair', classMeta);
setMetadataFor(RsaPssPublicKey, 'RsaPssPublicKey', classMeta, RsaPublicKey, [RsaPublicKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(RsaPssPrivateKey, 'RsaPssPrivateKey', classMeta, RsaPrivateKey, [RsaPrivateKey, EncodableKey], VOID, VOID, VOID, [1]);
setMetadataFor(WebCryptoRsaPss, 'WebCryptoRsaPss', objectMeta, WebCryptoRsa, [WebCryptoRsa, CryptographyAlgorithm]);
setMetadataFor($encodeToCOROUTINE$4, '$encodeToCOROUTINE$4', classMeta, CoroutineImpl);
setMetadataFor($decodeFromCOROUTINE$5, '$decodeFromCOROUTINE$5', classMeta, CoroutineImpl);
setMetadataFor(WebCryptoKeyDecoder, 'WebCryptoKeyDecoder', classMeta, VOID, [KeyDecoder], VOID, VOID, VOID, [2]);
setMetadataFor(WebCryptoKeyWrapper, 'WebCryptoKeyWrapper', classMeta);
setMetadataFor($generateKeyCOROUTINE$6, '$generateKeyCOROUTINE$6', classMeta, CoroutineImpl);
setMetadataFor(WebCryptoSymmetricKeyGenerator, 'WebCryptoSymmetricKeyGenerator', classMeta, VOID, [KeyGenerator], VOID, VOID, VOID, [0]);
setMetadataFor($encryptCOROUTINE$8, '$encryptCOROUTINE$8', classMeta, CoroutineImpl);
setMetadataFor($exportKeyCOROUTINE$11, '$exportKeyCOROUTINE$11', classMeta, CoroutineImpl);
setMetadataFor(WebCrypto, 'WebCrypto', objectMeta, VOID, VOID, VOID, VOID, VOID, [2, 3, 4, 5]);
setMetadataFor($awaitCOROUTINE$12, '$awaitCOROUTINE$12', classMeta, CoroutineImpl);
//endregion
function get_defaultProvider() {
  _init_properties_WebCryptoCryptographyProvider_kt__i22tls();
  return defaultProvider;
}
var defaultProvider;
var WebCrypto$delegate;
function WebCryptoCryptographyProvider() {
  WebCryptoCryptographyProvider_instance = this;
  CryptographyProvider.call(this);
}
protoOf(WebCryptoCryptographyProvider).y4u = function (identifier) {
  var tmp = equals(identifier, SHA1_getInstance()) ? Companion_getInstance_10().q4y_1 : equals(identifier, SHA256_getInstance()) ? Companion_getInstance_10().r4y_1 : equals(identifier, SHA384_getInstance()) ? Companion_getInstance_10().s4y_1 : equals(identifier, SHA512_getInstance()) ? Companion_getInstance_10().t4y_1 : equals(identifier, Companion_getInstance_6()) ? WebCryptoHmac_getInstance() : equals(identifier, Companion_getInstance_5()) ? WebCryptoAesCbc_getInstance() : equals(identifier, Companion_getInstance_4()) ? WebCryptoAesCtr_getInstance() : equals(identifier, Companion_getInstance_3()) ? WebCryptoAesGcm_getInstance() : equals(identifier, Companion_getInstance_2()) ? WebCryptoRsaOaep_getInstance() : equals(identifier, Companion_getInstance_1()) ? WebCryptoRsaPss_getInstance() : equals(identifier, Companion_getInstance_0()) ? WebCryptoRsaPkcs1_getInstance() : equals(identifier, Companion_getInstance()) ? WebCryptoEcdsa_getInstance() : null;
  return (tmp == null ? true : isInterface(tmp, CryptographyAlgorithm)) ? tmp : THROW_CCE();
};
var WebCryptoCryptographyProvider_instance;
function WebCryptoCryptographyProvider_getInstance() {
  if (WebCryptoCryptographyProvider_instance == null)
    new WebCryptoCryptographyProvider();
  return WebCryptoCryptographyProvider_instance;
}
function defaultProvider$lambda() {
  _init_properties_WebCryptoCryptographyProvider_kt__i22tls();
  return WebCryptoCryptographyProvider_getInstance();
}
var properties_initialized_WebCryptoCryptographyProvider_kt_n89q9u;
function _init_properties_WebCryptoCryptographyProvider_kt__i22tls() {
  if (!properties_initialized_WebCryptoCryptographyProvider_kt_n89q9u) {
    properties_initialized_WebCryptoCryptographyProvider_kt_n89q9u = true;
    defaultProvider = lazy(defaultProvider$lambda);
    WebCrypto$delegate = get_defaultProvider();
  }
}
function AesKey(key) {
  WebCryptoEncodableKey.call(this, key, AesKeyProcessor_getInstance());
  this.w4y_1 = key;
}
function WebCryptoAes(algorithmName, keyWrapper) {
  this.z4y_1 = algorithmName;
  this.a4z_1 = keyWrapper;
}
protoOf(WebCryptoAes).b4z = function (keySize) {
  return new WebCryptoSymmetricKeyGenerator(AesKeyGenerationAlgorithm(this.z4y_1, _BinarySize___get_inBits__impl__p3mjjl(_SymmetricKeySize___get_value__impl__5onst0(keySize))), this.a4z_1);
};
function AesKeyProcessor() {
  AesKeyProcessor_instance = this;
  WebCryptoKeyProcessor.call(this);
}
protoOf(AesKeyProcessor).c4z = function (format) {
  var tmp;
  switch (format.aa_1) {
    case 0:
      tmp = 'raw';
      break;
    case 1:
      tmp = 'jwk';
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
};
protoOf(AesKeyProcessor).d4z = function (format) {
  return this.c4z(format instanceof Format ? format : THROW_CCE());
};
protoOf(AesKeyProcessor).e4z = function (format, key) {
  return key;
};
protoOf(AesKeyProcessor).f4z = function (format, key) {
  return this.e4z(format instanceof Format ? format : THROW_CCE(), key);
};
protoOf(AesKeyProcessor).g4z = function (format, key) {
  return key;
};
protoOf(AesKeyProcessor).h4z = function (format, key) {
  return this.g4z(format instanceof Format ? format : THROW_CCE(), key);
};
var AesKeyProcessor_instance;
function AesKeyProcessor_getInstance() {
  if (AesKeyProcessor_instance == null)
    new AesKeyProcessor();
  return AesKeyProcessor_instance;
}
function AesCbcKey(key) {
  AesKey.call(this, key);
}
function WebCryptoAesCbc$AesCbcKey$_init_$ref_lop2vf() {
  var l = function (p0) {
    return new AesCbcKey(p0);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoAesCbc() {
  WebCryptoAesCbc_instance = this;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp = ['encrypt', 'decrypt'];
  WebCryptoAes.call(this, 'AES-CBC', new WebCryptoKeyWrapper(tmp, WebCryptoAesCbc$AesCbcKey$_init_$ref_lop2vf()));
}
var WebCryptoAesCbc_instance;
function WebCryptoAesCbc_getInstance() {
  if (WebCryptoAesCbc_instance == null)
    new WebCryptoAesCbc();
  return WebCryptoAesCbc_instance;
}
function AesCtrKey(key) {
  AesKey.call(this, key);
}
function WebCryptoAesCtr$AesCtrKey$_init_$ref_5qzjvv() {
  var l = function (p0) {
    return new AesCtrKey(p0);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoAesCtr() {
  WebCryptoAesCtr_instance = this;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp = ['encrypt', 'decrypt'];
  WebCryptoAes.call(this, 'AES-CTR', new WebCryptoKeyWrapper(tmp, WebCryptoAesCtr$AesCtrKey$_init_$ref_5qzjvv()));
}
var WebCryptoAesCtr_instance;
function WebCryptoAesCtr_getInstance() {
  if (WebCryptoAesCtr_instance == null)
    new WebCryptoAesCtr();
  return WebCryptoAesCtr_instance;
}
function AesGcmKey(key) {
  AesKey.call(this, key);
}
protoOf(AesGcmKey).b4v = function (tagSize) {
  return new AesGcmCipher(this.w4y_1, _BinarySize___get_inBits__impl__p3mjjl(tagSize));
};
function WebCryptoAesGcm$AesGcmKey$_init_$ref_c6pr3f() {
  var l = function (p0) {
    return new AesGcmKey(p0);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoAesGcm() {
  WebCryptoAesGcm_instance = this;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp = ['encrypt', 'decrypt'];
  WebCryptoAes.call(this, 'AES-GCM', new WebCryptoKeyWrapper(tmp, WebCryptoAesGcm$AesGcmKey$_init_$ref_c6pr3f()));
}
var WebCryptoAesGcm_instance;
function WebCryptoAesGcm_getInstance() {
  if (WebCryptoAesGcm_instance == null)
    new WebCryptoAesGcm();
  return WebCryptoAesGcm_instance;
}
function $encryptCOROUTINE$2(_this__u8e3s4, plaintextInput, associatedData, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.t4z_1 = _this__u8e3s4;
  this.u4z_1 = plaintextInput;
  this.v4z_1 = associatedData;
}
protoOf($encryptCOROUTINE$2).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.w4z_1 = Default_getInstance().yg(12);
          this.ic_1 = 1;
          suspendResult = WebCrypto_getInstance().a50(AesGcmCipherAlgorithm(this.v4z_1, this.w4z_1, this.t4z_1.y4z_1), this.t4z_1.x4z_1, this.u4z_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var ciphertext = suspendResult;
          var this_0 = this.w4z_1;
          return primitiveArrayConcat([this_0, ciphertext]);
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function AesGcmCipher(key, tagSizeBits) {
  this.x4z_1 = key;
  this.y4z_1 = tagSizeBits;
}
protoOf(AesGcmCipher).k4v = function (plaintextInput, associatedData, $completion) {
  var tmp = new $encryptCOROUTINE$2(this, plaintextInput, associatedData, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(AesGcmCipher).l4v = function (plaintextInput, associatedData) {
  nonBlocking();
};
function Companion() {
  Companion_instance_1 = this;
  this.q4y_1 = new WebCryptoDigest('SHA-1', SHA1_getInstance());
  this.r4y_1 = new WebCryptoDigest('SHA-256', SHA256_getInstance());
  this.s4y_1 = new WebCryptoDigest('SHA-384', SHA384_getInstance());
  this.t4y_1 = new WebCryptoDigest('SHA-512', SHA512_getInstance());
}
var Companion_instance_1;
function Companion_getInstance_10() {
  if (Companion_instance_1 == null)
    new Companion();
  return Companion_instance_1;
}
function WebCryptoDigest(algorithm, id) {
  Companion_getInstance_10();
  this.b50_1 = algorithm;
  this.c50_1 = id;
}
function EcPublicKey(publicKey) {
  WebCryptoEncodableKey.call(this, publicKey, EcPublicKeyProcessor_getInstance());
  this.f50_1 = publicKey;
}
function EcPrivateKey(privateKey) {
  WebCryptoEncodableKey.call(this, privateKey, EcPrivateKeyProcessor_getInstance());
  this.i50_1 = privateKey;
}
function WebCryptoEc$keyPairWrapper$lambda($keyPairWrapper, this$0) {
  return function (it) {
    return $keyPairWrapper(this$0.m50_1.k50_1(it.publicKey), this$0.n50_1.k50_1(it.privateKey));
  };
}
function WebCryptoEc(algorithmName, publicKeyWrapper, privateKeyWrapper, keyPairWrapper) {
  this.l50_1 = algorithmName;
  this.m50_1 = publicKeyWrapper;
  this.n50_1 = privateKeyWrapper;
  var tmp = this;
  // Inline function 'kotlin.collections.plus' call
  var this_0 = this.m50_1.j50_1;
  var elements = this.n50_1.j50_1;
  // Inline function 'kotlin.js.asDynamic' call
  tmp.o50_1 = this_0.concat(elements);
  var tmp_0 = this;
  tmp_0.p50_1 = WebCryptoEc$keyPairWrapper$lambda(keyPairWrapper, this);
}
function EcPublicKeyProcessor() {
  EcPublicKeyProcessor_instance = this;
  WebCryptoKeyProcessor.call(this);
}
protoOf(EcPublicKeyProcessor).q50 = function (format) {
  var tmp;
  switch (format.aa_1) {
    case 3:
      tmp = 'jwk';
      break;
    case 0:
      tmp = 'raw';
      break;
    case 1:
    case 2:
      tmp = 'spki';
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
};
protoOf(EcPublicKeyProcessor).d4z = function (format) {
  return this.q50(format instanceof Format_0 ? format : THROW_CCE());
};
protoOf(EcPublicKeyProcessor).r50 = function (format, key) {
  var tmp;
  switch (format.aa_1) {
    case 3:
      tmp = key;
      break;
    case 0:
      tmp = key;
      break;
    case 1:
      tmp = key;
      break;
    case 2:
      tmp = unwrapPem(Companion_getInstance_7().x4v_1, key);
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
};
protoOf(EcPublicKeyProcessor).f4z = function (format, key) {
  return this.r50(format instanceof Format_0 ? format : THROW_CCE(), key);
};
protoOf(EcPublicKeyProcessor).s50 = function (format, key) {
  var tmp;
  switch (format.aa_1) {
    case 3:
      tmp = key;
      break;
    case 0:
      tmp = key;
      break;
    case 1:
      tmp = key;
      break;
    case 2:
      tmp = wrapPem(Companion_getInstance_7().x4v_1, key);
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
};
protoOf(EcPublicKeyProcessor).h4z = function (format, key) {
  return this.s50(format instanceof Format_0 ? format : THROW_CCE(), key);
};
var EcPublicKeyProcessor_instance;
function EcPublicKeyProcessor_getInstance() {
  if (EcPublicKeyProcessor_instance == null)
    new EcPublicKeyProcessor();
  return EcPublicKeyProcessor_instance;
}
function EcPrivateKeyProcessor() {
  EcPrivateKeyProcessor_instance = this;
  WebCryptoKeyProcessor.call(this);
}
protoOf(EcPrivateKeyProcessor).t50 = function (format) {
  var tmp;
  switch (format.aa_1) {
    case 2:
      tmp = 'jwk';
      break;
    case 0:
    case 1:
      tmp = 'pkcs8';
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
};
protoOf(EcPrivateKeyProcessor).d4z = function (format) {
  return this.t50(format instanceof Format_1 ? format : THROW_CCE());
};
protoOf(EcPrivateKeyProcessor).u50 = function (format, key) {
  var tmp;
  switch (format.aa_1) {
    case 2:
      tmp = key;
      break;
    case 0:
      tmp = key;
      break;
    case 1:
      tmp = unwrapPem(Companion_getInstance_7().y4v_1, key);
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
};
protoOf(EcPrivateKeyProcessor).f4z = function (format, key) {
  return this.u50(format instanceof Format_1 ? format : THROW_CCE(), key);
};
protoOf(EcPrivateKeyProcessor).v50 = function (format, key) {
  var tmp;
  switch (format.aa_1) {
    case 2:
      tmp = key;
      break;
    case 0:
      tmp = key;
      break;
    case 1:
      tmp = wrapPem(Companion_getInstance_7().y4v_1, key);
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
};
protoOf(EcPrivateKeyProcessor).h4z = function (format, key) {
  return this.v50(format instanceof Format_1 ? format : THROW_CCE(), key);
};
var EcPrivateKeyProcessor_instance;
function EcPrivateKeyProcessor_getInstance() {
  if (EcPrivateKeyProcessor_instance == null)
    new EcPrivateKeyProcessor();
  return EcPrivateKeyProcessor_instance;
}
function EcdsaKeyPair(publicKey, privateKey) {
  this.w50_1 = publicKey;
  this.x50_1 = privateKey;
}
function EcdsaPublicKey(publicKey) {
  EcPublicKey.call(this, publicKey);
}
function EcdsaPrivateKey(privateKey) {
  EcPrivateKey.call(this, privateKey);
}
function WebCryptoEcdsa$EcdsaPublicKey$_init_$ref_5egfgi() {
  var l = function (p0) {
    return new EcdsaPublicKey(p0);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoEcdsa$EcdsaPrivateKey$_init_$ref_8mqrbu() {
  var l = function (p0) {
    return new EcdsaPrivateKey(p0);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoEcdsa$EcdsaKeyPair$_init_$ref_l5vyez() {
  var l = function (p0, p1) {
    return new EcdsaKeyPair(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoEcdsa() {
  WebCryptoEcdsa_instance = this;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp = ['verify'];
  var tmp_0 = new WebCryptoKeyWrapper(tmp, WebCryptoEcdsa$EcdsaPublicKey$_init_$ref_5egfgi());
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp_1 = ['sign'];
  var tmp_2 = new WebCryptoKeyWrapper(tmp_1, WebCryptoEcdsa$EcdsaPrivateKey$_init_$ref_8mqrbu());
  WebCryptoEc.call(this, 'ECDSA', tmp_0, tmp_2, WebCryptoEcdsa$EcdsaKeyPair$_init_$ref_l5vyez());
}
var WebCryptoEcdsa_instance;
function WebCryptoEcdsa_getInstance() {
  if (WebCryptoEcdsa_instance == null)
    new WebCryptoEcdsa();
  return WebCryptoEcdsa_instance;
}
function HmacKey(key) {
  WebCryptoEncodableKey.call(this, key, HmacKeyProcessor_getInstance());
  this.a51_1 = key;
}
function WebCryptoHmac$HmacKey$_init_$ref_enwl2t() {
  var l = function (p0) {
    return new HmacKey(p0);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoHmac() {
  WebCryptoHmac_instance = this;
  var tmp = this;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp_0 = ['sign', 'verify'];
  tmp.b51_1 = new WebCryptoKeyWrapper(tmp_0, WebCryptoHmac$HmacKey$_init_$ref_enwl2t());
}
var WebCryptoHmac_instance;
function WebCryptoHmac_getInstance() {
  if (WebCryptoHmac_instance == null)
    new WebCryptoHmac();
  return WebCryptoHmac_instance;
}
function HmacKeyProcessor() {
  HmacKeyProcessor_instance = this;
  WebCryptoKeyProcessor.call(this);
}
protoOf(HmacKeyProcessor).c51 = function (format) {
  var tmp;
  switch (format.aa_1) {
    case 0:
      tmp = 'raw';
      break;
    case 1:
      tmp = 'jwk';
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
};
protoOf(HmacKeyProcessor).d4z = function (format) {
  return this.c51(format instanceof Format_2 ? format : THROW_CCE());
};
protoOf(HmacKeyProcessor).d51 = function (format, key) {
  return key;
};
protoOf(HmacKeyProcessor).f4z = function (format, key) {
  return this.d51(format instanceof Format_2 ? format : THROW_CCE(), key);
};
protoOf(HmacKeyProcessor).e51 = function (format, key) {
  return key;
};
protoOf(HmacKeyProcessor).h4z = function (format, key) {
  return this.e51(format instanceof Format_2 ? format : THROW_CCE(), key);
};
var HmacKeyProcessor_instance;
function HmacKeyProcessor_getInstance() {
  if (HmacKeyProcessor_instance == null)
    new HmacKeyProcessor();
  return HmacKeyProcessor_instance;
}
function RsaPublicKey(publicKey) {
  WebCryptoEncodableKey.call(this, publicKey, RsaPublicKeyProcessor_getInstance());
  this.h51_1 = publicKey;
}
function RsaPrivateKey(privateKey) {
  WebCryptoEncodableKey.call(this, privateKey, RsaPrivateKeyProcessor_getInstance());
  this.k51_1 = privateKey;
}
function WebCryptoRsa$keyPairWrapper$lambda($keyPairWrapper, this$0) {
  return function (it) {
    return $keyPairWrapper(this$0.m51_1.k50_1(it.publicKey), this$0.n51_1.k50_1(it.privateKey));
  };
}
function WebCryptoRsa(algorithmName, publicKeyWrapper, privateKeyWrapper, keyPairWrapper) {
  this.l51_1 = algorithmName;
  this.m51_1 = publicKeyWrapper;
  this.n51_1 = privateKeyWrapper;
  var tmp = this;
  // Inline function 'kotlin.collections.plus' call
  var this_0 = this.m51_1.j50_1;
  var elements = this.n51_1.j50_1;
  // Inline function 'kotlin.js.asDynamic' call
  tmp.o51_1 = this_0.concat(elements);
  var tmp_0 = this;
  tmp_0.p51_1 = WebCryptoRsa$keyPairWrapper$lambda(keyPairWrapper, this);
}
protoOf(WebCryptoRsa).q51 = function (digest) {
  return new WebCryptoKeyDecoder(RsaKeyImportAlgorithm(this.l51_1, hashAlgorithmName(digest)), RsaPublicKeyProcessor_getInstance(), this.m51_1);
};
function RsaPublicKeyProcessor() {
  RsaPublicKeyProcessor_instance = this;
  WebCryptoKeyProcessor.call(this);
}
protoOf(RsaPublicKeyProcessor).r51 = function (format) {
  var tmp;
  if (equals(format, JWK_getInstance())) {
    tmp = 'jwk';
  } else if (((equals(format, Generic_getInstance_0()) ? true : equals(format, Generic_getInstance())) ? true : equals(format, PKCS1_getInstance_0())) ? true : equals(format, PKCS1_getInstance())) {
    tmp = 'spki';
  } else {
    noWhenBranchMatchedException();
  }
  return tmp;
};
protoOf(RsaPublicKeyProcessor).d4z = function (format) {
  return this.r51(format instanceof Format_3 ? format : THROW_CCE());
};
protoOf(RsaPublicKeyProcessor).s51 = function (format, key) {
  var tmp;
  if (equals(format, JWK_getInstance())) {
    tmp = key;
  } else if (equals(format, Generic_getInstance_0())) {
    tmp = key;
  } else if (equals(format, Generic_getInstance())) {
    tmp = unwrapPem(Companion_getInstance_7().x4v_1, key);
  } else if (equals(format, PKCS1_getInstance_0())) {
    tmp = wrapPublicKey(RsaKeyAlgorithmIdentifier_instance, key);
  } else if (equals(format, PKCS1_getInstance())) {
    tmp = wrapPublicKey(RsaKeyAlgorithmIdentifier_instance, unwrapPem(Companion_getInstance_7().z4v_1, key));
  } else {
    noWhenBranchMatchedException();
  }
  return tmp;
};
protoOf(RsaPublicKeyProcessor).f4z = function (format, key) {
  return this.s51(format instanceof Format_3 ? format : THROW_CCE(), key);
};
protoOf(RsaPublicKeyProcessor).t51 = function (format, key) {
  var tmp;
  if (equals(format, JWK_getInstance())) {
    tmp = key;
  } else if (equals(format, Generic_getInstance_0())) {
    tmp = key;
  } else if (equals(format, Generic_getInstance())) {
    tmp = wrapPem(Companion_getInstance_7().x4v_1, key);
  } else if (equals(format, PKCS1_getInstance_0())) {
    tmp = unwrapPublicKey(get_RSA(Companion_instance_0), key);
  } else if (equals(format, PKCS1_getInstance())) {
    tmp = wrapPem(Companion_getInstance_7().z4v_1, unwrapPublicKey(get_RSA(Companion_instance_0), key));
  } else {
    noWhenBranchMatchedException();
  }
  return tmp;
};
protoOf(RsaPublicKeyProcessor).h4z = function (format, key) {
  return this.t51(format instanceof Format_3 ? format : THROW_CCE(), key);
};
var RsaPublicKeyProcessor_instance;
function RsaPublicKeyProcessor_getInstance() {
  if (RsaPublicKeyProcessor_instance == null)
    new RsaPublicKeyProcessor();
  return RsaPublicKeyProcessor_instance;
}
function RsaPrivateKeyProcessor() {
  RsaPrivateKeyProcessor_instance = this;
  WebCryptoKeyProcessor.call(this);
}
protoOf(RsaPrivateKeyProcessor).u51 = function (format) {
  var tmp;
  if (equals(format, JWK_getInstance_0())) {
    tmp = 'jwk';
  } else if (((equals(format, Generic_getInstance_2()) ? true : equals(format, Generic_getInstance_1())) ? true : equals(format, PKCS1_getInstance_2())) ? true : equals(format, PKCS1_getInstance_1())) {
    tmp = 'pkcs8';
  } else {
    noWhenBranchMatchedException();
  }
  return tmp;
};
protoOf(RsaPrivateKeyProcessor).d4z = function (format) {
  return this.u51(format instanceof Format_4 ? format : THROW_CCE());
};
protoOf(RsaPrivateKeyProcessor).v51 = function (format, key) {
  var tmp;
  if (equals(format, JWK_getInstance_0())) {
    tmp = key;
  } else if (equals(format, Generic_getInstance_2())) {
    tmp = key;
  } else if (equals(format, Generic_getInstance_1())) {
    tmp = unwrapPem(Companion_getInstance_7().y4v_1, key);
  } else if (equals(format, PKCS1_getInstance_2())) {
    tmp = wrapPrivateKey(0, RsaKeyAlgorithmIdentifier_instance, key);
  } else if (equals(format, PKCS1_getInstance_1())) {
    tmp = wrapPrivateKey(0, RsaKeyAlgorithmIdentifier_instance, unwrapPem(Companion_getInstance_7().a4w_1, key));
  } else {
    noWhenBranchMatchedException();
  }
  return tmp;
};
protoOf(RsaPrivateKeyProcessor).f4z = function (format, key) {
  return this.v51(format instanceof Format_4 ? format : THROW_CCE(), key);
};
protoOf(RsaPrivateKeyProcessor).w51 = function (format, key) {
  var tmp;
  if (equals(format, JWK_getInstance_0())) {
    tmp = key;
  } else if (equals(format, Generic_getInstance_2())) {
    tmp = key;
  } else if (equals(format, Generic_getInstance_1())) {
    tmp = wrapPem(Companion_getInstance_7().y4v_1, key);
  } else if (equals(format, PKCS1_getInstance_2())) {
    tmp = unwrapPrivateKey(get_RSA(Companion_instance_0), key);
  } else if (equals(format, PKCS1_getInstance_1())) {
    tmp = wrapPem(Companion_getInstance_7().a4w_1, unwrapPrivateKey(get_RSA(Companion_instance_0), key));
  } else {
    noWhenBranchMatchedException();
  }
  return tmp;
};
protoOf(RsaPrivateKeyProcessor).h4z = function (format, key) {
  return this.w51(format instanceof Format_4 ? format : THROW_CCE(), key);
};
var RsaPrivateKeyProcessor_instance;
function RsaPrivateKeyProcessor_getInstance() {
  if (RsaPrivateKeyProcessor_instance == null)
    new RsaPrivateKeyProcessor();
  return RsaPrivateKeyProcessor_instance;
}
function RsaOaepKeyPair(publicKey, privateKey) {
  this.x51_1 = publicKey;
  this.y51_1 = privateKey;
}
function RsaOaepPublicKey(publicKey) {
  RsaPublicKey.call(this, publicKey);
}
protoOf(RsaOaepPublicKey).c52 = function () {
  return new RsaOaepEncryptor(this.h51_1);
};
function RsaOaepPrivateKey(privateKey) {
  RsaPrivateKey.call(this, privateKey);
}
function WebCryptoRsaOaep$RsaOaepPublicKey$_init_$ref_2xzkj4() {
  var l = function (p0) {
    return new RsaOaepPublicKey(p0);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoRsaOaep$RsaOaepPrivateKey$_init_$ref_ds5c3s() {
  var l = function (p0) {
    return new RsaOaepPrivateKey(p0);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoRsaOaep$RsaOaepKeyPair$_init_$ref_whtofn() {
  var l = function (p0, p1) {
    return new RsaOaepKeyPair(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoRsaOaep() {
  WebCryptoRsaOaep_instance = this;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp = ['encrypt'];
  var tmp_0 = new WebCryptoKeyWrapper(tmp, WebCryptoRsaOaep$RsaOaepPublicKey$_init_$ref_2xzkj4());
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp_1 = ['decrypt'];
  var tmp_2 = new WebCryptoKeyWrapper(tmp_1, WebCryptoRsaOaep$RsaOaepPrivateKey$_init_$ref_ds5c3s());
  WebCryptoRsa.call(this, 'RSA-OAEP', tmp_0, tmp_2, WebCryptoRsaOaep$RsaOaepKeyPair$_init_$ref_whtofn());
}
var WebCryptoRsaOaep_instance;
function WebCryptoRsaOaep_getInstance() {
  if (WebCryptoRsaOaep_instance == null)
    new WebCryptoRsaOaep();
  return WebCryptoRsaOaep_instance;
}
function RsaOaepEncryptor(key) {
  this.d52_1 = key;
}
protoOf(RsaOaepEncryptor).k4v = function (plaintextInput, associatedData, $completion) {
  return WebCrypto_getInstance().a50(RsaOaepCipherAlgorithm(associatedData), this.d52_1, plaintextInput, $completion);
};
protoOf(RsaOaepEncryptor).l4v = function (plaintextInput, associatedData) {
  nonBlocking();
};
function RsaPkcs1KeyPair(publicKey, privateKey) {
  this.e52_1 = publicKey;
  this.f52_1 = privateKey;
}
function RsaPkcs1PublicKey(publicKey) {
  RsaPublicKey.call(this, publicKey);
}
function RsaPkcs1PrivateKey(privateKey) {
  RsaPrivateKey.call(this, privateKey);
}
function WebCryptoRsaPkcs1$RsaPkcs1PublicKey$_init_$ref_kiwvhe() {
  var l = function (p0) {
    return new RsaPkcs1PublicKey(p0);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoRsaPkcs1$RsaPkcs1PrivateKey$_init_$ref_y0qpl2() {
  var l = function (p0) {
    return new RsaPkcs1PrivateKey(p0);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoRsaPkcs1$RsaPkcs1KeyPair$_init_$ref_s062w5() {
  var l = function (p0, p1) {
    return new RsaPkcs1KeyPair(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoRsaPkcs1() {
  WebCryptoRsaPkcs1_instance = this;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp = ['verify'];
  var tmp_0 = new WebCryptoKeyWrapper(tmp, WebCryptoRsaPkcs1$RsaPkcs1PublicKey$_init_$ref_kiwvhe());
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp_1 = ['sign'];
  var tmp_2 = new WebCryptoKeyWrapper(tmp_1, WebCryptoRsaPkcs1$RsaPkcs1PrivateKey$_init_$ref_y0qpl2());
  WebCryptoRsa.call(this, 'RSASSA-PKCS1-v1_5', tmp_0, tmp_2, WebCryptoRsaPkcs1$RsaPkcs1KeyPair$_init_$ref_s062w5());
}
var WebCryptoRsaPkcs1_instance;
function WebCryptoRsaPkcs1_getInstance() {
  if (WebCryptoRsaPkcs1_instance == null)
    new WebCryptoRsaPkcs1();
  return WebCryptoRsaPkcs1_instance;
}
function RsaPssKeyPair(publicKey, privateKey) {
  this.g52_1 = publicKey;
  this.h52_1 = privateKey;
}
function RsaPssPublicKey(publicKey) {
  RsaPublicKey.call(this, publicKey);
}
function RsaPssPrivateKey(privateKey) {
  RsaPrivateKey.call(this, privateKey);
}
function WebCryptoRsaPss$RsaPssPublicKey$_init_$ref_o813fm() {
  var l = function (p0) {
    return new RsaPssPublicKey(p0);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoRsaPss$RsaPssPrivateKey$_init_$ref_6l5g3q() {
  var l = function (p0) {
    return new RsaPssPrivateKey(p0);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoRsaPss$RsaPssKeyPair$_init_$ref_3h8asb() {
  var l = function (p0, p1) {
    return new RsaPssKeyPair(p0, p1);
  };
  l.callableName = '<init>';
  return l;
}
function WebCryptoRsaPss() {
  WebCryptoRsaPss_instance = this;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp = ['verify'];
  var tmp_0 = new WebCryptoKeyWrapper(tmp, WebCryptoRsaPss$RsaPssPublicKey$_init_$ref_o813fm());
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp_1 = ['sign'];
  var tmp_2 = new WebCryptoKeyWrapper(tmp_1, WebCryptoRsaPss$RsaPssPrivateKey$_init_$ref_6l5g3q());
  WebCryptoRsa.call(this, 'RSA-PSS', tmp_0, tmp_2, WebCryptoRsaPss$RsaPssKeyPair$_init_$ref_3h8asb());
}
var WebCryptoRsaPss_instance;
function WebCryptoRsaPss_getInstance() {
  if (WebCryptoRsaPss_instance == null)
    new WebCryptoRsaPss();
  return WebCryptoRsaPss_instance;
}
function unwrapPem(label, key) {
  return ensurePemLabel(PEM_instance.v4v(key), label).u4v_1;
}
function wrapPem(label, key) {
  return PEM_instance.r4v(new PemContent(label, key));
}
function wrapPublicKey(identifier, key) {
  return Default_getInstance_0().i3s(Companion_getInstance_8().u4i(), new SubjectPublicKeyInfo(identifier, new BitArray(0, key)));
}
function unwrapPublicKey(algorithm, key) {
  // Inline function 'kotlin.also' call
  var this_0 = Default_getInstance_0().j3s(Companion_getInstance_8().u4i(), key);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'dev.whyoleg.cryptography.providers.webcrypto.internal.unwrapPublicKey.<anonymous>' call
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(this_0.i4y_1.v4x() === algorithm)) {
    // Inline function 'dev.whyoleg.cryptography.providers.webcrypto.internal.unwrapPublicKey.<anonymous>.<anonymous>' call
    var message = "Expected algorithm '" + _ObjectIdentifier___get_value__impl__wqzjw3(algorithm) + "', received: '" + new ObjectIdentifier(this_0.i4y_1.v4x()) + "'";
    throw IllegalStateException_init_$Create$(toString(message));
  }
  return this_0.j4y_1.f4w_1;
}
function wrapPrivateKey(version, identifier, key) {
  return Default_getInstance_0().i3s(Companion_getInstance_9().u4i(), new PrivateKeyInfo(version, identifier, key));
}
function unwrapPrivateKey(algorithm, key) {
  // Inline function 'kotlin.also' call
  var this_0 = Default_getInstance_0().j3s(Companion_getInstance_9().u4i(), key);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'dev.whyoleg.cryptography.providers.webcrypto.internal.unwrapPrivateKey.<anonymous>' call
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(this_0.o4y_1.v4x() === algorithm)) {
    // Inline function 'kotlin.check.<anonymous>' call
    var message = 'Check failed.';
    throw IllegalStateException_init_$Create$(toString(message));
  }
  return this_0.p4y_1;
}
function hashAlgorithmName(_this__u8e3s4) {
  var tmp;
  if (equals(_this__u8e3s4, SHA1_getInstance())) {
    tmp = 'SHA-1';
  } else if (equals(_this__u8e3s4, SHA256_getInstance())) {
    tmp = 'SHA-256';
  } else if (equals(_this__u8e3s4, SHA384_getInstance())) {
    tmp = 'SHA-384';
  } else if (equals(_this__u8e3s4, SHA512_getInstance())) {
    tmp = 'SHA-512';
  } else {
    throw CryptographyException_init_$Create$('Unsupported hash algorithm: ' + _this__u8e3s4);
  }
  return tmp;
}
function nonBlocking() {
  throw CryptographyException_init_$Create$('Only non-blocking(suspend) calls are supported in WebCrypto');
}
function $encodeToCOROUTINE$4(_this__u8e3s4, format, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.q52_1 = _this__u8e3s4;
  this.r52_1 = format;
}
protoOf($encodeToCOROUTINE$4).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.s52_1 = this.q52_1.y4y_1;
          this.ic_1 = 1;
          suspendResult = WebCrypto_getInstance().t52(this.q52_1.y4y_1.d4z(this.r52_1), this.q52_1.x4y_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var ARGUMENT = suspendResult;
          return this.s52_1.h4z(this.r52_1, ARGUMENT);
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function WebCryptoEncodableKey(key, keyProcessor) {
  this.x4y_1 = key;
  this.y4y_1 = keyProcessor;
}
protoOf(WebCryptoEncodableKey).d4v = function (format, $completion) {
  var tmp = new $encodeToCOROUTINE$4(this, format, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(WebCryptoEncodableKey).e4v = function (format) {
  nonBlocking();
};
function $decodeFromCOROUTINE$5(_this__u8e3s4, format, input, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.c53_1 = _this__u8e3s4;
  this.d53_1 = format;
  this.e53_1 = input;
}
protoOf($decodeFromCOROUTINE$5).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.f53_1 = this.c53_1.i53_1.k50_1;
          this.ic_1 = 1;
          suspendResult = WebCrypto_getInstance().j53(this.c53_1.h53_1.d4z(this.d53_1), this.c53_1.h53_1.f4z(this.d53_1, this.e53_1), this.c53_1.g53_1, true, this.c53_1.i53_1.j50_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var ARGUMENT = suspendResult;
          return this.f53_1(ARGUMENT);
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function WebCryptoKeyDecoder(algorithm, keyProcessor, keyWrapper) {
  this.g53_1 = algorithm;
  this.h53_1 = keyProcessor;
  this.i53_1 = keyWrapper;
}
protoOf(WebCryptoKeyDecoder).g4v = function (format, input, $completion) {
  var tmp = new $decodeFromCOROUTINE$5(this, format, input, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(WebCryptoKeyDecoder).h4v = function (format, input) {
  nonBlocking();
};
function WebCryptoKeyProcessor() {
}
function WebCryptoKeyWrapper(usages, wrap) {
  this.j50_1 = usages;
  this.k50_1 = wrap;
}
function $generateKeyCOROUTINE$6(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.s53_1 = _this__u8e3s4;
}
protoOf($generateKeyCOROUTINE$6).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.t53_1 = this.s53_1.v53_1.k50_1;
          this.ic_1 = 1;
          suspendResult = WebCrypto_getInstance().w53(this.s53_1.u53_1, true, this.s53_1.v53_1.j50_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var ARGUMENT = suspendResult;
          return this.t53_1(ARGUMENT);
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function WebCryptoSymmetricKeyGenerator(algorithm, keyWrapper) {
  this.u53_1 = algorithm;
  this.v53_1 = keyWrapper;
}
protoOf(WebCryptoSymmetricKeyGenerator).i4v = function ($completion) {
  var tmp = new $generateKeyCOROUTINE$6(this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(WebCryptoSymmetricKeyGenerator).j4v = function () {
  nonBlocking();
};
function get_initHook() {
  return initHook_0;
}
var initHook_0;
function initHook$init$() {
  Registry_getInstance().v4u(get_defaultProvider());
  return Unit_instance;
}
function AesGcmCipherAlgorithm(additionalData, iv, tagLength) {
  // Inline function 'kotlin.js.unsafeCast' call
  return additionalData == null ? {name: 'AES-GCM', iv: iv, tagLength: tagLength} : {name: 'AES-GCM', iv: iv, tagLength: tagLength, additionalData: additionalData};
}
function RsaOaepCipherAlgorithm(label) {
  // Inline function 'kotlin.js.unsafeCast' call
  return label == null ? {name: 'RSA-OAEP'} : {name: 'RSA-OAEP', label: label};
}
function AesKeyGenerationAlgorithm(name, length) {
  // Inline function 'kotlin.js.unsafeCast' call
  return {name: name, length: length};
}
function RsaKeyImportAlgorithm(name, hash) {
  // Inline function 'kotlin.js.unsafeCast' call
  return {name: name, hash: hash};
}
function getSubtleCrypto() {
  // Inline function 'kotlin.js.unsafeCast' call
  return function () {
    var isNodeJs = typeof process !== 'undefined' && process.versions != null && process.versions.node != null;
    if (isNodeJs) {
      return eval('require')('node:crypto').webcrypto.subtle;
    } else {
      return (window ? window.crypto ? window.crypto : window.msCrypto : self.crypto).subtle;
    }
  }();
}
function $encryptCOROUTINE$8(_this__u8e3s4, algorithm, key, data, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.f54_1 = _this__u8e3s4;
  this.g54_1 = algorithm;
  this.h54_1 = key;
  this.i54_1 = data;
}
protoOf($encryptCOROUTINE$8).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = await_0(this.f54_1.z4z_1.encrypt(this.g54_1, this.h54_1, this.i54_1), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var ARGUMENT = suspendResult;
          return toByteArray(ARGUMENT);
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $exportKeyCOROUTINE$11(_this__u8e3s4, format, key, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.r54_1 = _this__u8e3s4;
  this.s54_1 = format;
  this.t54_1 = key;
}
protoOf($exportKeyCOROUTINE$11).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = await_0(this.r54_1.z4z_1.exportKey(this.s54_1, this.t54_1), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var keyData = suspendResult;
          var tmp_0;
          if (this.s54_1 === 'jwk') {
            tmp_0 = encodeToByteArray(JSON.stringify(keyData));
          } else {
            tmp_0 = toByteArray(keyData);
          }

          return tmp_0;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function WebCrypto() {
  WebCrypto_instance = this;
  this.z4z_1 = getSubtleCrypto();
}
protoOf(WebCrypto).a50 = function (algorithm, key, data, $completion) {
  var tmp = new $encryptCOROUTINE$8(this, algorithm, key, data, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(WebCrypto).j53 = function (format, keyData, algorithm, extractable, keyUsages, $completion) {
  var key = format === 'jwk' ? JSON.parse(decodeToString(keyData)) : keyData;
  return await_0(this.z4z_1.importKey(format, key, algorithm, extractable, keyUsages), $completion);
};
protoOf(WebCrypto).t52 = function (format, key, $completion) {
  var tmp = new $exportKeyCOROUTINE$11(this, format, key, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(WebCrypto).w53 = function (algorithm, extractable, keyUsages, $completion) {
  return await_0(this.z4z_1.generateKey(algorithm, extractable, keyUsages), $completion);
};
var WebCrypto_instance;
function WebCrypto_getInstance() {
  if (WebCrypto_instance == null)
    new WebCrypto();
  return WebCrypto_instance;
}
function toByteArray(_this__u8e3s4) {
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return new Int8Array(_this__u8e3s4);
}
function await_0(_this__u8e3s4, $completion) {
  var tmp = new $awaitCOROUTINE$12(_this__u8e3s4, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function await$lambda($continuation) {
  return function (it) {
    // Inline function 'kotlin.coroutines.resume' call
    var this_0 = $continuation;
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(it);
    this_0.j6(tmp$ret$0);
    return null;
  };
}
function await$lambda_0($continuation) {
  return function (it) {
    // Inline function 'kotlin.coroutines.resumeWithException' call
    var this_0 = $continuation;
    // Inline function 'kotlin.Companion.failure' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(createFailure(it));
    this_0.j6(tmp$ret$0);
    return null;
  };
}
function $awaitCOROUTINE$12(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.c55_1 = _this__u8e3s4;
}
protoOf($awaitCOROUTINE$12).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          var safe = SafeContinuation_init_$Create$(intercepted(this));
          var tmp_0 = await$lambda(safe);
          this.c55_1.then(tmp_0, await$lambda_0(safe));
          suspendResult = returnIfSuspended(safe.k6(), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          return suspendResult;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
//region block: post-declaration
protoOf(AesGcmKey).c4v = cipher$default;
protoOf(AesGcmCipher).m4v = encrypt;
protoOf(AesGcmCipher).n4v = encryptBlocking;
protoOf(RsaOaepEncryptor).m4v = encrypt;
protoOf(RsaOaepEncryptor).n4v = encryptBlocking;
//endregion
//region block: init
initHook_0 = initHook$init$();
//endregion
//region block: exports
var initHook = {get: get_initHook};
export {
  initHook as initHook,
};
//endregion

//# sourceMappingURL=cryptography-kotlin-cryptography-provider-webcrypto.mjs.map
