import {
  protoOf180f3jzyo7rfj as protoOf,
  classMetawt99a3kyl3us as classMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  VOID7hggqo3abtya as VOID,
  CoroutineImpl2sn3kjnwmfr10 as CoroutineImpl,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  plus1ogy4liedzq5j as plus,
  toMutableSetjdpdbr9jsqq8 as toMutableSet,
  ArrayList_init_$Create$2qnngtk1et9r9 as ArrayList_init_$Create$,
  objectMeta213120oau977m as objectMeta,
  toString1pkumu07cwy4m as toString,
  Collection1k04j3hzsbod0 as Collection,
  isInterface3d6p8outrmvmk as isInterface,
  getKClassFromExpression3vpejubogshaw as getKClassFromExpression,
  Unitkvevlwgzwiuc as Unit,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  equals2au1ep9vhcato as equals,
  joinToString1cxrrlmo0chqs as joinToString,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  ArrayList_init_$Create$1s1wkrw82c0iw as ArrayList_init_$Create$_0,
  Exceptiondt2hlxn7j7vw as Exception,
  Exception_init_$Init$32vb8wlewqrmh as Exception_init_$Init$,
  captureStack1fzi4aczwc4hg as captureStack,
  PrimitiveClasses_getInstance2v63zn04dtq03 as PrimitiveClasses_getInstance,
  getKClass1s3j9wy1cofik as getKClass,
  setOf45ia9pnfhe90 as setOf,
  endsWith3cq61xxngobwh as endsWith,
  startsWith26w8qjqapeeq6 as startsWith,
  LinkedHashSet_init_$Create$3qv13l7kzf0ni as LinkedHashSet_init_$Create$,
} from './kotlin-kotlin-stdlib.mjs';
import {
  PipelineContext34fsb0mycu471 as PipelineContext,
  AttributeKey3aq8ytwgx54f7 as AttributeKey,
  KtorSimpleLogger1xdphsp5l4e48 as KtorSimpleLogger,
} from './ktor-ktor-utils.mjs';
import {
  HttpResponseContainer3r9yzy4mwwvc9 as HttpResponseContainer,
  Phases_getInstance3gwf7ca9zp4r6 as Phases_getInstance,
  Phases_getInstance3cv4l5wlctlnh as Phases_getInstance_0,
  HttpClientPlugin3rce8c1crrw1q as HttpClientPlugin,
  accept2gi3b7wj4jds9 as accept,
  EmptyContent_getInstance116ybdh9l8hek as EmptyContent_getInstance,
} from './ktor-ktor-client-core.mjs';
import {
  contentType317fn4f991q9a as contentType,
  Application_getInstanceq87g3bor693u as Application_getInstance,
  OutgoingContent3t2ohmyam9o76 as OutgoingContent,
  contentType2zzm38yxo3syt as contentType_0,
  HttpHeaders_getInstanceelogg8fjd54u as HttpHeaders_getInstance,
  charset1dribv3ku48b1 as charset,
  NullBody_instance2i6w0hfghwfg0 as NullBody_instance,
  HttpStatusCode3o1wkms10pg4k as HttpStatusCode,
} from './ktor-ktor-http.mjs';
import {
  suitableCharset1jgdcpdzbzgzn as suitableCharset,
  register$default1vru4l6f6i5dq as register$default,
  Configuration20xgygxdzhlk5 as Configuration,
  deserialize3kqe4vxpbxz1 as deserialize,
} from './ktor-ktor-serialization.mjs';
import {
  Charsets_getInstanceqs70pvl4noow as Charsets_getInstance,
  ByteReadChannel2wzou76jce72d as ByteReadChannel,
} from './ktor-ktor-io.mjs';
//region block: imports
//endregion
//region block: pre-declaration
setMetadataFor(ConverterRegistration, 'ConverterRegistration', classMeta);
setMetadataFor(ContentNegotiation$Config$defaultMatcher$1, VOID, classMeta);
setMetadataFor(ContentNegotiation$Plugin$install$slambda, 'ContentNegotiation$Plugin$install$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [2]);
setMetadataFor(ContentNegotiation$Plugin$install$slambda_1, 'ContentNegotiation$Plugin$install$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [2]);
setMetadataFor(Config, 'Config', classMeta, VOID, [Configuration], Config);
setMetadataFor(Plugin, 'Plugin', objectMeta, VOID, [HttpClientPlugin]);
setMetadataFor($convertRequestCOROUTINE$0, '$convertRequestCOROUTINE$0', classMeta, CoroutineImpl);
setMetadataFor($convertResponseCOROUTINE$1, '$convertResponseCOROUTINE$1', classMeta, CoroutineImpl);
setMetadataFor(ContentNegotiation, 'ContentNegotiation', classMeta, VOID, VOID, VOID, VOID, VOID, [2, 5]);
setMetadataFor(ContentConverterException, 'ContentConverterException', classMeta, Exception);
setMetadataFor(JsonContentTypeMatcher, 'JsonContentTypeMatcher', objectMeta);
//endregion
function get_LOGGER() {
  _init_properties_ContentNegotiation_kt__o183go();
  return LOGGER;
}
var LOGGER;
function get_DefaultCommonIgnoredTypes() {
  _init_properties_ContentNegotiation_kt__o183go();
  return DefaultCommonIgnoredTypes;
}
var DefaultCommonIgnoredTypes;
function ConverterRegistration(converter, contentTypeToSend, contentTypeMatcher) {
  this.q3g_1 = converter;
  this.r3g_1 = contentTypeToSend;
  this.s3g_1 = contentTypeMatcher;
}
function defaultMatcher($this, pattern) {
  return new ContentNegotiation$Config$defaultMatcher$1(pattern);
}
function ContentNegotiation$Config$defaultMatcher$1($pattern) {
  this.t3g_1 = $pattern;
}
protoOf(ContentNegotiation$Config$defaultMatcher$1).u3g = function (contentType) {
  return contentType.z22(this.t3g_1);
};
function ContentNegotiation$Plugin$install$slambda($plugin, resultContinuation) {
  this.d3h_1 = $plugin;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(ContentNegotiation$Plugin$install$slambda).n2h = function ($this$intercept, it, $completion) {
  var tmp = this.o2h($this$intercept, it, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ContentNegotiation$Plugin$install$slambda).dk = function (p1, p2, $completion) {
  var tmp = p1 instanceof PipelineContext ? p1 : THROW_CCE();
  return this.n2h(tmp, !(p2 == null) ? p2 : THROW_CCE(), $completion);
};
protoOf(ContentNegotiation$Plugin$install$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          this.ic_1 = 1;
          suspendResult = this.d3h_1.k3h(this.e3h_1.j20_1, this.e3h_1.m1z(), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.g3h_1 = suspendResult;
          var tmp_0 = this;
          var tmp_1;
          if (this.g3h_1 == null) {
            return Unit_instance;
          } else {
            tmp_1 = this.g3h_1;
          }

          tmp_0.h3h_1 = tmp_1;
          this.ic_1 = 2;
          suspendResult = this.e3h_1.n1z(this.h3h_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          return Unit_instance;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
protoOf(ContentNegotiation$Plugin$install$slambda).o2h = function ($this$intercept, it, completion) {
  var i = new ContentNegotiation$Plugin$install$slambda(this.d3h_1, completion);
  i.e3h_1 = $this$intercept;
  i.f3h_1 = it;
  return i;
};
function ContentNegotiation$Plugin$install$slambda_0($plugin, resultContinuation) {
  var i = new ContentNegotiation$Plugin$install$slambda($plugin, resultContinuation);
  var l = function ($this$intercept, it, $completion) {
    return i.n2h($this$intercept, it, $completion);
  };
  l.$arity = 2;
  return l;
}
function ContentNegotiation$Plugin$install$slambda_1($plugin, resultContinuation) {
  this.t3h_1 = $plugin;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(ContentNegotiation$Plugin$install$slambda_1).h2i = function ($this$intercept, _name_for_destructuring_parameter_0__wldtmu, $completion) {
  var tmp = this.i2i($this$intercept, _name_for_destructuring_parameter_0__wldtmu, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ContentNegotiation$Plugin$install$slambda_1).dk = function (p1, p2, $completion) {
  var tmp = p1 instanceof PipelineContext ? p1 : THROW_CCE();
  return this.h2i(tmp, p2 instanceof HttpResponseContainer ? p2 : THROW_CCE(), $completion);
};
protoOf(ContentNegotiation$Plugin$install$slambda_1).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          this.w3h_1 = this.v3h_1.we();
          this.x3h_1 = this.v3h_1.xe();
          var tmp_0 = this;
          var tmp0_elvis_lhs = contentType(this.u3h_1.j20_1.u2h());
          var tmp_1;
          if (tmp0_elvis_lhs == null) {
            this.u3h_1;
            get_LOGGER().e21('Response doesn\'t have "Content-Type" header, skipping ContentNegotiation plugin');
            return Unit_instance;
          } else {
            tmp_1 = tmp0_elvis_lhs;
          }

          tmp_0.y3h_1 = tmp_1;
          this.z3h_1 = suitableCharset(this.u3h_1.j20_1.d2l().h27());
          this.ic_1 = 1;
          suspendResult = this.t3h_1.d3i(this.u3h_1.j20_1.d2l().g2l(), this.w3h_1, this.x3h_1, this.y3h_1, this.z3h_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.a3i_1 = suspendResult;
          var tmp_2 = this;
          var tmp_3;
          if (this.a3i_1 == null) {
            return Unit_instance;
          } else {
            tmp_3 = this.a3i_1;
          }

          tmp_2.b3i_1 = tmp_3;
          this.c3i_1 = new HttpResponseContainer(this.w3h_1, this.b3i_1);
          this.ic_1 = 2;
          suspendResult = this.u3h_1.n1z(this.c3i_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          return Unit_instance;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
protoOf(ContentNegotiation$Plugin$install$slambda_1).i2i = function ($this$intercept, _name_for_destructuring_parameter_0__wldtmu, completion) {
  var i = new ContentNegotiation$Plugin$install$slambda_1(this.t3h_1, completion);
  i.u3h_1 = $this$intercept;
  i.v3h_1 = _name_for_destructuring_parameter_0__wldtmu;
  return i;
};
function ContentNegotiation$Plugin$install$slambda_2($plugin, resultContinuation) {
  var i = new ContentNegotiation$Plugin$install$slambda_1($plugin, resultContinuation);
  var l = function ($this$intercept, _name_for_destructuring_parameter_0__wldtmu, $completion) {
    return i.h2i($this$intercept, _name_for_destructuring_parameter_0__wldtmu, $completion);
  };
  l.$arity = 2;
  return l;
}
function Config() {
  this.e3i_1 = toMutableSet(plus(get_DefaultIgnoredTypes(), get_DefaultCommonIgnoredTypes()));
  var tmp = this;
  // Inline function 'kotlin.collections.mutableListOf' call
  tmp.f3i_1 = ArrayList_init_$Create$();
}
protoOf(Config).a2e = function (contentType, converter, configuration) {
  var matcher = contentType.equals(Application_getInstance().s21_1) ? JsonContentTypeMatcher_instance : defaultMatcher(this, contentType);
  this.g3i(contentType, converter, matcher, configuration);
};
protoOf(Config).g3i = function (contentTypeToSend, converter, contentTypeMatcher, configuration) {
  // Inline function 'kotlin.apply' call
  // Inline function 'kotlin.contracts.contract' call
  configuration(converter);
  var registration = new ConverterRegistration(converter, contentTypeToSend, contentTypeMatcher);
  this.f3i_1.r(registration);
};
function Plugin() {
  Plugin_instance = this;
  this.h3i_1 = new AttributeKey('ContentNegotiation');
}
protoOf(Plugin).k2 = function () {
  return this.h3i_1;
};
protoOf(Plugin).i3i = function (block) {
  // Inline function 'kotlin.apply' call
  var this_0 = new Config();
  // Inline function 'kotlin.contracts.contract' call
  block(this_0);
  var config = this_0;
  return new ContentNegotiation(config.f3i_1, config.e3i_1);
};
protoOf(Plugin).y2j = function (block) {
  return this.i3i(block);
};
protoOf(Plugin).j3i = function (plugin, scope) {
  var tmp = Phases_getInstance().s2p_1;
  scope.t2g_1.n20(tmp, ContentNegotiation$Plugin$install$slambda_0(plugin, null));
  var tmp_0 = Phases_getInstance_0().t2j_1;
  scope.u2g_1.n20(tmp_0, ContentNegotiation$Plugin$install$slambda_2(plugin, null));
};
protoOf(Plugin).z2j = function (plugin, scope) {
  return this.j3i(plugin instanceof ContentNegotiation ? plugin : THROW_CCE(), scope);
};
var Plugin_instance;
function Plugin_getInstance() {
  if (Plugin_instance == null)
    new Plugin();
  return Plugin_instance;
}
function ContentNegotiation$convertRequest$lambda(it) {
  return toString(it.q3g_1);
}
function $convertRequestCOROUTINE$0(_this__u8e3s4, request, body, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.s3i_1 = _this__u8e3s4;
  this.t3i_1 = request;
  this.u3i_1 = body;
}
protoOf($convertRequestCOROUTINE$0).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 7;
          var tmp0_iterator = this.s3i_1.i3h_1.u();
          while (tmp0_iterator.v()) {
            var element = tmp0_iterator.w();
            get_LOGGER().e21('Adding Accept=' + element.r3g_1.v22_1 + ' header for ' + this.t3i_1.t2i_1);
            accept(this.t3i_1, element.r3g_1);
          }

          var tmp_0;
          var tmp_1 = this.u3i_1;
          if (tmp_1 instanceof OutgoingContent) {
            tmp_0 = true;
          } else {
            var tmp$ret$0;
            l$ret$1: do {
              var this_0 = this.s3i_1.j3h_1;
              var tmp_2;
              if (isInterface(this_0, Collection)) {
                tmp_2 = this_0.b1();
              } else {
                tmp_2 = false;
              }
              if (tmp_2) {
                tmp$ret$0 = false;
                break l$ret$1;
              }
              var tmp0_iterator_0 = this_0.u();
              while (tmp0_iterator_0.v()) {
                var element_0 = tmp0_iterator_0.w();
                if (element_0.t6(this.u3i_1)) {
                  tmp$ret$0 = true;
                  break l$ret$1;
                }
              }
              tmp$ret$0 = false;
            }
             while (false);
            tmp_0 = tmp$ret$0;
          }

          if (tmp_0) {
            get_LOGGER().e21('Body type ' + getKClassFromExpression(this.u3i_1) + ' is in ignored types. ' + ('Skipping ContentNegotiation for ' + this.t3i_1.t2i_1 + '.'));
            return null;
          }

          var tmp_3 = this;
          var tmp0_elvis_lhs = contentType_0(this.t3i_1);
          var tmp_4;
          if (tmp0_elvis_lhs == null) {
            this.s3i_1;
            get_LOGGER().e21("Request doesn't have Content-Type header. Skipping ContentNegotiation for " + this.t3i_1.t2i_1 + '.');
            return null;
          } else {
            tmp_4 = tmp0_elvis_lhs;
          }

          tmp_3.v3i_1 = tmp_4;
          var tmp_5 = this.u3i_1;
          if (tmp_5 instanceof Unit) {
            get_LOGGER().e21('Sending empty body for ' + this.t3i_1.t2i_1);
            this.t3i_1.v2i_1.x1x(HttpHeaders_getInstance().w23_1);
            return EmptyContent_getInstance();
          }

          var tmp_6 = this;
          var this_1 = this.s3i_1.i3h_1;
          var destination = ArrayList_init_$Create$();
          var tmp0_iterator_1 = this_1.u();
          while (tmp0_iterator_1.v()) {
            var element_1 = tmp0_iterator_1.w();
            if (element_1.s3g_1.u3g(this.v3i_1)) {
              destination.r(element_1);
            }
          }

          var tmp_7;
          if (!destination.b1()) {
            tmp_7 = destination;
          } else {
            tmp_7 = null;
          }

          var tmp1_elvis_lhs = tmp_7;
          var tmp_8;
          if (tmp1_elvis_lhs == null) {
            this.s3i_1;
            get_LOGGER().e21('None of the registered converters match request Content-Type=' + this.v3i_1 + '. ' + ('Skipping ContentNegotiation for ' + this.t3i_1.t2i_1 + '.'));
            return null;
          } else {
            tmp_8 = tmp1_elvis_lhs;
          }

          tmp_6.w3i_1 = tmp_8;
          if (this.t3i_1.b37() == null) {
            get_LOGGER().e21('Request has unknown body type. Skipping ContentNegotiation for ' + this.t3i_1.t2i_1 + '.');
            return null;
          }

          this.t3i_1.v2i_1.x1x(HttpHeaders_getInstance().w23_1);
          this.ic_1 = 1;
          continue $sm;
        case 1:
          var tmp_9 = this;
          tmp_9.y3i_1 = this.w3i_1;
          this.z3i_1 = this.y3i_1.u();
          this.ic_1 = 2;
          continue $sm;
        case 2:
          if (!this.z3i_1.v()) {
            this.ic_1 = 5;
            continue $sm;
          }

          this.a3j_1 = this.z3i_1.w();
          var tmp_10 = this;
          tmp_10.b3j_1 = this.a3j_1;
          this.ic_1 = 3;
          var tmp0_elvis_lhs_0 = charset(this.v3i_1);
          var tmp_11 = tmp0_elvis_lhs_0 == null ? Charsets_getInstance().t1p_1 : tmp0_elvis_lhs_0;
          var tmp_12 = ensureNotNull(this.t3i_1.b37());
          var this_2 = this.u3i_1;
          var tmp_13;
          if (!equals(this_2, NullBody_instance)) {
            tmp_13 = this_2;
          } else {
            tmp_13 = null;
          }

          suspendResult = this.b3j_1.q3g_1.d2e(this.v3i_1, tmp_11, tmp_12, tmp_13, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 3:
          var result = suspendResult;
          if (!(result == null)) {
            get_LOGGER().e21('Converted request body using ' + this.b3j_1.q3g_1 + ' for ' + this.t3i_1.t2i_1);
          }

          var result_0 = result;
          if (!(result_0 == null)) {
            this.x3i_1 = result_0;
            this.ic_1 = 6;
            continue $sm;
          } else {
            this.ic_1 = 4;
            continue $sm;
          }

        case 4:
          this.ic_1 = 2;
          continue $sm;
        case 5:
          this.x3i_1 = null;
          if (false) {
            this.ic_1 = 1;
            continue $sm;
          }

          this.ic_1 = 6;
          continue $sm;
        case 6:
          var tmp2_elvis_lhs = this.x3i_1;
          var tmp_14;
          if (tmp2_elvis_lhs == null) {
            var tmp_15 = "Can't convert " + toString(this.u3i_1) + ' with contentType ' + this.v3i_1 + ' using converters ';
            throw new ContentConverterException(tmp_15 + joinToString(this.w3i_1, VOID, VOID, VOID, VOID, VOID, ContentNegotiation$convertRequest$lambda));
          } else {
            tmp_14 = tmp2_elvis_lhs;
          }

          var serializedContent = tmp_14;
          return serializedContent;
        case 7:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 7) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $convertResponseCOROUTINE$1(_this__u8e3s4, requestUrl, info, body, responseContentType, charset, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.k3j_1 = _this__u8e3s4;
  this.l3j_1 = requestUrl;
  this.m3j_1 = info;
  this.n3j_1 = body;
  this.o3j_1 = responseContentType;
  this.p3j_1 = charset;
}
protoOf($convertResponseCOROUTINE$1).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          var tmp_0 = this.n3j_1;
          if (!isInterface(tmp_0, ByteReadChannel)) {
            get_LOGGER().e21('Response body is already transformed. Skipping ContentNegotiation for ' + this.l3j_1 + '.');
            return null;
          }

          if (this.k3j_1.j3h_1.z(this.m3j_1.z20_1)) {
            get_LOGGER().e21('Response body type ' + this.m3j_1.z20_1 + ' is in ignored types. ' + ('Skipping ContentNegotiation for ' + this.l3j_1 + '.'));
            return null;
          }

          var tmp_1 = this;
          var this_0 = this.k3j_1.i3h_1;
          var destination = ArrayList_init_$Create$();
          var tmp0_iterator = this_0.u();
          while (tmp0_iterator.v()) {
            var element = tmp0_iterator.w();
            if (element.s3g_1.u3g(this.o3j_1)) {
              destination.r(element);
            }
          }

          var destination_0 = ArrayList_init_$Create$_0(collectionSizeOrDefault(destination, 10));
          var tmp0_iterator_0 = destination.u();
          while (tmp0_iterator_0.v()) {
            var item = tmp0_iterator_0.w();
            destination_0.r(item.q3g_1);
          }

          var tmp_2;
          if (!destination_0.b1()) {
            tmp_2 = destination_0;
          } else {
            tmp_2 = null;
          }

          var tmp0_elvis_lhs = tmp_2;
          var tmp_3;
          if (tmp0_elvis_lhs == null) {
            this.k3j_1;
            get_LOGGER().e21('None of the registered converters match response with Content-Type=' + this.o3j_1 + '. ' + ('Skipping ContentNegotiation for ' + this.l3j_1 + '.'));
            return null;
          } else {
            tmp_3 = tmp0_elvis_lhs;
          }

          tmp_1.q3j_1 = tmp_3;
          this.ic_1 = 1;
          suspendResult = deserialize(this.q3j_1, this.n3j_1, this.m3j_1, this.p3j_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var result = suspendResult;
          if (!isInterface(result, ByteReadChannel)) {
            get_LOGGER().e21('Response body was converted to ' + getKClassFromExpression(result) + ' for ' + this.l3j_1 + '.');
          }

          return result;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function ContentNegotiation(registrations, ignoredTypes) {
  Plugin_getInstance();
  this.i3h_1 = registrations;
  this.j3h_1 = ignoredTypes;
}
protoOf(ContentNegotiation).k3h = function (request, body, $completion) {
  var tmp = new $convertRequestCOROUTINE$0(this, request, body, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ContentNegotiation).d3i = function (requestUrl, info, body, responseContentType, charset, $completion) {
  var tmp = new $convertResponseCOROUTINE$1(this, requestUrl, info, body, responseContentType, charset, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
function ContentConverterException(message) {
  Exception_init_$Init$(message, this);
  captureStack(this, ContentConverterException);
}
var properties_initialized_ContentNegotiation_kt_1ayduy;
function _init_properties_ContentNegotiation_kt__o183go() {
  if (!properties_initialized_ContentNegotiation_kt_1ayduy) {
    properties_initialized_ContentNegotiation_kt_1ayduy = true;
    LOGGER = KtorSimpleLogger('io.ktor.client.plugins.contentnegotiation.ContentNegotiation');
    DefaultCommonIgnoredTypes = setOf([PrimitiveClasses_getInstance().x7(), PrimitiveClasses_getInstance().t7(), getKClass(HttpStatusCode), getKClass(ByteReadChannel), getKClass(OutgoingContent)]);
  }
}
function JsonContentTypeMatcher() {
}
protoOf(JsonContentTypeMatcher).u3g = function (contentType) {
  if (contentType.z22(Application_getInstance().s21_1)) {
    return true;
  }
  var value = contentType.y22().toString();
  return startsWith(value, 'application/') ? endsWith(value, '+json') : false;
};
var JsonContentTypeMatcher_instance;
function JsonContentTypeMatcher_getInstance() {
  return JsonContentTypeMatcher_instance;
}
function get_DefaultIgnoredTypes() {
  _init_properties_DefaultIgnoredTypesJs_kt__rjtdk1();
  return DefaultIgnoredTypes;
}
var DefaultIgnoredTypes;
var properties_initialized_DefaultIgnoredTypesJs_kt_65g2xt;
function _init_properties_DefaultIgnoredTypesJs_kt__rjtdk1() {
  if (!properties_initialized_DefaultIgnoredTypesJs_kt_65g2xt) {
    properties_initialized_DefaultIgnoredTypesJs_kt_65g2xt = true;
    // Inline function 'kotlin.collections.mutableSetOf' call
    DefaultIgnoredTypes = LinkedHashSet_init_$Create$();
  }
}
//region block: post-declaration
protoOf(Config).b2e = register$default;
//endregion
//region block: init
JsonContentTypeMatcher_instance = new JsonContentTypeMatcher();
//endregion
//region block: exports
export {
  Plugin_getInstance as Plugin_getInstance21w9qppp8svkg,
};
//endregion

//# sourceMappingURL=ktor-ktor-client-content-negotiation.mjs.map
