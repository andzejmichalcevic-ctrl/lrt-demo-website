import {
  protoOf180f3jzyo7rfj as protoOf,
  objectMeta213120oau977m as objectMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  VOID7hggqo3abtya as VOID,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  last1x5hqf11b8kkw as last,
  countTrailingZeroBitszhs0313cn11e as countTrailingZeroBits,
  toString1pkumu07cwy4m as toString,
  IllegalStateException_init_$Create$3ib9qa3pip8n4 as IllegalStateException_init_$Create$,
  objectCreate1ve4bgxiu4x98 as objectCreate,
  classMetawt99a3kyl3us as classMeta,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  copyOfRange3alro60z4hhf8 as copyOfRange,
  takeHighestOneBit9p7rdtda63bc as takeHighestOneBit,
  copyOfwy6h3t5vzqpl as copyOf,
  toByte4i43936u611k as toByte,
  arrayCopytctsywo3h7gj as arrayCopy,
  equals2au1ep9vhcato as equals,
  isByteArray4nnzfn1x4o3w as isByteArray,
  StringBuilder_init_$Create$2mwec1027v00x as StringBuilder_init_$Create$,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  IntCompanionObject_instance3tw56cgyd5vup as IntCompanionObject_instance,
  split2bvyvnrlcifjv as split,
  toInt2q8uldh7sc951 as toInt,
} from './kotlin-kotlin-stdlib.mjs';
import {
  PluginGeneratedSerialDescriptorqdzeg5asqhfg as PluginGeneratedSerialDescriptor,
  IntSerializer_getInstance2q7s8kvk1il5u as IntSerializer_getInstance,
  ByteArraySerializer_getInstance1p0ix35e82iv6 as ByteArraySerializer_getInstance,
  UnknownFieldException_init_$Create$1mnsp66c6fnup as UnknownFieldException_init_$Create$,
  typeParametersSerializers2likxjr48tr7y as typeParametersSerializers,
  GeneratedSerializer1f7t7hssdd2ws as GeneratedSerializer,
  throwMissingFieldException2cmke0v3ynf14 as throwMissingFieldException,
  EmptySerializersModule991ju6pz9b79 as EmptySerializersModule,
  BinaryFormat3f3aelhmz0ro1 as BinaryFormat,
  InlineClassDescriptor2odlvyasjrmr0 as InlineClassDescriptor,
  StringSerializer_getInstance2wffkbpdux3h9 as StringSerializer_getInstance,
  AbstractDecoder35guh02ubh2hm as AbstractDecoder,
  Companion_instance2e54edlpusznp as Companion_instance,
  ByteArraySerializersn06x87bo7h0 as ByteArraySerializer,
  PolymorphicKindla9gurooefwb as PolymorphicKind,
  CLASS_getInstance14ex35co4jkrb as CLASS_getInstance,
  SerializationException_init_$Create$1byppqmdb64jn as SerializationException_init_$Create$,
  AbstractEncoder2gxtu3xmy3f8j as AbstractEncoder,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
import {
  Companion_getInstance1jgozvdka497o as Companion_getInstance,
  toBigInt2ed03w99r27qk as toBigInt,
  toBigInt29u3xna2n8w21 as toBigInt_0,
  toBigInt3kphjqnio21gn as toBigInt_1,
  toBigInt11bczolyoumqk as toBigInt_2,
  BigInt23zwv5kv3od56 as BigInt,
  decodeToBigInt1petkle13vaiv as decodeToBigInt,
  encodeToByteArrayripney4e4aue as encodeToByteArray,
} from './cryptography-kotlin-cryptography-bigint.mjs';
//region block: imports
var imul = Math.imul;
var clz32 = Math.clz32;
//endregion
//region block: pre-declaration
setMetadataFor(Companion, 'Companion', objectMeta);
setMetadataFor($serializer, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(BitArray, 'BitArray', classMeta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance});
setMetadataFor(DER, 'DER', classMeta, VOID, [BinaryFormat]);
setMetadataFor(Default, 'Default', objectMeta, DER);
setMetadataFor(Companion_0, 'Companion', objectMeta);
setMetadataFor($serializer_0, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(ObjectIdentifier, 'ObjectIdentifier', classMeta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_0});
setMetadataFor(ByteArrayInput, 'ByteArrayInput', classMeta);
setMetadataFor(ByteArrayOutput, 'ByteArrayOutput', classMeta, VOID, VOID, ByteArrayOutput);
setMetadataFor(DerDecoder, 'DerDecoder', classMeta, AbstractDecoder);
setMetadataFor(DerEncoder, 'DerEncoder', classMeta, AbstractEncoder);
setMetadataFor(DerInput, 'DerInput', classMeta);
setMetadataFor(DerOutput, 'DerOutput', classMeta);
//endregion
function Companion() {
}
protoOf(Companion).u4i = function () {
  return $serializer_getInstance();
};
var Companion_instance_0;
function Companion_getInstance_0() {
  return Companion_instance_0;
}
function $serializer() {
  $serializer_instance = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('dev.whyoleg.cryptography.serialization.asn1.BitArray', this, 2);
  tmp0_serialDesc.w41('unusedBits', false);
  tmp0_serialDesc.w41('byteArray', false);
  this.c4w_1 = tmp0_serialDesc;
}
protoOf($serializer).z3q = function () {
  return this.c4w_1;
};
protoOf($serializer).l42 = function () {
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [IntSerializer_getInstance(), ByteArraySerializer_getInstance()];
};
protoOf($serializer).n3r = function (decoder) {
  var tmp0_desc = this.c4w_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = 0;
  var tmp5_local1 = null;
  var tmp6_input = decoder.m3u(tmp0_desc);
  if (tmp6_input.b3v()) {
    tmp4_local0 = tmp6_input.r3u(tmp0_desc, 0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp6_input.y3u(tmp0_desc, 1, ByteArraySerializer_getInstance(), tmp5_local1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp6_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp6_input.r3u(tmp0_desc, 0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp6_input.y3u(tmp0_desc, 1, ByteArraySerializer_getInstance(), tmp5_local1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp6_input.n3u(tmp0_desc);
  return BitArray_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
};
protoOf($serializer).d4w = function (encoder, value) {
  var tmp0_desc = this.c4w_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  tmp1_output.v3v(tmp0_desc, 0, value.e4w_1);
  tmp1_output.c3w(tmp0_desc, 1, ByteArraySerializer_getInstance(), value.f4w_1);
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer).m3r = function (encoder, value) {
  return this.d4w(encoder, value instanceof BitArray ? value : THROW_CCE());
};
var $serializer_instance;
function $serializer_getInstance() {
  if ($serializer_instance == null)
    new $serializer();
  return $serializer_instance;
}
function BitArray_init_$Init$(seen1, unusedBits, byteArray, serializationConstructorMarker, $this) {
  if (!(3 === (3 & seen1))) {
    throwMissingFieldException(seen1, 3, $serializer_getInstance().c4w_1);
  }
  $this.e4w_1 = unusedBits;
  $this.f4w_1 = byteArray;
  // Inline function 'kotlin.collections.isEmpty' call
  if ($this.f4w_1.length === 0) {
    // Inline function 'kotlin.check' call
    // Inline function 'kotlin.contracts.contract' call
    if (!($this.e4w_1 === 0)) {
      // Inline function 'dev.whyoleg.cryptography.serialization.asn1.BitArray.<init>.<anonymous>' call
      var message = "empty array couldn't have unused bits";
      throw IllegalStateException_init_$Create$(toString(message));
    }
  } else {
    // Inline function 'kotlin.check' call
    // Inline function 'kotlin.countTrailingZeroBits' call
    var this_0 = last($this.f4w_1);
    var tmp$ret$2 = countTrailingZeroBits(this_0 | 256);
    // Inline function 'kotlin.contracts.contract' call
    if (!($this.e4w_1 <= tmp$ret$2)) {
      // Inline function 'dev.whyoleg.cryptography.serialization.asn1.BitArray.<init>.<anonymous>' call
      var message_0 = 'At least ' + $this.e4w_1 + ' last bits should be unused';
      throw IllegalStateException_init_$Create$(toString(message_0));
    }
  }
  return $this;
}
function BitArray_init_$Create$(seen1, unusedBits, byteArray, serializationConstructorMarker) {
  return BitArray_init_$Init$(seen1, unusedBits, byteArray, serializationConstructorMarker, objectCreate(protoOf(BitArray)));
}
function BitArray(unusedBits, byteArray) {
  this.e4w_1 = unusedBits;
  this.f4w_1 = byteArray;
  // Inline function 'kotlin.collections.isEmpty' call
  if (this.f4w_1.length === 0) {
    // Inline function 'kotlin.check' call
    // Inline function 'kotlin.contracts.contract' call
    if (!(this.e4w_1 === 0)) {
      // Inline function 'dev.whyoleg.cryptography.serialization.asn1.BitArray.<anonymous>' call
      var message = "empty array couldn't have unused bits";
      throw IllegalStateException_init_$Create$(toString(message));
    }
  } else {
    // Inline function 'kotlin.check' call
    // Inline function 'kotlin.countTrailingZeroBits' call
    var this_0 = last(this.f4w_1);
    var tmp$ret$2 = countTrailingZeroBits(this_0 | 256);
    // Inline function 'kotlin.contracts.contract' call
    if (!(this.e4w_1 <= tmp$ret$2)) {
      // Inline function 'dev.whyoleg.cryptography.serialization.asn1.BitArray.<anonymous>' call
      var message_0 = 'At least ' + this.e4w_1 + ' last bits should be unused';
      throw IllegalStateException_init_$Create$(toString(message_0));
    }
  }
}
function Default() {
  Default_instance = this;
  DER.call(this, EmptySerializersModule());
}
var Default_instance;
function Default_getInstance() {
  if (Default_instance == null)
    new Default();
  return Default_instance;
}
function DER(serializersModule) {
  Default_getInstance();
  this.g4w_1 = serializersModule;
}
protoOf(DER).k3r = function () {
  return this.g4w_1;
};
protoOf(DER).i3s = function (serializer, value) {
  var output = new ByteArrayOutput();
  (new DerEncoder(this, output)).l3r(serializer, value);
  return output.m4w();
};
protoOf(DER).j3s = function (deserializer, bytes) {
  var input = new ByteArrayInput(bytes);
  return (new DerDecoder(this, input)).o3r(deserializer);
};
function _ObjectIdentifier___init__impl__7hutfr(value) {
  return value;
}
function _ObjectIdentifier___get_value__impl__wqzjw3($this) {
  return $this;
}
function Companion_0() {
}
protoOf(Companion_0).u4i = function () {
  return $serializer_getInstance_0();
};
var Companion_instance_1;
function Companion_getInstance_1() {
  return Companion_instance_1;
}
function $serializer_0() {
  $serializer_instance_0 = this;
  var tmp0_serialDesc = new InlineClassDescriptor('dev.whyoleg.cryptography.serialization.asn1.ObjectIdentifier', this);
  tmp0_serialDesc.w41('value', false);
  this.q4w_1 = tmp0_serialDesc;
}
protoOf($serializer_0).z3q = function () {
  return this.q4w_1;
};
protoOf($serializer_0).l42 = function () {
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [StringSerializer_getInstance()];
};
protoOf($serializer_0).r4w = function (decoder) {
  return _ObjectIdentifier___init__impl__7hutfr(decoder.k3u(this.q4w_1).i3u());
};
protoOf($serializer_0).n3r = function (decoder) {
  return new ObjectIdentifier(this.r4w(decoder));
};
protoOf($serializer_0).s4w = function (encoder, value) {
  var tmp0_inlineEncoder = encoder.r3v(this.q4w_1);
  if (tmp0_inlineEncoder == null)
    null;
  else {
    tmp0_inlineEncoder.p3v(_ObjectIdentifier___get_value__impl__wqzjw3(value));
  }
};
protoOf($serializer_0).m3r = function (encoder, value) {
  return this.s4w(encoder, value instanceof ObjectIdentifier ? value.t4w_1 : THROW_CCE());
};
var $serializer_instance_0;
function $serializer_getInstance_0() {
  if ($serializer_instance_0 == null)
    new $serializer_0();
  return $serializer_instance_0;
}
function ObjectIdentifier__toString_impl_dtwsrd($this) {
  return 'ObjectIdentifier(value=' + $this + ')';
}
function ObjectIdentifier__hashCode_impl_7x941i($this) {
  return getStringHashCode($this);
}
function ObjectIdentifier__equals_impl_u5dbkq($this, other) {
  if (!(other instanceof ObjectIdentifier))
    return false;
  if (!($this === (other instanceof ObjectIdentifier ? other.t4w_1 : THROW_CCE())))
    return false;
  return true;
}
function ObjectIdentifier(value) {
  this.t4w_1 = value;
}
protoOf(ObjectIdentifier).toString = function () {
  return ObjectIdentifier__toString_impl_dtwsrd(this.t4w_1);
};
protoOf(ObjectIdentifier).hashCode = function () {
  return ObjectIdentifier__hashCode_impl_7x941i(this.t4w_1);
};
protoOf(ObjectIdentifier).equals = function (other) {
  return ObjectIdentifier__equals_impl_u5dbkq(this.t4w_1, other);
};
function get_emptyArray() {
  _init_properties_ByteArrayInput_kt__imea6f();
  return emptyArray;
}
var emptyArray;
function _get_available__saq0tk($this) {
  return $this.v4w_1 - $this.w4w_1 | 0;
}
function ensureAvailableBytes($this, count) {
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(_get_available__saq0tk($this) >= count)) {
    // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.ByteArrayInput.ensureAvailableBytes.<anonymous>' call
    var message = 'Unexpected EOF, available ' + _get_available__saq0tk($this) + ' bytes, requested: ' + count;
    throw IllegalStateException_init_$Create$(toString(message));
  }
}
function ByteArrayInput(array, startIndex, endIndex) {
  startIndex = startIndex === VOID ? 0 : startIndex;
  endIndex = endIndex === VOID ? array.length : endIndex;
  this.u4w_1 = array;
  this.v4w_1 = endIndex;
  this.w4w_1 = startIndex;
}
protoOf(ByteArrayInput).x4w = function () {
  return _get_available__saq0tk(this) === 0;
};
protoOf(ByteArrayInput).toString = function () {
  return 'ByteArrayInput(size=' + this.u4w_1.length + ', endIndex=' + this.v4w_1 + ', position=' + this.w4w_1 + ', available=' + _get_available__saq0tk(this) + ')';
};
protoOf(ByteArrayInput).y4w = function () {
  ensureAvailableBytes(this, 1);
  return this.u4w_1[this.w4w_1];
};
protoOf(ByteArrayInput).o4m = function () {
  ensureAvailableBytes(this, 1);
  var tmp1 = this.w4w_1;
  this.w4w_1 = tmp1 + 1 | 0;
  return this.u4w_1[tmp1];
};
protoOf(ByteArrayInput).z4w = function (length) {
  ensureAvailableBytes(this, length);
  if (length === 0)
    return get_emptyArray();
  // Inline function 'kotlin.also' call
  var this_0 = copyOfRange(this.u4w_1, this.w4w_1, this.w4w_1 + length | 0);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.ByteArrayInput.read.<anonymous>' call
  this.w4w_1 = this.w4w_1 + length | 0;
  return this_0;
};
protoOf(ByteArrayInput).a4x = function (length) {
  ensureAvailableBytes(this, length);
  if (length === 0)
    return new ByteArrayInput(get_emptyArray());
  // Inline function 'kotlin.also' call
  var this_0 = new ByteArrayInput(this.u4w_1, this.w4w_1, this.w4w_1 + length | 0);
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.ByteArrayInput.readSlice.<anonymous>' call
  this.w4w_1 = this.w4w_1 + length | 0;
  return this_0;
};
var properties_initialized_ByteArrayInput_kt_acgl39;
function _init_properties_ByteArrayInput_kt__imea6f() {
  if (!properties_initialized_ByteArrayInput_kt_acgl39) {
    properties_initialized_ByteArrayInput_kt_acgl39 = true;
    emptyArray = new Int8Array(0);
  }
}
function ensureCapacity($this, elementsToAppend) {
  if (($this.l4w_1 + elementsToAppend | 0) <= $this.k4w_1.length)
    return Unit_instance;
  $this.k4w_1 = copyOf($this.k4w_1, takeHighestOneBit($this.l4w_1 + elementsToAppend | 0) << 1);
}
function ByteArrayOutput() {
  this.k4w_1 = new Int8Array(32);
  this.l4w_1 = 0;
}
protoOf(ByteArrayOutput).n = function () {
  return this.l4w_1;
};
protoOf(ByteArrayOutput).m4w = function () {
  return copyOf(this.k4w_1, this.l4w_1);
};
protoOf(ByteArrayOutput).b4x = function (byte) {
  ensureCapacity(this, 1);
  var tmp = this.k4w_1;
  var tmp1 = this.l4w_1;
  this.l4w_1 = tmp1 + 1 | 0;
  tmp[tmp1] = byte;
};
protoOf(ByteArrayOutput).c4x = function (byte) {
  this.b4x(toByte(byte));
};
protoOf(ByteArrayOutput).d4x = function (bytes) {
  // Inline function 'kotlin.collections.isEmpty' call
  if (bytes.length === 0)
    return Unit_instance;
  ensureCapacity(this, bytes.length);
  // Inline function 'kotlin.collections.copyInto' call
  var destination = this.k4w_1;
  var destinationOffset = this.l4w_1;
  var endIndex = bytes.length;
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp = bytes;
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  arrayCopy(tmp, destination, destinationOffset, 0, endIndex);
  this.l4w_1 = this.l4w_1 + bytes.length | 0;
};
protoOf(ByteArrayOutput).e4x = function (output) {
  if (output.n() === 0)
    return Unit_instance;
  ensureCapacity(this, output.l4w_1);
  // Inline function 'kotlin.collections.copyInto' call
  var this_0 = output.k4w_1;
  var destination = this.k4w_1;
  var destinationOffset = this.l4w_1;
  var endIndex = output.l4w_1;
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp = this_0;
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  arrayCopy(tmp, destination, destinationOffset, 0, endIndex);
  this.l4w_1 = this.l4w_1 + output.l4w_1 | 0;
};
function DerDecoder(der, byteArrayInput) {
  AbstractDecoder.call(this);
  this.n4w_1 = der;
  this.o4w_1 = new DerInput(byteArrayInput);
  this.p4w_1 = 0;
}
protoOf(DerDecoder).k3r = function () {
  return this.n4w_1.k3r();
};
protoOf(DerDecoder).b3v = function () {
  return true;
};
protoOf(DerDecoder).c3v = function (descriptor) {
  var tmp;
  if (this.o4w_1.x4w()) {
    tmp = -1;
  } else {
    var tmp1 = this.p4w_1;
    this.p4w_1 = tmp1 + 1 | 0;
    tmp = tmp1;
  }
  return tmp;
};
protoOf(DerDecoder).y3t = function () {
  return this.o4w_1.g4x();
};
protoOf(DerDecoder).z3t = function () {
  return this.o4w_1.h4x();
};
protoOf(DerDecoder).b3u = function () {
  return this.o4w_1.i4x().zb();
};
protoOf(DerDecoder).c3u = function () {
  return this.o4w_1.i4x().ac();
};
protoOf(DerDecoder).d3u = function () {
  return this.o4w_1.i4x().ra();
};
protoOf(DerDecoder).e3u = function () {
  return this.o4w_1.i4x().k4u();
};
protoOf(DerDecoder).o3r = function (deserializer) {
  var tmp0_subject = deserializer.z3q();
  var tmp;
  if (equals(tmp0_subject, ByteArraySerializer().z3q())) {
    var tmp_0 = this.o4w_1.l4x();
    tmp = !(tmp_0 == null) ? tmp_0 : THROW_CCE();
  } else if (equals(tmp0_subject, Companion_instance_0.u4i().z3q())) {
    var tmp_1 = this.o4w_1.k4x();
    tmp = !(tmp_1 == null) ? tmp_1 : THROW_CCE();
  } else if (equals(tmp0_subject, Companion_instance_1.u4i().z3q())) {
    var tmp_2 = this.o4w_1.j4x();
    tmp = !(new ObjectIdentifier(tmp_2) == null) ? new ObjectIdentifier(tmp_2) : THROW_CCE();
  } else if (equals(tmp0_subject, Companion_getInstance().u4i().z3q())) {
    var tmp_3 = this.o4w_1.i4x();
    tmp = !(tmp_3 == null) ? tmp_3 : THROW_CCE();
  } else {
    tmp = deserializer.n3r(this);
  }
  return tmp;
};
protoOf(DerDecoder).m3u = function (descriptor) {
  var tmp0_subject = descriptor.u3s();
  var tmp;
  var tmp_0;
  if (equals(tmp0_subject, CLASS_getInstance())) {
    tmp_0 = true;
  } else {
    tmp_0 = tmp0_subject instanceof PolymorphicKind;
  }
  if (tmp_0) {
    tmp = new DerDecoder(this.n4w_1, this.o4w_1.m4x());
  } else {
    throw SerializationException_init_$Create$('This serial kind is not supported as structure: ' + descriptor);
  }
  return tmp;
};
protoOf(DerDecoder).k3u = function (descriptor) {
  var message = 'Inline decoding is not supported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(DerDecoder).x3u = function (descriptor, index) {
  var message = 'Inline decoding is not supported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(DerDecoder).j3u = function (enumDescriptor) {
  var message = 'Enum decoding is not supported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(DerDecoder).i3u = function () {
  var message = 'String decoding is not supported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(DerDecoder).h3u = function () {
  var message = 'Char decoding is not supported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(DerDecoder).a3u = function () {
  var message = 'Boolean decoding is not supported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(DerDecoder).g3u = function () {
  var message = 'Double decoding is not supported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(DerDecoder).f3u = function () {
  var message = 'Float decoding is not supported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(DerDecoder).x3t = function () {
  var message = 'should not be called';
  throw IllegalStateException_init_$Create$(toString(message));
};
function DerEncoder(der, byteArrayOutput, parentOutput) {
  parentOutput = parentOutput === VOID ? null : parentOutput;
  AbstractEncoder.call(this);
  this.h4w_1 = der;
  this.i4w_1 = parentOutput;
  this.j4w_1 = new DerOutput(byteArrayOutput);
}
protoOf(DerEncoder).k3r = function () {
  return this.h4w_1.k3r();
};
protoOf(DerEncoder).h3w = function (descriptor, index) {
  return false;
};
protoOf(DerEncoder).e3v = function (descriptor, index) {
  return true;
};
protoOf(DerEncoder).f3w = function () {
};
protoOf(DerEncoder).g3v = function () {
  return this.j4w_1.o4x();
};
protoOf(DerEncoder).i3v = function (value) {
  return this.j4w_1.p4x(toBigInt(value));
};
protoOf(DerEncoder).j3v = function (value) {
  return this.j4w_1.p4x(toBigInt_0(value));
};
protoOf(DerEncoder).k3v = function (value) {
  return this.j4w_1.p4x(toBigInt_1(value));
};
protoOf(DerEncoder).l3v = function (value) {
  return this.j4w_1.p4x(toBigInt_2(value));
};
protoOf(DerEncoder).l3r = function (serializer, value) {
  var tmp0_subject = serializer.z3q();
  var tmp;
  if (equals(tmp0_subject, ByteArraySerializer().z3q())) {
    this.j4w_1.s4x((!(value == null) ? isByteArray(value) : false) ? value : THROW_CCE());
    tmp = Unit_instance;
  } else if (equals(tmp0_subject, Companion_instance_0.u4i().z3q())) {
    this.j4w_1.r4x(value instanceof BitArray ? value : THROW_CCE());
    tmp = Unit_instance;
  } else if (equals(tmp0_subject, Companion_instance_1.u4i().z3q())) {
    this.j4w_1.q4x(value instanceof ObjectIdentifier ? value.t4w_1 : THROW_CCE());
    tmp = Unit_instance;
  } else if (equals(tmp0_subject, Companion_getInstance().u4i().z3q())) {
    this.j4w_1.p4x(value instanceof BigInt ? value : THROW_CCE());
    tmp = Unit_instance;
  } else {
    serializer.m3r(this, value);
    tmp = Unit_instance;
  }
  return tmp;
};
protoOf(DerEncoder).m3u = function (descriptor) {
  var tmp0_subject = descriptor.u3s();
  var tmp;
  var tmp_0;
  if (equals(tmp0_subject, CLASS_getInstance())) {
    tmp_0 = true;
  } else {
    tmp_0 = tmp0_subject instanceof PolymorphicKind;
  }
  if (tmp_0) {
    tmp = new DerEncoder(this.h4w_1, new ByteArrayOutput(), this.j4w_1);
  } else {
    throw SerializationException_init_$Create$('This serial kind is not supported as structure: ' + descriptor);
  }
  return tmp;
};
protoOf(DerEncoder).n3u = function (descriptor) {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.checkNotNull' call
    var value = this.i4w_1;
    // Inline function 'kotlin.contracts.contract' call
    if (value == null) {
      // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.DerEncoder.endStructure.<anonymous>' call
      var message = 'Should be called after beginStructure';
      throw IllegalStateException_init_$Create$(toString(message));
    } else {
      tmp$ret$1 = value;
      break $l$block;
    }
  }
  tmp$ret$1.t4x(this.j4w_1);
};
protoOf(DerEncoder).r3v = function (descriptor) {
  var message = 'Inline encoding is not supported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(DerEncoder).u4x = function (enumDescriptor, index) {
  var message = 'Enum encoding is not supported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(DerEncoder).q3v = function (enumDescriptor, index) {
  return this.u4x(enumDescriptor, index);
};
protoOf(DerEncoder).p3v = function (value) {
  var message = 'String encoding is not supported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(DerEncoder).o3v = function (value) {
  var message = 'Char encoding is not supported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(DerEncoder).h3v = function (value) {
  var message = 'Boolean encoding is not supported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(DerEncoder).m3v = function (value) {
  var message = 'Float encoding is not supported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(DerEncoder).n3v = function (value) {
  var message = 'Double encoding is not supported';
  throw IllegalStateException_init_$Create$(toString(message));
};
protoOf(DerEncoder).f3v = function (value) {
  var message = 'should not be called';
  throw IllegalStateException_init_$Create$(toString(message));
};
function DerInput(input) {
  this.f4x_1 = input;
}
protoOf(DerInput).x4w = function () {
  return this.f4x_1.x4w();
};
protoOf(DerInput).g4x = function () {
  return !(this.f4x_1.y4w() === get_DerTag_NULL());
};
protoOf(DerInput).h4x = function () {
  var length = readTagLength(this.f4x_1, get_DerTag_NULL());
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(length === 0)) {
    // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.DerInput.readNull.<anonymous>' call
    var message = 'NULL tag length should be zero, but was: ' + length;
    throw IllegalStateException_init_$Create$(toString(message));
  }
  return null;
};
protoOf(DerInput).i4x = function () {
  return decodeToBigInt(readTagBytes(this.f4x_1, get_DerTag_INTEGER()));
};
protoOf(DerInput).k4x = function () {
  var length = readTagLength(this.f4x_1, get_DerTag_BIT_STRING());
  var unusedBits = this.f4x_1.o4m();
  var bytes = this.f4x_1.z4w(length - 1 | 0);
  // Inline function 'kotlin.collections.isEmpty' call
  if (bytes.length === 0) {
    // Inline function 'kotlin.check' call
    // Inline function 'kotlin.contracts.contract' call
    if (!(unusedBits === 0)) {
      // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.DerInput.readBitString.<anonymous>' call
      var message = 'wrong number of unused bits, expected 0, received: ' + unusedBits;
      throw IllegalStateException_init_$Create$(toString(message));
    }
  } else {
    // Inline function 'kotlin.countTrailingZeroBits' call
    var this_0 = last(bytes);
    var trailingZeros = countTrailingZeroBits(this_0 | 256);
    // Inline function 'kotlin.check' call
    // Inline function 'kotlin.contracts.contract' call
    if (!(unusedBits <= trailingZeros)) {
      // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.DerInput.readBitString.<anonymous>' call
      var message_0 = 'Not all unused bits are zeros, expected at least ' + unusedBits + ' trailing zeros, received ' + trailingZeros;
      throw IllegalStateException_init_$Create$(toString(message_0));
    }
  }
  return new BitArray(unusedBits, bytes);
};
protoOf(DerInput).l4x = function () {
  return readTagBytes(this.f4x_1, get_DerTag_OCTET_STRING());
};
protoOf(DerInput).j4x = function () {
  return _ObjectIdentifier___init__impl__7hutfr(readOidElements(readTagSlice(this.f4x_1, get_DerTag_OID())));
};
protoOf(DerInput).m4x = function () {
  return readTagSlice(this.f4x_1, get_DerTag_SEQUENCE());
};
function readTagLength(_this__u8e3s4, tag) {
  var currentTag = _this__u8e3s4.o4m();
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(currentTag === tag)) {
    // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.readTagLength.<anonymous>' call
    var message = "Requested tag '" + tag + "', received: '" + name(currentTag) + "'";
    throw IllegalStateException_init_$Create$(toString(message));
  }
  return readLength(_this__u8e3s4);
}
function readTagBytes(_this__u8e3s4, tag) {
  return _this__u8e3s4.z4w(readTagLength(_this__u8e3s4, tag));
}
function readOidElements(_this__u8e3s4) {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder_init_$Create$();
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.readOidElements.<anonymous>' call
  var first = readOidElement(_this__u8e3s4);
  if (first < 40) {
    this_0.o5(_Char___init__impl__6a9atx(48)).o5(_Char___init__impl__6a9atx(46)).h8(first);
  } else if (first < 80) {
    this_0.o5(_Char___init__impl__6a9atx(49)).o5(_Char___init__impl__6a9atx(46)).h8(first - 40 | 0);
  } else {
    this_0.o5(_Char___init__impl__6a9atx(50)).o5(_Char___init__impl__6a9atx(46)).h8(first - 80 | 0);
  }
  while (!_this__u8e3s4.x4w()) {
    this_0.o5(_Char___init__impl__6a9atx(46)).h8(readOidElement(_this__u8e3s4));
  }
  return this_0.toString();
}
function readTagSlice(_this__u8e3s4, tag) {
  return _this__u8e3s4.a4x(readTagLength(_this__u8e3s4, tag));
}
function readLength(_this__u8e3s4) {
  var first = _this__u8e3s4.o4m();
  if (first >= 0)
    return first;
  var numberOfLengthBytes = first & 127;
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(numberOfLengthBytes <= 4)) {
    // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.readLength.<anonymous>' call
    var message = 'Supported number of bytes for tag length are in range 1..4, but was: ' + numberOfLengthBytes + ' ';
    throw IllegalStateException_init_$Create$(toString(message));
  }
  var length = 0;
  // Inline function 'kotlin.repeat' call
  // Inline function 'kotlin.contracts.contract' call
  var inductionVariable = 0;
  if (inductionVariable < numberOfLengthBytes)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.readLength.<anonymous>' call
      length = (length << 8) + (_this__u8e3s4.o4m() & 255) | 0;
    }
     while (inductionVariable < numberOfLengthBytes);
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(length > 0)) {
    // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.readLength.<anonymous>' call
    var message_0 = 'length overflow: ' + length;
    throw IllegalStateException_init_$Create$(toString(message_0));
  }
  return length;
}
function readOidElement(_this__u8e3s4) {
  var element = 0;
  do {
    var b = _this__u8e3s4.o4m();
    element = (element << 7) + (b & 127) | 0;
  }
   while ((b & 128) === 128);
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(element > 0)) {
    // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.readOidElement.<anonymous>' call
    var message = 'element overflow: ' + element;
    throw IllegalStateException_init_$Create$(toString(message));
  }
  return element;
}
function DerOutput(output) {
  this.n4x_1 = output;
}
protoOf(DerOutput).o4x = function () {
  writeTag(this.n4x_1, get_DerTag_NULL(), 0);
};
protoOf(DerOutput).p4x = function (value) {
  writeTag_0(this.n4x_1, get_DerTag_INTEGER(), encodeToByteArray(value));
};
protoOf(DerOutput).r4x = function (bits) {
  writeTag(this.n4x_1, get_DerTag_BIT_STRING(), bits.f4w_1.length + 1 | 0);
  this.n4x_1.c4x(bits.e4w_1);
  this.n4x_1.d4x(bits.f4w_1);
};
protoOf(DerOutput).s4x = function (bytes) {
  writeTag_0(this.n4x_1, get_DerTag_OCTET_STRING(), bytes);
};
protoOf(DerOutput).q4x = function (value) {
  var intermediate = new ByteArrayOutput();
  var strings = split(_ObjectIdentifier___get_value__impl__wqzjw3(value), ['.']);
  writeOidElements(intermediate, strings);
  writeTag_1(this.n4x_1, get_DerTag_OID(), intermediate);
};
protoOf(DerOutput).t4x = function (bytes) {
  writeTag_1(this.n4x_1, get_DerTag_SEQUENCE(), bytes.n4x_1);
};
function writeTag(_this__u8e3s4, tag, length) {
  _this__u8e3s4.b4x(tag);
  writeLength(_this__u8e3s4, length);
}
function writeTag_0(_this__u8e3s4, tag, bytes) {
  writeTag(_this__u8e3s4, tag, bytes.length);
  _this__u8e3s4.d4x(bytes);
}
function writeOidElements(_this__u8e3s4, elements) {
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(elements.n() >= 2)) {
    // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.writeOidElements.<anonymous>' call
    var message = 'at least 2 components expected but was ' + elements.n();
    throw IllegalStateException_init_$Create$(toString(message));
  }
  writeOidElement(_this__u8e3s4, imul(writeOidElements$element(elements, 0), 40) + writeOidElements$element(elements, 1) | 0);
  // Inline function 'kotlin.repeat' call
  var times = elements.n() - 2 | 0;
  // Inline function 'kotlin.contracts.contract' call
  var inductionVariable = 0;
  if (inductionVariable < times)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.writeOidElements.<anonymous>' call
      writeOidElement(_this__u8e3s4, writeOidElements$element(elements, index + 2 | 0));
    }
     while (inductionVariable < times);
}
function writeTag_1(_this__u8e3s4, tag, bytes) {
  writeTag(_this__u8e3s4, tag, bytes.n());
  _this__u8e3s4.e4x(bytes);
}
function writeLength(_this__u8e3s4, length) {
  if (length < 128)
    return _this__u8e3s4.c4x(length);
  // Inline function 'kotlin.countLeadingZeroBits' call
  var numberOfLengthBytes = 4 - (clz32(length) / 8 | 0) | 0;
  _this__u8e3s4.c4x(numberOfLengthBytes | 128);
  // Inline function 'kotlin.repeat' call
  // Inline function 'kotlin.contracts.contract' call
  var inductionVariable = 0;
  if (inductionVariable < numberOfLengthBytes)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.writeLength.<anonymous>' call
      _this__u8e3s4.c4x(length >>> imul(8, (numberOfLengthBytes - 1 | 0) - index | 0) | 0);
    }
     while (inductionVariable < numberOfLengthBytes);
}
function writeOidElement(_this__u8e3s4, element) {
  if (element < 128)
    return _this__u8e3s4.c4x(element);
  // Inline function 'kotlin.countLeadingZeroBits' call
  var l = (32 - clz32(element) | 0) / 7 | 0;
  // Inline function 'kotlin.repeat' call
  // Inline function 'kotlin.contracts.contract' call
  var inductionVariable = 0;
  if (inductionVariable < l)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'dev.whyoleg.cryptography.serialization.asn1.internal.writeOidElement.<anonymous>' call
      _this__u8e3s4.c4x((element >>> imul(l - index | 0, 7) | 0) & 127 | 128);
    }
     while (inductionVariable < l);
  _this__u8e3s4.c4x(element & 127);
}
function writeOidElements$element($elements, index) {
  return toInt($elements.f1(index));
}
function get_DerTag_NULL() {
  return DerTag_NULL;
}
var DerTag_NULL;
function get_DerTag_INTEGER() {
  return DerTag_INTEGER;
}
var DerTag_INTEGER;
function get_DerTag_BIT_STRING() {
  return DerTag_BIT_STRING;
}
var DerTag_BIT_STRING;
function get_DerTag_OCTET_STRING() {
  return DerTag_OCTET_STRING;
}
var DerTag_OCTET_STRING;
function get_DerTag_OID() {
  return DerTag_OID;
}
var DerTag_OID;
function get_DerTag_SEQUENCE() {
  return DerTag_SEQUENCE;
}
var DerTag_SEQUENCE;
function name(tag) {
  return tag === 2 ? 'INTEGER' : tag === 3 ? 'BIT_STRING' : tag === 4 ? 'OCTET_STRING' : tag === 5 ? 'NULL' : tag === 6 ? 'OID' : tag === 48 ? 'SEQUENCE' : 'UNKNOWN[' + tag + ']';
}
//region block: post-declaration
protoOf($serializer).m42 = typeParametersSerializers;
protoOf($serializer_0).m42 = typeParametersSerializers;
//endregion
//region block: init
Companion_instance_0 = new Companion();
Companion_instance_1 = new Companion_0();
DerTag_NULL = 5;
DerTag_INTEGER = 2;
DerTag_BIT_STRING = 3;
DerTag_OCTET_STRING = 4;
DerTag_OID = 6;
DerTag_SEQUENCE = 48;
//endregion
//region block: exports
export {
  BitArray as BitArray3ibxegq42amh4,
  ObjectIdentifier as ObjectIdentifierz6uf0uceu1gm,
  _ObjectIdentifier___init__impl__7hutfr as _ObjectIdentifier___init__impl__7hutfrpi3i6lsjnc1q,
  _ObjectIdentifier___get_value__impl__wqzjw3 as _ObjectIdentifier___get_value__impl__wqzjw3smbbvmgbuky3,
  $serializer_getInstance as $serializer_getInstance2ldxc6slhxdj4,
  Default_getInstance as Default_getInstance2lxyd89gwu0mk,
  Companion_instance_1 as Companion_instance1lybiqv5r9a9w,
};
//endregion

//# sourceMappingURL=cryptography-kotlin-cryptography-serialization-asn1.mjs.map
