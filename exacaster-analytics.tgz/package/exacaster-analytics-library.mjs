import {
  VOID7hggqo3abtya as VOID,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  CoroutineImpl2sn3kjnwmfr10 as CoroutineImpl,
  protoOf180f3jzyo7rfj as protoOf,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  isInterface3d6p8outrmvmk as isInterface,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  Exceptiondt2hlxn7j7vw as Exception,
  classMetawt99a3kyl3us as classMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  Companion_getInstance3vz87v4c01z2t as Companion_getInstance,
  DurationUnit_SECONDS_getInstance3kfz9s0dx4cip as DurationUnit_SECONDS_getInstance,
  toDuration7gy6v749ektt as toDuration,
  isBlank1dvkhjjvox3p0 as isBlank,
  toString1pkumu07cwy4m as toString,
  IllegalArgumentException_init_$Create$310sysrobvll9 as IllegalArgumentException_init_$Create$,
  Duration5ynfiptaqcrg as Duration,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  Duration__hashCode_impl_u4exz637nai0kujh6oy as Duration__hashCode_impl_u4exz6,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  hashCodeq5arwsb9dgti as hashCode,
  equals2au1ep9vhcato as equals,
  Duration__times_impl_sfuzvp316nlxvoppoay as Duration__times_impl_sfuzvp,
  _Duration___get_inWholeMilliseconds__impl__msfiryzor4f65wcski as _Duration___get_inWholeMilliseconds__impl__msfiry,
  Default_getInstance3u4i6y54ri5cn as Default_getInstance,
  numberToLong1a4cndvg6c52s as numberToLong,
  DurationUnit_MILLISECONDS_getInstance2qykn69hriyvp as DurationUnit_MILLISECONDS_getInstance,
  toDurationba1nlt78o6vu as toDuration_0,
  IllegalStateException_init_$Create$3ib9qa3pip8n4 as IllegalStateException_init_$Create$,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  objectMeta213120oau977m as objectMeta,
  plus2m1vv33moko5t as plus,
  toMapcf6xfku344cz as toMap,
  LinkedHashMap_init_$Create$1p3p95clvi93w as LinkedHashMap_init_$Create$,
  captureStack1fzi4aczwc4hg as captureStack,
  Exception_init_$Init$2fx1sms2m4tu1 as Exception_init_$Init$,
  replace3le3ie7l9k8aq as replace,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  trim11nh7r46at6sx as trim,
  Default_getInstance5ktjwh40tq1j as Default_getInstance_0,
  getKClass1s3j9wy1cofik as getKClass,
  arrayOf1akklvh2at202 as arrayOf,
  createKType1lgox3mzhchp5 as createKType,
  encodeToByteArray1onwao0uakjfh as encodeToByteArray,
  until1jbpn0z3f8lbg as until,
  sliceArray2hu2ljigibgmi as sliceArray,
  DurationUnit_HOURS_getInstance2xc83zeokhqlh as DurationUnit_HOURS_getInstance,
  Long2qws0ah9gnpki as Long,
  ArrayList_init_$Create$2qnngtk1et9r9 as ArrayList_init_$Create$,
  last1vo29oleiqj36 as last,
  lastOrNull1aq5oz189qoe1 as lastOrNull,
  getKClassFromExpression3vpejubogshaw as getKClassFromExpression,
  contentEquals1cdp6c846cfdi as contentEquals,
  contentHashCode25jw6rgkgywwr as contentHashCode,
  objectCreate1ve4bgxiu4x98 as objectCreate,
  LazyThreadSafetyMode_PUBLICATION_getInstance2wcpeyiugdaea as LazyThreadSafetyMode_PUBLICATION_getInstance,
  lazy1261dae0bgscp as lazy,
  THROW_IAE23kobfj9wdoxr as THROW_IAE,
  Enum3alwj03lh1n41 as Enum,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  mapCapacity1h45rc3eh9p2l as mapCapacity,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  LinkedHashMap_init_$Create$7ps311k1ff73 as LinkedHashMap_init_$Create$_0,
  toString30pk9tzaqopn as toString_0,
  to2cs3ny02qtbcb as to,
  Map140uvy3s5zad8 as Map,
  ArrayList_init_$Create$1s1wkrw82c0iw as ArrayList_init_$Create$_0,
  List3hktaavzmj137 as List,
  isNumberiramasdbon0i as isNumber,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  toDouble1kn912gjoizjp as toDouble,
  toDoubleOrNullkxwozihadygj as toDoubleOrNull,
  toLongkk4waq8msp1k as toLong,
  toLongOrNullutqivezb0wx1 as toLongOrNull,
  toInt2q8uldh7sc951 as toInt,
  toIntOrNull3w2d066r9pvwm as toIntOrNull,
  toBoolean2azvnq2ukl7b3 as toBoolean,
  interfaceMeta1u1l5puptm1ve as interfaceMeta,
  emptyMapr06gerzljqtm as emptyMap,
  getNumberHashCode2l4nbdcihl25f as getNumberHashCode,
  createInvariantKTypeProjection3sfd0u0y62ozd as createInvariantKTypeProjection,
  toLongw1zpgk99d84b as toLong_0,
  first58ocm7j58k3q as first,
  listOf1jh22dvmctj1r as listOf,
  contains2gm06f5aa19ov as contains,
  Result3t1vadv16kmzk as Result,
  _Result___get_value__impl__bjfvqgo6z1uu11rodr as _Result___get_value__impl__bjfvqg,
  _Result___get_isFailure__impl__jpirivzehaw445b0cy as _Result___get_isFailure__impl__jpiriv,
  PrimitiveClasses_getInstance2v63zn04dtq03 as PrimitiveClasses_getInstance,
  Companion_instance2oawqq9qiaris as Companion_instance,
  Exception_init_$Create$2kid4wexypdn as Exception_init_$Create$,
  createFailure8paxfkfa5dc7 as createFailure,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  _Duration___get_inWholeSeconds__impl__hpy7b328tt6xo432gi4 as _Duration___get_inWholeSeconds__impl__hpy7b3,
  emptyList1g2z5xcrvp2zy as emptyList,
  toMutableList20rdgwi7d3cwi as toMutableList,
  take3onnpy6q7ctcz as take,
  toSet2orjxp16sotqu as toSet,
  removeAll3o43e67jmwdpc as removeAll,
  toString1h6jjoch8cjt8 as toString_1,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  padStart36w1507hs626a as padStart,
  joinToString26w4x2pxjux6a as joinToString,
  println2shhhgwwt4c61 as println,
  stackTraceToString2670q6lbhdojj as stackTraceToString,
  toDuration28gf6ughsr3vf as toDuration_1,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  contains3ue2qo8xhmpf1 as contains_0,
  joinToString1cxrrlmo0chqs as joinToString_0,
  Collection1k04j3hzsbod0 as Collection,
  Paire9pteg33gng7 as Pair,
  Regex_init_$Create$xe1wdfnzfij1 as Regex_init_$Create$,
  lazy2hsh8ze7j6ikd as lazy_0,
  KProperty1ca4yb4wlo496 as KProperty1,
  getPropertyCallableRef1ajb9in178r5r as getPropertyCallableRef,
  intercepted2ogpsikxxj4u0 as intercepted,
  returnIfSuspendedqak8u4r448cu as returnIfSuspended,
} from './kotlin-kotlin-stdlib.mjs';
import {
  launch1c91vkjzdi9sd as launch,
  CoroutineScopefcb5f5dwqcas as CoroutineScope,
  SupervisorJobythnfxkr3jxc as SupervisorJob,
  Dispatchers_getInstanceitgtkvqfcnx3 as Dispatchers_getInstance,
  CoroutineScopelux7s7zphw7e as CoroutineScope_0,
  get_isActivehakov5bm97hw as get_isActive,
  delayolwo40i9ucjz as delay,
  MutableStateFlow34bfoyvwu8czu as MutableStateFlow,
  Mutex16li1l0asjv17 as Mutex,
  get_MODE_CANCELLABLE3br9qqv7xeh9e as get_MODE_CANCELLABLE,
  CancellableContinuationImpl1cx201opicavg as CancellableContinuationImpl,
  asStateFlow34rribx643ke5 as asStateFlow,
} from './kotlinx-coroutines-core.mjs';
import { uuid4al7pp0fcb8o5 as uuid4 } from './uuid.mjs';
import {
  Companion_getInstance1ywh0s7eq8pl0 as Companion_getInstance_0,
  Companion_instance9ju2qvy4ht9 as Companion_instance_0,
  Format_RAW_getInstance5n4hkxye28ll as Format_RAW_getInstance,
  Companion_getInstance2x3fgbv8b1la3 as Companion_getInstance_1,
  SHA256_getInstance1g7vhwtv2c9q6 as SHA256_getInstance,
  Generic_getInstance1nwvav7eaksaz as Generic_getInstance,
  Companion_getInstance208las7jmkph8 as Companion_getInstance_2,
} from './cryptography-kotlin-cryptography-core.mjs';
import {
  Default_getInstance363hicrc7jsft as Default_getInstance_1,
  JsonObjectee06ihoeeiqj as JsonObject,
  JsonPrimitiveolttw629wj53 as JsonPrimitive,
  JsonArray2urf8ey7u44sd as JsonArray,
  JsonPrimitive1xkjzc5d7ihuv as JsonPrimitive_0,
  JsonPrimitive2fp8648nd60dn as JsonPrimitive_1,
  JsonNull_getInstance2gh8fwl8w0wl7 as JsonNull_getInstance,
  JsonPrimitive3ttzjh2ft5dnx as JsonPrimitive_2,
  JsonNull2liwjj96vm0w2 as JsonNull,
  JsonEncoder1qlse6simkfi1 as JsonEncoder,
  JsonDecoder1rijst5ne6qla as JsonDecoder,
  Companion_instance2dhls90gezp41 as Companion_instance_1,
  JsonObjectBuilder2nl6rv6vdayuk as JsonObjectBuilder,
  Jsonsmkyu9xjl7fv as Json,
} from './kotlinx-serialization-kotlinx-serialization-json.mjs';
import {
  serializer1i4e9ym37oxmo as serializer,
  KSerializerzf77vz1967fq as KSerializer,
  PluginGeneratedSerialDescriptorqdzeg5asqhfg as PluginGeneratedSerialDescriptor,
  StringSerializer_getInstance2wffkbpdux3h9 as StringSerializer_getInstance,
  get_nullable197rfua9r7fsz as get_nullable,
  UnknownFieldException_init_$Create$1mnsp66c6fnup as UnknownFieldException_init_$Create$,
  typeParametersSerializers2likxjr48tr7y as typeParametersSerializers,
  GeneratedSerializer1f7t7hssdd2ws as GeneratedSerializer,
  throwMissingFieldException2cmke0v3ynf14 as throwMissingFieldException,
  ArrayListSerializer7k5wnrulb3y6 as ArrayListSerializer,
  createSimpleEnumSerializer2guioz11kk1m0 as createSimpleEnumSerializer,
  SerializerFactory1qv9hivitncuv as SerializerFactory,
  buildClassSerialDescriptors2a6xdp6mrtw as buildClassSerialDescriptor,
  SealedClassSerializer_init_$Create$36ciaynfdyjkr as SealedClassSerializer_init_$Create$,
  LinkedHashMapSerializermaoj2nyji7op as LinkedHashMapSerializer,
  LongSerializer_getInstance194e4t3ow5wjs as LongSerializer_getInstance,
  BooleanSerializer_getInstance1t8habeqgiyq1 as BooleanSerializer_getInstance,
  DoubleSerializer_getInstance3da4hv5ndgjlx as DoubleSerializer_getInstance,
  IntSerializer_getInstance2q7s8kvk1il5u as IntSerializer_getInstance,
  FloatSerializer_getInstance2fspe61zbqree as FloatSerializer_getInstance,
  ListSerializer1hxuk9dx5n9du as ListSerializer,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
import { System_instance3dr57gee6r420 as System_instance } from './Kotlin-DateTime-library-kotlinx-datetime.mjs';
import {
  HttpRequestBuilder15f2nnx9sjuv1 as HttpRequestBuilder,
  url2l6iw5ri21nxb as url,
  header3kx6g3yb4df1r as header,
  HttpStatement3zxb33q8lku as HttpStatement,
  bodyAsText1is16t8kuttw9 as bodyAsText,
  HttpClient3584jcajl7sef as HttpClient,
} from './ktor-ktor-client-core.mjs';
import {
  Application_getInstanceq87g3bor693u as Application_getInstance,
  contentType1lwcfjsjo0z8g as contentType,
  OutgoingContent3t2ohmyam9o76 as OutgoingContent,
  NullBody_instance2i6w0hfghwfg0 as NullBody_instance,
  Companion_getInstance1p3cpld7r1jz3 as Companion_getInstance_3,
  isSuccess1pokn37fdu56v as isSuccess,
} from './ktor-ktor-http.mjs';
import {
  JsType_instance744k4z46bwev as JsType_instance,
  typeInfoImpl3ju54ew51hieg as typeInfoImpl,
} from './ktor-ktor-utils.mjs';
import { jsonu6qnfo3b405p as json } from './ktor-ktor-serialization-kotlinx-json.mjs';
import {
  LogLevel_NONE_getInstance20dqm0srjwub0 as LogLevel_NONE_getInstance,
  LogLevel_HEADERS_getInstance2l5onq0kxun3t as LogLevel_HEADERS_getInstance,
  Companion_getInstance1jrxni30zx3hj as Companion_getInstance_4,
} from './ktor-ktor-client-logging.mjs';
import { Plugin_getInstance21w9qppp8svkg as Plugin_getInstance } from './ktor-ktor-client-content-negotiation.mjs';
import {
  decodeValue1tpu2zv9bx2qw as decodeValue,
  encodeValue242y8vttc9801 as encodeValue,
} from './MultiplatformSettings-multiplatform-settings-serialization.mjs';
import { StorageSettings203mesgel706z as StorageSettings } from './MultiplatformSettings-multiplatform-settings.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
setMetadataFor(AnalyticsClient$handleLifecycleChange$slambda, 'AnalyticsClient$handleLifecycleChange$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(AnalyticsClient, 'AnalyticsClient', classMeta, VOID, VOID, VOID, VOID, VOID, [1, 0]);
setMetadataFor(AnalyticsConfiguration, 'AnalyticsConfiguration', classMeta);
setMetadataFor(ExponentialBackoffRetryPolicy, 'ExponentialBackoffRetryPolicy', classMeta, VOID, VOID, ExponentialBackoffRetryPolicy);
setMetadataFor(ExacasterAnalytics$lifecycle$slambda, 'ExacasterAnalytics$lifecycle$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(ExacasterAnalytics$track$slambda, 'ExacasterAnalytics$track$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(ExacasterAnalytics$screen$slambda, 'ExacasterAnalytics$screen$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(ExacasterAnalytics$identify$slambda, 'ExacasterAnalytics$identify$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(ExacasterAnalytics$reset$slambda, 'ExacasterAnalytics$reset$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(ExacasterAnalytics$flush$slambda, 'ExacasterAnalytics$flush$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(ExacasterAnalytics$optOut$slambda, 'ExacasterAnalytics$optOut$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(ExacasterAnalytics$optIn$slambda, 'ExacasterAnalytics$optIn$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(ExacasterAnalytics, 'ExacasterAnalytics', objectMeta);
setMetadataFor($buildCOROUTINE$0, '$buildCOROUTINE$0', classMeta, CoroutineImpl);
setMetadataFor(IdentifyEventBuilder, 'IdentifyEventBuilder', classMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor($buildCOROUTINE$1, '$buildCOROUTINE$1', classMeta, CoroutineImpl);
setMetadataFor(LifecycleEventBuilder, 'LifecycleEventBuilder', classMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor($buildCOROUTINE$2, '$buildCOROUTINE$2', classMeta, CoroutineImpl);
setMetadataFor(ScreenEventBuilder, 'ScreenEventBuilder', classMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor($buildCOROUTINE$3, '$buildCOROUTINE$3', classMeta, CoroutineImpl);
setMetadataFor(TrackEventBuilder, 'TrackEventBuilder', classMeta, VOID, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(EncryptionException, 'EncryptionException', classMeta, Exception);
setMetadataFor(InvalidKey, 'InvalidKey', classMeta, EncryptionException, VOID, InvalidKey);
setMetadataFor(EncryptionFailed, 'EncryptionFailed', classMeta, EncryptionException, VOID, EncryptionFailed);
setMetadataFor(Companion, 'Companion', objectMeta);
setMetadataFor($encryptCOROUTINE$4, '$encryptCOROUTINE$4', classMeta, CoroutineImpl);
setMetadataFor($decodeRsaPublicKeyCOROUTINE$5, '$decodeRsaPublicKeyCOROUTINE$5', classMeta, CoroutineImpl);
setMetadataFor(EncryptionManager, 'EncryptionManager', classMeta, VOID, VOID, EncryptionManager, VOID, VOID, [2, 1]);
setMetadataFor(JwksCache, 'JwksCache', classMeta, VOID, VOID, JwksCache);
setMetadataFor(EncryptedPayload, 'EncryptedPayload', classMeta);
setMetadataFor($serializer, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(Jwk, 'Jwk', classMeta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance});
setMetadataFor(Companion_0, 'Companion', objectMeta);
setMetadataFor($serializer_0, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(Jwks, 'Jwks', classMeta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_0});
setMetadataFor(Companion_1, 'Companion', objectMeta, VOID, [SerializerFactory]);
setMetadataFor(AppLifecycleState, 'AppLifecycleState', classMeta, Enum, VOID, VOID, VOID, {0: Companion_getInstance_7});
setMetadataFor(AnyValueSerializer, 'AnyValueSerializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(Companion_2, 'Companion', objectMeta, VOID, [SerializerFactory]);
setMetadataFor(Event, 'Event', interfaceMeta, VOID, VOID, VOID, VOID, {0: Companion_getInstance_8});
setMetadataFor(Companion_3, 'Companion', objectMeta);
setMetadataFor($serializer_1, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(LifecycleEvent, 'LifecycleEvent', classMeta, VOID, [Event], VOID, VOID, {0: $serializer_getInstance_1});
setMetadataFor(Companion_4, 'Companion', objectMeta);
setMetadataFor($serializer_2, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(TrackEvent, 'TrackEvent', classMeta, VOID, [Event], VOID, VOID, {0: $serializer_getInstance_2});
setMetadataFor(Companion_5, 'Companion', objectMeta);
setMetadataFor($serializer_3, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(ScreenEvent, 'ScreenEvent', classMeta, VOID, [Event], VOID, VOID, {0: $serializer_getInstance_3});
setMetadataFor(Companion_6, 'Companion', objectMeta);
setMetadataFor($serializer_4, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(IdentifyEvent, 'IdentifyEvent', classMeta, VOID, [Event], VOID, VOID, {0: $serializer_getInstance_4});
setMetadataFor(Companion_7, 'Companion', objectMeta);
setMetadataFor($serializer_5, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(EventContext, 'EventContext', classMeta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_5});
setMetadataFor(Companion_8, 'Companion', objectMeta);
setMetadataFor($serializer_6, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(ApplicationInfo, 'ApplicationInfo', classMeta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_6});
setMetadataFor(Companion_9, 'Companion', objectMeta);
setMetadataFor($serializer_7, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(DeviceInfo, 'DeviceInfo', classMeta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_7});
setMetadataFor(Companion_10, 'Companion', objectMeta, VOID, [SerializerFactory]);
setMetadataFor(DeviceType, 'DeviceType', classMeta, Enum, VOID, VOID, VOID, {0: Companion_getInstance_16});
setMetadataFor(Companion_11, 'Companion', objectMeta);
setMetadataFor($serializer_8, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(NetworkInfo, 'NetworkInfo', classMeta, VOID, VOID, NetworkInfo, VOID, {0: $serializer_getInstance_8});
setMetadataFor(Companion_12, 'Companion', objectMeta);
setMetadataFor($serializer_9, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(LocationInfo, 'LocationInfo', classMeta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_9});
setMetadataFor(Companion_13, 'Companion', objectMeta);
setMetadataFor($serializer_10, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(ScreenInfo, 'ScreenInfo', classMeta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_10});
setMetadataFor(Companion_14, 'Companion', objectMeta);
setMetadataFor($serializer_11, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(OSInfo, 'OSInfo', classMeta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_11});
setMetadataFor(Companion_15, 'Companion', objectMeta);
setMetadataFor($serializer_12, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(LibraryInfo, 'LibraryInfo', classMeta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_12});
setMetadataFor($uploadBatchCOROUTINE$6, '$uploadBatchCOROUTINE$6', classMeta, CoroutineImpl);
setMetadataFor($uploadAdaptiveCOROUTINE$7, '$uploadAdaptiveCOROUTINE$7', classMeta, CoroutineImpl);
setMetadataFor($uploadSplitCOROUTINE$8, '$uploadSplitCOROUTINE$8', classMeta, CoroutineImpl);
setMetadataFor($uploadRawCOROUTINE$9, '$uploadRawCOROUTINE$9', classMeta, CoroutineImpl);
setMetadataFor($uploadWithEncryptionCOROUTINE$10, '$uploadWithEncryptionCOROUTINE$10', classMeta, CoroutineImpl);
setMetadataFor($fetchAndCacheJwksCOROUTINE$11, '$fetchAndCacheJwksCOROUTINE$11', classMeta, CoroutineImpl);
setMetadataFor($handleSuccessCOROUTINE$12, '$handleSuccessCOROUTINE$12', classMeta, CoroutineImpl);
setMetadataFor($handleRetryableErrorCOROUTINE$13, '$handleRetryableErrorCOROUTINE$13', classMeta, CoroutineImpl);
setMetadataFor($handlePermanentErrorCOROUTINE$14, '$handlePermanentErrorCOROUTINE$14', classMeta, CoroutineImpl);
setMetadataFor(EventUploader, 'EventUploader', classMeta, VOID, VOID, VOID, VOID, VOID, [1, 2, 3, 0]);
setMetadataFor(UploadResult, 'UploadResult', classMeta);
setMetadataFor(Success, 'Success', classMeta, UploadResult);
setMetadataFor(RetryableFailure, 'RetryableFailure', classMeta, UploadResult);
setMetadataFor(PermanentFailure, 'PermanentFailure', classMeta, UploadResult);
setMetadataFor($uploadEventsCOROUTINE$15, '$uploadEventsCOROUTINE$15', classMeta, CoroutineImpl);
setMetadataFor($uploadEncryptedBatchCOROUTINE$16, '$uploadEncryptedBatchCOROUTINE$16', classMeta, CoroutineImpl);
setMetadataFor($fetchJwksCOROUTINE$17, '$fetchJwksCOROUTINE$17', classMeta, CoroutineImpl);
setMetadataFor($handleHttpResponseCOROUTINE$18, '$handleHttpResponseCOROUTINE$18', classMeta, CoroutineImpl);
setMetadataFor(KtorNetworkClient, 'KtorNetworkClient', classMeta, VOID, VOID, VOID, VOID, VOID, [2, 0, 1]);
setMetadataFor(NetworkResponse, 'NetworkResponse', classMeta);
setMetadataFor(Success_0, 'Success', objectMeta, NetworkResponse);
setMetadataFor(RetryableError, 'RetryableError', classMeta, NetworkResponse);
setMetadataFor(PermanentError, 'PermanentError', classMeta, NetworkResponse);
setMetadataFor(NetworkClientFactory$createKtorClient$httpClient$1$2$1, VOID, classMeta);
setMetadataFor(NetworkClientFactory, 'NetworkClientFactory', objectMeta);
setMetadataFor(EventQueue$startAutoFlush$slambda, 'EventQueue$startAutoFlush$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor(EventQueue$uploadBatch$slambda, 'EventQueue$uploadBatch$slambda', classMeta, CoroutineImpl, VOID, VOID, VOID, VOID, [1]);
setMetadataFor($enqueueCOROUTINE$22, '$enqueueCOROUTINE$22', classMeta, CoroutineImpl);
setMetadataFor($removeOldestEventsCOROUTINE$23, '$removeOldestEventsCOROUTINE$23', classMeta, CoroutineImpl);
setMetadataFor($flushCOROUTINE$24, '$flushCOROUTINE$24', classMeta, CoroutineImpl);
setMetadataFor($uploadBatchCOROUTINE$25, '$uploadBatchCOROUTINE$25', classMeta, CoroutineImpl);
setMetadataFor($updateQueueSizeCOROUTINE$26, '$updateQueueSizeCOROUTINE$26', classMeta, CoroutineImpl);
setMetadataFor(EventQueue, 'EventQueue', classMeta, VOID, VOID, VOID, VOID, VOID, [1, 0]);
setMetadataFor(Companion_16, 'Companion', objectMeta);
setMetadataFor($serializer_13, '$serializer', objectMeta, VOID, [GeneratedSerializer]);
setMetadataFor(StoredEvent, 'StoredEvent', classMeta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_13});
setMetadataFor($insertEventCOROUTINE$27, '$insertEventCOROUTINE$27', classMeta, CoroutineImpl);
setMetadataFor($getPendingEventsCOROUTINE$28, '$getPendingEventsCOROUTINE$28', classMeta, CoroutineImpl);
setMetadataFor($getPendingEventsCountCOROUTINE$29, '$getPendingEventsCountCOROUTINE$29', classMeta, CoroutineImpl);
setMetadataFor($incrementRetryCountCOROUTINE$30, '$incrementRetryCountCOROUTINE$30', classMeta, CoroutineImpl);
setMetadataFor($deleteEventsCOROUTINE$32, '$deleteEventsCOROUTINE$32', classMeta, CoroutineImpl);
setMetadataFor(SettingsEventStorage, 'SettingsEventStorage', classMeta, VOID, VOID, VOID, VOID, VOID, [0, 1]);
setMetadataFor(SettingsPreferencesStorage, 'SettingsPreferencesStorage', classMeta);
setMetadataFor(BatchIdGenerator, 'BatchIdGenerator', objectMeta);
function error$default(message, throwable, $super) {
  throwable = throwable === VOID ? null : throwable;
  var tmp;
  if ($super === VOID) {
    this.z57(message, throwable);
    tmp = Unit_instance;
  } else {
    tmp = $super.z57.call(this, message, throwable);
  }
  return tmp;
}
setMetadataFor(AnalyticsLogger, 'AnalyticsLogger', interfaceMeta);
setMetadataFor(DefaultLogger, 'DefaultLogger', classMeta, VOID, [AnalyticsLogger]);
setMetadataFor(NoOpLogger, 'NoOpLogger', objectMeta, VOID, [AnalyticsLogger]);
setMetadataFor(SystemTimeProvider, 'SystemTimeProvider', classMeta, VOID, VOID, SystemTimeProvider);
setMetadataFor(Analytics_0, 'Analytics', objectMeta);
setMetadataFor(JsAnalyticsConfiguration, 'JsAnalyticsConfiguration', interfaceMeta);
setMetadataFor($collectContextCOROUTINE$33, '$collectContextCOROUTINE$33', classMeta, CoroutineImpl);
setMetadataFor($collectLocationInfoCOROUTINE$34, '$collectLocationInfoCOROUTINE$34', classMeta, CoroutineImpl);
setMetadataFor(JsContextCollector, 'JsContextCollector', classMeta, VOID, VOID, JsContextCollector, VOID, VOID, [0]);
setMetadataFor($hasLocationPermissionCOROUTINE$35, '$hasLocationPermissionCOROUTINE$35', classMeta, CoroutineImpl);
setMetadataFor($getCurrentLocationCOROUTINE$36, '$getCurrentLocationCOROUTINE$36', classMeta, CoroutineImpl);
setMetadataFor(JsLocationCollector, 'JsLocationCollector', classMeta, VOID, VOID, JsLocationCollector, VOID, VOID, [0]);
setMetadataFor(JsLifecycleTracker, 'JsLifecycleTracker', classMeta, VOID, VOID, JsLifecycleTracker);
//endregion
function handleLifecycleChange($this, state) {
  $this.e56_1.n56('App lifecycle changed to: ' + state);
  launch($this.g56_1, VOID, VOID, AnalyticsClient$handleLifecycleChange$slambda_0($this, state, null));
}
function loadPersistedState($this) {
  $this.k56_1 = $this.d56_1.o56();
  var tmp = $this;
  var tmp0_elvis_lhs = $this.d56_1.p56();
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlin.also' call
    var this_0 = uuid4().toString();
    // Inline function 'kotlin.contracts.contract' call
    // Inline function 'com.exacaster.analytics.AnalyticsClient.loadPersistedState.<anonymous>' call
    $this.d56_1.q56(this_0);
    tmp_0 = this_0;
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  tmp.l56_1 = tmp_0;
  $this.m56_1 = $this.d56_1.r56();
  $this.e56_1.n56('Loaded persisted state - userId: ' + $this.k56_1 + ', anonymousId: ' + $this.l56_1);
}
function AnalyticsClient$handleLifecycleChange$ref($boundThis) {
  var l = function (p0) {
    handleLifecycleChange($boundThis, p0);
    return Unit_instance;
  };
  l.callableName = 'handleLifecycleChange';
  return l;
}
function AnalyticsClient$handleLifecycleChange$slambda(this$0, $state, resultContinuation) {
  this.a57_1 = this$0;
  this.b57_1 = $state;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(AnalyticsClient$handleLifecycleChange$slambda).d1m = function ($this$launch, $completion) {
  var tmp = this.e1m($this$launch, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(AnalyticsClient$handleLifecycleChange$slambda).gd = function (p1, $completion) {
  return this.d1m((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(AnalyticsClient$handleLifecycleChange$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 9;
          this.jc_1 = 4;
          if (this.a57_1.c56_1.t57_1) {
            this.d57_1 = new LifecycleEventBuilder(this.b57_1);
            this.ic_1 = 1;
            suspendResult = this.d57_1.l57(this.a57_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 3;
            continue $sm;
          }

        case 1:
          this.e57_1 = suspendResult;
          this.ic_1 = 2;
          suspendResult = this.a57_1.y57(this.e57_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          this.a57_1.e56_1.n56('Tracked lifecycle event: ' + this.b57_1);
          this.ic_1 = 3;
          continue $sm;
        case 3:
          this.jc_1 = 9;
          this.ic_1 = 5;
          continue $sm;
        case 4:
          this.jc_1 = 9;
          var tmp_0 = this.lc_1;
          if (tmp_0 instanceof Exception) {
            this.f57_1 = this.lc_1;
            this.a57_1.e56_1.z57('Failed to track lifecycle event: ' + this.b57_1, this.f57_1);
            this.ic_1 = 5;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 5:
          this.jc_1 = 9;
          this.g57_1 = this.b57_1;
          this.h57_1 = this.g57_1.aa_1;
          if (this.h57_1 === 0) {
            this.a57_1.e56_1.n56('App initialized');
            this.a57_1.f56_1.j58();
            this.ic_1 = 8;
            continue $sm;
          } else {
            if (this.h57_1 === 1) {
              this.a57_1.e56_1.n56('App entered foreground');
              this.ic_1 = 8;
              continue $sm;
            } else {
              if (this.h57_1 === 2) {
                this.ic_1 = 7;
                suspendResult = this.a57_1.f56_1.i58(this);
                if (suspendResult === get_COROUTINE_SUSPENDED()) {
                  return suspendResult;
                }
                continue $sm;
              } else {
                if (this.h57_1 === 3) {
                  this.ic_1 = 6;
                  suspendResult = this.a57_1.f56_1.i58(this);
                  if (suspendResult === get_COROUTINE_SUSPENDED()) {
                    return suspendResult;
                  }
                  continue $sm;
                } else {
                  this.ic_1 = 8;
                  continue $sm;
                }
              }
            }
          }

        case 6:
          this.a57_1.f56_1.k58();
          this.a57_1.i56_1.l58();
          this.a57_1.e56_1.n56('App terminating');
          this.ic_1 = 8;
          continue $sm;
        case 7:
          this.a57_1.e56_1.n56('App entered background');
          this.ic_1 = 8;
          continue $sm;
        case 8:
          return Unit_instance;
        case 9:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 9) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
protoOf(AnalyticsClient$handleLifecycleChange$slambda).e1m = function ($this$launch, completion) {
  var i = new AnalyticsClient$handleLifecycleChange$slambda(this.a57_1, this.b57_1, completion);
  i.c57_1 = $this$launch;
  return i;
};
function AnalyticsClient$handleLifecycleChange$slambda_0(this$0, $state, resultContinuation) {
  var i = new AnalyticsClient$handleLifecycleChange$slambda(this$0, $state, resultContinuation);
  var l = function ($this$launch, $completion) {
    return i.d1m($this$launch, $completion);
  };
  l.$arity = 1;
  return l;
}
function AnalyticsClient(configuration, preferencesStorage, logger, eventQueue, scope, contextCollector, lifecycleTracker, timeProvider) {
  timeProvider = timeProvider === VOID ? new SystemTimeProvider() : timeProvider;
  this.c56_1 = configuration;
  this.d56_1 = preferencesStorage;
  this.e56_1 = logger;
  this.f56_1 = eventQueue;
  this.g56_1 = scope;
  this.h56_1 = contextCollector;
  this.i56_1 = lifecycleTracker;
  this.j56_1 = timeProvider;
  this.k56_1 = null;
  this.l56_1 = uuid4().toString();
  this.m56_1 = false;
  loadPersistedState(this);
  // Inline function 'kotlin.let' call
  // Inline function 'kotlin.contracts.contract' call
  var it = this.i56_1;
  it.m58(AnalyticsClient$handleLifecycleChange$ref(this));
  it.n58();
}
protoOf(AnalyticsClient).y57 = function (event, $completion) {
  if (this.m56_1) {
    this.e56_1.n56('Event dropped: user opted out');
    return Unit_instance;
  }
  return this.f56_1.o58(event, $completion);
};
protoOf(AnalyticsClient).p58 = function ($completion) {
  return this.h56_1.p58($completion);
};
protoOf(AnalyticsClient).q58 = function (userId) {
  this.k56_1 = userId;
  this.d56_1.q58(userId);
  this.e56_1.n56('User ID set: ' + userId);
};
protoOf(AnalyticsClient).o56 = function () {
  return this.k56_1;
};
protoOf(AnalyticsClient).p56 = function () {
  return this.l56_1;
};
protoOf(AnalyticsClient).x1m = function () {
  this.k56_1 = null;
  this.l56_1 = uuid4().toString();
  this.d56_1.x();
  this.d56_1.q56(this.l56_1);
  this.e56_1.n56('User data reset');
};
protoOf(AnalyticsClient).r58 = function (optOut) {
  this.m56_1 = optOut;
  this.d56_1.r58(optOut);
  this.e56_1.n56('Opt-out status: ' + optOut);
};
protoOf(AnalyticsClient).i58 = function ($completion) {
  return this.f56_1.i58($completion);
};
protoOf(AnalyticsClient).s58 = function () {
  return this.j56_1.t58();
};
function AnalyticsConfiguration(writeKey, endpoint, flushInterval, flushQueueSize, maxQueueSize, maxBatchSize, enableDebugLogging, trackApplicationLifecycle, collectAdvertisingId, collectLocation, enableEncryption, retryPolicy) {
  var tmp;
  if (flushInterval === VOID) {
    // Inline function 'kotlin.time.Companion.seconds' call
    Companion_getInstance();
    tmp = toDuration(30, DurationUnit_SECONDS_getInstance());
  } else {
    tmp = flushInterval;
  }
  flushInterval = tmp;
  flushQueueSize = flushQueueSize === VOID ? 20 : flushQueueSize;
  maxQueueSize = maxQueueSize === VOID ? 1000 : maxQueueSize;
  maxBatchSize = maxBatchSize === VOID ? 500 : maxBatchSize;
  enableDebugLogging = enableDebugLogging === VOID ? true : enableDebugLogging;
  trackApplicationLifecycle = trackApplicationLifecycle === VOID ? true : trackApplicationLifecycle;
  collectAdvertisingId = collectAdvertisingId === VOID ? true : collectAdvertisingId;
  collectLocation = collectLocation === VOID ? true : collectLocation;
  enableEncryption = enableEncryption === VOID ? false : enableEncryption;
  retryPolicy = retryPolicy === VOID ? new ExponentialBackoffRetryPolicy() : retryPolicy;
  this.m57_1 = writeKey;
  this.n57_1 = endpoint;
  this.o57_1 = flushInterval;
  this.p57_1 = flushQueueSize;
  this.q57_1 = maxQueueSize;
  this.r57_1 = maxBatchSize;
  this.s57_1 = enableDebugLogging;
  this.t57_1 = trackApplicationLifecycle;
  this.u57_1 = collectAdvertisingId;
  this.v57_1 = collectLocation;
  this.w57_1 = enableEncryption;
  this.x57_1 = retryPolicy;
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.text.isNotBlank' call
  var this_0 = this.m57_1;
  // Inline function 'kotlin.contracts.contract' call
  if (!!isBlank(this_0)) {
    // Inline function 'com.exacaster.analytics.AnalyticsConfiguration.<anonymous>' call
    var message = 'Write key cannot be blank';
    throw IllegalArgumentException_init_$Create$(toString(message));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.text.isNotBlank' call
  var this_1 = this.n57_1;
  // Inline function 'kotlin.contracts.contract' call
  if (!!isBlank(this_1)) {
    // Inline function 'com.exacaster.analytics.AnalyticsConfiguration.<anonymous>' call
    var message_0 = 'Endpoint cannot be blank';
    throw IllegalArgumentException_init_$Create$(toString(message_0));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(this.p57_1 > 0)) {
    // Inline function 'com.exacaster.analytics.AnalyticsConfiguration.<anonymous>' call
    var message_1 = 'Flush queue size must be positive';
    throw IllegalArgumentException_init_$Create$(toString(message_1));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(this.q57_1 > 0)) {
    // Inline function 'com.exacaster.analytics.AnalyticsConfiguration.<anonymous>' call
    var message_2 = 'Max queue size must be positive';
    throw IllegalArgumentException_init_$Create$(toString(message_2));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(this.r57_1 > 0)) {
    // Inline function 'com.exacaster.analytics.AnalyticsConfiguration.<anonymous>' call
    var message_3 = 'Max batch size must be positive';
    throw IllegalArgumentException_init_$Create$(toString(message_3));
  }
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(this.r57_1 <= this.q57_1)) {
    // Inline function 'com.exacaster.analytics.AnalyticsConfiguration.<anonymous>' call
    var message_4 = 'Max batch size cannot exceed max queue size';
    throw IllegalArgumentException_init_$Create$(toString(message_4));
  }
}
protoOf(AnalyticsConfiguration).toString = function () {
  return 'AnalyticsConfiguration(writeKey=' + this.m57_1 + ', endpoint=' + this.n57_1 + ', flushInterval=' + new Duration(this.o57_1) + ', flushQueueSize=' + this.p57_1 + ', maxQueueSize=' + this.q57_1 + ', maxBatchSize=' + this.r57_1 + ', enableDebugLogging=' + this.s57_1 + ', trackApplicationLifecycle=' + this.t57_1 + ', collectAdvertisingId=' + this.u57_1 + ', collectLocation=' + this.v57_1 + ', enableEncryption=' + this.w57_1 + ', retryPolicy=' + this.x57_1 + ')';
};
protoOf(AnalyticsConfiguration).hashCode = function () {
  var result = getStringHashCode(this.m57_1);
  result = imul(result, 31) + getStringHashCode(this.n57_1) | 0;
  result = imul(result, 31) + Duration__hashCode_impl_u4exz6(this.o57_1) | 0;
  result = imul(result, 31) + this.p57_1 | 0;
  result = imul(result, 31) + this.q57_1 | 0;
  result = imul(result, 31) + this.r57_1 | 0;
  result = imul(result, 31) + getBooleanHashCode(this.s57_1) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.t57_1) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.u57_1) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.v57_1) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.w57_1) | 0;
  result = imul(result, 31) + hashCode(this.x57_1) | 0;
  return result;
};
protoOf(AnalyticsConfiguration).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof AnalyticsConfiguration))
    return false;
  var tmp0_other_with_cast = other instanceof AnalyticsConfiguration ? other : THROW_CCE();
  if (!(this.m57_1 === tmp0_other_with_cast.m57_1))
    return false;
  if (!(this.n57_1 === tmp0_other_with_cast.n57_1))
    return false;
  if (!equals(this.o57_1, tmp0_other_with_cast.o57_1))
    return false;
  if (!(this.p57_1 === tmp0_other_with_cast.p57_1))
    return false;
  if (!(this.q57_1 === tmp0_other_with_cast.q57_1))
    return false;
  if (!(this.r57_1 === tmp0_other_with_cast.r57_1))
    return false;
  if (!(this.s57_1 === tmp0_other_with_cast.s57_1))
    return false;
  if (!(this.t57_1 === tmp0_other_with_cast.t57_1))
    return false;
  if (!(this.u57_1 === tmp0_other_with_cast.u57_1))
    return false;
  if (!(this.v57_1 === tmp0_other_with_cast.v57_1))
    return false;
  if (!(this.w57_1 === tmp0_other_with_cast.w57_1))
    return false;
  if (!equals(this.x57_1, tmp0_other_with_cast.x57_1))
    return false;
  return true;
};
function ExponentialBackoffRetryPolicy(maxRetries, initialDelay, maxDelay, multiplier, jitterFactor) {
  maxRetries = maxRetries === VOID ? 6 : maxRetries;
  var tmp;
  if (initialDelay === VOID) {
    // Inline function 'kotlin.time.Companion.seconds' call
    Companion_getInstance();
    tmp = toDuration(1, DurationUnit_SECONDS_getInstance());
  } else {
    tmp = initialDelay;
  }
  initialDelay = tmp;
  var tmp_0;
  if (maxDelay === VOID) {
    // Inline function 'kotlin.time.Companion.seconds' call
    Companion_getInstance();
    tmp_0 = toDuration(32, DurationUnit_SECONDS_getInstance());
  } else {
    tmp_0 = maxDelay;
  }
  maxDelay = tmp_0;
  multiplier = multiplier === VOID ? 2.0 : multiplier;
  jitterFactor = jitterFactor === VOID ? 0.1 : jitterFactor;
  this.u58_1 = maxRetries;
  this.v58_1 = initialDelay;
  this.w58_1 = maxDelay;
  this.x58_1 = multiplier;
  this.y58_1 = jitterFactor;
}
protoOf(ExponentialBackoffRetryPolicy).z58 = function () {
  return this.u58_1;
};
protoOf(ExponentialBackoffRetryPolicy).a59 = function (attemptNumber) {
  if (attemptNumber >= this.u58_1) {
    return null;
  }
  // Inline function 'kotlin.math.pow' call
  var this_0 = this.x58_1;
  var tmp$ret$0 = Math.pow(this_0, attemptNumber);
  var exponentialDelay = Duration__times_impl_sfuzvp(this.v58_1, tmp$ret$0);
  // Inline function 'kotlin.comparisons.minOf' call
  var a = _Duration___get_inWholeMilliseconds__impl__msfiry(exponentialDelay);
  var b = _Duration___get_inWholeMilliseconds__impl__msfiry(this.w58_1);
  var cappedDelay = a.o6(b) <= 0 ? a : b;
  var jitter = (Default_getInstance().wg() * 2 - 1) * this.y58_1 * cappedDelay.p6();
  // Inline function 'kotlin.Long.plus' call
  var tmp$ret$2 = cappedDelay.p6() + jitter;
  var finalDelay = numberToLong(tmp$ret$2);
  // Inline function 'kotlin.time.Companion.milliseconds' call
  Companion_getInstance();
  return toDuration_0(finalDelay, DurationUnit_MILLISECONDS_getInstance());
};
function ensureInitialized($this) {
  $l$block: {
    // Inline function 'kotlin.checkNotNull' call
    // Inline function 'kotlin.contracts.contract' call
    if ($this.b59_1 == null) {
      // Inline function 'com.exacaster.analytics.ExacasterAnalytics.ensureInitialized.<anonymous>' call
      var message = 'ExacasterAnalytics must be initialized before use. Call ExacasterAnalytics.initialize() first.';
      throw IllegalStateException_init_$Create$(toString(message));
    } else {
      break $l$block;
    }
  }
}
function ExacasterAnalytics$lifecycle$slambda($lifecycleState, $builder, resultContinuation) {
  this.n59_1 = $lifecycleState;
  this.o59_1 = $builder;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(ExacasterAnalytics$lifecycle$slambda).d1m = function ($this$launch, $completion) {
  var tmp = this.e1m($this$launch, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ExacasterAnalytics$lifecycle$slambda).gd = function (p1, $completion) {
  return this.d1m((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(ExacasterAnalytics$lifecycle$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 5;
          this.jc_1 = 4;
          this.q59_1 = new LifecycleEventBuilder(this.n59_1);
          var tmp0_safe_receiver = this.o59_1;
          if (tmp0_safe_receiver == null)
            null;
          else
            tmp0_safe_receiver(this.q59_1);
          this.ic_1 = 1;
          suspendResult = this.q59_1.l57(ensureNotNull(ExacasterAnalytics_getInstance().b59_1), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.r59_1 = suspendResult;
          this.s59_1 = ExacasterAnalytics_getInstance().b59_1;
          if (this.s59_1 == null) {
            this.t59_1 = null;
            this.ic_1 = 3;
            continue $sm;
          } else {
            this.ic_1 = 2;
            suspendResult = this.s59_1.y57(this.r59_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          }

        case 2:
          var tmp_0 = this;
          tmp_0.t59_1 = Unit_instance;
          this.ic_1 = 3;
          continue $sm;
        case 3:
          ExacasterAnalytics_getInstance().c59_1.n56('Tracked lifecycle: ' + this.n59_1);
          this.jc_1 = 5;
          this.ic_1 = 6;
          continue $sm;
        case 4:
          this.jc_1 = 5;
          var tmp_1 = this.lc_1;
          if (tmp_1 instanceof Exception) {
            var e = this.lc_1;
            ExacasterAnalytics_getInstance().c59_1.z57('Failed to track lifecycle: ' + this.n59_1, e);
            this.ic_1 = 6;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 5:
          throw this.lc_1;
        case 6:
          this.jc_1 = 5;
          return Unit_instance;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 5) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
protoOf(ExacasterAnalytics$lifecycle$slambda).e1m = function ($this$launch, completion) {
  var i = new ExacasterAnalytics$lifecycle$slambda(this.n59_1, this.o59_1, completion);
  i.p59_1 = $this$launch;
  return i;
};
function ExacasterAnalytics$lifecycle$slambda_0($lifecycleState, $builder, resultContinuation) {
  var i = new ExacasterAnalytics$lifecycle$slambda($lifecycleState, $builder, resultContinuation);
  var l = function ($this$launch, $completion) {
    return i.d1m($this$launch, $completion);
  };
  l.$arity = 1;
  return l;
}
function ExacasterAnalytics$track$slambda($eventName, $builder, resultContinuation) {
  this.c5a_1 = $eventName;
  this.d5a_1 = $builder;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(ExacasterAnalytics$track$slambda).d1m = function ($this$launch, $completion) {
  var tmp = this.e1m($this$launch, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ExacasterAnalytics$track$slambda).gd = function (p1, $completion) {
  return this.d1m((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(ExacasterAnalytics$track$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 5;
          this.jc_1 = 4;
          this.f5a_1 = new TrackEventBuilder(this.c5a_1);
          var tmp0_safe_receiver = this.d5a_1;
          if (tmp0_safe_receiver == null)
            null;
          else
            tmp0_safe_receiver(this.f5a_1);
          this.ic_1 = 1;
          suspendResult = this.f5a_1.m5a(ensureNotNull(ExacasterAnalytics_getInstance().b59_1), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.g5a_1 = suspendResult;
          this.h5a_1 = ExacasterAnalytics_getInstance().b59_1;
          if (this.h5a_1 == null) {
            this.i5a_1 = null;
            this.ic_1 = 3;
            continue $sm;
          } else {
            this.ic_1 = 2;
            suspendResult = this.h5a_1.y57(this.g5a_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          }

        case 2:
          var tmp_0 = this;
          tmp_0.i5a_1 = Unit_instance;
          this.ic_1 = 3;
          continue $sm;
        case 3:
          ExacasterAnalytics_getInstance().c59_1.n56('Tracked event: ' + this.c5a_1);
          this.jc_1 = 5;
          this.ic_1 = 6;
          continue $sm;
        case 4:
          this.jc_1 = 5;
          var tmp_1 = this.lc_1;
          if (tmp_1 instanceof Exception) {
            var e = this.lc_1;
            ExacasterAnalytics_getInstance().c59_1.z57('Failed to track event: ' + this.c5a_1, e);
            this.ic_1 = 6;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 5:
          throw this.lc_1;
        case 6:
          this.jc_1 = 5;
          return Unit_instance;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 5) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
protoOf(ExacasterAnalytics$track$slambda).e1m = function ($this$launch, completion) {
  var i = new ExacasterAnalytics$track$slambda(this.c5a_1, this.d5a_1, completion);
  i.e5a_1 = $this$launch;
  return i;
};
function ExacasterAnalytics$track$slambda_0($eventName, $builder, resultContinuation) {
  var i = new ExacasterAnalytics$track$slambda($eventName, $builder, resultContinuation);
  var l = function ($this$launch, $completion) {
    return i.d1m($this$launch, $completion);
  };
  l.$arity = 1;
  return l;
}
function ExacasterAnalytics$screen$slambda($screenName, $builder, resultContinuation) {
  this.v5a_1 = $screenName;
  this.w5a_1 = $builder;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(ExacasterAnalytics$screen$slambda).d1m = function ($this$launch, $completion) {
  var tmp = this.e1m($this$launch, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ExacasterAnalytics$screen$slambda).gd = function (p1, $completion) {
  return this.d1m((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(ExacasterAnalytics$screen$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 5;
          this.jc_1 = 4;
          this.y5a_1 = new ScreenEventBuilder(this.v5a_1);
          var tmp0_safe_receiver = this.w5a_1;
          if (tmp0_safe_receiver == null)
            null;
          else
            tmp0_safe_receiver(this.y5a_1);
          this.ic_1 = 1;
          suspendResult = this.y5a_1.f5b(ensureNotNull(ExacasterAnalytics_getInstance().b59_1), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.z5a_1 = suspendResult;
          this.a5b_1 = ExacasterAnalytics_getInstance().b59_1;
          if (this.a5b_1 == null) {
            this.b5b_1 = null;
            this.ic_1 = 3;
            continue $sm;
          } else {
            this.ic_1 = 2;
            suspendResult = this.a5b_1.y57(this.z5a_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          }

        case 2:
          var tmp_0 = this;
          tmp_0.b5b_1 = Unit_instance;
          this.ic_1 = 3;
          continue $sm;
        case 3:
          ExacasterAnalytics_getInstance().c59_1.n56('Tracked screen: ' + this.v5a_1);
          this.jc_1 = 5;
          this.ic_1 = 6;
          continue $sm;
        case 4:
          this.jc_1 = 5;
          var tmp_1 = this.lc_1;
          if (tmp_1 instanceof Exception) {
            var e = this.lc_1;
            ExacasterAnalytics_getInstance().c59_1.z57('Failed to track screen: ' + this.v5a_1, e);
            this.ic_1 = 6;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 5:
          throw this.lc_1;
        case 6:
          this.jc_1 = 5;
          return Unit_instance;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 5) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
protoOf(ExacasterAnalytics$screen$slambda).e1m = function ($this$launch, completion) {
  var i = new ExacasterAnalytics$screen$slambda(this.v5a_1, this.w5a_1, completion);
  i.x5a_1 = $this$launch;
  return i;
};
function ExacasterAnalytics$screen$slambda_0($screenName, $builder, resultContinuation) {
  var i = new ExacasterAnalytics$screen$slambda($screenName, $builder, resultContinuation);
  var l = function ($this$launch, $completion) {
    return i.d1m($this$launch, $completion);
  };
  l.$arity = 1;
  return l;
}
function ExacasterAnalytics$identify$slambda($userId, $builder, resultContinuation) {
  this.o5b_1 = $userId;
  this.p5b_1 = $builder;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(ExacasterAnalytics$identify$slambda).d1m = function ($this$launch, $completion) {
  var tmp = this.e1m($this$launch, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ExacasterAnalytics$identify$slambda).gd = function (p1, $completion) {
  return this.d1m((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(ExacasterAnalytics$identify$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 5;
          this.jc_1 = 4;
          var tmp0_safe_receiver = ExacasterAnalytics_getInstance().b59_1;
          if (tmp0_safe_receiver == null)
            null;
          else {
            tmp0_safe_receiver.q58(this.o5b_1);
          }

          this.r5b_1 = new IdentifyEventBuilder(this.o5b_1);
          var tmp1_safe_receiver = this.p5b_1;
          if (tmp1_safe_receiver == null)
            null;
          else
            tmp1_safe_receiver(this.r5b_1);
          this.ic_1 = 1;
          suspendResult = this.r5b_1.y5b(ensureNotNull(ExacasterAnalytics_getInstance().b59_1), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.s5b_1 = suspendResult;
          this.t5b_1 = ExacasterAnalytics_getInstance().b59_1;
          if (this.t5b_1 == null) {
            this.u5b_1 = null;
            this.ic_1 = 3;
            continue $sm;
          } else {
            this.ic_1 = 2;
            suspendResult = this.t5b_1.y57(this.s5b_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          }

        case 2:
          var tmp_0 = this;
          tmp_0.u5b_1 = Unit_instance;
          this.ic_1 = 3;
          continue $sm;
        case 3:
          ExacasterAnalytics_getInstance().c59_1.n56('Identified user: ' + this.o5b_1);
          this.jc_1 = 5;
          this.ic_1 = 6;
          continue $sm;
        case 4:
          this.jc_1 = 5;
          var tmp_1 = this.lc_1;
          if (tmp_1 instanceof Exception) {
            var e = this.lc_1;
            ExacasterAnalytics_getInstance().c59_1.z57('Failed to identify user: ' + this.o5b_1, e);
            this.ic_1 = 6;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 5:
          throw this.lc_1;
        case 6:
          this.jc_1 = 5;
          return Unit_instance;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 5) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
protoOf(ExacasterAnalytics$identify$slambda).e1m = function ($this$launch, completion) {
  var i = new ExacasterAnalytics$identify$slambda(this.o5b_1, this.p5b_1, completion);
  i.q5b_1 = $this$launch;
  return i;
};
function ExacasterAnalytics$identify$slambda_0($userId, $builder, resultContinuation) {
  var i = new ExacasterAnalytics$identify$slambda($userId, $builder, resultContinuation);
  var l = function ($this$launch, $completion) {
    return i.d1m($this$launch, $completion);
  };
  l.$arity = 1;
  return l;
}
function ExacasterAnalytics$reset$slambda(resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(ExacasterAnalytics$reset$slambda).d1m = function ($this$launch, $completion) {
  var tmp = this.e1m($this$launch, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ExacasterAnalytics$reset$slambda).gd = function (p1, $completion) {
  return this.d1m((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(ExacasterAnalytics$reset$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      if (tmp === 0) {
        this.jc_1 = 1;
        try {
          var tmp0_safe_receiver = ExacasterAnalytics_getInstance().b59_1;
          if (tmp0_safe_receiver == null)
            null;
          else {
            tmp0_safe_receiver.x1m();
          }
          ExacasterAnalytics_getInstance().c59_1.n56('Reset user data');
        } catch ($p) {
          if ($p instanceof Exception) {
            var e = $p;
            ExacasterAnalytics_getInstance().c59_1.z57('Failed to reset', e);
          } else {
            throw $p;
          }
        }
        return Unit_instance;
      } else if (tmp === 1) {
        throw this.lc_1;
      }
    } catch ($p) {
      var e_0 = $p;
      throw e_0;
    }
   while (true);
};
protoOf(ExacasterAnalytics$reset$slambda).e1m = function ($this$launch, completion) {
  var i = new ExacasterAnalytics$reset$slambda(completion);
  i.h5c_1 = $this$launch;
  return i;
};
function ExacasterAnalytics$reset$slambda_0(resultContinuation) {
  var i = new ExacasterAnalytics$reset$slambda(resultContinuation);
  var l = function ($this$launch, $completion) {
    return i.d1m($this$launch, $completion);
  };
  l.$arity = 1;
  return l;
}
function ExacasterAnalytics$flush$slambda(resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(ExacasterAnalytics$flush$slambda).d1m = function ($this$launch, $completion) {
  var tmp = this.e1m($this$launch, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ExacasterAnalytics$flush$slambda).gd = function (p1, $completion) {
  return this.d1m((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(ExacasterAnalytics$flush$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 4;
          this.jc_1 = 3;
          this.r5c_1 = ExacasterAnalytics_getInstance().b59_1;
          if (this.r5c_1 == null) {
            this.s5c_1 = null;
            this.ic_1 = 2;
            continue $sm;
          } else {
            this.ic_1 = 1;
            suspendResult = this.r5c_1.i58(this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          }

        case 1:
          var tmp_0 = this;
          tmp_0.s5c_1 = Unit_instance;
          this.ic_1 = 2;
          continue $sm;
        case 2:
          ExacasterAnalytics_getInstance().c59_1.n56('Flushing events');
          this.jc_1 = 4;
          this.ic_1 = 5;
          continue $sm;
        case 3:
          this.jc_1 = 4;
          var tmp_1 = this.lc_1;
          if (tmp_1 instanceof Exception) {
            var e = this.lc_1;
            ExacasterAnalytics_getInstance().c59_1.z57('Failed to flush', e);
            this.ic_1 = 5;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 4:
          throw this.lc_1;
        case 5:
          this.jc_1 = 4;
          return Unit_instance;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 4) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
protoOf(ExacasterAnalytics$flush$slambda).e1m = function ($this$launch, completion) {
  var i = new ExacasterAnalytics$flush$slambda(completion);
  i.q5c_1 = $this$launch;
  return i;
};
function ExacasterAnalytics$flush$slambda_0(resultContinuation) {
  var i = new ExacasterAnalytics$flush$slambda(resultContinuation);
  var l = function ($this$launch, $completion) {
    return i.d1m($this$launch, $completion);
  };
  l.$arity = 1;
  return l;
}
function ExacasterAnalytics$optOut$slambda(resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(ExacasterAnalytics$optOut$slambda).d1m = function ($this$launch, $completion) {
  var tmp = this.e1m($this$launch, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ExacasterAnalytics$optOut$slambda).gd = function (p1, $completion) {
  return this.d1m((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(ExacasterAnalytics$optOut$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      if (tmp === 0) {
        this.jc_1 = 1;
        try {
          var tmp0_safe_receiver = ExacasterAnalytics_getInstance().b59_1;
          if (tmp0_safe_receiver == null)
            null;
          else {
            tmp0_safe_receiver.r58(true);
          }
          ExacasterAnalytics_getInstance().c59_1.n56('User opted out');
        } catch ($p) {
          if ($p instanceof Exception) {
            var e = $p;
            ExacasterAnalytics_getInstance().c59_1.z57('Failed to opt out', e);
          } else {
            throw $p;
          }
        }
        return Unit_instance;
      } else if (tmp === 1) {
        throw this.lc_1;
      }
    } catch ($p) {
      var e_0 = $p;
      throw e_0;
    }
   while (true);
};
protoOf(ExacasterAnalytics$optOut$slambda).e1m = function ($this$launch, completion) {
  var i = new ExacasterAnalytics$optOut$slambda(completion);
  i.b5d_1 = $this$launch;
  return i;
};
function ExacasterAnalytics$optOut$slambda_0(resultContinuation) {
  var i = new ExacasterAnalytics$optOut$slambda(resultContinuation);
  var l = function ($this$launch, $completion) {
    return i.d1m($this$launch, $completion);
  };
  l.$arity = 1;
  return l;
}
function ExacasterAnalytics$optIn$slambda(resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(ExacasterAnalytics$optIn$slambda).d1m = function ($this$launch, $completion) {
  var tmp = this.e1m($this$launch, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(ExacasterAnalytics$optIn$slambda).gd = function (p1, $completion) {
  return this.d1m((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(ExacasterAnalytics$optIn$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      if (tmp === 0) {
        this.jc_1 = 1;
        try {
          var tmp0_safe_receiver = ExacasterAnalytics_getInstance().b59_1;
          if (tmp0_safe_receiver == null)
            null;
          else {
            tmp0_safe_receiver.r58(false);
          }
          ExacasterAnalytics_getInstance().c59_1.n56('User opted in');
        } catch ($p) {
          if ($p instanceof Exception) {
            var e = $p;
            ExacasterAnalytics_getInstance().c59_1.z57('Failed to opt in', e);
          } else {
            throw $p;
          }
        }
        return Unit_instance;
      } else if (tmp === 1) {
        throw this.lc_1;
      }
    } catch ($p) {
      var e_0 = $p;
      throw e_0;
    }
   while (true);
};
protoOf(ExacasterAnalytics$optIn$slambda).e1m = function ($this$launch, completion) {
  var i = new ExacasterAnalytics$optIn$slambda(completion);
  i.k5d_1 = $this$launch;
  return i;
};
function ExacasterAnalytics$optIn$slambda_0(resultContinuation) {
  var i = new ExacasterAnalytics$optIn$slambda(resultContinuation);
  var l = function ($this$launch, $completion) {
    return i.d1m($this$launch, $completion);
  };
  l.$arity = 1;
  return l;
}
function ExacasterAnalytics() {
  ExacasterAnalytics_instance = this;
  this.b59_1 = null;
  this.c59_1 = NoOpLogger_instance;
  this.d59_1 = CoroutineScope_0(SupervisorJob().nf(Dispatchers_getInstance().ey_1));
  this.e59_1 = '1.0.0';
}
protoOf(ExacasterAnalytics).l5d = function (configuration, settings, contextCollector, lifecycleTracker) {
  if (!(this.b59_1 == null)) {
    this.c59_1.m5d('Exacaster Analytics SDK is already initialized');
    return Unit_instance;
  }
  var tmp = this;
  var tmp_0;
  if (configuration.s57_1) {
    tmp_0 = new DefaultLogger(true);
  } else {
    tmp_0 = NoOpLogger_instance;
  }
  tmp.c59_1 = tmp_0;
  this.c59_1.n5d('Initializing Exacaster Analytics SDK v1.0.0');
  var eventStorage = new SettingsEventStorage(settings, this.c59_1);
  var preferencesStorage = new SettingsPreferencesStorage(settings);
  var networkClient = NetworkClientFactory_instance.o5d(configuration, this.c59_1);
  var tmp_1;
  if (configuration.w57_1) {
    this.c59_1.n5d('Encryption enabled');
    tmp_1 = new EncryptionManager();
  } else {
    tmp_1 = null;
  }
  var encryptionManager = tmp_1;
  var tmp_2;
  if (configuration.w57_1) {
    tmp_2 = new JwksCache();
  } else {
    tmp_2 = null;
  }
  var jwksCache = tmp_2;
  var eventUploader = new EventUploader(networkClient, eventStorage, configuration, this.c59_1, encryptionManager, jwksCache);
  var eventQueue = new EventQueue(eventStorage, configuration, this.c59_1, eventUploader, this.d59_1);
  this.b59_1 = new AnalyticsClient(configuration, preferencesStorage, this.c59_1, eventQueue, this.d59_1, contextCollector, lifecycleTracker);
  this.c59_1.n5d('SDK initialized successfully');
};
protoOf(ExacasterAnalytics).p5d = function (lifecycleState, builder) {
  ensureInitialized(this);
  launch(this.d59_1, VOID, VOID, ExacasterAnalytics$lifecycle$slambda_0(lifecycleState, builder, null));
};
protoOf(ExacasterAnalytics).q5d = function (eventName, builder) {
  ensureInitialized(this);
  launch(this.d59_1, VOID, VOID, ExacasterAnalytics$track$slambda_0(eventName, builder, null));
};
protoOf(ExacasterAnalytics).r5d = function (screenName, builder) {
  ensureInitialized(this);
  launch(this.d59_1, VOID, VOID, ExacasterAnalytics$screen$slambda_0(screenName, builder, null));
};
protoOf(ExacasterAnalytics).s5d = function (userId, builder) {
  ensureInitialized(this);
  launch(this.d59_1, VOID, VOID, ExacasterAnalytics$identify$slambda_0(userId, builder, null));
};
protoOf(ExacasterAnalytics).x1m = function () {
  ensureInitialized(this);
  launch(this.d59_1, VOID, VOID, ExacasterAnalytics$reset$slambda_0(null));
};
protoOf(ExacasterAnalytics).f6 = function () {
  ensureInitialized(this);
  launch(this.d59_1, VOID, VOID, ExacasterAnalytics$flush$slambda_0(null));
};
protoOf(ExacasterAnalytics).t5d = function () {
  ensureInitialized(this);
  launch(this.d59_1, VOID, VOID, ExacasterAnalytics$optOut$slambda_0(null));
};
protoOf(ExacasterAnalytics).u5d = function () {
  ensureInitialized(this);
  launch(this.d59_1, VOID, VOID, ExacasterAnalytics$optIn$slambda_0(null));
};
var ExacasterAnalytics_instance;
function ExacasterAnalytics_getInstance() {
  if (ExacasterAnalytics_instance == null)
    new ExacasterAnalytics();
  return ExacasterAnalytics_instance;
}
function $buildCOROUTINE$0(_this__u8e3s4, client, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.d5e_1 = _this__u8e3s4;
  this.e5e_1 = client;
}
protoOf($buildCOROUTINE$0).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.e5e_1.p58(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var context = suspendResult;
          var tmp_0;
          if (!this.d5e_1.x5b_1.b1()) {
            tmp_0 = context.q5e(VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, plus(context.p5e_1, this.d5e_1.x5b_1));
          } else {
            tmp_0 = context;
          }

          var mergedContext = tmp_0;
          return new IdentifyEvent(uuid4().toString(), this.e5e_1.s58(), VOID, this.d5e_1.v5b_1, this.e5e_1.p56(), mergedContext, toMap(this.d5e_1.w5b_1));
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function IdentifyEventBuilder(userId) {
  this.v5b_1 = userId;
  var tmp = this;
  // Inline function 'kotlin.collections.mutableMapOf' call
  tmp.w5b_1 = LinkedHashMap_init_$Create$();
  var tmp_0 = this;
  // Inline function 'kotlin.collections.mutableMapOf' call
  tmp_0.x5b_1 = LinkedHashMap_init_$Create$();
}
protoOf(IdentifyEventBuilder).r5e = function (block) {
  // Inline function 'kotlin.apply' call
  // Inline function 'kotlin.contracts.contract' call
  block(this.w5b_1);
};
protoOf(IdentifyEventBuilder).s5e = function (block) {
  // Inline function 'kotlin.apply' call
  // Inline function 'kotlin.contracts.contract' call
  block(this.x5b_1);
};
protoOf(IdentifyEventBuilder).y5b = function (client, $completion) {
  var tmp = new $buildCOROUTINE$0(this, client, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
function $buildCOROUTINE$1(_this__u8e3s4, client, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.b5f_1 = _this__u8e3s4;
  this.c5f_1 = client;
}
protoOf($buildCOROUTINE$1).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.c5f_1.p58(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var context = suspendResult;
          var tmp_0;
          if (!this.b5f_1.k57_1.b1()) {
            tmp_0 = context.q5e(VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, plus(context.p5e_1, this.b5f_1.k57_1));
          } else {
            tmp_0 = context;
          }

          var mergedContext = tmp_0;
          return new LifecycleEvent(uuid4().toString(), this.c5f_1.s58(), VOID, this.c5f_1.o56(), this.c5f_1.p56(), mergedContext, this.b5f_1.i57_1, toMap(this.b5f_1.j57_1));
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function LifecycleEventBuilder(lifecycleState) {
  this.i57_1 = lifecycleState;
  var tmp = this;
  // Inline function 'kotlin.collections.mutableMapOf' call
  tmp.j57_1 = LinkedHashMap_init_$Create$();
  var tmp_0 = this;
  // Inline function 'kotlin.collections.mutableMapOf' call
  tmp_0.k57_1 = LinkedHashMap_init_$Create$();
}
protoOf(LifecycleEventBuilder).r5e = function (block) {
  // Inline function 'kotlin.apply' call
  // Inline function 'kotlin.contracts.contract' call
  block(this.j57_1);
};
protoOf(LifecycleEventBuilder).s5e = function (block) {
  // Inline function 'kotlin.apply' call
  // Inline function 'kotlin.contracts.contract' call
  block(this.k57_1);
};
protoOf(LifecycleEventBuilder).l57 = function (client, $completion) {
  var tmp = new $buildCOROUTINE$1(this, client, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
function $buildCOROUTINE$2(_this__u8e3s4, client, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.l5f_1 = _this__u8e3s4;
  this.m5f_1 = client;
}
protoOf($buildCOROUTINE$2).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.m5f_1.p58(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var context = suspendResult;
          var tmp_0;
          if (!this.l5f_1.e5b_1.b1()) {
            tmp_0 = context.q5e(VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, plus(context.p5e_1, this.l5f_1.e5b_1));
          } else {
            tmp_0 = context;
          }

          var mergedContext = tmp_0;
          return new ScreenEvent(uuid4().toString(), this.m5f_1.s58(), VOID, this.m5f_1.o56(), this.m5f_1.p56(), mergedContext, this.l5f_1.c5b_1, toMap(this.l5f_1.d5b_1));
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function ScreenEventBuilder(screenName) {
  this.c5b_1 = screenName;
  var tmp = this;
  // Inline function 'kotlin.collections.mutableMapOf' call
  tmp.d5b_1 = LinkedHashMap_init_$Create$();
  var tmp_0 = this;
  // Inline function 'kotlin.collections.mutableMapOf' call
  tmp_0.e5b_1 = LinkedHashMap_init_$Create$();
}
protoOf(ScreenEventBuilder).r5e = function (block) {
  // Inline function 'kotlin.apply' call
  // Inline function 'kotlin.contracts.contract' call
  block(this.d5b_1);
};
protoOf(ScreenEventBuilder).s5e = function (block) {
  // Inline function 'kotlin.apply' call
  // Inline function 'kotlin.contracts.contract' call
  block(this.e5b_1);
};
protoOf(ScreenEventBuilder).f5b = function (client, $completion) {
  var tmp = new $buildCOROUTINE$2(this, client, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
function $buildCOROUTINE$3(_this__u8e3s4, client, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.v5f_1 = _this__u8e3s4;
  this.w5f_1 = client;
}
protoOf($buildCOROUTINE$3).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.ic_1 = 1;
          suspendResult = this.w5f_1.p58(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var context = suspendResult;
          var tmp_0;
          if (!this.v5f_1.l5a_1.b1()) {
            tmp_0 = context.q5e(VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, plus(context.p5e_1, this.v5f_1.l5a_1));
          } else {
            tmp_0 = context;
          }

          var mergedContext = tmp_0;
          return new TrackEvent(uuid4().toString(), this.w5f_1.s58(), VOID, this.w5f_1.o56(), this.w5f_1.p56(), mergedContext, this.v5f_1.j5a_1, toMap(this.v5f_1.k5a_1));
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function TrackEventBuilder(eventName) {
  this.j5a_1 = eventName;
  var tmp = this;
  // Inline function 'kotlin.collections.mutableMapOf' call
  tmp.k5a_1 = LinkedHashMap_init_$Create$();
  var tmp_0 = this;
  // Inline function 'kotlin.collections.mutableMapOf' call
  tmp_0.l5a_1 = LinkedHashMap_init_$Create$();
}
protoOf(TrackEventBuilder).r5e = function (block) {
  // Inline function 'kotlin.apply' call
  // Inline function 'kotlin.contracts.contract' call
  block(this.k5a_1);
};
protoOf(TrackEventBuilder).s5e = function (block) {
  // Inline function 'kotlin.apply' call
  // Inline function 'kotlin.contracts.contract' call
  block(this.l5a_1);
};
protoOf(TrackEventBuilder).m5a = function (client, $completion) {
  var tmp = new $buildCOROUTINE$3(this, client, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
function InvalidKey(message, cause) {
  message = message === VOID ? 'Invalid RSA public key format' : message;
  cause = cause === VOID ? null : cause;
  EncryptionException.call(this, message, cause);
  captureStack(this, InvalidKey);
}
function EncryptionFailed(message, cause) {
  message = message === VOID ? 'Failed to encrypt payload' : message;
  cause = cause === VOID ? null : cause;
  EncryptionException.call(this, message, cause);
  captureStack(this, EncryptionFailed);
}
function EncryptionException(message, cause) {
  cause = cause === VOID ? null : cause;
  Exception_init_$Init$(message, cause, this);
  captureStack(this, EncryptionException);
}
function Companion() {
  this.x5f_1 = 12;
  this.y5f_1 = 16;
}
var Companion_instance_2;
function Companion_getInstance_5() {
  return Companion_instance_2;
}
function decodeRsaPublicKey($this, jwk, $completion) {
  var tmp = new $decodeRsaPublicKeyCOROUTINE$5($this, jwk, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function decodePemPublicKey($this, pem) {
  // Inline function 'kotlin.text.trim' call
  var this_0 = replace(replace(replace(replace(replace(replace(replace(pem, '-----BEGIN PUBLIC KEY-----', ''), '-----END PUBLIC KEY-----', ''), '-----BEGIN RSA PUBLIC KEY-----', ''), '-----END RSA PUBLIC KEY-----', ''), '\n', ''), '\r', ''), ' ', '');
  var base64Content = toString(trim(isCharSequence(this_0) ? this_0 : THROW_CCE()));
  return Default_getInstance_0().og(base64Content);
}
function $encryptCOROUTINE$4(_this__u8e3s4, jsonPayload, publicKey, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.v5g_1 = _this__u8e3s4;
  this.w5g_1 = jsonPayload;
  this.x5g_1 = publicKey;
}
protoOf($encryptCOROUTINE$4).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 7;
          this.jc_1 = 6;
          this.y5g_1 = this.v5g_1.j5h_1.z4u(Companion_getInstance_0());
          this.ic_1 = 1;
          suspendResult = this.y5g_1.b4z(Companion_instance_0.f4v()).i4v(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.z5g_1 = suspendResult;
          this.a5h_1 = this.z5g_1.c4v();
          var tmp_0 = this;
          var this_0 = Default_getInstance_1();
          var value = this.w5g_1;
          var this_1 = this_0.k3r();
          var this_2 = serializer(this_1, createKType(getKClass(JsonObject), arrayOf([]), false));
          tmp_0.b5h_1 = encodeToByteArray(this_0.g3s(isInterface(this_2, KSerializer) ? this_2 : THROW_CCE(), value));
          this.ic_1 = 2;
          suspendResult = this.a5h_1.m4v(this.b5h_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          this.c5h_1 = suspendResult;
          if (this.c5h_1.length <= 28) {
            throw new EncryptionFailed('Encryption failed: invalid ciphertext length');
          }

          this.d5h_1 = sliceArray(this.c5h_1, until(0, 12));
          this.e5h_1 = sliceArray(this.c5h_1, until(12, this.c5h_1.length));
          this.f5h_1 = sliceArray(this.e5h_1, until(this.e5h_1.length - 16 | 0, this.e5h_1.length));
          this.ic_1 = 3;
          suspendResult = decodeRsaPublicKey(this.v5g_1, this.x5g_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 3:
          this.g5h_1 = suspendResult;
          this.h5h_1 = this.g5h_1.c52();
          this.ic_1 = 4;
          suspendResult = this.z5g_1.d4v(Format_RAW_getInstance(), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 4:
          this.i5h_1 = suspendResult;
          this.ic_1 = 5;
          suspendResult = this.h5h_1.m4v(this.i5h_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 5:
          var encryptedKeyBytes = suspendResult;
          var encryptedKeyBase64 = Default_getInstance_0().kg(encryptedKeyBytes);
          var ivBase64 = Default_getInstance_0().kg(this.d5h_1);
          var tagBase64 = Default_getInstance_0().kg(this.f5h_1);
          return new EncryptedPayload(this.e5h_1, encryptedKeyBase64, this.x5g_1.l5h_1, ivBase64, tagBase64);
        case 6:
          this.jc_1 = 7;
          var tmp_1 = this.lc_1;
          if (tmp_1 instanceof Exception) {
            var e = this.lc_1;
            throw new EncryptionFailed('Encryption failed: ' + e.message, e);
          } else {
            throw this.lc_1;
          }

        case 7:
          throw this.lc_1;
        case 8:
          this.jc_1 = 7;
          return Unit_instance;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 7) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
function $decodeRsaPublicKeyCOROUTINE$5(_this__u8e3s4, jwk, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.h5g_1 = _this__u8e3s4;
  this.i5g_1 = jwk;
}
protoOf($decodeRsaPublicKeyCOROUTINE$5).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          this.jc_1 = 2;
          this.j5g_1 = this.h5g_1.j5h_1.z4u(Companion_getInstance_1());
          this.k5g_1 = this.j5g_1.q51(SHA256_getInstance());
          this.l5g_1 = this.i5g_1.q5h_1;
          this.m5g_1 = decodePemPublicKey(this.h5g_1, this.l5g_1);
          this.ic_1 = 1;
          suspendResult = this.k5g_1.g4v(Generic_getInstance(), this.m5g_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          return suspendResult;
        case 2:
          this.jc_1 = 3;
          var tmp_0 = this.lc_1;
          if (tmp_0 instanceof Exception) {
            var e = this.lc_1;
            throw new InvalidKey('Failed to decode RSA public key: ' + e.message, e);
          } else {
            throw this.lc_1;
          }

        case 3:
          throw this.lc_1;
        case 4:
          this.jc_1 = 3;
          return Unit_instance;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 3) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
function EncryptionManager() {
  this.j5h_1 = Companion_getInstance_2().x4u();
}
protoOf(EncryptionManager).s5h = function (jsonPayload, publicKey, $completion) {
  var tmp = new $encryptCOROUTINE$4(this, jsonPayload, publicKey, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
function JwksCache(cacheDuration) {
  var tmp;
  if (cacheDuration === VOID) {
    // Inline function 'kotlin.time.Companion.hours' call
    Companion_getInstance();
    tmp = toDuration(24, DurationUnit_HOURS_getInstance());
  } else {
    tmp = cacheDuration;
  }
  cacheDuration = tmp;
  this.t5h_1 = cacheDuration;
  this.u5h_1 = null;
  this.v5h_1 = new Long(0, 0);
}
protoOf(JwksCache).fv = function () {
  var now = System_instance.p4t().z4t();
  var tmp;
  if (now.mb(this.v5h_1).o6(_Duration___get_inWholeMilliseconds__impl__msfiry(this.t5h_1)) < 0) {
    tmp = this.u5h_1;
  } else {
    tmp = null;
  }
  return tmp;
};
protoOf(JwksCache).w5h = function (jwks) {
  this.u5h_1 = jwks;
  this.v5h_1 = System_instance.p4t().z4t();
};
protoOf(JwksCache).x = function () {
  this.u5h_1 = null;
  this.v5h_1 = new Long(0, 0);
};
protoOf(JwksCache).x5h = function () {
  var tmp0_safe_receiver = this.fv();
  var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.y5h_1;
  var tmp;
  if (tmp1_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var tmp0_iterator = tmp1_safe_receiver.u();
    while (tmp0_iterator.v()) {
      var element = tmp0_iterator.w();
      // Inline function 'com.exacaster.analytics.encryption.JwksCache.getEncryptionKey.<anonymous>' call
      if (element.z5h() ? !(element.r5h_1 === 'revoked') : false) {
        destination.r(element);
      }
    }
    tmp = destination;
  }
  var tmp2_elvis_lhs = tmp;
  var tmp_0;
  if (tmp2_elvis_lhs == null) {
    return null;
  } else {
    tmp_0 = tmp2_elvis_lhs;
  }
  var keys = tmp_0;
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination_0 = ArrayList_init_$Create$();
  var tmp0_iterator_0 = keys.u();
  while (tmp0_iterator_0.v()) {
    var element_0 = tmp0_iterator_0.w();
    // Inline function 'com.exacaster.analytics.encryption.JwksCache.getEncryptionKey.<anonymous>' call
    if (element_0.r5h_1 === 'active') {
      destination_0.r(element_0);
    }
  }
  var activeKeys = destination_0;
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!activeKeys.b1()) {
    return last(activeKeys);
  }
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination_1 = ArrayList_init_$Create$();
  var tmp0_iterator_1 = keys.u();
  while (tmp0_iterator_1.v()) {
    var element_1 = tmp0_iterator_1.w();
    // Inline function 'com.exacaster.analytics.encryption.JwksCache.getEncryptionKey.<anonymous>' call
    if (element_1.r5h_1 === 'deprecated') {
      destination_1.r(element_1);
    }
  }
  var deprecatedKeys = destination_1;
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!deprecatedKeys.b1()) {
    return last(deprecatedKeys);
  }
  return lastOrNull(keys);
};
function EncryptedPayload(ciphertext, encryptedKey, kid, iv, tag) {
  this.a5i_1 = ciphertext;
  this.b5i_1 = encryptedKey;
  this.c5i_1 = kid;
  this.d5i_1 = iv;
  this.e5i_1 = tag;
}
protoOf(EncryptedPayload).equals = function (other) {
  if (this === other)
    return true;
  if (other == null ? true : !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
    return false;
  if (!(other instanceof EncryptedPayload))
    THROW_CCE();
  if (!contentEquals(this.a5i_1, other.a5i_1))
    return false;
  if (!(this.b5i_1 === other.b5i_1))
    return false;
  if (!(this.c5i_1 === other.c5i_1))
    return false;
  if (!(this.d5i_1 === other.d5i_1))
    return false;
  if (!(this.e5i_1 === other.e5i_1))
    return false;
  return true;
};
protoOf(EncryptedPayload).hashCode = function () {
  var result = contentHashCode(this.a5i_1);
  result = imul(31, result) + getStringHashCode(this.b5i_1) | 0;
  result = imul(31, result) + getStringHashCode(this.c5i_1) | 0;
  result = imul(31, result) + getStringHashCode(this.d5i_1) | 0;
  result = imul(31, result) + getStringHashCode(this.e5i_1) | 0;
  return result;
};
protoOf(EncryptedPayload).toString = function () {
  return 'EncryptedPayload(ciphertext=' + toString(this.a5i_1) + ', encryptedKey=' + this.b5i_1 + ', kid=' + this.c5i_1 + ', iv=' + this.d5i_1 + ', tag=' + this.e5i_1 + ')';
};
function $serializer() {
  $serializer_instance = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('com.exacaster.analytics.encryption.models.Jwk', this, 8);
  tmp0_serialDesc.w41('kty', false);
  tmp0_serialDesc.w41('kid', false);
  tmp0_serialDesc.w41('use', false);
  tmp0_serialDesc.w41('alg', false);
  tmp0_serialDesc.w41('n', false);
  tmp0_serialDesc.w41('e', false);
  tmp0_serialDesc.w41('pem', false);
  tmp0_serialDesc.w41('status', true);
  this.f5i_1 = tmp0_serialDesc;
}
protoOf($serializer).z3q = function () {
  return this.f5i_1;
};
protoOf($serializer).l42 = function () {
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [StringSerializer_getInstance(), StringSerializer_getInstance(), StringSerializer_getInstance(), StringSerializer_getInstance(), StringSerializer_getInstance(), StringSerializer_getInstance(), StringSerializer_getInstance(), get_nullable(StringSerializer_getInstance())];
};
protoOf($serializer).n3r = function (decoder) {
  var tmp0_desc = this.f5i_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = null;
  var tmp5_local1 = null;
  var tmp6_local2 = null;
  var tmp7_local3 = null;
  var tmp8_local4 = null;
  var tmp9_local5 = null;
  var tmp10_local6 = null;
  var tmp11_local7 = null;
  var tmp12_input = decoder.m3u(tmp0_desc);
  if (tmp12_input.b3v()) {
    tmp4_local0 = tmp12_input.w3u(tmp0_desc, 0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp12_input.w3u(tmp0_desc, 1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
    tmp6_local2 = tmp12_input.w3u(tmp0_desc, 2);
    tmp3_bitMask0 = tmp3_bitMask0 | 4;
    tmp7_local3 = tmp12_input.w3u(tmp0_desc, 3);
    tmp3_bitMask0 = tmp3_bitMask0 | 8;
    tmp8_local4 = tmp12_input.w3u(tmp0_desc, 4);
    tmp3_bitMask0 = tmp3_bitMask0 | 16;
    tmp9_local5 = tmp12_input.w3u(tmp0_desc, 5);
    tmp3_bitMask0 = tmp3_bitMask0 | 32;
    tmp10_local6 = tmp12_input.w3u(tmp0_desc, 6);
    tmp3_bitMask0 = tmp3_bitMask0 | 64;
    tmp11_local7 = tmp12_input.a3v(tmp0_desc, 7, StringSerializer_getInstance(), tmp11_local7);
    tmp3_bitMask0 = tmp3_bitMask0 | 128;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp12_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp12_input.w3u(tmp0_desc, 0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp12_input.w3u(tmp0_desc, 1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        case 2:
          tmp6_local2 = tmp12_input.w3u(tmp0_desc, 2);
          tmp3_bitMask0 = tmp3_bitMask0 | 4;
          break;
        case 3:
          tmp7_local3 = tmp12_input.w3u(tmp0_desc, 3);
          tmp3_bitMask0 = tmp3_bitMask0 | 8;
          break;
        case 4:
          tmp8_local4 = tmp12_input.w3u(tmp0_desc, 4);
          tmp3_bitMask0 = tmp3_bitMask0 | 16;
          break;
        case 5:
          tmp9_local5 = tmp12_input.w3u(tmp0_desc, 5);
          tmp3_bitMask0 = tmp3_bitMask0 | 32;
          break;
        case 6:
          tmp10_local6 = tmp12_input.w3u(tmp0_desc, 6);
          tmp3_bitMask0 = tmp3_bitMask0 | 64;
          break;
        case 7:
          tmp11_local7 = tmp12_input.a3v(tmp0_desc, 7, StringSerializer_getInstance(), tmp11_local7);
          tmp3_bitMask0 = tmp3_bitMask0 | 128;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp12_input.n3u(tmp0_desc);
  return Jwk_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, tmp11_local7, null);
};
protoOf($serializer).g5i = function (encoder, value) {
  var tmp0_desc = this.f5i_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  tmp1_output.a3w(tmp0_desc, 0, value.k5h_1);
  tmp1_output.a3w(tmp0_desc, 1, value.l5h_1);
  tmp1_output.a3w(tmp0_desc, 2, value.m5h_1);
  tmp1_output.a3w(tmp0_desc, 3, value.n5h_1);
  tmp1_output.a3w(tmp0_desc, 4, value.o5h_1);
  tmp1_output.a3w(tmp0_desc, 5, value.p5h_1);
  tmp1_output.a3w(tmp0_desc, 6, value.q5h_1);
  if (tmp1_output.h3w(tmp0_desc, 7) ? true : !(value.r5h_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 7, StringSerializer_getInstance(), value.r5h_1);
  }
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer).m3r = function (encoder, value) {
  return this.g5i(encoder, value instanceof Jwk ? value : THROW_CCE());
};
var $serializer_instance;
function $serializer_getInstance() {
  if ($serializer_instance == null)
    new $serializer();
  return $serializer_instance;
}
function Jwk_init_$Init$(seen1, kty, kid, use, alg, n, e, pem, status, serializationConstructorMarker, $this) {
  if (!(127 === (127 & seen1))) {
    throwMissingFieldException(seen1, 127, $serializer_getInstance().f5i_1);
  }
  $this.k5h_1 = kty;
  $this.l5h_1 = kid;
  $this.m5h_1 = use;
  $this.n5h_1 = alg;
  $this.o5h_1 = n;
  $this.p5h_1 = e;
  $this.q5h_1 = pem;
  if (0 === (seen1 & 128))
    $this.r5h_1 = null;
  else
    $this.r5h_1 = status;
  return $this;
}
function Jwk_init_$Create$(seen1, kty, kid, use, alg, n, e, pem, status, serializationConstructorMarker) {
  return Jwk_init_$Init$(seen1, kty, kid, use, alg, n, e, pem, status, serializationConstructorMarker, objectCreate(protoOf(Jwk)));
}
function Jwk() {
}
protoOf(Jwk).z5h = function () {
  return (this.k5h_1 === 'RSA' ? this.n5h_1 === 'RSA-OAEP-256' : false) ? this.m5h_1 === 'enc' : false;
};
protoOf(Jwk).toString = function () {
  return 'Jwk(kty=' + this.k5h_1 + ', kid=' + this.l5h_1 + ', use=' + this.m5h_1 + ', alg=' + this.n5h_1 + ', n=' + this.o5h_1 + ', e=' + this.p5h_1 + ', pem=' + this.q5h_1 + ', status=' + this.r5h_1 + ')';
};
protoOf(Jwk).hashCode = function () {
  var result = getStringHashCode(this.k5h_1);
  result = imul(result, 31) + getStringHashCode(this.l5h_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.m5h_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.n5h_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.o5h_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.p5h_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.q5h_1) | 0;
  result = imul(result, 31) + (this.r5h_1 == null ? 0 : getStringHashCode(this.r5h_1)) | 0;
  return result;
};
protoOf(Jwk).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Jwk))
    return false;
  var tmp0_other_with_cast = other instanceof Jwk ? other : THROW_CCE();
  if (!(this.k5h_1 === tmp0_other_with_cast.k5h_1))
    return false;
  if (!(this.l5h_1 === tmp0_other_with_cast.l5h_1))
    return false;
  if (!(this.m5h_1 === tmp0_other_with_cast.m5h_1))
    return false;
  if (!(this.n5h_1 === tmp0_other_with_cast.n5h_1))
    return false;
  if (!(this.o5h_1 === tmp0_other_with_cast.o5h_1))
    return false;
  if (!(this.p5h_1 === tmp0_other_with_cast.p5h_1))
    return false;
  if (!(this.q5h_1 === tmp0_other_with_cast.q5h_1))
    return false;
  if (!(this.r5h_1 == tmp0_other_with_cast.r5h_1))
    return false;
  return true;
};
function Companion_0() {
  Companion_instance_3 = this;
  var tmp = this;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  tmp.h5i_1 = [new ArrayListSerializer($serializer_getInstance())];
}
var Companion_instance_3;
function Companion_getInstance_6() {
  if (Companion_instance_3 == null)
    new Companion_0();
  return Companion_instance_3;
}
function $serializer_0() {
  $serializer_instance_0 = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('com.exacaster.analytics.encryption.models.Jwks', this, 1);
  tmp0_serialDesc.w41('keys', false);
  this.i5i_1 = tmp0_serialDesc;
}
protoOf($serializer_0).z3q = function () {
  return this.i5i_1;
};
protoOf($serializer_0).l42 = function () {
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [Companion_getInstance_6().h5i_1[0]];
};
protoOf($serializer_0).n3r = function (decoder) {
  var tmp0_desc = this.i5i_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = null;
  var tmp5_input = decoder.m3u(tmp0_desc);
  var tmp6_cached = Companion_getInstance_6().h5i_1;
  if (tmp5_input.b3v()) {
    tmp4_local0 = tmp5_input.y3u(tmp0_desc, 0, tmp6_cached[0], tmp4_local0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp5_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp5_input.y3u(tmp0_desc, 0, tmp6_cached[0], tmp4_local0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp5_input.n3u(tmp0_desc);
  return Jwks_init_$Create$(tmp3_bitMask0, tmp4_local0, null);
};
protoOf($serializer_0).j5i = function (encoder, value) {
  var tmp0_desc = this.i5i_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  var tmp2_cached = Companion_getInstance_6().h5i_1;
  tmp1_output.c3w(tmp0_desc, 0, tmp2_cached[0], value.y5h_1);
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer_0).m3r = function (encoder, value) {
  return this.j5i(encoder, value instanceof Jwks ? value : THROW_CCE());
};
var $serializer_instance_0;
function $serializer_getInstance_0() {
  if ($serializer_instance_0 == null)
    new $serializer_0();
  return $serializer_instance_0;
}
function Jwks_init_$Init$(seen1, keys, serializationConstructorMarker, $this) {
  if (!(1 === (1 & seen1))) {
    throwMissingFieldException(seen1, 1, $serializer_getInstance_0().i5i_1);
  }
  $this.y5h_1 = keys;
  return $this;
}
function Jwks_init_$Create$(seen1, keys, serializationConstructorMarker) {
  return Jwks_init_$Init$(seen1, keys, serializationConstructorMarker, objectCreate(protoOf(Jwks)));
}
function Jwks(keys) {
  Companion_getInstance_6();
  this.y5h_1 = keys;
}
protoOf(Jwks).toString = function () {
  return 'Jwks(keys=' + this.y5h_1 + ')';
};
protoOf(Jwks).hashCode = function () {
  return hashCode(this.y5h_1);
};
protoOf(Jwks).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Jwks))
    return false;
  var tmp0_other_with_cast = other instanceof Jwks ? other : THROW_CCE();
  if (!equals(this.y5h_1, tmp0_other_with_cast.y5h_1))
    return false;
  return true;
};
function _get_$cachedSerializer__te6jhj($this) {
  return $this.k5i_1.l2();
}
function AppLifecycleState$Companion$_anonymous__2qb01z() {
  return createSimpleEnumSerializer('com.exacaster.analytics.lifecycle.AppLifecycleState', values());
}
var AppLifecycleState_INITIALIZED_instance;
var AppLifecycleState_FOREGROUND_instance;
var AppLifecycleState_BACKGROUND_instance;
var AppLifecycleState_TERMINATED_instance;
function Companion_1() {
  Companion_instance_4 = this;
  var tmp = this;
  var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
  tmp.k5i_1 = lazy(tmp_0, AppLifecycleState$Companion$_anonymous__2qb01z);
}
protoOf(Companion_1).u4i = function () {
  return _get_$cachedSerializer__te6jhj(this);
};
protoOf(Companion_1).w42 = function (typeParamsSerializers) {
  return this.u4i();
};
var Companion_instance_4;
function Companion_getInstance_7() {
  AppLifecycleState_initEntries();
  if (Companion_instance_4 == null)
    new Companion_1();
  return Companion_instance_4;
}
function values() {
  return [AppLifecycleState_INITIALIZED_getInstance(), AppLifecycleState_FOREGROUND_getInstance(), AppLifecycleState_BACKGROUND_getInstance(), AppLifecycleState_TERMINATED_getInstance()];
}
function valueOf(value) {
  switch (value) {
    case 'INITIALIZED':
      return AppLifecycleState_INITIALIZED_getInstance();
    case 'FOREGROUND':
      return AppLifecycleState_FOREGROUND_getInstance();
    case 'BACKGROUND':
      return AppLifecycleState_BACKGROUND_getInstance();
    case 'TERMINATED':
      return AppLifecycleState_TERMINATED_getInstance();
    default:
      AppLifecycleState_initEntries();
      THROW_IAE('No enum constant value.');
      break;
  }
}
var AppLifecycleState_entriesInitialized;
function AppLifecycleState_initEntries() {
  if (AppLifecycleState_entriesInitialized)
    return Unit_instance;
  AppLifecycleState_entriesInitialized = true;
  AppLifecycleState_INITIALIZED_instance = new AppLifecycleState('INITIALIZED', 0);
  AppLifecycleState_FOREGROUND_instance = new AppLifecycleState('FOREGROUND', 1);
  AppLifecycleState_BACKGROUND_instance = new AppLifecycleState('BACKGROUND', 2);
  AppLifecycleState_TERMINATED_instance = new AppLifecycleState('TERMINATED', 3);
  Companion_getInstance_7();
}
function AppLifecycleState(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function AppLifecycleState_INITIALIZED_getInstance() {
  AppLifecycleState_initEntries();
  return AppLifecycleState_INITIALIZED_instance;
}
function AppLifecycleState_FOREGROUND_getInstance() {
  AppLifecycleState_initEntries();
  return AppLifecycleState_FOREGROUND_instance;
}
function AppLifecycleState_BACKGROUND_getInstance() {
  AppLifecycleState_initEntries();
  return AppLifecycleState_BACKGROUND_instance;
}
function AppLifecycleState_TERMINATED_getInstance() {
  AppLifecycleState_initEntries();
  return AppLifecycleState_TERMINATED_instance;
}
function serializeValue($this, value) {
  var tmp;
  if (value == null) {
    tmp = JsonNull_getInstance();
  } else {
    if (!(value == null) ? typeof value === 'string' : false) {
      tmp = JsonPrimitive(value);
    } else {
      if (isNumber(value)) {
        tmp = JsonPrimitive_1(value);
      } else {
        if (!(value == null) ? typeof value === 'boolean' : false) {
          tmp = JsonPrimitive_0(value);
        } else {
          if (!(value == null) ? isInterface(value, List) : false) {
            // Inline function 'kotlin.collections.map' call
            // Inline function 'kotlin.collections.mapTo' call
            var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(value, 10));
            var tmp0_iterator = value.u();
            while (tmp0_iterator.v()) {
              var item = tmp0_iterator.w();
              // Inline function 'com.exacaster.analytics.models.AnyValueSerializer.serializeValue.<anonymous>' call
              var tmp$ret$0 = serializeValue(AnyValueSerializer_getInstance(), item);
              destination.r(tmp$ret$0);
            }
            tmp = new JsonArray(destination);
          } else {
            if (!(value == null) ? isInterface(value, Map) : false) {
              // Inline function 'kotlin.collections.associate' call
              var this_0 = value.h2();
              var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(this_0, 10)), 16);
              // Inline function 'kotlin.collections.associateTo' call
              var destination_0 = LinkedHashMap_init_$Create$_0(capacity);
              var tmp0_iterator_0 = this_0.u();
              while (tmp0_iterator_0.v()) {
                var element = tmp0_iterator_0.w();
                // Inline function 'kotlin.collections.plusAssign' call
                // Inline function 'com.exacaster.analytics.models.AnyValueSerializer.serializeValue.<anonymous>' call
                var pair = to(toString_0(element.k2()), serializeValue(AnyValueSerializer_getInstance(), element.l2()));
                destination_0.i2(pair.ue_1, pair.ve_1);
              }
              tmp = new JsonObject(destination_0);
            } else {
              tmp = JsonPrimitive(toString(value));
            }
          }
        }
      }
    }
  }
  return tmp;
}
function deserializeJsonElement($this, element) {
  var tmp;
  if (element instanceof JsonNull) {
    tmp = 'null';
  } else {
    if (element instanceof JsonPrimitive_2) {
      tmp = element.w4i() ? element.e2l() : (element.e2l() === 'true' ? true : element.e2l() === 'false') ? toBoolean(element.e2l()) : !(toIntOrNull(element.e2l()) == null) ? toInt(element.e2l()) : !(toLongOrNull(element.e2l()) == null) ? toLong(element.e2l()) : !(toDoubleOrNull(element.e2l()) == null) ? toDouble(element.e2l()) : element.e2l();
    } else {
      if (element instanceof JsonArray) {
        // Inline function 'kotlin.collections.map' call
        // Inline function 'kotlin.collections.mapTo' call
        var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(element, 10));
        var tmp0_iterator = element.u();
        while (tmp0_iterator.v()) {
          var item = tmp0_iterator.w();
          // Inline function 'com.exacaster.analytics.models.AnyValueSerializer.deserializeJsonElement.<anonymous>' call
          var tmp$ret$0 = deserializeJsonElement(AnyValueSerializer_getInstance(), item);
          destination.r(tmp$ret$0);
        }
        tmp = destination;
      } else {
        if (element instanceof JsonObject) {
          // Inline function 'kotlin.collections.mapValues' call
          // Inline function 'kotlin.collections.mapValuesTo' call
          var destination_0 = LinkedHashMap_init_$Create$_0(mapCapacity(element.n()));
          // Inline function 'kotlin.collections.associateByTo' call
          var tmp0_iterator_0 = element.h2().u();
          while (tmp0_iterator_0.v()) {
            var element_0 = tmp0_iterator_0.w();
            // Inline function 'kotlin.collections.mapValuesTo.<anonymous>' call
            var tmp_0 = element_0.k2();
            // Inline function 'com.exacaster.analytics.models.AnyValueSerializer.deserializeJsonElement.<anonymous>' call
            var tmp$ret$4 = deserializeJsonElement(AnyValueSerializer_getInstance(), element_0.l2());
            destination_0.i2(tmp_0, tmp$ret$4);
          }
          tmp = destination_0;
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
  }
  return tmp;
}
function AnyValueSerializer() {
  AnyValueSerializer_instance = this;
  this.l5i_1 = buildClassSerialDescriptor('AnyValue', []);
}
protoOf(AnyValueSerializer).z3q = function () {
  return this.l5i_1;
};
protoOf(AnyValueSerializer).m5i = function (encoder, value) {
  var tmp0_elvis_lhs = isInterface(encoder, JsonEncoder) ? encoder : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalStateException_init_$Create$('AnyValueSerializer only works with JSON');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var jsonEncoder = tmp;
  var tmp_0;
  if (typeof value === 'string') {
    tmp_0 = JsonPrimitive(value);
  } else {
    if (isNumber(value)) {
      tmp_0 = JsonPrimitive_1(value);
    } else {
      if (typeof value === 'boolean') {
        tmp_0 = JsonPrimitive_0(value);
      } else {
        if (isInterface(value, List)) {
          // Inline function 'kotlin.collections.map' call
          // Inline function 'kotlin.collections.mapTo' call
          var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(value, 10));
          var tmp0_iterator = value.u();
          while (tmp0_iterator.v()) {
            var item = tmp0_iterator.w();
            // Inline function 'com.exacaster.analytics.models.AnyValueSerializer.serialize.<anonymous>' call
            var tmp$ret$0 = serializeValue(AnyValueSerializer_getInstance(), item);
            destination.r(tmp$ret$0);
          }
          tmp_0 = new JsonArray(destination);
        } else {
          if (isInterface(value, Map)) {
            // Inline function 'kotlin.collections.associate' call
            var this_0 = value.h2();
            var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(this_0, 10)), 16);
            // Inline function 'kotlin.collections.associateTo' call
            var destination_0 = LinkedHashMap_init_$Create$_0(capacity);
            var tmp0_iterator_0 = this_0.u();
            while (tmp0_iterator_0.v()) {
              var element = tmp0_iterator_0.w();
              // Inline function 'kotlin.collections.plusAssign' call
              // Inline function 'com.exacaster.analytics.models.AnyValueSerializer.serialize.<anonymous>' call
              var pair = to(toString_0(element.k2()), serializeValue(AnyValueSerializer_getInstance(), element.l2()));
              destination_0.i2(pair.ue_1, pair.ve_1);
            }
            tmp_0 = new JsonObject(destination_0);
          } else {
            tmp_0 = JsonPrimitive(toString(value));
          }
        }
      }
    }
  }
  var element_0 = tmp_0;
  jsonEncoder.a4k(element_0);
};
protoOf(AnyValueSerializer).m3r = function (encoder, value) {
  return this.m5i(encoder, !(value == null) ? value : THROW_CCE());
};
protoOf(AnyValueSerializer).n3r = function (decoder) {
  var tmp0_elvis_lhs = isInterface(decoder, JsonDecoder) ? decoder : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalStateException_init_$Create$('AnyValueSerializer only works with JSON');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var jsonDecoder = tmp;
  return deserializeJsonElement(this, jsonDecoder.t4i());
};
var AnyValueSerializer_instance;
function AnyValueSerializer_getInstance() {
  if (AnyValueSerializer_instance == null)
    new AnyValueSerializer();
  return AnyValueSerializer_instance;
}
function Companion_2() {
}
protoOf(Companion_2).u4i = function () {
  var tmp = getKClass(Event);
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp_0 = [getKClass(IdentifyEvent), getKClass(LifecycleEvent), getKClass(ScreenEvent), getKClass(TrackEvent)];
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp_1 = [$serializer_getInstance_4(), $serializer_getInstance_1(), $serializer_getInstance_3(), $serializer_getInstance_2()];
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$8 = [];
  return SealedClassSerializer_init_$Create$('com.exacaster.analytics.models.Event', tmp, tmp_0, tmp_1, tmp$ret$8);
};
protoOf(Companion_2).w42 = function (typeParamsSerializers) {
  return this.u4i();
};
var Companion_instance_5;
function Companion_getInstance_8() {
  return Companion_instance_5;
}
function Event() {
}
function Companion_3() {
  Companion_instance_6 = this;
  var tmp = this;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  tmp.o5i_1 = [null, null, null, null, null, null, Companion_getInstance_7().u4i(), new LinkedHashMapSerializer(StringSerializer_getInstance(), AnyValueSerializer_getInstance())];
}
var Companion_instance_6;
function Companion_getInstance_9() {
  if (Companion_instance_6 == null)
    new Companion_3();
  return Companion_instance_6;
}
function $serializer_1() {
  $serializer_instance_1 = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('com.exacaster.analytics.models.LifecycleEvent', this, 8);
  tmp0_serialDesc.w41('eventId', false);
  tmp0_serialDesc.w41('timestamp', false);
  tmp0_serialDesc.w41('eventType', true);
  tmp0_serialDesc.w41('userId', true);
  tmp0_serialDesc.w41('anonymousId', true);
  tmp0_serialDesc.w41('context', false);
  tmp0_serialDesc.w41('lifecycleState', false);
  tmp0_serialDesc.w41('properties', true);
  this.p5i_1 = tmp0_serialDesc;
}
protoOf($serializer_1).z3q = function () {
  return this.p5i_1;
};
protoOf($serializer_1).l42 = function () {
  var tmp0_cached = Companion_getInstance_9().o5i_1;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [StringSerializer_getInstance(), LongSerializer_getInstance(), StringSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), $serializer_getInstance_5(), tmp0_cached[6], tmp0_cached[7]];
};
protoOf($serializer_1).n3r = function (decoder) {
  var tmp0_desc = this.p5i_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = null;
  var tmp5_local1 = new Long(0, 0);
  var tmp6_local2 = null;
  var tmp7_local3 = null;
  var tmp8_local4 = null;
  var tmp9_local5 = null;
  var tmp10_local6 = null;
  var tmp11_local7 = null;
  var tmp12_input = decoder.m3u(tmp0_desc);
  var tmp13_cached = Companion_getInstance_9().o5i_1;
  if (tmp12_input.b3v()) {
    tmp4_local0 = tmp12_input.w3u(tmp0_desc, 0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp12_input.s3u(tmp0_desc, 1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
    tmp6_local2 = tmp12_input.w3u(tmp0_desc, 2);
    tmp3_bitMask0 = tmp3_bitMask0 | 4;
    tmp7_local3 = tmp12_input.a3v(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
    tmp3_bitMask0 = tmp3_bitMask0 | 8;
    tmp8_local4 = tmp12_input.a3v(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
    tmp3_bitMask0 = tmp3_bitMask0 | 16;
    tmp9_local5 = tmp12_input.y3u(tmp0_desc, 5, $serializer_getInstance_5(), tmp9_local5);
    tmp3_bitMask0 = tmp3_bitMask0 | 32;
    tmp10_local6 = tmp12_input.y3u(tmp0_desc, 6, tmp13_cached[6], tmp10_local6);
    tmp3_bitMask0 = tmp3_bitMask0 | 64;
    tmp11_local7 = tmp12_input.y3u(tmp0_desc, 7, tmp13_cached[7], tmp11_local7);
    tmp3_bitMask0 = tmp3_bitMask0 | 128;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp12_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp12_input.w3u(tmp0_desc, 0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp12_input.s3u(tmp0_desc, 1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        case 2:
          tmp6_local2 = tmp12_input.w3u(tmp0_desc, 2);
          tmp3_bitMask0 = tmp3_bitMask0 | 4;
          break;
        case 3:
          tmp7_local3 = tmp12_input.a3v(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
          tmp3_bitMask0 = tmp3_bitMask0 | 8;
          break;
        case 4:
          tmp8_local4 = tmp12_input.a3v(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
          tmp3_bitMask0 = tmp3_bitMask0 | 16;
          break;
        case 5:
          tmp9_local5 = tmp12_input.y3u(tmp0_desc, 5, $serializer_getInstance_5(), tmp9_local5);
          tmp3_bitMask0 = tmp3_bitMask0 | 32;
          break;
        case 6:
          tmp10_local6 = tmp12_input.y3u(tmp0_desc, 6, tmp13_cached[6], tmp10_local6);
          tmp3_bitMask0 = tmp3_bitMask0 | 64;
          break;
        case 7:
          tmp11_local7 = tmp12_input.y3u(tmp0_desc, 7, tmp13_cached[7], tmp11_local7);
          tmp3_bitMask0 = tmp3_bitMask0 | 128;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp12_input.n3u(tmp0_desc);
  return LifecycleEvent_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, tmp11_local7, null);
};
protoOf($serializer_1).q5i = function (encoder, value) {
  var tmp0_desc = this.p5i_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  var tmp2_cached = Companion_getInstance_9().o5i_1;
  tmp1_output.a3w(tmp0_desc, 0, value.r5i_1);
  tmp1_output.w3v(tmp0_desc, 1, value.s5i_1);
  tmp1_output.a3w(tmp0_desc, 2, value.t5i_1);
  if (tmp1_output.h3w(tmp0_desc, 3) ? true : !(value.u5i_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 3, StringSerializer_getInstance(), value.u5i_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 4) ? true : !(value.v5i_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 4, StringSerializer_getInstance(), value.v5i_1);
  }
  tmp1_output.c3w(tmp0_desc, 5, $serializer_getInstance_5(), value.w5i_1);
  tmp1_output.c3w(tmp0_desc, 6, tmp2_cached[6], value.x5i_1);
  if (tmp1_output.h3w(tmp0_desc, 7) ? true : !equals(value.y5i_1, emptyMap())) {
    tmp1_output.c3w(tmp0_desc, 7, tmp2_cached[7], value.y5i_1);
  }
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer_1).m3r = function (encoder, value) {
  return this.q5i(encoder, value instanceof LifecycleEvent ? value : THROW_CCE());
};
var $serializer_instance_1;
function $serializer_getInstance_1() {
  if ($serializer_instance_1 == null)
    new $serializer_1();
  return $serializer_instance_1;
}
function LifecycleEvent_init_$Init$(seen1, eventId, timestamp, eventType, userId, anonymousId, context, lifecycleState, properties, serializationConstructorMarker, $this) {
  if (!(99 === (99 & seen1))) {
    throwMissingFieldException(seen1, 99, $serializer_getInstance_1().p5i_1);
  }
  $this.r5i_1 = eventId;
  $this.s5i_1 = timestamp;
  if (0 === (seen1 & 4))
    $this.t5i_1 = 'lifecycle';
  else
    $this.t5i_1 = eventType;
  if (0 === (seen1 & 8))
    $this.u5i_1 = null;
  else
    $this.u5i_1 = userId;
  if (0 === (seen1 & 16))
    $this.v5i_1 = null;
  else
    $this.v5i_1 = anonymousId;
  $this.w5i_1 = context;
  $this.x5i_1 = lifecycleState;
  if (0 === (seen1 & 128))
    $this.y5i_1 = emptyMap();
  else
    $this.y5i_1 = properties;
  return $this;
}
function LifecycleEvent_init_$Create$(seen1, eventId, timestamp, eventType, userId, anonymousId, context, lifecycleState, properties, serializationConstructorMarker) {
  return LifecycleEvent_init_$Init$(seen1, eventId, timestamp, eventType, userId, anonymousId, context, lifecycleState, properties, serializationConstructorMarker, objectCreate(protoOf(LifecycleEvent)));
}
function LifecycleEvent(eventId, timestamp, eventType, userId, anonymousId, context, lifecycleState, properties) {
  Companion_getInstance_9();
  eventType = eventType === VOID ? 'lifecycle' : eventType;
  userId = userId === VOID ? null : userId;
  anonymousId = anonymousId === VOID ? null : anonymousId;
  properties = properties === VOID ? emptyMap() : properties;
  this.r5i_1 = eventId;
  this.s5i_1 = timestamp;
  this.t5i_1 = eventType;
  this.u5i_1 = userId;
  this.v5i_1 = anonymousId;
  this.w5i_1 = context;
  this.x5i_1 = lifecycleState;
  this.y5i_1 = properties;
}
protoOf(LifecycleEvent).n5i = function () {
  return this.r5i_1;
};
protoOf(LifecycleEvent).toString = function () {
  return 'LifecycleEvent(eventId=' + this.r5i_1 + ', timestamp=' + this.s5i_1.toString() + ', eventType=' + this.t5i_1 + ', userId=' + this.u5i_1 + ', anonymousId=' + this.v5i_1 + ', context=' + this.w5i_1 + ', lifecycleState=' + this.x5i_1 + ', properties=' + this.y5i_1 + ')';
};
protoOf(LifecycleEvent).hashCode = function () {
  var result = getStringHashCode(this.r5i_1);
  result = imul(result, 31) + this.s5i_1.hashCode() | 0;
  result = imul(result, 31) + getStringHashCode(this.t5i_1) | 0;
  result = imul(result, 31) + (this.u5i_1 == null ? 0 : getStringHashCode(this.u5i_1)) | 0;
  result = imul(result, 31) + (this.v5i_1 == null ? 0 : getStringHashCode(this.v5i_1)) | 0;
  result = imul(result, 31) + this.w5i_1.hashCode() | 0;
  result = imul(result, 31) + this.x5i_1.hashCode() | 0;
  result = imul(result, 31) + hashCode(this.y5i_1) | 0;
  return result;
};
protoOf(LifecycleEvent).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof LifecycleEvent))
    return false;
  var tmp0_other_with_cast = other instanceof LifecycleEvent ? other : THROW_CCE();
  if (!(this.r5i_1 === tmp0_other_with_cast.r5i_1))
    return false;
  if (!this.s5i_1.equals(tmp0_other_with_cast.s5i_1))
    return false;
  if (!(this.t5i_1 === tmp0_other_with_cast.t5i_1))
    return false;
  if (!(this.u5i_1 == tmp0_other_with_cast.u5i_1))
    return false;
  if (!(this.v5i_1 == tmp0_other_with_cast.v5i_1))
    return false;
  if (!this.w5i_1.equals(tmp0_other_with_cast.w5i_1))
    return false;
  if (!this.x5i_1.equals(tmp0_other_with_cast.x5i_1))
    return false;
  if (!equals(this.y5i_1, tmp0_other_with_cast.y5i_1))
    return false;
  return true;
};
function Companion_4() {
  Companion_instance_7 = this;
  var tmp = this;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  tmp.z5i_1 = [null, null, null, null, null, null, null, new LinkedHashMapSerializer(StringSerializer_getInstance(), AnyValueSerializer_getInstance())];
}
var Companion_instance_7;
function Companion_getInstance_10() {
  if (Companion_instance_7 == null)
    new Companion_4();
  return Companion_instance_7;
}
function $serializer_2() {
  $serializer_instance_2 = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('com.exacaster.analytics.models.TrackEvent', this, 8);
  tmp0_serialDesc.w41('eventId', false);
  tmp0_serialDesc.w41('timestamp', false);
  tmp0_serialDesc.w41('eventType', true);
  tmp0_serialDesc.w41('userId', true);
  tmp0_serialDesc.w41('anonymousId', true);
  tmp0_serialDesc.w41('context', false);
  tmp0_serialDesc.w41('eventName', false);
  tmp0_serialDesc.w41('properties', true);
  this.a5j_1 = tmp0_serialDesc;
}
protoOf($serializer_2).z3q = function () {
  return this.a5j_1;
};
protoOf($serializer_2).l42 = function () {
  var tmp0_cached = Companion_getInstance_10().z5i_1;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [StringSerializer_getInstance(), LongSerializer_getInstance(), StringSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), $serializer_getInstance_5(), StringSerializer_getInstance(), tmp0_cached[7]];
};
protoOf($serializer_2).n3r = function (decoder) {
  var tmp0_desc = this.a5j_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = null;
  var tmp5_local1 = new Long(0, 0);
  var tmp6_local2 = null;
  var tmp7_local3 = null;
  var tmp8_local4 = null;
  var tmp9_local5 = null;
  var tmp10_local6 = null;
  var tmp11_local7 = null;
  var tmp12_input = decoder.m3u(tmp0_desc);
  var tmp13_cached = Companion_getInstance_10().z5i_1;
  if (tmp12_input.b3v()) {
    tmp4_local0 = tmp12_input.w3u(tmp0_desc, 0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp12_input.s3u(tmp0_desc, 1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
    tmp6_local2 = tmp12_input.w3u(tmp0_desc, 2);
    tmp3_bitMask0 = tmp3_bitMask0 | 4;
    tmp7_local3 = tmp12_input.a3v(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
    tmp3_bitMask0 = tmp3_bitMask0 | 8;
    tmp8_local4 = tmp12_input.a3v(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
    tmp3_bitMask0 = tmp3_bitMask0 | 16;
    tmp9_local5 = tmp12_input.y3u(tmp0_desc, 5, $serializer_getInstance_5(), tmp9_local5);
    tmp3_bitMask0 = tmp3_bitMask0 | 32;
    tmp10_local6 = tmp12_input.w3u(tmp0_desc, 6);
    tmp3_bitMask0 = tmp3_bitMask0 | 64;
    tmp11_local7 = tmp12_input.y3u(tmp0_desc, 7, tmp13_cached[7], tmp11_local7);
    tmp3_bitMask0 = tmp3_bitMask0 | 128;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp12_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp12_input.w3u(tmp0_desc, 0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp12_input.s3u(tmp0_desc, 1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        case 2:
          tmp6_local2 = tmp12_input.w3u(tmp0_desc, 2);
          tmp3_bitMask0 = tmp3_bitMask0 | 4;
          break;
        case 3:
          tmp7_local3 = tmp12_input.a3v(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
          tmp3_bitMask0 = tmp3_bitMask0 | 8;
          break;
        case 4:
          tmp8_local4 = tmp12_input.a3v(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
          tmp3_bitMask0 = tmp3_bitMask0 | 16;
          break;
        case 5:
          tmp9_local5 = tmp12_input.y3u(tmp0_desc, 5, $serializer_getInstance_5(), tmp9_local5);
          tmp3_bitMask0 = tmp3_bitMask0 | 32;
          break;
        case 6:
          tmp10_local6 = tmp12_input.w3u(tmp0_desc, 6);
          tmp3_bitMask0 = tmp3_bitMask0 | 64;
          break;
        case 7:
          tmp11_local7 = tmp12_input.y3u(tmp0_desc, 7, tmp13_cached[7], tmp11_local7);
          tmp3_bitMask0 = tmp3_bitMask0 | 128;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp12_input.n3u(tmp0_desc);
  return TrackEvent_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, tmp11_local7, null);
};
protoOf($serializer_2).b5j = function (encoder, value) {
  var tmp0_desc = this.a5j_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  var tmp2_cached = Companion_getInstance_10().z5i_1;
  tmp1_output.a3w(tmp0_desc, 0, value.c5j_1);
  tmp1_output.w3v(tmp0_desc, 1, value.d5j_1);
  tmp1_output.a3w(tmp0_desc, 2, value.e5j_1);
  if (tmp1_output.h3w(tmp0_desc, 3) ? true : !(value.f5j_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 3, StringSerializer_getInstance(), value.f5j_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 4) ? true : !(value.g5j_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 4, StringSerializer_getInstance(), value.g5j_1);
  }
  tmp1_output.c3w(tmp0_desc, 5, $serializer_getInstance_5(), value.h5j_1);
  tmp1_output.a3w(tmp0_desc, 6, value.i5j_1);
  if (tmp1_output.h3w(tmp0_desc, 7) ? true : !equals(value.j5j_1, emptyMap())) {
    tmp1_output.c3w(tmp0_desc, 7, tmp2_cached[7], value.j5j_1);
  }
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer_2).m3r = function (encoder, value) {
  return this.b5j(encoder, value instanceof TrackEvent ? value : THROW_CCE());
};
var $serializer_instance_2;
function $serializer_getInstance_2() {
  if ($serializer_instance_2 == null)
    new $serializer_2();
  return $serializer_instance_2;
}
function TrackEvent_init_$Init$(seen1, eventId, timestamp, eventType, userId, anonymousId, context, eventName, properties, serializationConstructorMarker, $this) {
  if (!(99 === (99 & seen1))) {
    throwMissingFieldException(seen1, 99, $serializer_getInstance_2().a5j_1);
  }
  $this.c5j_1 = eventId;
  $this.d5j_1 = timestamp;
  if (0 === (seen1 & 4))
    $this.e5j_1 = 'track';
  else
    $this.e5j_1 = eventType;
  if (0 === (seen1 & 8))
    $this.f5j_1 = null;
  else
    $this.f5j_1 = userId;
  if (0 === (seen1 & 16))
    $this.g5j_1 = null;
  else
    $this.g5j_1 = anonymousId;
  $this.h5j_1 = context;
  $this.i5j_1 = eventName;
  if (0 === (seen1 & 128))
    $this.j5j_1 = emptyMap();
  else
    $this.j5j_1 = properties;
  return $this;
}
function TrackEvent_init_$Create$(seen1, eventId, timestamp, eventType, userId, anonymousId, context, eventName, properties, serializationConstructorMarker) {
  return TrackEvent_init_$Init$(seen1, eventId, timestamp, eventType, userId, anonymousId, context, eventName, properties, serializationConstructorMarker, objectCreate(protoOf(TrackEvent)));
}
function TrackEvent(eventId, timestamp, eventType, userId, anonymousId, context, eventName, properties) {
  Companion_getInstance_10();
  eventType = eventType === VOID ? 'track' : eventType;
  userId = userId === VOID ? null : userId;
  anonymousId = anonymousId === VOID ? null : anonymousId;
  properties = properties === VOID ? emptyMap() : properties;
  this.c5j_1 = eventId;
  this.d5j_1 = timestamp;
  this.e5j_1 = eventType;
  this.f5j_1 = userId;
  this.g5j_1 = anonymousId;
  this.h5j_1 = context;
  this.i5j_1 = eventName;
  this.j5j_1 = properties;
}
protoOf(TrackEvent).n5i = function () {
  return this.c5j_1;
};
protoOf(TrackEvent).toString = function () {
  return 'TrackEvent(eventId=' + this.c5j_1 + ', timestamp=' + this.d5j_1.toString() + ', eventType=' + this.e5j_1 + ', userId=' + this.f5j_1 + ', anonymousId=' + this.g5j_1 + ', context=' + this.h5j_1 + ', eventName=' + this.i5j_1 + ', properties=' + this.j5j_1 + ')';
};
protoOf(TrackEvent).hashCode = function () {
  var result = getStringHashCode(this.c5j_1);
  result = imul(result, 31) + this.d5j_1.hashCode() | 0;
  result = imul(result, 31) + getStringHashCode(this.e5j_1) | 0;
  result = imul(result, 31) + (this.f5j_1 == null ? 0 : getStringHashCode(this.f5j_1)) | 0;
  result = imul(result, 31) + (this.g5j_1 == null ? 0 : getStringHashCode(this.g5j_1)) | 0;
  result = imul(result, 31) + this.h5j_1.hashCode() | 0;
  result = imul(result, 31) + getStringHashCode(this.i5j_1) | 0;
  result = imul(result, 31) + hashCode(this.j5j_1) | 0;
  return result;
};
protoOf(TrackEvent).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof TrackEvent))
    return false;
  var tmp0_other_with_cast = other instanceof TrackEvent ? other : THROW_CCE();
  if (!(this.c5j_1 === tmp0_other_with_cast.c5j_1))
    return false;
  if (!this.d5j_1.equals(tmp0_other_with_cast.d5j_1))
    return false;
  if (!(this.e5j_1 === tmp0_other_with_cast.e5j_1))
    return false;
  if (!(this.f5j_1 == tmp0_other_with_cast.f5j_1))
    return false;
  if (!(this.g5j_1 == tmp0_other_with_cast.g5j_1))
    return false;
  if (!this.h5j_1.equals(tmp0_other_with_cast.h5j_1))
    return false;
  if (!(this.i5j_1 === tmp0_other_with_cast.i5j_1))
    return false;
  if (!equals(this.j5j_1, tmp0_other_with_cast.j5j_1))
    return false;
  return true;
};
function Companion_5() {
  Companion_instance_8 = this;
  var tmp = this;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  tmp.k5j_1 = [null, null, null, null, null, null, null, new LinkedHashMapSerializer(StringSerializer_getInstance(), AnyValueSerializer_getInstance())];
}
var Companion_instance_8;
function Companion_getInstance_11() {
  if (Companion_instance_8 == null)
    new Companion_5();
  return Companion_instance_8;
}
function $serializer_3() {
  $serializer_instance_3 = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('com.exacaster.analytics.models.ScreenEvent', this, 8);
  tmp0_serialDesc.w41('eventId', false);
  tmp0_serialDesc.w41('timestamp', false);
  tmp0_serialDesc.w41('eventType', true);
  tmp0_serialDesc.w41('userId', true);
  tmp0_serialDesc.w41('anonymousId', true);
  tmp0_serialDesc.w41('context', false);
  tmp0_serialDesc.w41('screenName', false);
  tmp0_serialDesc.w41('properties', true);
  this.l5j_1 = tmp0_serialDesc;
}
protoOf($serializer_3).z3q = function () {
  return this.l5j_1;
};
protoOf($serializer_3).l42 = function () {
  var tmp0_cached = Companion_getInstance_11().k5j_1;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [StringSerializer_getInstance(), LongSerializer_getInstance(), StringSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), $serializer_getInstance_5(), StringSerializer_getInstance(), tmp0_cached[7]];
};
protoOf($serializer_3).n3r = function (decoder) {
  var tmp0_desc = this.l5j_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = null;
  var tmp5_local1 = new Long(0, 0);
  var tmp6_local2 = null;
  var tmp7_local3 = null;
  var tmp8_local4 = null;
  var tmp9_local5 = null;
  var tmp10_local6 = null;
  var tmp11_local7 = null;
  var tmp12_input = decoder.m3u(tmp0_desc);
  var tmp13_cached = Companion_getInstance_11().k5j_1;
  if (tmp12_input.b3v()) {
    tmp4_local0 = tmp12_input.w3u(tmp0_desc, 0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp12_input.s3u(tmp0_desc, 1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
    tmp6_local2 = tmp12_input.w3u(tmp0_desc, 2);
    tmp3_bitMask0 = tmp3_bitMask0 | 4;
    tmp7_local3 = tmp12_input.a3v(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
    tmp3_bitMask0 = tmp3_bitMask0 | 8;
    tmp8_local4 = tmp12_input.a3v(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
    tmp3_bitMask0 = tmp3_bitMask0 | 16;
    tmp9_local5 = tmp12_input.y3u(tmp0_desc, 5, $serializer_getInstance_5(), tmp9_local5);
    tmp3_bitMask0 = tmp3_bitMask0 | 32;
    tmp10_local6 = tmp12_input.w3u(tmp0_desc, 6);
    tmp3_bitMask0 = tmp3_bitMask0 | 64;
    tmp11_local7 = tmp12_input.y3u(tmp0_desc, 7, tmp13_cached[7], tmp11_local7);
    tmp3_bitMask0 = tmp3_bitMask0 | 128;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp12_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp12_input.w3u(tmp0_desc, 0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp12_input.s3u(tmp0_desc, 1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        case 2:
          tmp6_local2 = tmp12_input.w3u(tmp0_desc, 2);
          tmp3_bitMask0 = tmp3_bitMask0 | 4;
          break;
        case 3:
          tmp7_local3 = tmp12_input.a3v(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
          tmp3_bitMask0 = tmp3_bitMask0 | 8;
          break;
        case 4:
          tmp8_local4 = tmp12_input.a3v(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
          tmp3_bitMask0 = tmp3_bitMask0 | 16;
          break;
        case 5:
          tmp9_local5 = tmp12_input.y3u(tmp0_desc, 5, $serializer_getInstance_5(), tmp9_local5);
          tmp3_bitMask0 = tmp3_bitMask0 | 32;
          break;
        case 6:
          tmp10_local6 = tmp12_input.w3u(tmp0_desc, 6);
          tmp3_bitMask0 = tmp3_bitMask0 | 64;
          break;
        case 7:
          tmp11_local7 = tmp12_input.y3u(tmp0_desc, 7, tmp13_cached[7], tmp11_local7);
          tmp3_bitMask0 = tmp3_bitMask0 | 128;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp12_input.n3u(tmp0_desc);
  return ScreenEvent_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, tmp11_local7, null);
};
protoOf($serializer_3).m5j = function (encoder, value) {
  var tmp0_desc = this.l5j_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  var tmp2_cached = Companion_getInstance_11().k5j_1;
  tmp1_output.a3w(tmp0_desc, 0, value.n5j_1);
  tmp1_output.w3v(tmp0_desc, 1, value.o5j_1);
  tmp1_output.a3w(tmp0_desc, 2, value.p5j_1);
  if (tmp1_output.h3w(tmp0_desc, 3) ? true : !(value.q5j_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 3, StringSerializer_getInstance(), value.q5j_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 4) ? true : !(value.r5j_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 4, StringSerializer_getInstance(), value.r5j_1);
  }
  tmp1_output.c3w(tmp0_desc, 5, $serializer_getInstance_5(), value.s5j_1);
  tmp1_output.a3w(tmp0_desc, 6, value.t5j_1);
  if (tmp1_output.h3w(tmp0_desc, 7) ? true : !equals(value.u5j_1, emptyMap())) {
    tmp1_output.c3w(tmp0_desc, 7, tmp2_cached[7], value.u5j_1);
  }
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer_3).m3r = function (encoder, value) {
  return this.m5j(encoder, value instanceof ScreenEvent ? value : THROW_CCE());
};
var $serializer_instance_3;
function $serializer_getInstance_3() {
  if ($serializer_instance_3 == null)
    new $serializer_3();
  return $serializer_instance_3;
}
function ScreenEvent_init_$Init$(seen1, eventId, timestamp, eventType, userId, anonymousId, context, screenName, properties, serializationConstructorMarker, $this) {
  if (!(99 === (99 & seen1))) {
    throwMissingFieldException(seen1, 99, $serializer_getInstance_3().l5j_1);
  }
  $this.n5j_1 = eventId;
  $this.o5j_1 = timestamp;
  if (0 === (seen1 & 4))
    $this.p5j_1 = 'screen';
  else
    $this.p5j_1 = eventType;
  if (0 === (seen1 & 8))
    $this.q5j_1 = null;
  else
    $this.q5j_1 = userId;
  if (0 === (seen1 & 16))
    $this.r5j_1 = null;
  else
    $this.r5j_1 = anonymousId;
  $this.s5j_1 = context;
  $this.t5j_1 = screenName;
  if (0 === (seen1 & 128))
    $this.u5j_1 = emptyMap();
  else
    $this.u5j_1 = properties;
  return $this;
}
function ScreenEvent_init_$Create$(seen1, eventId, timestamp, eventType, userId, anonymousId, context, screenName, properties, serializationConstructorMarker) {
  return ScreenEvent_init_$Init$(seen1, eventId, timestamp, eventType, userId, anonymousId, context, screenName, properties, serializationConstructorMarker, objectCreate(protoOf(ScreenEvent)));
}
function ScreenEvent(eventId, timestamp, eventType, userId, anonymousId, context, screenName, properties) {
  Companion_getInstance_11();
  eventType = eventType === VOID ? 'screen' : eventType;
  userId = userId === VOID ? null : userId;
  anonymousId = anonymousId === VOID ? null : anonymousId;
  properties = properties === VOID ? emptyMap() : properties;
  this.n5j_1 = eventId;
  this.o5j_1 = timestamp;
  this.p5j_1 = eventType;
  this.q5j_1 = userId;
  this.r5j_1 = anonymousId;
  this.s5j_1 = context;
  this.t5j_1 = screenName;
  this.u5j_1 = properties;
}
protoOf(ScreenEvent).n5i = function () {
  return this.n5j_1;
};
protoOf(ScreenEvent).toString = function () {
  return 'ScreenEvent(eventId=' + this.n5j_1 + ', timestamp=' + this.o5j_1.toString() + ', eventType=' + this.p5j_1 + ', userId=' + this.q5j_1 + ', anonymousId=' + this.r5j_1 + ', context=' + this.s5j_1 + ', screenName=' + this.t5j_1 + ', properties=' + this.u5j_1 + ')';
};
protoOf(ScreenEvent).hashCode = function () {
  var result = getStringHashCode(this.n5j_1);
  result = imul(result, 31) + this.o5j_1.hashCode() | 0;
  result = imul(result, 31) + getStringHashCode(this.p5j_1) | 0;
  result = imul(result, 31) + (this.q5j_1 == null ? 0 : getStringHashCode(this.q5j_1)) | 0;
  result = imul(result, 31) + (this.r5j_1 == null ? 0 : getStringHashCode(this.r5j_1)) | 0;
  result = imul(result, 31) + this.s5j_1.hashCode() | 0;
  result = imul(result, 31) + getStringHashCode(this.t5j_1) | 0;
  result = imul(result, 31) + hashCode(this.u5j_1) | 0;
  return result;
};
protoOf(ScreenEvent).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof ScreenEvent))
    return false;
  var tmp0_other_with_cast = other instanceof ScreenEvent ? other : THROW_CCE();
  if (!(this.n5j_1 === tmp0_other_with_cast.n5j_1))
    return false;
  if (!this.o5j_1.equals(tmp0_other_with_cast.o5j_1))
    return false;
  if (!(this.p5j_1 === tmp0_other_with_cast.p5j_1))
    return false;
  if (!(this.q5j_1 == tmp0_other_with_cast.q5j_1))
    return false;
  if (!(this.r5j_1 == tmp0_other_with_cast.r5j_1))
    return false;
  if (!this.s5j_1.equals(tmp0_other_with_cast.s5j_1))
    return false;
  if (!(this.t5j_1 === tmp0_other_with_cast.t5j_1))
    return false;
  if (!equals(this.u5j_1, tmp0_other_with_cast.u5j_1))
    return false;
  return true;
};
function Companion_6() {
  Companion_instance_9 = this;
  var tmp = this;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  tmp.v5j_1 = [null, null, null, null, null, null, new LinkedHashMapSerializer(StringSerializer_getInstance(), AnyValueSerializer_getInstance())];
}
var Companion_instance_9;
function Companion_getInstance_12() {
  if (Companion_instance_9 == null)
    new Companion_6();
  return Companion_instance_9;
}
function $serializer_4() {
  $serializer_instance_4 = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('com.exacaster.analytics.models.IdentifyEvent', this, 7);
  tmp0_serialDesc.w41('eventId', false);
  tmp0_serialDesc.w41('timestamp', false);
  tmp0_serialDesc.w41('eventType', true);
  tmp0_serialDesc.w41('userId', false);
  tmp0_serialDesc.w41('anonymousId', true);
  tmp0_serialDesc.w41('context', false);
  tmp0_serialDesc.w41('properties', true);
  this.w5j_1 = tmp0_serialDesc;
}
protoOf($serializer_4).z3q = function () {
  return this.w5j_1;
};
protoOf($serializer_4).l42 = function () {
  var tmp0_cached = Companion_getInstance_12().v5j_1;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [StringSerializer_getInstance(), LongSerializer_getInstance(), StringSerializer_getInstance(), StringSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), $serializer_getInstance_5(), tmp0_cached[6]];
};
protoOf($serializer_4).n3r = function (decoder) {
  var tmp0_desc = this.w5j_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = null;
  var tmp5_local1 = new Long(0, 0);
  var tmp6_local2 = null;
  var tmp7_local3 = null;
  var tmp8_local4 = null;
  var tmp9_local5 = null;
  var tmp10_local6 = null;
  var tmp11_input = decoder.m3u(tmp0_desc);
  var tmp12_cached = Companion_getInstance_12().v5j_1;
  if (tmp11_input.b3v()) {
    tmp4_local0 = tmp11_input.w3u(tmp0_desc, 0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp11_input.s3u(tmp0_desc, 1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
    tmp6_local2 = tmp11_input.w3u(tmp0_desc, 2);
    tmp3_bitMask0 = tmp3_bitMask0 | 4;
    tmp7_local3 = tmp11_input.w3u(tmp0_desc, 3);
    tmp3_bitMask0 = tmp3_bitMask0 | 8;
    tmp8_local4 = tmp11_input.a3v(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
    tmp3_bitMask0 = tmp3_bitMask0 | 16;
    tmp9_local5 = tmp11_input.y3u(tmp0_desc, 5, $serializer_getInstance_5(), tmp9_local5);
    tmp3_bitMask0 = tmp3_bitMask0 | 32;
    tmp10_local6 = tmp11_input.y3u(tmp0_desc, 6, tmp12_cached[6], tmp10_local6);
    tmp3_bitMask0 = tmp3_bitMask0 | 64;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp11_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp11_input.w3u(tmp0_desc, 0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp11_input.s3u(tmp0_desc, 1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        case 2:
          tmp6_local2 = tmp11_input.w3u(tmp0_desc, 2);
          tmp3_bitMask0 = tmp3_bitMask0 | 4;
          break;
        case 3:
          tmp7_local3 = tmp11_input.w3u(tmp0_desc, 3);
          tmp3_bitMask0 = tmp3_bitMask0 | 8;
          break;
        case 4:
          tmp8_local4 = tmp11_input.a3v(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
          tmp3_bitMask0 = tmp3_bitMask0 | 16;
          break;
        case 5:
          tmp9_local5 = tmp11_input.y3u(tmp0_desc, 5, $serializer_getInstance_5(), tmp9_local5);
          tmp3_bitMask0 = tmp3_bitMask0 | 32;
          break;
        case 6:
          tmp10_local6 = tmp11_input.y3u(tmp0_desc, 6, tmp12_cached[6], tmp10_local6);
          tmp3_bitMask0 = tmp3_bitMask0 | 64;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp11_input.n3u(tmp0_desc);
  return IdentifyEvent_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, null);
};
protoOf($serializer_4).x5j = function (encoder, value) {
  var tmp0_desc = this.w5j_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  var tmp2_cached = Companion_getInstance_12().v5j_1;
  tmp1_output.a3w(tmp0_desc, 0, value.y5j_1);
  tmp1_output.w3v(tmp0_desc, 1, value.z5j_1);
  tmp1_output.a3w(tmp0_desc, 2, value.a5k_1);
  tmp1_output.a3w(tmp0_desc, 3, value.b5k_1);
  if (tmp1_output.h3w(tmp0_desc, 4) ? true : !(value.c5k_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 4, StringSerializer_getInstance(), value.c5k_1);
  }
  tmp1_output.c3w(tmp0_desc, 5, $serializer_getInstance_5(), value.d5k_1);
  if (tmp1_output.h3w(tmp0_desc, 6) ? true : !equals(value.e5k_1, emptyMap())) {
    tmp1_output.c3w(tmp0_desc, 6, tmp2_cached[6], value.e5k_1);
  }
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer_4).m3r = function (encoder, value) {
  return this.x5j(encoder, value instanceof IdentifyEvent ? value : THROW_CCE());
};
var $serializer_instance_4;
function $serializer_getInstance_4() {
  if ($serializer_instance_4 == null)
    new $serializer_4();
  return $serializer_instance_4;
}
function IdentifyEvent_init_$Init$(seen1, eventId, timestamp, eventType, userId, anonymousId, context, properties, serializationConstructorMarker, $this) {
  if (!(43 === (43 & seen1))) {
    throwMissingFieldException(seen1, 43, $serializer_getInstance_4().w5j_1);
  }
  $this.y5j_1 = eventId;
  $this.z5j_1 = timestamp;
  if (0 === (seen1 & 4))
    $this.a5k_1 = 'identify';
  else
    $this.a5k_1 = eventType;
  $this.b5k_1 = userId;
  if (0 === (seen1 & 16))
    $this.c5k_1 = null;
  else
    $this.c5k_1 = anonymousId;
  $this.d5k_1 = context;
  if (0 === (seen1 & 64))
    $this.e5k_1 = emptyMap();
  else
    $this.e5k_1 = properties;
  return $this;
}
function IdentifyEvent_init_$Create$(seen1, eventId, timestamp, eventType, userId, anonymousId, context, properties, serializationConstructorMarker) {
  return IdentifyEvent_init_$Init$(seen1, eventId, timestamp, eventType, userId, anonymousId, context, properties, serializationConstructorMarker, objectCreate(protoOf(IdentifyEvent)));
}
function IdentifyEvent(eventId, timestamp, eventType, userId, anonymousId, context, properties) {
  Companion_getInstance_12();
  eventType = eventType === VOID ? 'identify' : eventType;
  anonymousId = anonymousId === VOID ? null : anonymousId;
  properties = properties === VOID ? emptyMap() : properties;
  this.y5j_1 = eventId;
  this.z5j_1 = timestamp;
  this.a5k_1 = eventType;
  this.b5k_1 = userId;
  this.c5k_1 = anonymousId;
  this.d5k_1 = context;
  this.e5k_1 = properties;
}
protoOf(IdentifyEvent).n5i = function () {
  return this.y5j_1;
};
protoOf(IdentifyEvent).toString = function () {
  return 'IdentifyEvent(eventId=' + this.y5j_1 + ', timestamp=' + this.z5j_1.toString() + ', eventType=' + this.a5k_1 + ', userId=' + this.b5k_1 + ', anonymousId=' + this.c5k_1 + ', context=' + this.d5k_1 + ', properties=' + this.e5k_1 + ')';
};
protoOf(IdentifyEvent).hashCode = function () {
  var result = getStringHashCode(this.y5j_1);
  result = imul(result, 31) + this.z5j_1.hashCode() | 0;
  result = imul(result, 31) + getStringHashCode(this.a5k_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.b5k_1) | 0;
  result = imul(result, 31) + (this.c5k_1 == null ? 0 : getStringHashCode(this.c5k_1)) | 0;
  result = imul(result, 31) + this.d5k_1.hashCode() | 0;
  result = imul(result, 31) + hashCode(this.e5k_1) | 0;
  return result;
};
protoOf(IdentifyEvent).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof IdentifyEvent))
    return false;
  var tmp0_other_with_cast = other instanceof IdentifyEvent ? other : THROW_CCE();
  if (!(this.y5j_1 === tmp0_other_with_cast.y5j_1))
    return false;
  if (!this.z5j_1.equals(tmp0_other_with_cast.z5j_1))
    return false;
  if (!(this.a5k_1 === tmp0_other_with_cast.a5k_1))
    return false;
  if (!(this.b5k_1 === tmp0_other_with_cast.b5k_1))
    return false;
  if (!(this.c5k_1 == tmp0_other_with_cast.c5k_1))
    return false;
  if (!this.d5k_1.equals(tmp0_other_with_cast.d5k_1))
    return false;
  if (!equals(this.e5k_1, tmp0_other_with_cast.e5k_1))
    return false;
  return true;
};
function Companion_7() {
  Companion_instance_10 = this;
  var tmp = this;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  tmp.f5k_1 = [null, null, null, null, null, null, null, null, null, null, new LinkedHashMapSerializer(StringSerializer_getInstance(), AnyValueSerializer_getInstance())];
}
var Companion_instance_10;
function Companion_getInstance_13() {
  if (Companion_instance_10 == null)
    new Companion_7();
  return Companion_instance_10;
}
function $serializer_5() {
  $serializer_instance_5 = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('com.exacaster.analytics.models.EventContext', this, 11);
  tmp0_serialDesc.w41('app', false);
  tmp0_serialDesc.w41('device', false);
  tmp0_serialDesc.w41('network', true);
  tmp0_serialDesc.w41('location', true);
  tmp0_serialDesc.w41('screen', true);
  tmp0_serialDesc.w41('os', false);
  tmp0_serialDesc.w41('locale', false);
  tmp0_serialDesc.w41('timezone', false);
  tmp0_serialDesc.w41('userAgent', true);
  tmp0_serialDesc.w41('library', false);
  tmp0_serialDesc.w41('traits', true);
  this.g5k_1 = tmp0_serialDesc;
}
protoOf($serializer_5).z3q = function () {
  return this.g5k_1;
};
protoOf($serializer_5).l42 = function () {
  var tmp0_cached = Companion_getInstance_13().f5k_1;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [$serializer_getInstance_6(), $serializer_getInstance_7(), get_nullable($serializer_getInstance_8()), get_nullable($serializer_getInstance_9()), get_nullable($serializer_getInstance_10()), $serializer_getInstance_11(), StringSerializer_getInstance(), StringSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), $serializer_getInstance_12(), tmp0_cached[10]];
};
protoOf($serializer_5).n3r = function (decoder) {
  var tmp0_desc = this.g5k_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = null;
  var tmp5_local1 = null;
  var tmp6_local2 = null;
  var tmp7_local3 = null;
  var tmp8_local4 = null;
  var tmp9_local5 = null;
  var tmp10_local6 = null;
  var tmp11_local7 = null;
  var tmp12_local8 = null;
  var tmp13_local9 = null;
  var tmp14_local10 = null;
  var tmp15_input = decoder.m3u(tmp0_desc);
  var tmp16_cached = Companion_getInstance_13().f5k_1;
  if (tmp15_input.b3v()) {
    tmp4_local0 = tmp15_input.y3u(tmp0_desc, 0, $serializer_getInstance_6(), tmp4_local0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp15_input.y3u(tmp0_desc, 1, $serializer_getInstance_7(), tmp5_local1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
    tmp6_local2 = tmp15_input.a3v(tmp0_desc, 2, $serializer_getInstance_8(), tmp6_local2);
    tmp3_bitMask0 = tmp3_bitMask0 | 4;
    tmp7_local3 = tmp15_input.a3v(tmp0_desc, 3, $serializer_getInstance_9(), tmp7_local3);
    tmp3_bitMask0 = tmp3_bitMask0 | 8;
    tmp8_local4 = tmp15_input.a3v(tmp0_desc, 4, $serializer_getInstance_10(), tmp8_local4);
    tmp3_bitMask0 = tmp3_bitMask0 | 16;
    tmp9_local5 = tmp15_input.y3u(tmp0_desc, 5, $serializer_getInstance_11(), tmp9_local5);
    tmp3_bitMask0 = tmp3_bitMask0 | 32;
    tmp10_local6 = tmp15_input.w3u(tmp0_desc, 6);
    tmp3_bitMask0 = tmp3_bitMask0 | 64;
    tmp11_local7 = tmp15_input.w3u(tmp0_desc, 7);
    tmp3_bitMask0 = tmp3_bitMask0 | 128;
    tmp12_local8 = tmp15_input.a3v(tmp0_desc, 8, StringSerializer_getInstance(), tmp12_local8);
    tmp3_bitMask0 = tmp3_bitMask0 | 256;
    tmp13_local9 = tmp15_input.y3u(tmp0_desc, 9, $serializer_getInstance_12(), tmp13_local9);
    tmp3_bitMask0 = tmp3_bitMask0 | 512;
    tmp14_local10 = tmp15_input.y3u(tmp0_desc, 10, tmp16_cached[10], tmp14_local10);
    tmp3_bitMask0 = tmp3_bitMask0 | 1024;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp15_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp15_input.y3u(tmp0_desc, 0, $serializer_getInstance_6(), tmp4_local0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp15_input.y3u(tmp0_desc, 1, $serializer_getInstance_7(), tmp5_local1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        case 2:
          tmp6_local2 = tmp15_input.a3v(tmp0_desc, 2, $serializer_getInstance_8(), tmp6_local2);
          tmp3_bitMask0 = tmp3_bitMask0 | 4;
          break;
        case 3:
          tmp7_local3 = tmp15_input.a3v(tmp0_desc, 3, $serializer_getInstance_9(), tmp7_local3);
          tmp3_bitMask0 = tmp3_bitMask0 | 8;
          break;
        case 4:
          tmp8_local4 = tmp15_input.a3v(tmp0_desc, 4, $serializer_getInstance_10(), tmp8_local4);
          tmp3_bitMask0 = tmp3_bitMask0 | 16;
          break;
        case 5:
          tmp9_local5 = tmp15_input.y3u(tmp0_desc, 5, $serializer_getInstance_11(), tmp9_local5);
          tmp3_bitMask0 = tmp3_bitMask0 | 32;
          break;
        case 6:
          tmp10_local6 = tmp15_input.w3u(tmp0_desc, 6);
          tmp3_bitMask0 = tmp3_bitMask0 | 64;
          break;
        case 7:
          tmp11_local7 = tmp15_input.w3u(tmp0_desc, 7);
          tmp3_bitMask0 = tmp3_bitMask0 | 128;
          break;
        case 8:
          tmp12_local8 = tmp15_input.a3v(tmp0_desc, 8, StringSerializer_getInstance(), tmp12_local8);
          tmp3_bitMask0 = tmp3_bitMask0 | 256;
          break;
        case 9:
          tmp13_local9 = tmp15_input.y3u(tmp0_desc, 9, $serializer_getInstance_12(), tmp13_local9);
          tmp3_bitMask0 = tmp3_bitMask0 | 512;
          break;
        case 10:
          tmp14_local10 = tmp15_input.y3u(tmp0_desc, 10, tmp16_cached[10], tmp14_local10);
          tmp3_bitMask0 = tmp3_bitMask0 | 1024;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp15_input.n3u(tmp0_desc);
  return EventContext_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, tmp11_local7, tmp12_local8, tmp13_local9, tmp14_local10, null);
};
protoOf($serializer_5).h5k = function (encoder, value) {
  var tmp0_desc = this.g5k_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  var tmp2_cached = Companion_getInstance_13().f5k_1;
  tmp1_output.c3w(tmp0_desc, 0, $serializer_getInstance_6(), value.f5e_1);
  tmp1_output.c3w(tmp0_desc, 1, $serializer_getInstance_7(), value.g5e_1);
  if (tmp1_output.h3w(tmp0_desc, 2) ? true : !(value.h5e_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 2, $serializer_getInstance_8(), value.h5e_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 3) ? true : !(value.i5e_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 3, $serializer_getInstance_9(), value.i5e_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 4) ? true : !(value.j5e_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 4, $serializer_getInstance_10(), value.j5e_1);
  }
  tmp1_output.c3w(tmp0_desc, 5, $serializer_getInstance_11(), value.k5e_1);
  tmp1_output.a3w(tmp0_desc, 6, value.l5e_1);
  tmp1_output.a3w(tmp0_desc, 7, value.m5e_1);
  if (tmp1_output.h3w(tmp0_desc, 8) ? true : !(value.n5e_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 8, StringSerializer_getInstance(), value.n5e_1);
  }
  tmp1_output.c3w(tmp0_desc, 9, $serializer_getInstance_12(), value.o5e_1);
  if (tmp1_output.h3w(tmp0_desc, 10) ? true : !equals(value.p5e_1, emptyMap())) {
    tmp1_output.c3w(tmp0_desc, 10, tmp2_cached[10], value.p5e_1);
  }
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer_5).m3r = function (encoder, value) {
  return this.h5k(encoder, value instanceof EventContext ? value : THROW_CCE());
};
var $serializer_instance_5;
function $serializer_getInstance_5() {
  if ($serializer_instance_5 == null)
    new $serializer_5();
  return $serializer_instance_5;
}
function EventContext_init_$Init$(seen1, app, device, network, location, screen, os, locale, timezone, userAgent, library, traits, serializationConstructorMarker, $this) {
  if (!(739 === (739 & seen1))) {
    throwMissingFieldException(seen1, 739, $serializer_getInstance_5().g5k_1);
  }
  $this.f5e_1 = app;
  $this.g5e_1 = device;
  if (0 === (seen1 & 4))
    $this.h5e_1 = null;
  else
    $this.h5e_1 = network;
  if (0 === (seen1 & 8))
    $this.i5e_1 = null;
  else
    $this.i5e_1 = location;
  if (0 === (seen1 & 16))
    $this.j5e_1 = null;
  else
    $this.j5e_1 = screen;
  $this.k5e_1 = os;
  $this.l5e_1 = locale;
  $this.m5e_1 = timezone;
  if (0 === (seen1 & 256))
    $this.n5e_1 = null;
  else
    $this.n5e_1 = userAgent;
  $this.o5e_1 = library;
  if (0 === (seen1 & 1024))
    $this.p5e_1 = emptyMap();
  else
    $this.p5e_1 = traits;
  return $this;
}
function EventContext_init_$Create$(seen1, app, device, network, location, screen, os, locale, timezone, userAgent, library, traits, serializationConstructorMarker) {
  return EventContext_init_$Init$(seen1, app, device, network, location, screen, os, locale, timezone, userAgent, library, traits, serializationConstructorMarker, objectCreate(protoOf(EventContext)));
}
function EventContext(app, device, network, location, screen, os, locale, timezone, userAgent, library, traits) {
  Companion_getInstance_13();
  network = network === VOID ? null : network;
  location = location === VOID ? null : location;
  screen = screen === VOID ? null : screen;
  userAgent = userAgent === VOID ? null : userAgent;
  traits = traits === VOID ? emptyMap() : traits;
  this.f5e_1 = app;
  this.g5e_1 = device;
  this.h5e_1 = network;
  this.i5e_1 = location;
  this.j5e_1 = screen;
  this.k5e_1 = os;
  this.l5e_1 = locale;
  this.m5e_1 = timezone;
  this.n5e_1 = userAgent;
  this.o5e_1 = library;
  this.p5e_1 = traits;
}
protoOf(EventContext).i5k = function (app, device, network, location, screen, os, locale, timezone, userAgent, library, traits) {
  return new EventContext(app, device, network, location, screen, os, locale, timezone, userAgent, library, traits);
};
protoOf(EventContext).q5e = function (app, device, network, location, screen, os, locale, timezone, userAgent, library, traits, $super) {
  app = app === VOID ? this.f5e_1 : app;
  device = device === VOID ? this.g5e_1 : device;
  network = network === VOID ? this.h5e_1 : network;
  location = location === VOID ? this.i5e_1 : location;
  screen = screen === VOID ? this.j5e_1 : screen;
  os = os === VOID ? this.k5e_1 : os;
  locale = locale === VOID ? this.l5e_1 : locale;
  timezone = timezone === VOID ? this.m5e_1 : timezone;
  userAgent = userAgent === VOID ? this.n5e_1 : userAgent;
  library = library === VOID ? this.o5e_1 : library;
  traits = traits === VOID ? this.p5e_1 : traits;
  return $super === VOID ? this.i5k(app, device, network, location, screen, os, locale, timezone, userAgent, library, traits) : $super.i5k.call(this, app, device, network, location, screen, os, locale, timezone, userAgent, library, traits);
};
protoOf(EventContext).toString = function () {
  return 'EventContext(app=' + this.f5e_1 + ', device=' + this.g5e_1 + ', network=' + this.h5e_1 + ', location=' + this.i5e_1 + ', screen=' + this.j5e_1 + ', os=' + this.k5e_1 + ', locale=' + this.l5e_1 + ', timezone=' + this.m5e_1 + ', userAgent=' + this.n5e_1 + ', library=' + this.o5e_1 + ', traits=' + this.p5e_1 + ')';
};
protoOf(EventContext).hashCode = function () {
  var result = this.f5e_1.hashCode();
  result = imul(result, 31) + this.g5e_1.hashCode() | 0;
  result = imul(result, 31) + (this.h5e_1 == null ? 0 : this.h5e_1.hashCode()) | 0;
  result = imul(result, 31) + (this.i5e_1 == null ? 0 : this.i5e_1.hashCode()) | 0;
  result = imul(result, 31) + (this.j5e_1 == null ? 0 : this.j5e_1.hashCode()) | 0;
  result = imul(result, 31) + this.k5e_1.hashCode() | 0;
  result = imul(result, 31) + getStringHashCode(this.l5e_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.m5e_1) | 0;
  result = imul(result, 31) + (this.n5e_1 == null ? 0 : getStringHashCode(this.n5e_1)) | 0;
  result = imul(result, 31) + this.o5e_1.hashCode() | 0;
  result = imul(result, 31) + hashCode(this.p5e_1) | 0;
  return result;
};
protoOf(EventContext).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof EventContext))
    return false;
  var tmp0_other_with_cast = other instanceof EventContext ? other : THROW_CCE();
  if (!this.f5e_1.equals(tmp0_other_with_cast.f5e_1))
    return false;
  if (!this.g5e_1.equals(tmp0_other_with_cast.g5e_1))
    return false;
  if (!equals(this.h5e_1, tmp0_other_with_cast.h5e_1))
    return false;
  if (!equals(this.i5e_1, tmp0_other_with_cast.i5e_1))
    return false;
  if (!equals(this.j5e_1, tmp0_other_with_cast.j5e_1))
    return false;
  if (!this.k5e_1.equals(tmp0_other_with_cast.k5e_1))
    return false;
  if (!(this.l5e_1 === tmp0_other_with_cast.l5e_1))
    return false;
  if (!(this.m5e_1 === tmp0_other_with_cast.m5e_1))
    return false;
  if (!(this.n5e_1 == tmp0_other_with_cast.n5e_1))
    return false;
  if (!this.o5e_1.equals(tmp0_other_with_cast.o5e_1))
    return false;
  if (!equals(this.p5e_1, tmp0_other_with_cast.p5e_1))
    return false;
  return true;
};
function Companion_8() {
}
var Companion_instance_11;
function Companion_getInstance_14() {
  return Companion_instance_11;
}
function $serializer_6() {
  $serializer_instance_6 = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('com.exacaster.analytics.models.ApplicationInfo', this, 6);
  tmp0_serialDesc.w41('name', false);
  tmp0_serialDesc.w41('version', false);
  tmp0_serialDesc.w41('build', false);
  tmp0_serialDesc.w41('namespace', false);
  tmp0_serialDesc.w41('versionCode', true);
  tmp0_serialDesc.w41('environment', true);
  this.j5k_1 = tmp0_serialDesc;
}
protoOf($serializer_6).z3q = function () {
  return this.j5k_1;
};
protoOf($serializer_6).l42 = function () {
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [StringSerializer_getInstance(), StringSerializer_getInstance(), StringSerializer_getInstance(), StringSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), StringSerializer_getInstance()];
};
protoOf($serializer_6).n3r = function (decoder) {
  var tmp0_desc = this.j5k_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = null;
  var tmp5_local1 = null;
  var tmp6_local2 = null;
  var tmp7_local3 = null;
  var tmp8_local4 = null;
  var tmp9_local5 = null;
  var tmp10_input = decoder.m3u(tmp0_desc);
  if (tmp10_input.b3v()) {
    tmp4_local0 = tmp10_input.w3u(tmp0_desc, 0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp10_input.w3u(tmp0_desc, 1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
    tmp6_local2 = tmp10_input.w3u(tmp0_desc, 2);
    tmp3_bitMask0 = tmp3_bitMask0 | 4;
    tmp7_local3 = tmp10_input.w3u(tmp0_desc, 3);
    tmp3_bitMask0 = tmp3_bitMask0 | 8;
    tmp8_local4 = tmp10_input.a3v(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
    tmp3_bitMask0 = tmp3_bitMask0 | 16;
    tmp9_local5 = tmp10_input.w3u(tmp0_desc, 5);
    tmp3_bitMask0 = tmp3_bitMask0 | 32;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp10_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp10_input.w3u(tmp0_desc, 0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp10_input.w3u(tmp0_desc, 1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        case 2:
          tmp6_local2 = tmp10_input.w3u(tmp0_desc, 2);
          tmp3_bitMask0 = tmp3_bitMask0 | 4;
          break;
        case 3:
          tmp7_local3 = tmp10_input.w3u(tmp0_desc, 3);
          tmp3_bitMask0 = tmp3_bitMask0 | 8;
          break;
        case 4:
          tmp8_local4 = tmp10_input.a3v(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
          tmp3_bitMask0 = tmp3_bitMask0 | 16;
          break;
        case 5:
          tmp9_local5 = tmp10_input.w3u(tmp0_desc, 5);
          tmp3_bitMask0 = tmp3_bitMask0 | 32;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp10_input.n3u(tmp0_desc);
  return ApplicationInfo_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, null);
};
protoOf($serializer_6).k5k = function (encoder, value) {
  var tmp0_desc = this.j5k_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  tmp1_output.a3w(tmp0_desc, 0, value.l5k_1);
  tmp1_output.a3w(tmp0_desc, 1, value.m5k_1);
  tmp1_output.a3w(tmp0_desc, 2, value.n5k_1);
  tmp1_output.a3w(tmp0_desc, 3, value.o5k_1);
  if (tmp1_output.h3w(tmp0_desc, 4) ? true : !(value.p5k_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 4, StringSerializer_getInstance(), value.p5k_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 5) ? true : !(value.q5k_1 === 'production')) {
    tmp1_output.a3w(tmp0_desc, 5, value.q5k_1);
  }
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer_6).m3r = function (encoder, value) {
  return this.k5k(encoder, value instanceof ApplicationInfo ? value : THROW_CCE());
};
var $serializer_instance_6;
function $serializer_getInstance_6() {
  if ($serializer_instance_6 == null)
    new $serializer_6();
  return $serializer_instance_6;
}
function ApplicationInfo_init_$Init$(seen1, name, version, build, namespace, versionCode, environment, serializationConstructorMarker, $this) {
  if (!(15 === (15 & seen1))) {
    throwMissingFieldException(seen1, 15, $serializer_getInstance_6().j5k_1);
  }
  $this.l5k_1 = name;
  $this.m5k_1 = version;
  $this.n5k_1 = build;
  $this.o5k_1 = namespace;
  if (0 === (seen1 & 16))
    $this.p5k_1 = null;
  else
    $this.p5k_1 = versionCode;
  if (0 === (seen1 & 32))
    $this.q5k_1 = 'production';
  else
    $this.q5k_1 = environment;
  return $this;
}
function ApplicationInfo_init_$Create$(seen1, name, version, build, namespace, versionCode, environment, serializationConstructorMarker) {
  return ApplicationInfo_init_$Init$(seen1, name, version, build, namespace, versionCode, environment, serializationConstructorMarker, objectCreate(protoOf(ApplicationInfo)));
}
function ApplicationInfo(name, version, build, namespace, versionCode, environment) {
  versionCode = versionCode === VOID ? null : versionCode;
  environment = environment === VOID ? 'production' : environment;
  this.l5k_1 = name;
  this.m5k_1 = version;
  this.n5k_1 = build;
  this.o5k_1 = namespace;
  this.p5k_1 = versionCode;
  this.q5k_1 = environment;
}
protoOf(ApplicationInfo).toString = function () {
  return 'ApplicationInfo(name=' + this.l5k_1 + ', version=' + this.m5k_1 + ', build=' + this.n5k_1 + ', namespace=' + this.o5k_1 + ', versionCode=' + this.p5k_1 + ', environment=' + this.q5k_1 + ')';
};
protoOf(ApplicationInfo).hashCode = function () {
  var result = getStringHashCode(this.l5k_1);
  result = imul(result, 31) + getStringHashCode(this.m5k_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.n5k_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.o5k_1) | 0;
  result = imul(result, 31) + (this.p5k_1 == null ? 0 : getStringHashCode(this.p5k_1)) | 0;
  result = imul(result, 31) + getStringHashCode(this.q5k_1) | 0;
  return result;
};
protoOf(ApplicationInfo).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof ApplicationInfo))
    return false;
  var tmp0_other_with_cast = other instanceof ApplicationInfo ? other : THROW_CCE();
  if (!(this.l5k_1 === tmp0_other_with_cast.l5k_1))
    return false;
  if (!(this.m5k_1 === tmp0_other_with_cast.m5k_1))
    return false;
  if (!(this.n5k_1 === tmp0_other_with_cast.n5k_1))
    return false;
  if (!(this.o5k_1 === tmp0_other_with_cast.o5k_1))
    return false;
  if (!(this.p5k_1 == tmp0_other_with_cast.p5k_1))
    return false;
  if (!(this.q5k_1 === tmp0_other_with_cast.q5k_1))
    return false;
  return true;
};
function Companion_9() {
  Companion_instance_12 = this;
  var tmp = this;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  tmp.s5k_1 = [null, null, null, null, Companion_getInstance_16().u4i(), null, null, null, null, null, null];
}
var Companion_instance_12;
function Companion_getInstance_15() {
  if (Companion_instance_12 == null)
    new Companion_9();
  return Companion_instance_12;
}
function $serializer_7() {
  $serializer_instance_7 = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('com.exacaster.analytics.models.DeviceInfo', this, 11);
  tmp0_serialDesc.w41('id', false);
  tmp0_serialDesc.w41('manufacturer', false);
  tmp0_serialDesc.w41('model', false);
  tmp0_serialDesc.w41('name', true);
  tmp0_serialDesc.w41('type', false);
  tmp0_serialDesc.w41('advertisingId', true);
  tmp0_serialDesc.w41('adTrackingEnabled', true);
  tmp0_serialDesc.w41('attAuthorizationStatus', true);
  tmp0_serialDesc.w41('brand', true);
  tmp0_serialDesc.w41('product', true);
  tmp0_serialDesc.w41('isTablet', true);
  this.t5k_1 = tmp0_serialDesc;
}
protoOf($serializer_7).z3q = function () {
  return this.t5k_1;
};
protoOf($serializer_7).l42 = function () {
  var tmp0_cached = Companion_getInstance_15().s5k_1;
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [StringSerializer_getInstance(), StringSerializer_getInstance(), StringSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), tmp0_cached[4], get_nullable(StringSerializer_getInstance()), BooleanSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), BooleanSerializer_getInstance()];
};
protoOf($serializer_7).n3r = function (decoder) {
  var tmp0_desc = this.t5k_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = null;
  var tmp5_local1 = null;
  var tmp6_local2 = null;
  var tmp7_local3 = null;
  var tmp8_local4 = null;
  var tmp9_local5 = null;
  var tmp10_local6 = false;
  var tmp11_local7 = null;
  var tmp12_local8 = null;
  var tmp13_local9 = null;
  var tmp14_local10 = false;
  var tmp15_input = decoder.m3u(tmp0_desc);
  var tmp16_cached = Companion_getInstance_15().s5k_1;
  if (tmp15_input.b3v()) {
    tmp4_local0 = tmp15_input.w3u(tmp0_desc, 0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp15_input.w3u(tmp0_desc, 1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
    tmp6_local2 = tmp15_input.w3u(tmp0_desc, 2);
    tmp3_bitMask0 = tmp3_bitMask0 | 4;
    tmp7_local3 = tmp15_input.a3v(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
    tmp3_bitMask0 = tmp3_bitMask0 | 8;
    tmp8_local4 = tmp15_input.y3u(tmp0_desc, 4, tmp16_cached[4], tmp8_local4);
    tmp3_bitMask0 = tmp3_bitMask0 | 16;
    tmp9_local5 = tmp15_input.a3v(tmp0_desc, 5, StringSerializer_getInstance(), tmp9_local5);
    tmp3_bitMask0 = tmp3_bitMask0 | 32;
    tmp10_local6 = tmp15_input.o3u(tmp0_desc, 6);
    tmp3_bitMask0 = tmp3_bitMask0 | 64;
    tmp11_local7 = tmp15_input.a3v(tmp0_desc, 7, StringSerializer_getInstance(), tmp11_local7);
    tmp3_bitMask0 = tmp3_bitMask0 | 128;
    tmp12_local8 = tmp15_input.a3v(tmp0_desc, 8, StringSerializer_getInstance(), tmp12_local8);
    tmp3_bitMask0 = tmp3_bitMask0 | 256;
    tmp13_local9 = tmp15_input.a3v(tmp0_desc, 9, StringSerializer_getInstance(), tmp13_local9);
    tmp3_bitMask0 = tmp3_bitMask0 | 512;
    tmp14_local10 = tmp15_input.o3u(tmp0_desc, 10);
    tmp3_bitMask0 = tmp3_bitMask0 | 1024;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp15_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp15_input.w3u(tmp0_desc, 0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp15_input.w3u(tmp0_desc, 1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        case 2:
          tmp6_local2 = tmp15_input.w3u(tmp0_desc, 2);
          tmp3_bitMask0 = tmp3_bitMask0 | 4;
          break;
        case 3:
          tmp7_local3 = tmp15_input.a3v(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
          tmp3_bitMask0 = tmp3_bitMask0 | 8;
          break;
        case 4:
          tmp8_local4 = tmp15_input.y3u(tmp0_desc, 4, tmp16_cached[4], tmp8_local4);
          tmp3_bitMask0 = tmp3_bitMask0 | 16;
          break;
        case 5:
          tmp9_local5 = tmp15_input.a3v(tmp0_desc, 5, StringSerializer_getInstance(), tmp9_local5);
          tmp3_bitMask0 = tmp3_bitMask0 | 32;
          break;
        case 6:
          tmp10_local6 = tmp15_input.o3u(tmp0_desc, 6);
          tmp3_bitMask0 = tmp3_bitMask0 | 64;
          break;
        case 7:
          tmp11_local7 = tmp15_input.a3v(tmp0_desc, 7, StringSerializer_getInstance(), tmp11_local7);
          tmp3_bitMask0 = tmp3_bitMask0 | 128;
          break;
        case 8:
          tmp12_local8 = tmp15_input.a3v(tmp0_desc, 8, StringSerializer_getInstance(), tmp12_local8);
          tmp3_bitMask0 = tmp3_bitMask0 | 256;
          break;
        case 9:
          tmp13_local9 = tmp15_input.a3v(tmp0_desc, 9, StringSerializer_getInstance(), tmp13_local9);
          tmp3_bitMask0 = tmp3_bitMask0 | 512;
          break;
        case 10:
          tmp14_local10 = tmp15_input.o3u(tmp0_desc, 10);
          tmp3_bitMask0 = tmp3_bitMask0 | 1024;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp15_input.n3u(tmp0_desc);
  return DeviceInfo_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, tmp11_local7, tmp12_local8, tmp13_local9, tmp14_local10, null);
};
protoOf($serializer_7).u5k = function (encoder, value) {
  var tmp0_desc = this.t5k_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  var tmp2_cached = Companion_getInstance_15().s5k_1;
  tmp1_output.a3w(tmp0_desc, 0, value.v5k_1);
  tmp1_output.a3w(tmp0_desc, 1, value.w5k_1);
  tmp1_output.a3w(tmp0_desc, 2, value.x5k_1);
  if (tmp1_output.h3w(tmp0_desc, 3) ? true : !(value.y5k_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 3, StringSerializer_getInstance(), value.y5k_1);
  }
  tmp1_output.c3w(tmp0_desc, 4, tmp2_cached[4], value.z5k_1);
  if (tmp1_output.h3w(tmp0_desc, 5) ? true : !(value.a5l_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 5, StringSerializer_getInstance(), value.a5l_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 6) ? true : !(value.b5l_1 === false)) {
    tmp1_output.s3v(tmp0_desc, 6, value.b5l_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 7) ? true : !(value.c5l_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 7, StringSerializer_getInstance(), value.c5l_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 8) ? true : !(value.d5l_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 8, StringSerializer_getInstance(), value.d5l_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 9) ? true : !(value.e5l_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 9, StringSerializer_getInstance(), value.e5l_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 10) ? true : !(value.f5l_1 === false)) {
    tmp1_output.s3v(tmp0_desc, 10, value.f5l_1);
  }
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer_7).m3r = function (encoder, value) {
  return this.u5k(encoder, value instanceof DeviceInfo ? value : THROW_CCE());
};
var $serializer_instance_7;
function $serializer_getInstance_7() {
  if ($serializer_instance_7 == null)
    new $serializer_7();
  return $serializer_instance_7;
}
function DeviceInfo_init_$Init$(seen1, id, manufacturer, model, name, type, advertisingId, adTrackingEnabled, attAuthorizationStatus, brand, product, isTablet, serializationConstructorMarker, $this) {
  if (!(23 === (23 & seen1))) {
    throwMissingFieldException(seen1, 23, $serializer_getInstance_7().t5k_1);
  }
  $this.v5k_1 = id;
  $this.w5k_1 = manufacturer;
  $this.x5k_1 = model;
  if (0 === (seen1 & 8))
    $this.y5k_1 = null;
  else
    $this.y5k_1 = name;
  $this.z5k_1 = type;
  if (0 === (seen1 & 32))
    $this.a5l_1 = null;
  else
    $this.a5l_1 = advertisingId;
  if (0 === (seen1 & 64))
    $this.b5l_1 = false;
  else
    $this.b5l_1 = adTrackingEnabled;
  if (0 === (seen1 & 128))
    $this.c5l_1 = null;
  else
    $this.c5l_1 = attAuthorizationStatus;
  if (0 === (seen1 & 256))
    $this.d5l_1 = null;
  else
    $this.d5l_1 = brand;
  if (0 === (seen1 & 512))
    $this.e5l_1 = null;
  else
    $this.e5l_1 = product;
  if (0 === (seen1 & 1024))
    $this.f5l_1 = false;
  else
    $this.f5l_1 = isTablet;
  return $this;
}
function DeviceInfo_init_$Create$(seen1, id, manufacturer, model, name, type, advertisingId, adTrackingEnabled, attAuthorizationStatus, brand, product, isTablet, serializationConstructorMarker) {
  return DeviceInfo_init_$Init$(seen1, id, manufacturer, model, name, type, advertisingId, adTrackingEnabled, attAuthorizationStatus, brand, product, isTablet, serializationConstructorMarker, objectCreate(protoOf(DeviceInfo)));
}
function DeviceInfo(id, manufacturer, model, name, type, advertisingId, adTrackingEnabled, attAuthorizationStatus, brand, product, isTablet) {
  Companion_getInstance_15();
  name = name === VOID ? null : name;
  advertisingId = advertisingId === VOID ? null : advertisingId;
  adTrackingEnabled = adTrackingEnabled === VOID ? false : adTrackingEnabled;
  attAuthorizationStatus = attAuthorizationStatus === VOID ? null : attAuthorizationStatus;
  brand = brand === VOID ? null : brand;
  product = product === VOID ? null : product;
  isTablet = isTablet === VOID ? false : isTablet;
  this.v5k_1 = id;
  this.w5k_1 = manufacturer;
  this.x5k_1 = model;
  this.y5k_1 = name;
  this.z5k_1 = type;
  this.a5l_1 = advertisingId;
  this.b5l_1 = adTrackingEnabled;
  this.c5l_1 = attAuthorizationStatus;
  this.d5l_1 = brand;
  this.e5l_1 = product;
  this.f5l_1 = isTablet;
}
protoOf(DeviceInfo).toString = function () {
  return 'DeviceInfo(id=' + this.v5k_1 + ', manufacturer=' + this.w5k_1 + ', model=' + this.x5k_1 + ', name=' + this.y5k_1 + ', type=' + this.z5k_1 + ', advertisingId=' + this.a5l_1 + ', adTrackingEnabled=' + this.b5l_1 + ', attAuthorizationStatus=' + this.c5l_1 + ', brand=' + this.d5l_1 + ', product=' + this.e5l_1 + ', isTablet=' + this.f5l_1 + ')';
};
protoOf(DeviceInfo).hashCode = function () {
  var result = getStringHashCode(this.v5k_1);
  result = imul(result, 31) + getStringHashCode(this.w5k_1) | 0;
  result = imul(result, 31) + getStringHashCode(this.x5k_1) | 0;
  result = imul(result, 31) + (this.y5k_1 == null ? 0 : getStringHashCode(this.y5k_1)) | 0;
  result = imul(result, 31) + this.z5k_1.hashCode() | 0;
  result = imul(result, 31) + (this.a5l_1 == null ? 0 : getStringHashCode(this.a5l_1)) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.b5l_1) | 0;
  result = imul(result, 31) + (this.c5l_1 == null ? 0 : getStringHashCode(this.c5l_1)) | 0;
  result = imul(result, 31) + (this.d5l_1 == null ? 0 : getStringHashCode(this.d5l_1)) | 0;
  result = imul(result, 31) + (this.e5l_1 == null ? 0 : getStringHashCode(this.e5l_1)) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.f5l_1) | 0;
  return result;
};
protoOf(DeviceInfo).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof DeviceInfo))
    return false;
  var tmp0_other_with_cast = other instanceof DeviceInfo ? other : THROW_CCE();
  if (!(this.v5k_1 === tmp0_other_with_cast.v5k_1))
    return false;
  if (!(this.w5k_1 === tmp0_other_with_cast.w5k_1))
    return false;
  if (!(this.x5k_1 === tmp0_other_with_cast.x5k_1))
    return false;
  if (!(this.y5k_1 == tmp0_other_with_cast.y5k_1))
    return false;
  if (!this.z5k_1.equals(tmp0_other_with_cast.z5k_1))
    return false;
  if (!(this.a5l_1 == tmp0_other_with_cast.a5l_1))
    return false;
  if (!(this.b5l_1 === tmp0_other_with_cast.b5l_1))
    return false;
  if (!(this.c5l_1 == tmp0_other_with_cast.c5l_1))
    return false;
  if (!(this.d5l_1 == tmp0_other_with_cast.d5l_1))
    return false;
  if (!(this.e5l_1 == tmp0_other_with_cast.e5l_1))
    return false;
  if (!(this.f5l_1 === tmp0_other_with_cast.f5l_1))
    return false;
  return true;
};
function _get_$cachedSerializer__te6jhj_0($this) {
  return $this.r5k_1.l2();
}
function DeviceType$Companion$_anonymous__9nzmxr() {
  return createSimpleEnumSerializer('com.exacaster.analytics.models.DeviceType', values_0());
}
var DeviceType_ANDROID_instance;
var DeviceType_IOS_instance;
var DeviceType_WEB_instance;
var DeviceType_UNKNOWN_instance;
function Companion_10() {
  Companion_instance_13 = this;
  var tmp = this;
  var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
  tmp.r5k_1 = lazy(tmp_0, DeviceType$Companion$_anonymous__9nzmxr);
}
protoOf(Companion_10).u4i = function () {
  return _get_$cachedSerializer__te6jhj_0(this);
};
protoOf(Companion_10).w42 = function (typeParamsSerializers) {
  return this.u4i();
};
var Companion_instance_13;
function Companion_getInstance_16() {
  DeviceType_initEntries();
  if (Companion_instance_13 == null)
    new Companion_10();
  return Companion_instance_13;
}
function values_0() {
  return [DeviceType_ANDROID_getInstance(), DeviceType_IOS_getInstance(), DeviceType_WEB_getInstance(), DeviceType_UNKNOWN_getInstance()];
}
var DeviceType_entriesInitialized;
function DeviceType_initEntries() {
  if (DeviceType_entriesInitialized)
    return Unit_instance;
  DeviceType_entriesInitialized = true;
  DeviceType_ANDROID_instance = new DeviceType('ANDROID', 0);
  DeviceType_IOS_instance = new DeviceType('IOS', 1);
  DeviceType_WEB_instance = new DeviceType('WEB', 2);
  DeviceType_UNKNOWN_instance = new DeviceType('UNKNOWN', 3);
  Companion_getInstance_16();
}
function DeviceType(name, ordinal) {
  Enum.call(this, name, ordinal);
}
function Companion_11() {
}
var Companion_instance_14;
function Companion_getInstance_17() {
  return Companion_instance_14;
}
function $serializer_8() {
  $serializer_instance_8 = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('com.exacaster.analytics.models.NetworkInfo', this, 6);
  tmp0_serialDesc.w41('carrier', true);
  tmp0_serialDesc.w41('cellular', true);
  tmp0_serialDesc.w41('wifi', true);
  tmp0_serialDesc.w41('bluetooth', true);
  tmp0_serialDesc.w41('networkType', true);
  tmp0_serialDesc.w41('networkTechnology', true);
  this.g5l_1 = tmp0_serialDesc;
}
protoOf($serializer_8).z3q = function () {
  return this.g5l_1;
};
protoOf($serializer_8).l42 = function () {
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [get_nullable(StringSerializer_getInstance()), BooleanSerializer_getInstance(), BooleanSerializer_getInstance(), BooleanSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance())];
};
protoOf($serializer_8).n3r = function (decoder) {
  var tmp0_desc = this.g5l_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = null;
  var tmp5_local1 = false;
  var tmp6_local2 = false;
  var tmp7_local3 = false;
  var tmp8_local4 = null;
  var tmp9_local5 = null;
  var tmp10_input = decoder.m3u(tmp0_desc);
  if (tmp10_input.b3v()) {
    tmp4_local0 = tmp10_input.a3v(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp10_input.o3u(tmp0_desc, 1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
    tmp6_local2 = tmp10_input.o3u(tmp0_desc, 2);
    tmp3_bitMask0 = tmp3_bitMask0 | 4;
    tmp7_local3 = tmp10_input.o3u(tmp0_desc, 3);
    tmp3_bitMask0 = tmp3_bitMask0 | 8;
    tmp8_local4 = tmp10_input.a3v(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
    tmp3_bitMask0 = tmp3_bitMask0 | 16;
    tmp9_local5 = tmp10_input.a3v(tmp0_desc, 5, StringSerializer_getInstance(), tmp9_local5);
    tmp3_bitMask0 = tmp3_bitMask0 | 32;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp10_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp10_input.a3v(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp10_input.o3u(tmp0_desc, 1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        case 2:
          tmp6_local2 = tmp10_input.o3u(tmp0_desc, 2);
          tmp3_bitMask0 = tmp3_bitMask0 | 4;
          break;
        case 3:
          tmp7_local3 = tmp10_input.o3u(tmp0_desc, 3);
          tmp3_bitMask0 = tmp3_bitMask0 | 8;
          break;
        case 4:
          tmp8_local4 = tmp10_input.a3v(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
          tmp3_bitMask0 = tmp3_bitMask0 | 16;
          break;
        case 5:
          tmp9_local5 = tmp10_input.a3v(tmp0_desc, 5, StringSerializer_getInstance(), tmp9_local5);
          tmp3_bitMask0 = tmp3_bitMask0 | 32;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp10_input.n3u(tmp0_desc);
  return NetworkInfo_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, null);
};
protoOf($serializer_8).h5l = function (encoder, value) {
  var tmp0_desc = this.g5l_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  if (tmp1_output.h3w(tmp0_desc, 0) ? true : !(value.i5l_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 0, StringSerializer_getInstance(), value.i5l_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 1) ? true : !(value.j5l_1 === false)) {
    tmp1_output.s3v(tmp0_desc, 1, value.j5l_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 2) ? true : !(value.k5l_1 === false)) {
    tmp1_output.s3v(tmp0_desc, 2, value.k5l_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 3) ? true : !(value.l5l_1 === false)) {
    tmp1_output.s3v(tmp0_desc, 3, value.l5l_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 4) ? true : !(value.m5l_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 4, StringSerializer_getInstance(), value.m5l_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 5) ? true : !(value.n5l_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 5, StringSerializer_getInstance(), value.n5l_1);
  }
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer_8).m3r = function (encoder, value) {
  return this.h5l(encoder, value instanceof NetworkInfo ? value : THROW_CCE());
};
var $serializer_instance_8;
function $serializer_getInstance_8() {
  if ($serializer_instance_8 == null)
    new $serializer_8();
  return $serializer_instance_8;
}
function NetworkInfo_init_$Init$(seen1, carrier, cellular, wifi, bluetooth, networkType, networkTechnology, serializationConstructorMarker, $this) {
  if (!(0 === (0 & seen1))) {
    throwMissingFieldException(seen1, 0, $serializer_getInstance_8().g5l_1);
  }
  if (0 === (seen1 & 1))
    $this.i5l_1 = null;
  else
    $this.i5l_1 = carrier;
  if (0 === (seen1 & 2))
    $this.j5l_1 = false;
  else
    $this.j5l_1 = cellular;
  if (0 === (seen1 & 4))
    $this.k5l_1 = false;
  else
    $this.k5l_1 = wifi;
  if (0 === (seen1 & 8))
    $this.l5l_1 = false;
  else
    $this.l5l_1 = bluetooth;
  if (0 === (seen1 & 16))
    $this.m5l_1 = null;
  else
    $this.m5l_1 = networkType;
  if (0 === (seen1 & 32))
    $this.n5l_1 = null;
  else
    $this.n5l_1 = networkTechnology;
  return $this;
}
function NetworkInfo_init_$Create$(seen1, carrier, cellular, wifi, bluetooth, networkType, networkTechnology, serializationConstructorMarker) {
  return NetworkInfo_init_$Init$(seen1, carrier, cellular, wifi, bluetooth, networkType, networkTechnology, serializationConstructorMarker, objectCreate(protoOf(NetworkInfo)));
}
function NetworkInfo(carrier, cellular, wifi, bluetooth, networkType, networkTechnology) {
  carrier = carrier === VOID ? null : carrier;
  cellular = cellular === VOID ? false : cellular;
  wifi = wifi === VOID ? false : wifi;
  bluetooth = bluetooth === VOID ? false : bluetooth;
  networkType = networkType === VOID ? null : networkType;
  networkTechnology = networkTechnology === VOID ? null : networkTechnology;
  this.i5l_1 = carrier;
  this.j5l_1 = cellular;
  this.k5l_1 = wifi;
  this.l5l_1 = bluetooth;
  this.m5l_1 = networkType;
  this.n5l_1 = networkTechnology;
}
protoOf(NetworkInfo).toString = function () {
  return 'NetworkInfo(carrier=' + this.i5l_1 + ', cellular=' + this.j5l_1 + ', wifi=' + this.k5l_1 + ', bluetooth=' + this.l5l_1 + ', networkType=' + this.m5l_1 + ', networkTechnology=' + this.n5l_1 + ')';
};
protoOf(NetworkInfo).hashCode = function () {
  var result = this.i5l_1 == null ? 0 : getStringHashCode(this.i5l_1);
  result = imul(result, 31) + getBooleanHashCode(this.j5l_1) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.k5l_1) | 0;
  result = imul(result, 31) + getBooleanHashCode(this.l5l_1) | 0;
  result = imul(result, 31) + (this.m5l_1 == null ? 0 : getStringHashCode(this.m5l_1)) | 0;
  result = imul(result, 31) + (this.n5l_1 == null ? 0 : getStringHashCode(this.n5l_1)) | 0;
  return result;
};
protoOf(NetworkInfo).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof NetworkInfo))
    return false;
  var tmp0_other_with_cast = other instanceof NetworkInfo ? other : THROW_CCE();
  if (!(this.i5l_1 == tmp0_other_with_cast.i5l_1))
    return false;
  if (!(this.j5l_1 === tmp0_other_with_cast.j5l_1))
    return false;
  if (!(this.k5l_1 === tmp0_other_with_cast.k5l_1))
    return false;
  if (!(this.l5l_1 === tmp0_other_with_cast.l5l_1))
    return false;
  if (!(this.m5l_1 == tmp0_other_with_cast.m5l_1))
    return false;
  if (!(this.n5l_1 == tmp0_other_with_cast.n5l_1))
    return false;
  return true;
};
function Companion_12() {
}
var Companion_instance_15;
function Companion_getInstance_18() {
  return Companion_instance_15;
}
function $serializer_9() {
  $serializer_instance_9 = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('com.exacaster.analytics.models.LocationInfo', this, 8);
  tmp0_serialDesc.w41('latitude', false);
  tmp0_serialDesc.w41('longitude', false);
  tmp0_serialDesc.w41('accuracy', true);
  tmp0_serialDesc.w41('altitude', true);
  tmp0_serialDesc.w41('speed', true);
  tmp0_serialDesc.w41('city', true);
  tmp0_serialDesc.w41('country', true);
  tmp0_serialDesc.w41('region', true);
  this.o5l_1 = tmp0_serialDesc;
}
protoOf($serializer_9).z3q = function () {
  return this.o5l_1;
};
protoOf($serializer_9).l42 = function () {
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [DoubleSerializer_getInstance(), DoubleSerializer_getInstance(), get_nullable(DoubleSerializer_getInstance()), get_nullable(DoubleSerializer_getInstance()), get_nullable(DoubleSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance())];
};
protoOf($serializer_9).n3r = function (decoder) {
  var tmp0_desc = this.o5l_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = 0.0;
  var tmp5_local1 = 0.0;
  var tmp6_local2 = null;
  var tmp7_local3 = null;
  var tmp8_local4 = null;
  var tmp9_local5 = null;
  var tmp10_local6 = null;
  var tmp11_local7 = null;
  var tmp12_input = decoder.m3u(tmp0_desc);
  if (tmp12_input.b3v()) {
    tmp4_local0 = tmp12_input.u3u(tmp0_desc, 0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp12_input.u3u(tmp0_desc, 1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
    tmp6_local2 = tmp12_input.a3v(tmp0_desc, 2, DoubleSerializer_getInstance(), tmp6_local2);
    tmp3_bitMask0 = tmp3_bitMask0 | 4;
    tmp7_local3 = tmp12_input.a3v(tmp0_desc, 3, DoubleSerializer_getInstance(), tmp7_local3);
    tmp3_bitMask0 = tmp3_bitMask0 | 8;
    tmp8_local4 = tmp12_input.a3v(tmp0_desc, 4, DoubleSerializer_getInstance(), tmp8_local4);
    tmp3_bitMask0 = tmp3_bitMask0 | 16;
    tmp9_local5 = tmp12_input.a3v(tmp0_desc, 5, StringSerializer_getInstance(), tmp9_local5);
    tmp3_bitMask0 = tmp3_bitMask0 | 32;
    tmp10_local6 = tmp12_input.a3v(tmp0_desc, 6, StringSerializer_getInstance(), tmp10_local6);
    tmp3_bitMask0 = tmp3_bitMask0 | 64;
    tmp11_local7 = tmp12_input.a3v(tmp0_desc, 7, StringSerializer_getInstance(), tmp11_local7);
    tmp3_bitMask0 = tmp3_bitMask0 | 128;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp12_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp12_input.u3u(tmp0_desc, 0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp12_input.u3u(tmp0_desc, 1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        case 2:
          tmp6_local2 = tmp12_input.a3v(tmp0_desc, 2, DoubleSerializer_getInstance(), tmp6_local2);
          tmp3_bitMask0 = tmp3_bitMask0 | 4;
          break;
        case 3:
          tmp7_local3 = tmp12_input.a3v(tmp0_desc, 3, DoubleSerializer_getInstance(), tmp7_local3);
          tmp3_bitMask0 = tmp3_bitMask0 | 8;
          break;
        case 4:
          tmp8_local4 = tmp12_input.a3v(tmp0_desc, 4, DoubleSerializer_getInstance(), tmp8_local4);
          tmp3_bitMask0 = tmp3_bitMask0 | 16;
          break;
        case 5:
          tmp9_local5 = tmp12_input.a3v(tmp0_desc, 5, StringSerializer_getInstance(), tmp9_local5);
          tmp3_bitMask0 = tmp3_bitMask0 | 32;
          break;
        case 6:
          tmp10_local6 = tmp12_input.a3v(tmp0_desc, 6, StringSerializer_getInstance(), tmp10_local6);
          tmp3_bitMask0 = tmp3_bitMask0 | 64;
          break;
        case 7:
          tmp11_local7 = tmp12_input.a3v(tmp0_desc, 7, StringSerializer_getInstance(), tmp11_local7);
          tmp3_bitMask0 = tmp3_bitMask0 | 128;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp12_input.n3u(tmp0_desc);
  return LocationInfo_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, tmp11_local7, null);
};
protoOf($serializer_9).p5l = function (encoder, value) {
  var tmp0_desc = this.o5l_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  tmp1_output.y3v(tmp0_desc, 0, value.q5l_1);
  tmp1_output.y3v(tmp0_desc, 1, value.r5l_1);
  if (tmp1_output.h3w(tmp0_desc, 2) ? true : !(value.s5l_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 2, DoubleSerializer_getInstance(), value.s5l_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 3) ? true : !(value.t5l_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 3, DoubleSerializer_getInstance(), value.t5l_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 4) ? true : !(value.u5l_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 4, DoubleSerializer_getInstance(), value.u5l_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 5) ? true : !(value.v5l_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 5, StringSerializer_getInstance(), value.v5l_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 6) ? true : !(value.w5l_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 6, StringSerializer_getInstance(), value.w5l_1);
  }
  if (tmp1_output.h3w(tmp0_desc, 7) ? true : !(value.x5l_1 == null)) {
    tmp1_output.d3w(tmp0_desc, 7, StringSerializer_getInstance(), value.x5l_1);
  }
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer_9).m3r = function (encoder, value) {
  return this.p5l(encoder, value instanceof LocationInfo ? value : THROW_CCE());
};
var $serializer_instance_9;
function $serializer_getInstance_9() {
  if ($serializer_instance_9 == null)
    new $serializer_9();
  return $serializer_instance_9;
}
function LocationInfo_init_$Init$(seen1, latitude, longitude, accuracy, altitude, speed, city, country, region, serializationConstructorMarker, $this) {
  if (!(3 === (3 & seen1))) {
    throwMissingFieldException(seen1, 3, $serializer_getInstance_9().o5l_1);
  }
  $this.q5l_1 = latitude;
  $this.r5l_1 = longitude;
  if (0 === (seen1 & 4))
    $this.s5l_1 = null;
  else
    $this.s5l_1 = accuracy;
  if (0 === (seen1 & 8))
    $this.t5l_1 = null;
  else
    $this.t5l_1 = altitude;
  if (0 === (seen1 & 16))
    $this.u5l_1 = null;
  else
    $this.u5l_1 = speed;
  if (0 === (seen1 & 32))
    $this.v5l_1 = null;
  else
    $this.v5l_1 = city;
  if (0 === (seen1 & 64))
    $this.w5l_1 = null;
  else
    $this.w5l_1 = country;
  if (0 === (seen1 & 128))
    $this.x5l_1 = null;
  else
    $this.x5l_1 = region;
  return $this;
}
function LocationInfo_init_$Create$(seen1, latitude, longitude, accuracy, altitude, speed, city, country, region, serializationConstructorMarker) {
  return LocationInfo_init_$Init$(seen1, latitude, longitude, accuracy, altitude, speed, city, country, region, serializationConstructorMarker, objectCreate(protoOf(LocationInfo)));
}
function LocationInfo(latitude, longitude, accuracy, altitude, speed, city, country, region) {
  accuracy = accuracy === VOID ? null : accuracy;
  altitude = altitude === VOID ? null : altitude;
  speed = speed === VOID ? null : speed;
  city = city === VOID ? null : city;
  country = country === VOID ? null : country;
  region = region === VOID ? null : region;
  this.q5l_1 = latitude;
  this.r5l_1 = longitude;
  this.s5l_1 = accuracy;
  this.t5l_1 = altitude;
  this.u5l_1 = speed;
  this.v5l_1 = city;
  this.w5l_1 = country;
  this.x5l_1 = region;
}
protoOf(LocationInfo).toString = function () {
  return 'LocationInfo(latitude=' + this.q5l_1 + ', longitude=' + this.r5l_1 + ', accuracy=' + this.s5l_1 + ', altitude=' + this.t5l_1 + ', speed=' + this.u5l_1 + ', city=' + this.v5l_1 + ', country=' + this.w5l_1 + ', region=' + this.x5l_1 + ')';
};
protoOf(LocationInfo).hashCode = function () {
  var result = getNumberHashCode(this.q5l_1);
  result = imul(result, 31) + getNumberHashCode(this.r5l_1) | 0;
  result = imul(result, 31) + (this.s5l_1 == null ? 0 : getNumberHashCode(this.s5l_1)) | 0;
  result = imul(result, 31) + (this.t5l_1 == null ? 0 : getNumberHashCode(this.t5l_1)) | 0;
  result = imul(result, 31) + (this.u5l_1 == null ? 0 : getNumberHashCode(this.u5l_1)) | 0;
  result = imul(result, 31) + (this.v5l_1 == null ? 0 : getStringHashCode(this.v5l_1)) | 0;
  result = imul(result, 31) + (this.w5l_1 == null ? 0 : getStringHashCode(this.w5l_1)) | 0;
  result = imul(result, 31) + (this.x5l_1 == null ? 0 : getStringHashCode(this.x5l_1)) | 0;
  return result;
};
protoOf(LocationInfo).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof LocationInfo))
    return false;
  var tmp0_other_with_cast = other instanceof LocationInfo ? other : THROW_CCE();
  if (!equals(this.q5l_1, tmp0_other_with_cast.q5l_1))
    return false;
  if (!equals(this.r5l_1, tmp0_other_with_cast.r5l_1))
    return false;
  if (!equals(this.s5l_1, tmp0_other_with_cast.s5l_1))
    return false;
  if (!equals(this.t5l_1, tmp0_other_with_cast.t5l_1))
    return false;
  if (!equals(this.u5l_1, tmp0_other_with_cast.u5l_1))
    return false;
  if (!(this.v5l_1 == tmp0_other_with_cast.v5l_1))
    return false;
  if (!(this.w5l_1 == tmp0_other_with_cast.w5l_1))
    return false;
  if (!(this.x5l_1 == tmp0_other_with_cast.x5l_1))
    return false;
  return true;
};
function Companion_13() {
}
var Companion_instance_16;
function Companion_getInstance_19() {
  return Companion_instance_16;
}
function $serializer_10() {
  $serializer_instance_10 = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('com.exacaster.analytics.models.ScreenInfo', this, 3);
  tmp0_serialDesc.w41('width', false);
  tmp0_serialDesc.w41('height', false);
  tmp0_serialDesc.w41('density', false);
  this.y5l_1 = tmp0_serialDesc;
}
protoOf($serializer_10).z3q = function () {
  return this.y5l_1;
};
protoOf($serializer_10).l42 = function () {
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [IntSerializer_getInstance(), IntSerializer_getInstance(), FloatSerializer_getInstance()];
};
protoOf($serializer_10).n3r = function (decoder) {
  var tmp0_desc = this.y5l_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = 0;
  var tmp5_local1 = 0;
  var tmp6_local2 = 0.0;
  var tmp7_input = decoder.m3u(tmp0_desc);
  if (tmp7_input.b3v()) {
    tmp4_local0 = tmp7_input.r3u(tmp0_desc, 0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp7_input.r3u(tmp0_desc, 1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
    tmp6_local2 = tmp7_input.t3u(tmp0_desc, 2);
    tmp3_bitMask0 = tmp3_bitMask0 | 4;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp7_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp7_input.r3u(tmp0_desc, 0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp7_input.r3u(tmp0_desc, 1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        case 2:
          tmp6_local2 = tmp7_input.t3u(tmp0_desc, 2);
          tmp3_bitMask0 = tmp3_bitMask0 | 4;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp7_input.n3u(tmp0_desc);
  return ScreenInfo_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
};
protoOf($serializer_10).z5l = function (encoder, value) {
  var tmp0_desc = this.y5l_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  tmp1_output.v3v(tmp0_desc, 0, value.a5m_1);
  tmp1_output.v3v(tmp0_desc, 1, value.b5m_1);
  tmp1_output.x3v(tmp0_desc, 2, value.c5m_1);
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer_10).m3r = function (encoder, value) {
  return this.z5l(encoder, value instanceof ScreenInfo ? value : THROW_CCE());
};
var $serializer_instance_10;
function $serializer_getInstance_10() {
  if ($serializer_instance_10 == null)
    new $serializer_10();
  return $serializer_instance_10;
}
function ScreenInfo_init_$Init$(seen1, width, height, density, serializationConstructorMarker, $this) {
  if (!(7 === (7 & seen1))) {
    throwMissingFieldException(seen1, 7, $serializer_getInstance_10().y5l_1);
  }
  $this.a5m_1 = width;
  $this.b5m_1 = height;
  $this.c5m_1 = density;
  return $this;
}
function ScreenInfo_init_$Create$(seen1, width, height, density, serializationConstructorMarker) {
  return ScreenInfo_init_$Init$(seen1, width, height, density, serializationConstructorMarker, objectCreate(protoOf(ScreenInfo)));
}
function ScreenInfo(width, height, density) {
  this.a5m_1 = width;
  this.b5m_1 = height;
  this.c5m_1 = density;
}
protoOf(ScreenInfo).toString = function () {
  return 'ScreenInfo(width=' + this.a5m_1 + ', height=' + this.b5m_1 + ', density=' + this.c5m_1 + ')';
};
protoOf(ScreenInfo).hashCode = function () {
  var result = this.a5m_1;
  result = imul(result, 31) + this.b5m_1 | 0;
  result = imul(result, 31) + getNumberHashCode(this.c5m_1) | 0;
  return result;
};
protoOf(ScreenInfo).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof ScreenInfo))
    return false;
  var tmp0_other_with_cast = other instanceof ScreenInfo ? other : THROW_CCE();
  if (!(this.a5m_1 === tmp0_other_with_cast.a5m_1))
    return false;
  if (!(this.b5m_1 === tmp0_other_with_cast.b5m_1))
    return false;
  if (!equals(this.c5m_1, tmp0_other_with_cast.c5m_1))
    return false;
  return true;
};
function Companion_14() {
}
var Companion_instance_17;
function Companion_getInstance_20() {
  return Companion_instance_17;
}
function $serializer_11() {
  $serializer_instance_11 = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('com.exacaster.analytics.models.OSInfo', this, 2);
  tmp0_serialDesc.w41('name', false);
  tmp0_serialDesc.w41('version', false);
  this.d5m_1 = tmp0_serialDesc;
}
protoOf($serializer_11).z3q = function () {
  return this.d5m_1;
};
protoOf($serializer_11).l42 = function () {
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [StringSerializer_getInstance(), StringSerializer_getInstance()];
};
protoOf($serializer_11).n3r = function (decoder) {
  var tmp0_desc = this.d5m_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = null;
  var tmp5_local1 = null;
  var tmp6_input = decoder.m3u(tmp0_desc);
  if (tmp6_input.b3v()) {
    tmp4_local0 = tmp6_input.w3u(tmp0_desc, 0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp6_input.w3u(tmp0_desc, 1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp6_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp6_input.w3u(tmp0_desc, 0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp6_input.w3u(tmp0_desc, 1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp6_input.n3u(tmp0_desc);
  return OSInfo_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
};
protoOf($serializer_11).e5m = function (encoder, value) {
  var tmp0_desc = this.d5m_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  tmp1_output.a3w(tmp0_desc, 0, value.f5m_1);
  tmp1_output.a3w(tmp0_desc, 1, value.g5m_1);
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer_11).m3r = function (encoder, value) {
  return this.e5m(encoder, value instanceof OSInfo ? value : THROW_CCE());
};
var $serializer_instance_11;
function $serializer_getInstance_11() {
  if ($serializer_instance_11 == null)
    new $serializer_11();
  return $serializer_instance_11;
}
function OSInfo_init_$Init$(seen1, name, version, serializationConstructorMarker, $this) {
  if (!(3 === (3 & seen1))) {
    throwMissingFieldException(seen1, 3, $serializer_getInstance_11().d5m_1);
  }
  $this.f5m_1 = name;
  $this.g5m_1 = version;
  return $this;
}
function OSInfo_init_$Create$(seen1, name, version, serializationConstructorMarker) {
  return OSInfo_init_$Init$(seen1, name, version, serializationConstructorMarker, objectCreate(protoOf(OSInfo)));
}
function OSInfo(name, version) {
  this.f5m_1 = name;
  this.g5m_1 = version;
}
protoOf(OSInfo).toString = function () {
  return 'OSInfo(name=' + this.f5m_1 + ', version=' + this.g5m_1 + ')';
};
protoOf(OSInfo).hashCode = function () {
  var result = getStringHashCode(this.f5m_1);
  result = imul(result, 31) + getStringHashCode(this.g5m_1) | 0;
  return result;
};
protoOf(OSInfo).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof OSInfo))
    return false;
  var tmp0_other_with_cast = other instanceof OSInfo ? other : THROW_CCE();
  if (!(this.f5m_1 === tmp0_other_with_cast.f5m_1))
    return false;
  if (!(this.g5m_1 === tmp0_other_with_cast.g5m_1))
    return false;
  return true;
};
function Companion_15() {
}
var Companion_instance_18;
function Companion_getInstance_21() {
  return Companion_instance_18;
}
function $serializer_12() {
  $serializer_instance_12 = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('com.exacaster.analytics.models.LibraryInfo', this, 2);
  tmp0_serialDesc.w41('name', true);
  tmp0_serialDesc.w41('version', false);
  this.h5m_1 = tmp0_serialDesc;
}
protoOf($serializer_12).z3q = function () {
  return this.h5m_1;
};
protoOf($serializer_12).l42 = function () {
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [StringSerializer_getInstance(), StringSerializer_getInstance()];
};
protoOf($serializer_12).n3r = function (decoder) {
  var tmp0_desc = this.h5m_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = null;
  var tmp5_local1 = null;
  var tmp6_input = decoder.m3u(tmp0_desc);
  if (tmp6_input.b3v()) {
    tmp4_local0 = tmp6_input.w3u(tmp0_desc, 0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp6_input.w3u(tmp0_desc, 1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp6_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp6_input.w3u(tmp0_desc, 0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp6_input.w3u(tmp0_desc, 1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp6_input.n3u(tmp0_desc);
  return LibraryInfo_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
};
protoOf($serializer_12).i5m = function (encoder, value) {
  var tmp0_desc = this.h5m_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  if (tmp1_output.h3w(tmp0_desc, 0) ? true : !(value.j5m_1 === 'exacaster-analytics')) {
    tmp1_output.a3w(tmp0_desc, 0, value.j5m_1);
  }
  tmp1_output.a3w(tmp0_desc, 1, value.k5m_1);
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer_12).m3r = function (encoder, value) {
  return this.i5m(encoder, value instanceof LibraryInfo ? value : THROW_CCE());
};
var $serializer_instance_12;
function $serializer_getInstance_12() {
  if ($serializer_instance_12 == null)
    new $serializer_12();
  return $serializer_instance_12;
}
function LibraryInfo_init_$Init$(seen1, name, version, serializationConstructorMarker, $this) {
  if (!(2 === (2 & seen1))) {
    throwMissingFieldException(seen1, 2, $serializer_getInstance_12().h5m_1);
  }
  if (0 === (seen1 & 1))
    $this.j5m_1 = 'exacaster-analytics';
  else
    $this.j5m_1 = name;
  $this.k5m_1 = version;
  return $this;
}
function LibraryInfo_init_$Create$(seen1, name, version, serializationConstructorMarker) {
  return LibraryInfo_init_$Init$(seen1, name, version, serializationConstructorMarker, objectCreate(protoOf(LibraryInfo)));
}
function LibraryInfo(name, version) {
  name = name === VOID ? 'exacaster-analytics' : name;
  this.j5m_1 = name;
  this.k5m_1 = version;
}
protoOf(LibraryInfo).toString = function () {
  return 'LibraryInfo(name=' + this.j5m_1 + ', version=' + this.k5m_1 + ')';
};
protoOf(LibraryInfo).hashCode = function () {
  var result = getStringHashCode(this.j5m_1);
  result = imul(result, 31) + getStringHashCode(this.k5m_1) | 0;
  return result;
};
protoOf(LibraryInfo).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof LibraryInfo))
    return false;
  var tmp0_other_with_cast = other instanceof LibraryInfo ? other : THROW_CCE();
  if (!(this.j5m_1 === tmp0_other_with_cast.j5m_1))
    return false;
  if (!(this.k5m_1 === tmp0_other_with_cast.k5m_1))
    return false;
  return true;
};
function DeviceType_ANDROID_getInstance() {
  DeviceType_initEntries();
  return DeviceType_ANDROID_instance;
}
function DeviceType_IOS_getInstance() {
  DeviceType_initEntries();
  return DeviceType_IOS_instance;
}
function DeviceType_WEB_getInstance() {
  DeviceType_initEntries();
  return DeviceType_WEB_instance;
}
function DeviceType_UNKNOWN_getInstance() {
  DeviceType_initEntries();
  return DeviceType_UNKNOWN_instance;
}
function uploadAdaptive($this, events, batchId, $completion) {
  var tmp = new $uploadAdaptiveCOROUTINE$7($this, events, batchId, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function uploadSplit($this, events, batchId, $completion) {
  var tmp = new $uploadSplitCOROUTINE$8($this, events, batchId, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function uploadRaw($this, events, batchId, $completion) {
  var tmp = new $uploadRawCOROUTINE$9($this, events, batchId, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function shouldSplitBySize($this, events) {
  if (events.n() <= 1) {
    return false;
  }
  var payloadSizeBytes = encodeToByteArray($this.l5o_1.g3s(Companion_instance_1.u4i(), serializeEvents($this, events))).length;
  if (payloadSizeBytes > $this.m5o_1) {
    $this.i5o_1.m5d('Payload size ' + payloadSizeBytes + ' bytes exceeds limit ' + $this.m5o_1 + '. Splitting batch of ' + events.n() + ' events.');
    return true;
  }
  return false;
}
function uploadWithEncryption($this, events, batchId, isRetry, $completion) {
  var tmp = new $uploadWithEncryptionCOROUTINE$10($this, events, batchId, isRetry, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function uploadWithEncryption$default($this, events, batchId, isRetry, $completion, $super) {
  isRetry = isRetry === VOID ? false : isRetry;
  return uploadWithEncryption($this, events, batchId, isRetry, $completion);
}
function fetchAndCacheJwks($this, $completion) {
  var tmp = new $fetchAndCacheJwksCOROUTINE$11($this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function serializeEvents($this, events) {
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(events, 10));
  var tmp0_iterator = events.u();
  while (tmp0_iterator.v()) {
    var item = tmp0_iterator.w();
    // Inline function 'com.exacaster.analytics.network.EventUploader.serializeEvents.<anonymous>' call
    var tmp = $this.l5o_1.w4g(item.t5p_1);
    var tmp$ret$0 = tmp instanceof JsonObject ? tmp : THROW_CCE();
    destination.r(tmp$ret$0);
  }
  var eventDataList = destination;
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  // Inline function 'kotlin.contracts.contract' call
  var builder = new JsonObjectBuilder();
  // Inline function 'com.exacaster.analytics.network.EventUploader.serializeEvents.<anonymous>' call
  // Inline function 'kotlinx.serialization.json.encodeToJsonElement' call
  var this_0 = $this.l5o_1;
  // Inline function 'kotlinx.serialization.serializer' call
  var this_1 = this_0.k3r();
  // Inline function 'kotlinx.serialization.internal.cast' call
  var this_2 = serializer(this_1, createKType(getKClass(List), arrayOf([createInvariantKTypeProjection(createKType(getKClass(JsonObject), arrayOf([]), false))]), false));
  var tmp$ret$4 = isInterface(this_2, KSerializer) ? this_2 : THROW_CCE();
  var tmp$ret$5 = this_0.v4g(tmp$ret$4, eventDataList);
  builder.i4j('events', tmp$ret$5);
  return builder.l1i();
}
function handleSuccess($this, events, uploadedCount, $completion) {
  var tmp = new $handleSuccessCOROUTINE$12($this, events, uploadedCount, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function handleRetryableError($this, events, error, $completion) {
  var tmp = new $handleRetryableErrorCOROUTINE$13($this, events, error, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function handlePermanentError($this, events, error, $completion) {
  var tmp = new $handlePermanentErrorCOROUTINE$14($this, events, error, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function EventUploader$json$lambda($this$Json) {
  $this$Json.n4h_1 = true;
  $this$Json.l4h_1 = true;
  return Unit_instance;
}
function $uploadBatchCOROUTINE$6(_this__u8e3s4, events, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.o5r_1 = _this__u8e3s4;
  this.p5r_1 = events;
}
protoOf($uploadBatchCOROUTINE$6).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 4;
          if (this.p5r_1.b1()) {
            this.o5r_1.i5o_1.n56('No events to upload');
            return new Success(0);
          }

          var tmp_0 = this;
          var this_0 = this.p5r_1;
          var destination = ArrayList_init_$Create$();
          var tmp0_iterator = this_0.u();
          while (tmp0_iterator.v()) {
            var element = tmp0_iterator.w();
            if (element.u5p_1.o6(toLong_0(this.o5r_1.h5o_1.x57_1.z58())) < 0) {
              destination.r(element);
            }
          }

          tmp_0.q5r_1 = destination;
          this.r5r_1 = this.p5r_1.n() - this.q5r_1.n() | 0;
          if (this.r5r_1 > 0) {
            this.o5r_1.i5o_1.m5d('' + this.r5r_1 + ' events were discarded for exceeding max retries.');
            this.ic_1 = 1;
            var this_1 = this.p5r_1;
            var destination_0 = ArrayList_init_$Create$();
            var tmp0_iterator_0 = this_1.u();
            while (tmp0_iterator_0.v()) {
              var element_0 = tmp0_iterator_0.w();
              if (element_0.u5p_1.o6(toLong_0(this.o5r_1.h5o_1.x57_1.z58())) >= 0) {
                destination_0.r(element_0);
              }
            }
            var destination_1 = ArrayList_init_$Create$_0(collectionSizeOrDefault(destination_0, 10));
            var tmp0_iterator_1 = destination_0.u();
            while (tmp0_iterator_1.v()) {
              var item = tmp0_iterator_1.w();
              destination_1.r(item.s5p_1);
            }
            suspendResult = this.o5r_1.g5o_1.t5r(destination_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 2;
            continue $sm;
          }

        case 1:
          this.ic_1 = 2;
          continue $sm;
        case 2:
          if (this.q5r_1.b1())
            return new Success(0);
          this.s5r_1 = BatchIdGenerator_instance.v5r();
          this.ic_1 = 3;
          suspendResult = uploadAdaptive(this.o5r_1, this.q5r_1, this.s5r_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 3:
          return suspendResult;
        case 4:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 4) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $uploadAdaptiveCOROUTINE$7(_this__u8e3s4, events, batchId, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.t5m_1 = _this__u8e3s4;
  this.u5m_1 = events;
  this.v5m_1 = batchId;
}
protoOf($uploadAdaptiveCOROUTINE$7).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 10;
          if (this.u5m_1.b1()) {
            return new Success(0);
          }

          if (shouldSplitBySize(this.t5m_1, this.u5m_1)) {
            this.ic_1 = 9;
            suspendResult = uploadSplit(this.t5m_1, this.u5m_1, this.v5m_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 1;
            continue $sm;
          }

        case 1:
          this.ic_1 = 2;
          suspendResult = uploadRaw(this.t5m_1, this.u5m_1, this.v5m_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          this.w5m_1 = suspendResult;
          this.x5m_1 = this.w5m_1;
          var tmp_0 = this.x5m_1;
          if (tmp_0 instanceof Success_0) {
            this.ic_1 = 7;
            suspendResult = handleSuccess(this.t5m_1, this.u5m_1, this.u5m_1.n(), this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            var tmp_1 = this.x5m_1;
            if (tmp_1 instanceof RetryableError) {
              this.ic_1 = 6;
              suspendResult = handleRetryableError(this.t5m_1, this.u5m_1, this.w5m_1, this);
              if (suspendResult === get_COROUTINE_SUSPENDED()) {
                return suspendResult;
              }
              continue $sm;
            } else {
              var tmp_2 = this.x5m_1;
              if (tmp_2 instanceof PermanentError) {
                if (this.w5m_1.x5r_1 === 413 ? this.u5m_1.n() > 1 : false) {
                  this.t5m_1.i5o_1.m5d('Received 413 for ' + this.u5m_1.n() + ' events. Splitting batch and retrying.');
                  this.ic_1 = 4;
                  suspendResult = uploadSplit(this.t5m_1, this.u5m_1, this.v5m_1, this);
                  if (suspendResult === get_COROUTINE_SUSPENDED()) {
                    return suspendResult;
                  }
                  continue $sm;
                } else {
                  this.ic_1 = 3;
                  suspendResult = handlePermanentError(this.t5m_1, this.u5m_1, this.w5m_1, this);
                  if (suspendResult === get_COROUTINE_SUSPENDED()) {
                    return suspendResult;
                  }
                  continue $sm;
                }
              } else {
                var tmp_3 = this;
                noWhenBranchMatchedException();
              }
            }
          }

          break;
        case 3:
          this.z5m_1 = suspendResult;
          this.ic_1 = 5;
          continue $sm;
        case 4:
          this.z5m_1 = suspendResult;
          this.ic_1 = 5;
          continue $sm;
        case 5:
          this.y5m_1 = this.z5m_1;
          this.ic_1 = 8;
          continue $sm;
        case 6:
          this.y5m_1 = suspendResult;
          this.ic_1 = 8;
          continue $sm;
        case 7:
          this.y5m_1 = suspendResult;
          this.ic_1 = 8;
          continue $sm;
        case 8:
          return this.y5m_1;
        case 9:
          return suspendResult;
        case 10:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 10) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $uploadSplitCOROUTINE$8(_this__u8e3s4, events, batchId, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.i5n_1 = _this__u8e3s4;
  this.j5n_1 = events;
  this.k5n_1 = batchId;
}
protoOf($uploadSplitCOROUTINE$8).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 9;
          if (this.j5n_1.n() <= 1) {
            this.ic_1 = 4;
            suspendResult = uploadRaw(this.i5n_1, this.j5n_1, this.k5n_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 1;
            continue $sm;
          }

        case 1:
          this.l5n_1 = this.j5n_1.n() / 2 | 0;
          this.m5n_1 = this.j5n_1.v1(0, this.l5n_1);
          this.n5n_1 = this.j5n_1.v1(this.l5n_1, this.j5n_1.n());
          this.ic_1 = 2;
          suspendResult = uploadAdaptive(this.i5n_1, this.m5n_1, this.k5n_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          this.o5n_1 = suspendResult;
          var tmp_0 = this.o5n_1;
          if (!(tmp_0 instanceof Success)) {
            return this.o5n_1;
          }

          this.ic_1 = 3;
          suspendResult = uploadAdaptive(this.i5n_1, this.n5n_1, this.k5n_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 3:
          this.p5n_1 = suspendResult;
          var tmp_1 = this.p5n_1;
          if (!(tmp_1 instanceof Success)) {
            return this.p5n_1;
          }

          return new Success(this.o5n_1.y5r_1 + this.p5n_1.y5r_1 | 0);
        case 4:
          this.q5n_1 = suspendResult;
          this.r5n_1 = this.q5n_1;
          var tmp_2 = this.r5n_1;
          if (tmp_2 instanceof Success_0) {
            this.ic_1 = 7;
            suspendResult = handleSuccess(this.i5n_1, this.j5n_1, this.j5n_1.n(), this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            var tmp_3 = this.r5n_1;
            if (tmp_3 instanceof RetryableError) {
              this.ic_1 = 6;
              suspendResult = handleRetryableError(this.i5n_1, this.j5n_1, this.q5n_1, this);
              if (suspendResult === get_COROUTINE_SUSPENDED()) {
                return suspendResult;
              }
              continue $sm;
            } else {
              var tmp_4 = this.r5n_1;
              if (tmp_4 instanceof PermanentError) {
                if (this.q5n_1.x5r_1 === 413) {
                  this.i5n_1.i5o_1.z5r('Dropping event ' + first(this.j5n_1).s5p_1 + ' because single-event payload exceeded server limit (413).');
                }
                this.ic_1 = 5;
                suspendResult = handlePermanentError(this.i5n_1, this.j5n_1, this.q5n_1, this);
                if (suspendResult === get_COROUTINE_SUSPENDED()) {
                  return suspendResult;
                }
                continue $sm;
              } else {
                var tmp_5 = this;
                noWhenBranchMatchedException();
              }
            }
          }

          break;
        case 5:
          this.s5n_1 = suspendResult;
          this.ic_1 = 8;
          continue $sm;
        case 6:
          this.s5n_1 = suspendResult;
          this.ic_1 = 8;
          continue $sm;
        case 7:
          this.s5n_1 = suspendResult;
          this.ic_1 = 8;
          continue $sm;
        case 8:
          return this.s5n_1;
        case 9:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 9) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $uploadRawCOROUTINE$9(_this__u8e3s4, events, batchId, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.b5o_1 = _this__u8e3s4;
  this.c5o_1 = events;
  this.d5o_1 = batchId;
}
protoOf($uploadRawCOROUTINE$9).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 4;
          if ((this.b5o_1.h5o_1.w57_1 ? !(this.b5o_1.j5o_1 == null) : false) ? !(this.b5o_1.k5o_1 == null) : false) {
            this.ic_1 = 2;
            suspendResult = uploadWithEncryption$default(this.b5o_1, this.c5o_1, this.d5o_1, VOID, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 1;
            suspendResult = this.b5o_1.f5o_1.a5s(serializeEvents(this.b5o_1, this.c5o_1), this.d5o_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          }

        case 1:
          this.e5o_1 = suspendResult;
          this.ic_1 = 3;
          continue $sm;
        case 2:
          this.e5o_1 = suspendResult;
          this.ic_1 = 3;
          continue $sm;
        case 3:
          return this.e5o_1;
        case 4:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 4) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $uploadWithEncryptionCOROUTINE$10(_this__u8e3s4, events, batchId, isRetry, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.v5o_1 = _this__u8e3s4;
  this.w5o_1 = events;
  this.x5o_1 = batchId;
  this.y5o_1 = isRetry;
}
protoOf($uploadWithEncryptionCOROUTINE$10).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 19;
          this.v5o_1.i5o_1.n56('Encryption enabled, preparing encrypted upload');
          this.z5o_1 = serializeEvents(this.v5o_1, this.w5o_1);
          var tmp_0 = this;
          var tmp0_safe_receiver = this.v5o_1.k5o_1;
          tmp_0.a5p_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.x5h();
          if (this.a5p_1 == null) {
            this.ic_1 = 1;
            suspendResult = fetchAndCacheJwks(this.v5o_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.b5p_1 = this.a5p_1;
            this.ic_1 = 2;
            continue $sm;
          }

        case 1:
          this.c5p_1 = suspendResult;
          var tmp_1 = this;
          var tmp_2;
          if (this.c5p_1 == null) {
            tmp_2 = null;
          } else {
            this.c5p_1;
            var tmp0_safe_receiver_0 = this.v5o_1.k5o_1;
            tmp_2 = tmp0_safe_receiver_0 == null ? null : tmp0_safe_receiver_0.x5h();
          }

          tmp_1.b5p_1 = tmp_2;
          this.ic_1 = 2;
          continue $sm;
        case 2:
          this.d5p_1 = this.b5p_1;
          if (this.d5p_1 == null) {
            this.v5o_1.i5o_1.m5d('No encryption key available, falling back to plaintext');
            this.ic_1 = 18;
            suspendResult = this.v5o_1.f5o_1.a5s(this.z5o_1, this.x5o_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 3;
            continue $sm;
          }

        case 3:
          this.jc_1 = 5;
          this.ic_1 = 4;
          suspendResult = ensureNotNull(this.v5o_1.j5o_1).s5h(this.z5o_1, this.d5p_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 4:
          this.e5p_1 = suspendResult;
          this.jc_1 = 19;
          this.ic_1 = 10;
          continue $sm;
        case 5:
          this.jc_1 = 19;
          var tmp_3 = this.lc_1;
          if (tmp_3 instanceof Exception) {
            this.f5p_1 = this.lc_1;
            this.v5o_1.i5o_1.z57('Encryption failed, refreshing JWKS and retrying', this.f5p_1);
            var tmp3_safe_receiver = this.v5o_1.k5o_1;
            if (tmp3_safe_receiver == null)
              null;
            else {
              tmp3_safe_receiver.x();
            }
            this.ic_1 = 6;
            suspendResult = fetchAndCacheJwks(this.v5o_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 6:
          this.g5p_1 = suspendResult;
          var tmp_4 = this;
          var tmp_5;
          if (this.g5p_1 == null) {
            tmp_5 = null;
          } else {
            this.g5p_1;
            var tmp0_safe_receiver_1 = this.v5o_1.k5o_1;
            tmp_5 = tmp0_safe_receiver_1 == null ? null : tmp0_safe_receiver_1.x5h();
          }

          tmp_4.d5p_1 = tmp_5;
          if (this.d5p_1 == null) {
            this.v5o_1.i5o_1.z5r('Still no encryption key available after refresh, falling back to plaintext');
            this.ic_1 = 17;
            suspendResult = this.v5o_1.f5o_1.a5s(this.z5o_1, this.x5o_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 7;
            continue $sm;
          }

        case 7:
          this.jc_1 = 15;
          this.ic_1 = 8;
          suspendResult = ensureNotNull(this.v5o_1.j5o_1).s5h(this.z5o_1, this.d5p_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 8:
          this.e5p_1 = suspendResult;
          this.jc_1 = 19;
          this.ic_1 = 9;
          continue $sm;
        case 9:
          this.jc_1 = 19;
          this.ic_1 = 10;
          continue $sm;
        case 10:
          this.jc_1 = 19;
          this.ic_1 = 11;
          suspendResult = this.v5o_1.f5o_1.b5s(this.e5p_1, this.x5o_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 11:
          this.h5p_1 = suspendResult;
          var tmp_6;
          var tmp_7;
          if (!this.y5o_1) {
            var tmp_8 = this.h5p_1;
            tmp_7 = tmp_8 instanceof PermanentError;
          } else {
            tmp_7 = false;
          }

          if (tmp_7) {
            tmp_6 = contains(listOf([400, 403]), this.h5p_1.x5r_1);
          } else {
            tmp_6 = false;
          }

          if (tmp_6) {
            this.v5o_1.i5o_1.m5d('Received ' + this.h5p_1.x5r_1 + ', refreshing JWKS and retrying upload.');
            var tmp5_safe_receiver = this.v5o_1.k5o_1;
            if (tmp5_safe_receiver == null)
              null;
            else {
              tmp5_safe_receiver.x();
            }
            this.ic_1 = 13;
            suspendResult = fetchAndCacheJwks(this.v5o_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 12;
            continue $sm;
          }

        case 12:
          return this.h5p_1;
        case 13:
          this.ic_1 = 14;
          suspendResult = uploadWithEncryption(this.v5o_1, this.w5o_1, this.x5o_1, true, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 14:
          return suspendResult;
        case 15:
          this.jc_1 = 19;
          var tmp_9 = this.lc_1;
          if (tmp_9 instanceof Exception) {
            this.i5p_1 = this.lc_1;
            this.v5o_1.i5o_1.z57('Encryption failed again, falling back to plaintext', this.i5p_1);
            this.ic_1 = 16;
            suspendResult = this.v5o_1.f5o_1.a5s(this.z5o_1, this.x5o_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 16:
          return suspendResult;
        case 17:
          return suspendResult;
        case 18:
          return suspendResult;
        case 19:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 19) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $fetchAndCacheJwksCOROUTINE$11(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.r5p_1 = _this__u8e3s4;
}
protoOf($fetchAndCacheJwksCOROUTINE$11).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          this.ic_1 = 1;
          suspendResult = this.r5p_1.f5o_1.c5s(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          this.ic_1 = 2;
          continue $sm;
        case 1:
          var unboxed = suspendResult.hk_1;
          suspendResult = new Result(unboxed);
          this.ic_1 = 2;
          continue $sm;
        case 2:
          var this_0 = suspendResult.hk_1;
          var tmp_0;
          if (_Result___get_isFailure__impl__jpiriv(this_0)) {
            tmp_0 = null;
          } else {
            var tmp_1 = _Result___get_value__impl__bjfvqg(this_0);
            tmp_0 = (tmp_1 == null ? true : !(tmp_1 == null)) ? tmp_1 : THROW_CCE();
          }

          var tmp0_safe_receiver = tmp_0;
          var tmp_2;
          if (tmp0_safe_receiver == null) {
            tmp_2 = null;
          } else {
            var tmp0_safe_receiver_0 = this.r5p_1.k5o_1;
            if (tmp0_safe_receiver_0 == null)
              null;
            else {
              tmp0_safe_receiver_0.w5h(tmp0_safe_receiver);
            }
            this.r5p_1.i5o_1.n56('JWKS cached successfully');
            tmp_2 = tmp0_safe_receiver;
          }

          return tmp_2;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $handleSuccessCOROUTINE$12(_this__u8e3s4, events, uploadedCount, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.d5q_1 = _this__u8e3s4;
  this.e5q_1 = events;
  this.f5q_1 = uploadedCount;
}
protoOf($handleSuccessCOROUTINE$12).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.d5q_1.i5o_1.n56('Upload successful: ' + this.f5q_1 + ' events');
          this.ic_1 = 1;
          var this_0 = this.e5q_1;
          var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
          var tmp0_iterator = this_0.u();
          while (tmp0_iterator.v()) {
            var item = tmp0_iterator.w();
            destination.r(item.s5p_1);
          }

          suspendResult = this.d5q_1.g5o_1.t5r(destination, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          return new Success(this.f5q_1);
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $handleRetryableErrorCOROUTINE$13(_this__u8e3s4, events, error, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.o5q_1 = _this__u8e3s4;
  this.p5q_1 = events;
  this.q5q_1 = error;
}
protoOf($handleRetryableErrorCOROUTINE$13).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 4;
          this.o5q_1.i5o_1.m5d('Upload failed with retryable error: ' + this.q5q_1.d5s_1 + ' (' + this.q5q_1.e5s_1 + ')');
          var tmp_0 = this;
          tmp_0.r5q_1 = this.p5q_1;
          this.s5q_1 = this.r5q_1.u();
          this.ic_1 = 1;
          continue $sm;
        case 1:
          if (!this.s5q_1.v()) {
            this.ic_1 = 3;
            continue $sm;
          }

          this.t5q_1 = this.s5q_1.w();
          var tmp_1 = this;
          tmp_1.u5q_1 = this.t5q_1;
          this.ic_1 = 2;
          suspendResult = this.o5q_1.g5o_1.f5s(this.u5q_1.s5p_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          this.ic_1 = 1;
          continue $sm;
        case 3:
          var retryDelay = this.o5q_1.h5o_1.x57_1.a59(first(this.p5q_1).u5p_1.ra());
          return new RetryableFailure(this.q5q_1.d5s_1, retryDelay);
        case 4:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 4) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $handlePermanentErrorCOROUTINE$14(_this__u8e3s4, events, error, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.d5r_1 = _this__u8e3s4;
  this.e5r_1 = events;
  this.f5r_1 = error;
}
protoOf($handlePermanentErrorCOROUTINE$14).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          this.d5r_1.i5o_1.z5r('Upload failed with permanent error: ' + this.f5r_1.w5r_1 + ' (' + this.f5r_1.x5r_1 + ')');
          this.ic_1 = 1;
          var this_0 = this.e5r_1;
          var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
          var tmp0_iterator = this_0.u();
          while (tmp0_iterator.v()) {
            var item = tmp0_iterator.w();
            destination.r(item.s5p_1);
          }

          suspendResult = this.d5r_1.g5o_1.t5r(destination, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          return new PermanentFailure(this.f5r_1.w5r_1);
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function EventUploader(networkClient, eventStorage, configuration, logger, encryptionManager, jwksCache) {
  encryptionManager = encryptionManager === VOID ? null : encryptionManager;
  jwksCache = jwksCache === VOID ? null : jwksCache;
  this.f5o_1 = networkClient;
  this.g5o_1 = eventStorage;
  this.h5o_1 = configuration;
  this.i5o_1 = logger;
  this.j5o_1 = encryptionManager;
  this.k5o_1 = jwksCache;
  var tmp = this;
  tmp.l5o_1 = Json(VOID, EventUploader$json$lambda);
  this.m5o_1 = 245760;
}
protoOf(EventUploader).g5s = function (events, $completion) {
  var tmp = new $uploadBatchCOROUTINE$6(this, events, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
function Success(uploadedCount) {
  UploadResult.call(this);
  this.y5r_1 = uploadedCount;
}
protoOf(Success).toString = function () {
  return 'Success(uploadedCount=' + this.y5r_1 + ')';
};
protoOf(Success).hashCode = function () {
  return this.y5r_1;
};
protoOf(Success).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof Success))
    return false;
  var tmp0_other_with_cast = other instanceof Success ? other : THROW_CCE();
  if (!(this.y5r_1 === tmp0_other_with_cast.y5r_1))
    return false;
  return true;
};
function RetryableFailure(message, retryAfter) {
  UploadResult.call(this);
  this.h5s_1 = message;
  this.i5s_1 = retryAfter;
}
protoOf(RetryableFailure).toString = function () {
  var tmp = this.i5s_1;
  return 'RetryableFailure(message=' + this.h5s_1 + ', retryAfter=' + (tmp == null ? null : new Duration(tmp)) + ')';
};
protoOf(RetryableFailure).hashCode = function () {
  var result = getStringHashCode(this.h5s_1);
  var tmp = imul(result, 31);
  var tmp_0;
  var tmp_1 = this.i5s_1;
  if ((tmp_1 == null ? null : new Duration(tmp_1)) == null) {
    tmp_0 = 0;
  } else {
    tmp_0 = Duration__hashCode_impl_u4exz6(this.i5s_1);
  }
  result = tmp + tmp_0 | 0;
  return result;
};
protoOf(RetryableFailure).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RetryableFailure))
    return false;
  var tmp0_other_with_cast = other instanceof RetryableFailure ? other : THROW_CCE();
  if (!(this.h5s_1 === tmp0_other_with_cast.h5s_1))
    return false;
  var tmp = this.i5s_1;
  var tmp_0 = tmp == null ? null : new Duration(tmp);
  var tmp_1 = tmp0_other_with_cast.i5s_1;
  if (!equals(tmp_0, tmp_1 == null ? null : new Duration(tmp_1)))
    return false;
  return true;
};
function PermanentFailure(message) {
  UploadResult.call(this);
  this.j5s_1 = message;
}
protoOf(PermanentFailure).toString = function () {
  return 'PermanentFailure(message=' + this.j5s_1 + ')';
};
protoOf(PermanentFailure).hashCode = function () {
  return getStringHashCode(this.j5s_1);
};
protoOf(PermanentFailure).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof PermanentFailure))
    return false;
  var tmp0_other_with_cast = other instanceof PermanentFailure ? other : THROW_CCE();
  if (!(this.j5s_1 === tmp0_other_with_cast.j5s_1))
    return false;
  return true;
};
function UploadResult() {
}
function handleHttpResponse($this, response, $completion) {
  var tmp = new $handleHttpResponseCOROUTINE$18($this, response, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function $uploadEventsCOROUTINE$15(_this__u8e3s4, events, batchId, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.e5t_1 = _this__u8e3s4;
  this.f5t_1 = events;
  this.g5t_1 = batchId;
}
protoOf($uploadEventsCOROUTINE$15).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 5;
          this.e5t_1.s5t_1.n56('Uploading events to ' + this.e5t_1.v5t_1);
          this.jc_1 = 3;
          var tmp_0 = this;
          tmp_0.i5t_1 = this.e5t_1.q5t_1;
          var tmp_1 = this;
          tmp_1.j5t_1 = this.e5t_1.v5t_1;
          var tmp_2 = this;
          tmp_2.k5t_1 = this.i5t_1;
          var tmp_3 = this;
          tmp_3.l5t_1 = this.k5t_1;
          var tmp_4 = this;
          var this_0 = new HttpRequestBuilder();
          url(this_0, this.j5t_1);
          header(this_0, 'x-api-key', this.e5t_1.r5t_1.m57_1);
          header(this_0, 'event_id', this.g5t_1);
          header(this_0, 'x-correlation-id', this.g5t_1);
          contentType(this_0, Application_getInstance().s21_1);
          var this_1 = this.e5t_1.t5t_1;
          var value = this.f5t_1;
          var this_2 = this_1.k3r();
          var this_3 = serializer(this_2, createKType(getKClass(JsonObject), arrayOf([]), false));
          var body = this_1.g3s(isInterface(this_3, KSerializer) ? this_3 : THROW_CCE(), value);
          if (body == null) {
            this_0.w2i_1 = NullBody_instance;
            var tmp_5 = JsType_instance;
            var tmp_6 = PrimitiveClasses_getInstance().t7();
            var tmp_7;
            try {
              tmp_7 = createKType(PrimitiveClasses_getInstance().t7(), arrayOf([]), false);
            } catch ($p) {
              var tmp_8;
              if ($p instanceof Error) {
                var cause = $p;
                tmp_8 = null;
              } else {
                throw $p;
              }
              tmp_7 = tmp_8;
            }
            this_0.s2o(typeInfoImpl(tmp_5, tmp_6, tmp_7));
          } else {
            if (body instanceof OutgoingContent) {
              this_0.w2i_1 = body;
              this_0.s2o(null);
            } else {
              this_0.w2i_1 = body;
              var tmp_9 = JsType_instance;
              var tmp_10 = PrimitiveClasses_getInstance().t7();
              var tmp_11;
              try {
                tmp_11 = createKType(PrimitiveClasses_getInstance().t7(), arrayOf([]), false);
              } catch ($p) {
                var tmp_12;
                if ($p instanceof Error) {
                  var cause_0 = $p;
                  tmp_12 = null;
                } else {
                  throw $p;
                }
                tmp_11 = tmp_12;
              }
              this_0.s2o(typeInfoImpl(tmp_9, tmp_10, tmp_11));
            }
          }

          tmp_4.m5t_1 = this_0;
          this.m5t_1.u2i_1 = Companion_getInstance_3().j27_1;
          var tmp_13 = this;
          tmp_13.n5t_1 = this.l5t_1;
          var tmp_14 = this;
          tmp_14.o5t_1 = this.m5t_1;
          this.ic_1 = 1;
          suspendResult = (new HttpStatement(this.o5t_1, this.n5t_1)).h3b(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.p5t_1 = suspendResult;
          this.ic_1 = 2;
          suspendResult = handleHttpResponse(this.e5t_1, this.p5t_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          this.h5t_1 = suspendResult;
          this.jc_1 = 5;
          this.ic_1 = 4;
          continue $sm;
        case 3:
          this.jc_1 = 5;
          var tmp_15 = this.lc_1;
          if (tmp_15 instanceof Exception) {
            var e = this.lc_1;
            var tmp_16 = this;
            this.e5t_1.s5t_1.z57('Upload failed', e);
            tmp_16.h5t_1 = new RetryableError('Network error: ' + e.message, null);
            this.ic_1 = 4;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 4:
          this.jc_1 = 5;
          return this.h5t_1;
        case 5:
          throw this.lc_1;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 5) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
function $uploadEncryptedBatchCOROUTINE$16(_this__u8e3s4, encryptedPayload, batchId, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.f5u_1 = _this__u8e3s4;
  this.g5u_1 = encryptedPayload;
  this.h5u_1 = batchId;
}
protoOf($uploadEncryptedBatchCOROUTINE$16).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 5;
          this.f5u_1.s5t_1.n56('Uploading encrypted batch to ' + this.f5u_1.v5t_1);
          this.f5u_1.s5t_1.n56('Key ID: ' + this.g5u_1.c5i_1 + ', Ciphertext size: ' + this.g5u_1.a5i_1.length + ' bytes');
          this.jc_1 = 3;
          var tmp_0 = this;
          tmp_0.j5u_1 = this.f5u_1.q5t_1;
          var tmp_1 = this;
          tmp_1.k5u_1 = this.f5u_1.v5t_1;
          var tmp_2 = this;
          tmp_2.l5u_1 = this.j5u_1;
          var tmp_3 = this;
          tmp_3.m5u_1 = this.l5u_1;
          var tmp_4 = this;
          var this_0 = new HttpRequestBuilder();
          url(this_0, this.k5u_1);
          header(this_0, 'x-api-key', this.f5u_1.r5t_1.m57_1);
          header(this_0, 'event_id', this.h5u_1);
          header(this_0, 'x-correlation-id', this.h5u_1);
          header(this_0, 'x-encrypted', 'true');
          header(this_0, 'x-key', this.g5u_1.b5i_1);
          header(this_0, 'x-kid', this.g5u_1.c5i_1);
          header(this_0, 'x-iv', this.g5u_1.d5i_1);
          contentType(this_0, Application_getInstance().v21_1);
          var body = this.g5u_1.a5i_1;
          if (body == null) {
            this_0.w2i_1 = NullBody_instance;
            var tmp_5 = JsType_instance;
            var tmp_6 = PrimitiveClasses_getInstance().x7();
            var tmp_7;
            try {
              tmp_7 = createKType(PrimitiveClasses_getInstance().x7(), arrayOf([]), false);
            } catch ($p) {
              var tmp_8;
              if ($p instanceof Error) {
                var cause = $p;
                tmp_8 = null;
              } else {
                throw $p;
              }
              tmp_7 = tmp_8;
            }
            this_0.s2o(typeInfoImpl(tmp_5, tmp_6, tmp_7));
          } else {
            if (body instanceof OutgoingContent) {
              this_0.w2i_1 = body;
              this_0.s2o(null);
            } else {
              this_0.w2i_1 = body;
              var tmp_9 = JsType_instance;
              var tmp_10 = PrimitiveClasses_getInstance().x7();
              var tmp_11;
              try {
                tmp_11 = createKType(PrimitiveClasses_getInstance().x7(), arrayOf([]), false);
              } catch ($p) {
                var tmp_12;
                if ($p instanceof Error) {
                  var cause_0 = $p;
                  tmp_12 = null;
                } else {
                  throw $p;
                }
                tmp_11 = tmp_12;
              }
              this_0.s2o(typeInfoImpl(tmp_9, tmp_10, tmp_11));
            }
          }

          tmp_4.n5u_1 = this_0;
          this.n5u_1.u2i_1 = Companion_getInstance_3().j27_1;
          var tmp_13 = this;
          tmp_13.o5u_1 = this.m5u_1;
          var tmp_14 = this;
          tmp_14.p5u_1 = this.n5u_1;
          this.ic_1 = 1;
          suspendResult = (new HttpStatement(this.p5u_1, this.o5u_1)).h3b(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.q5u_1 = suspendResult;
          this.ic_1 = 2;
          suspendResult = handleHttpResponse(this.f5u_1, this.q5u_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          this.i5u_1 = suspendResult;
          this.jc_1 = 5;
          this.ic_1 = 4;
          continue $sm;
        case 3:
          this.jc_1 = 5;
          var tmp_15 = this.lc_1;
          if (tmp_15 instanceof Exception) {
            var e = this.lc_1;
            var tmp_16 = this;
            this.f5u_1.s5t_1.z57('Encrypted upload failed', e);
            tmp_16.i5u_1 = new RetryableError('Network error: ' + e.message, null);
            this.ic_1 = 4;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 4:
          this.jc_1 = 5;
          return this.i5u_1;
        case 5:
          throw this.lc_1;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 5) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
function $fetchJwksCOROUTINE$17(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.z5u_1 = _this__u8e3s4;
}
protoOf($fetchJwksCOROUTINE$17).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 6;
          this.z5u_1.s5t_1.n56('Fetching JWKS from ' + this.z5u_1.w5t_1);
          this.jc_1 = 4;
          var tmp_0 = this;
          tmp_0.b5v_1 = this.z5u_1.q5t_1;
          var tmp_1 = this;
          tmp_1.c5v_1 = this.z5u_1.w5t_1;
          var tmp_2 = this;
          tmp_2.d5v_1 = this.b5v_1;
          var tmp_3 = this;
          tmp_3.e5v_1 = this.d5v_1;
          var tmp_4 = this;
          var this_0 = new HttpRequestBuilder();
          url(this_0, this.c5v_1);
          header(this_0, 'x-api-key', this.z5u_1.r5t_1.m57_1);
          tmp_4.f5v_1 = this_0;
          this.f5v_1.u2i_1 = Companion_getInstance_3().i27_1;
          var tmp_5 = this;
          tmp_5.g5v_1 = this.e5v_1;
          var tmp_6 = this;
          tmp_6.h5v_1 = this.f5v_1;
          this.ic_1 = 1;
          suspendResult = (new HttpStatement(this.h5v_1, this.g5v_1)).h3b(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.i5v_1 = suspendResult;
          if (isSuccess(this.i5v_1.j2c())) {
            var tmp_7 = this;
            tmp_7.k5v_1 = this.i5v_1;
            this.ic_1 = 2;
            var tmp_8 = this.k5v_1.b2m();
            var tmp_9 = JsType_instance;
            var tmp_10 = getKClass(Jwks);
            var tmp_11;
            try {
              tmp_11 = createKType(getKClass(Jwks), arrayOf([]), false);
            } catch ($p) {
              var tmp_12;
              if ($p instanceof Error) {
                var cause = $p;
                tmp_12 = null;
              } else {
                throw $p;
              }
              tmp_11 = tmp_12;
            }
            suspendResult = tmp_8.f2l(typeInfoImpl(tmp_9, tmp_10, tmp_11), this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            var tmp_13 = this;
            var errorMessage = 'JWKS fetch failed with status ' + this.i5v_1.j2c().c2a_1;
            this.z5u_1.s5t_1.z5r(errorMessage);
            var exception = Exception_init_$Create$(errorMessage);
            tmp_13.j5v_1 = _Result___init__impl__xyqfz8(createFailure(exception));
            this.ic_1 = 3;
            continue $sm;
          }

        case 2:
          var jwks = suspendResult instanceof Jwks ? suspendResult : THROW_CCE();
          var tmp_14 = this;
          tmp_14.j5v_1 = _Result___init__impl__xyqfz8(jwks);
          this.ic_1 = 3;
          continue $sm;
        case 3:
          this.a5v_1 = this.j5v_1;
          this.jc_1 = 6;
          this.ic_1 = 5;
          continue $sm;
        case 4:
          this.jc_1 = 6;
          var tmp_15 = this.lc_1;
          if (tmp_15 instanceof Exception) {
            var e = this.lc_1;
            var tmp_16 = this;
            this.z5u_1.s5t_1.z57('JWKS fetch failed', e);
            tmp_16.a5v_1 = _Result___init__impl__xyqfz8(createFailure(e));
            this.ic_1 = 5;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 5:
          this.jc_1 = 6;
          return new Result(this.a5v_1);
        case 6:
          throw this.lc_1;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 6) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
function $handleHttpResponseCOROUTINE$18(_this__u8e3s4, response, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.s5s_1 = _this__u8e3s4;
  this.t5s_1 = response;
}
protoOf($handleHttpResponseCOROUTINE$18).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          this.u5s_1 = this.t5s_1.j2c().c2a_1;
          var containsArg = this.u5s_1;
          if (200 <= containsArg ? containsArg <= 299 : false) {
            var tmp_0 = this;
            tmp_0.v5s_1 = Success_getInstance();
            this.ic_1 = 2;
            continue $sm;
          } else {
            if (this.u5s_1 === 429) {
              var tmp_1 = this;
              tmp_1.v5s_1 = new RetryableError('Rate limit error: ' + this.t5s_1.j2c().d2a_1, this.t5s_1.j2c().c2a_1);
              this.ic_1 = 2;
              continue $sm;
            } else {
              var containsArg_0 = this.u5s_1;
              if (400 <= containsArg_0 ? containsArg_0 <= 499 : false) {
                this.ic_1 = 1;
                suspendResult = bodyAsText(this.t5s_1, VOID, this);
                if (suspendResult === get_COROUTINE_SUSPENDED()) {
                  return suspendResult;
                }
                continue $sm;
              } else {
                var containsArg_1 = this.u5s_1;
                if (500 <= containsArg_1 ? containsArg_1 <= 599 : false) {
                  var tmp_2 = this;
                  tmp_2.v5s_1 = new RetryableError('Server error: ' + this.t5s_1.j2c().d2a_1, this.t5s_1.j2c().c2a_1);
                  this.ic_1 = 2;
                  continue $sm;
                } else {
                  var tmp_3 = this;
                  tmp_3.v5s_1 = new RetryableError('Unexpected status: ' + this.t5s_1.j2c().d2a_1, this.t5s_1.j2c().c2a_1);
                  this.ic_1 = 2;
                  continue $sm;
                }
              }
            }
          }

        case 1:
          var ARGUMENT = suspendResult;
          var ARGUMENT_0 = 'Client error: ' + ARGUMENT;
          this.v5s_1 = new PermanentError(ARGUMENT_0, this.t5s_1.j2c().c2a_1);
          this.ic_1 = 2;
          continue $sm;
        case 2:
          return this.v5s_1;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function KtorNetworkClient(httpClient, configuration, logger, json) {
  this.q5t_1 = httpClient;
  this.r5t_1 = configuration;
  this.s5t_1 = logger;
  this.t5t_1 = json;
  this.u5t_1 = this.r5t_1.n57_1;
  this.v5t_1 = this.u5t_1 + '/events';
  this.w5t_1 = this.u5t_1 + '/.well-known/jwks.json';
}
protoOf(KtorNetworkClient).a5s = function (events, batchId, $completion) {
  var tmp = new $uploadEventsCOROUTINE$15(this, events, batchId, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(KtorNetworkClient).b5s = function (encryptedPayload, batchId, $completion) {
  var tmp = new $uploadEncryptedBatchCOROUTINE$16(this, encryptedPayload, batchId, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(KtorNetworkClient).c5s = function ($completion) {
  var tmp = new $fetchJwksCOROUTINE$17(this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  var tmp_0 = tmp.uc();
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    return tmp_0;
  return tmp_0;
};
function Success_0() {
  Success_instance = this;
  NetworkResponse.call(this);
}
var Success_instance;
function Success_getInstance() {
  if (Success_instance == null)
    new Success_0();
  return Success_instance;
}
function RetryableError(message, statusCode) {
  statusCode = statusCode === VOID ? null : statusCode;
  NetworkResponse.call(this);
  this.d5s_1 = message;
  this.e5s_1 = statusCode;
}
protoOf(RetryableError).toString = function () {
  return 'RetryableError(message=' + this.d5s_1 + ', statusCode=' + this.e5s_1 + ')';
};
protoOf(RetryableError).hashCode = function () {
  var result = getStringHashCode(this.d5s_1);
  result = imul(result, 31) + (this.e5s_1 == null ? 0 : this.e5s_1) | 0;
  return result;
};
protoOf(RetryableError).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof RetryableError))
    return false;
  var tmp0_other_with_cast = other instanceof RetryableError ? other : THROW_CCE();
  if (!(this.d5s_1 === tmp0_other_with_cast.d5s_1))
    return false;
  if (!(this.e5s_1 == tmp0_other_with_cast.e5s_1))
    return false;
  return true;
};
function PermanentError(message, statusCode) {
  statusCode = statusCode === VOID ? null : statusCode;
  NetworkResponse.call(this);
  this.w5r_1 = message;
  this.x5r_1 = statusCode;
}
protoOf(PermanentError).toString = function () {
  return 'PermanentError(message=' + this.w5r_1 + ', statusCode=' + this.x5r_1 + ')';
};
protoOf(PermanentError).hashCode = function () {
  var result = getStringHashCode(this.w5r_1);
  result = imul(result, 31) + (this.x5r_1 == null ? 0 : this.x5r_1) | 0;
  return result;
};
protoOf(PermanentError).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof PermanentError))
    return false;
  var tmp0_other_with_cast = other instanceof PermanentError ? other : THROW_CCE();
  if (!(this.w5r_1 === tmp0_other_with_cast.w5r_1))
    return false;
  if (!(this.x5r_1 == tmp0_other_with_cast.x5r_1))
    return false;
  return true;
};
function NetworkResponse() {
}
function NetworkClientFactory$createKtorClient$lambda($this$Json) {
  $this$Json.n4h_1 = true;
  $this$Json.l4h_1 = true;
  $this$Json.o4h_1 = true;
  return Unit_instance;
}
function NetworkClientFactory$createKtorClient$lambda$lambda($json) {
  return function ($this$install) {
    json($this$install, $json);
    return Unit_instance;
  };
}
function NetworkClientFactory$createKtorClient$httpClient$1$2$1($logger) {
  this.l5v_1 = $logger;
}
protoOf(NetworkClientFactory$createKtorClient$httpClient$1$2$1).i3k = function (message) {
  this.l5v_1.n56('HTTP: ' + message);
};
function NetworkClientFactory$createKtorClient$lambda$lambda_0($configuration, $logger) {
  return function ($this$install) {
    var tmp = $this$install;
    var tmp_0;
    if ($configuration.s57_1) {
      tmp_0 = LogLevel_HEADERS_getInstance();
    } else {
      tmp_0 = LogLevel_NONE_getInstance();
    }
    tmp.x3l_1 = tmp_0;
    $this$install.y3l(new NetworkClientFactory$createKtorClient$httpClient$1$2$1($logger));
    return Unit_instance;
  };
}
function NetworkClientFactory$createKtorClient$lambda_0($json, $configuration, $logger) {
  return function ($this$HttpClient) {
    var tmp = Plugin_getInstance();
    $this$HttpClient.a2k(tmp, NetworkClientFactory$createKtorClient$lambda$lambda($json));
    var tmp_0 = Companion_getInstance_4();
    $this$HttpClient.a2k(tmp_0, NetworkClientFactory$createKtorClient$lambda$lambda_0($configuration, $logger));
    $this$HttpClient.f2j_1 = false;
    return Unit_instance;
  };
}
function NetworkClientFactory() {
}
protoOf(NetworkClientFactory).o5d = function (configuration, logger) {
  var json = Json(VOID, NetworkClientFactory$createKtorClient$lambda);
  var httpClient = HttpClient(NetworkClientFactory$createKtorClient$lambda_0(json, configuration, logger));
  return new KtorNetworkClient(httpClient, configuration, logger, json);
};
var NetworkClientFactory_instance;
function NetworkClientFactory_getInstance() {
  return NetworkClientFactory_instance;
}
function removeOldestEvents($this, $completion) {
  var tmp = new $removeOldestEventsCOROUTINE$23($this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function uploadBatch($this, events, $completion) {
  var tmp = new $uploadBatchCOROUTINE$25($this, events, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function updateQueueSize($this, $completion) {
  var tmp = new $updateQueueSizeCOROUTINE$26($this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function EventQueue$startAutoFlush$slambda(this$0, resultContinuation) {
  this.b5x_1 = this$0;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(EventQueue$startAutoFlush$slambda).d1m = function ($this$launch, $completion) {
  var tmp = this.e1m($this$launch, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(EventQueue$startAutoFlush$slambda).gd = function (p1, $completion) {
  return this.d1m((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(EventQueue$startAutoFlush$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 7;
          this.ic_1 = 1;
          continue $sm;
        case 1:
          if (!get_isActive(this.c5x_1)) {
            this.ic_1 = 6;
            continue $sm;
          }

          this.ic_1 = 2;
          suspendResult = delay(_Duration___get_inWholeMilliseconds__impl__msfiry(this.b5x_1.b58_1.o57_1), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          this.jc_1 = 4;
          this.ic_1 = 3;
          suspendResult = this.b5x_1.i58(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 3:
          this.jc_1 = 7;
          this.ic_1 = 5;
          continue $sm;
        case 4:
          this.jc_1 = 7;
          var tmp_0 = this.lc_1;
          if (tmp_0 instanceof Exception) {
            var e = this.lc_1;
            this.b5x_1.c58_1.z5r('Auto flush failed: ' + e.message);
            this.ic_1 = 5;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 5:
          this.jc_1 = 7;
          this.ic_1 = 1;
          continue $sm;
        case 6:
          return Unit_instance;
        case 7:
          throw this.lc_1;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 7) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
protoOf(EventQueue$startAutoFlush$slambda).e1m = function ($this$launch, completion) {
  var i = new EventQueue$startAutoFlush$slambda(this.b5x_1, completion);
  i.c5x_1 = $this$launch;
  return i;
};
function EventQueue$startAutoFlush$slambda_0(this$0, resultContinuation) {
  var i = new EventQueue$startAutoFlush$slambda(this$0, resultContinuation);
  var l = function ($this$launch, $completion) {
    return i.d1m($this$launch, $completion);
  };
  l.$arity = 1;
  return l;
}
function EventQueue$uploadBatch$slambda($delay, this$0, resultContinuation) {
  this.l5x_1 = $delay;
  this.m5x_1 = this$0;
  CoroutineImpl.call(this, resultContinuation);
}
protoOf(EventQueue$uploadBatch$slambda).d1m = function ($this$launch, $completion) {
  var tmp = this.e1m($this$launch, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(EventQueue$uploadBatch$slambda).gd = function (p1, $completion) {
  return this.d1m((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
};
protoOf(EventQueue$uploadBatch$slambda).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          this.ic_1 = 1;
          suspendResult = delay(_Duration___get_inWholeMilliseconds__impl__msfiry(this.l5x_1), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.ic_1 = 2;
          suspendResult = this.m5x_1.i58(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          return Unit_instance;
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
protoOf(EventQueue$uploadBatch$slambda).e1m = function ($this$launch, completion) {
  var i = new EventQueue$uploadBatch$slambda(this.l5x_1, this.m5x_1, completion);
  i.n5x_1 = $this$launch;
  return i;
};
function EventQueue$uploadBatch$slambda_0($delay, this$0, resultContinuation) {
  var i = new EventQueue$uploadBatch$slambda($delay, this$0, resultContinuation);
  var l = function ($this$launch, $completion) {
    return i.d1m($this$launch, $completion);
  };
  l.$arity = 1;
  return l;
}
function $enqueueCOROUTINE$22(_this__u8e3s4, event, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.w5x_1 = _this__u8e3s4;
  this.x5x_1 = event;
}
protoOf($enqueueCOROUTINE$22).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 8;
          this.jc_1 = 7;
          if (this.w5x_1.g58_1.l2().o6(toLong_0(this.w5x_1.b58_1.q57_1)) >= 0) {
            this.w5x_1.c58_1.m5d('Queue size limit reached (' + this.w5x_1.b58_1.q57_1 + '), removing oldest events');
            this.ic_1 = 1;
            suspendResult = removeOldestEvents(this.w5x_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 2;
            continue $sm;
          }

        case 1:
          this.ic_1 = 2;
          continue $sm;
        case 2:
          this.ic_1 = 3;
          suspendResult = this.w5x_1.a58_1.y5x(this.x5x_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 3:
          this.ic_1 = 4;
          suspendResult = updateQueueSize(this.w5x_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 4:
          this.w5x_1.c58_1.n56('Event enqueued: ' + this.x5x_1.n5i());
          if (this.w5x_1.g58_1.l2().o6(toLong_0(this.w5x_1.b58_1.p57_1)) >= 0) {
            this.w5x_1.c58_1.n56('Queue size threshold reached, triggering flush');
            this.ic_1 = 5;
            suspendResult = this.w5x_1.i58(this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 6;
            continue $sm;
          }

        case 5:
          this.ic_1 = 6;
          continue $sm;
        case 6:
          this.jc_1 = 8;
          this.ic_1 = 9;
          continue $sm;
        case 7:
          this.jc_1 = 8;
          var tmp_0 = this.lc_1;
          if (tmp_0 instanceof Exception) {
            var e = this.lc_1;
            this.w5x_1.c58_1.z5r('Failed to enqueue event: ' + e.message);
            this.ic_1 = 9;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 8:
          throw this.lc_1;
        case 9:
          this.jc_1 = 8;
          return Unit_instance;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 8) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
function $removeOldestEventsCOROUTINE$23(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.u5v_1 = _this__u8e3s4;
}
protoOf($removeOldestEventsCOROUTINE$23).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 6;
          this.jc_1 = 5;
          var tmp_0 = this;
          var this_0 = this.u5v_1.g58_1.l2();
          var other = this.u5v_1.b58_1.q57_1;
          tmp_0.v5v_1 = this_0.mb(toLong_0(other)).lb(toLong_0(100)).ra();
          if (this.v5v_1 > 0) {
            this.ic_1 = 1;
            suspendResult = this.u5v_1.a58_1.z5x(this.v5v_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.ic_1 = 4;
            continue $sm;
          }

        case 1:
          this.w5v_1 = suspendResult;
          var tmp_1 = this;
          var this_1 = this.w5v_1;
          var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_1, 10));
          var tmp0_iterator = this_1.u();
          while (tmp0_iterator.v()) {
            var item = tmp0_iterator.w();
            destination.r(item.s5p_1);
          }

          tmp_1.x5v_1 = destination;
          this.ic_1 = 2;
          suspendResult = this.u5v_1.a58_1.t5r(this.x5v_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 2:
          this.ic_1 = 3;
          suspendResult = updateQueueSize(this.u5v_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 3:
          this.u5v_1.c58_1.n5d('Removed ' + this.x5v_1.n() + ' old events from queue');
          this.ic_1 = 4;
          continue $sm;
        case 4:
          this.jc_1 = 6;
          this.ic_1 = 7;
          continue $sm;
        case 5:
          this.jc_1 = 6;
          var tmp_2 = this.lc_1;
          if (tmp_2 instanceof Exception) {
            var e = this.lc_1;
            this.u5v_1.c58_1.z5r('Failed to remove oldest events: ' + e.message);
            this.ic_1 = 7;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 6:
          throw this.lc_1;
        case 7:
          this.jc_1 = 6;
          return Unit_instance;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 6) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
function $flushCOROUTINE$24(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.i5y_1 = _this__u8e3s4;
}
protoOf($flushCOROUTINE$24).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 14;
          var tmp_0 = this;
          tmp_0.j5y_1 = this.i5y_1.h58_1;
          var tmp_1 = this;
          tmp_1.k5y_1 = null;
          this.ic_1 = 1;
          suspendResult = this.j5y_1.g1a(this.k5y_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.ic_1 = 2;
          continue $sm;
        case 2:
          this.ic_1 = 3;
          continue $sm;
        case 3:
          this.jc_1 = 12;
          this.jc_1 = 10;
          this.ic_1 = 4;
          suspendResult = this.i5y_1.a58_1.q5y(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 4:
          this.n5y_1 = suspendResult;
          if (this.n5y_1.equals(new Long(0, 0))) {
            this.i5y_1.c58_1.n56('No pending events to flush');
            this.m5y_1 = Unit_instance;
            this.jc_1 = 14;
            this.ic_1 = 9;
            continue $sm;
          } else {
            this.ic_1 = 5;
            continue $sm;
          }

        case 5:
          this.i5y_1.c58_1.n56('Flushing ' + this.n5y_1.toString() + ' pending events');
          this.o5y_1 = this.i5y_1.b58_1.r57_1;
          this.ic_1 = 6;
          suspendResult = this.i5y_1.a58_1.z5x(this.o5y_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 6:
          this.p5y_1 = suspendResult;
          if (this.p5y_1.b1()) {
            this.m5y_1 = Unit_instance;
            this.jc_1 = 14;
            this.ic_1 = 9;
            continue $sm;
          } else {
            this.ic_1 = 7;
            continue $sm;
          }

        case 7:
          this.ic_1 = 8;
          suspendResult = uploadBatch(this.i5y_1, this.p5y_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 8:
          this.jc_1 = 12;
          this.ic_1 = 11;
          continue $sm;
        case 9:
          this.jc_1 = 14;
          this.j5y_1.r19(this.k5y_1);
          return Unit_instance;
        case 10:
          this.jc_1 = 12;
          var tmp_2 = this.lc_1;
          if (tmp_2 instanceof Exception) {
            var e = this.lc_1;
            this.i5y_1.c58_1.z5r('Flush failed: ' + e.message);
            this.ic_1 = 11;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 11:
          var tmp_3 = this;
          this.jc_1 = 12;
          tmp_3.l5y_1 = Unit_instance;
          this.jc_1 = 14;
          this.ic_1 = 13;
          continue $sm;
        case 12:
          this.jc_1 = 14;
          var t = this.lc_1;
          this.j5y_1.r19(this.k5y_1);
          throw t;
        case 13:
          this.jc_1 = 14;
          this.j5y_1.r19(this.k5y_1);
          return Unit_instance;
        case 14:
          throw this.lc_1;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 14) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
function $uploadBatchCOROUTINE$25(_this__u8e3s4, events, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.g5w_1 = _this__u8e3s4;
  this.h5w_1 = events;
}
protoOf($uploadBatchCOROUTINE$25).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 6;
          this.ic_1 = 1;
          suspendResult = this.g5w_1.d58_1.g5s(this.h5w_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.i5w_1 = suspendResult;
          var tmp_0 = this.i5w_1;
          if (tmp_0 instanceof Success) {
            this.ic_1 = 4;
            suspendResult = updateQueueSize(this.g5w_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            var tmp_1 = this.i5w_1;
            if (tmp_1 instanceof RetryableFailure) {
              this.g5w_1.c58_1.m5d('Batch upload failed (retryable): ' + this.i5w_1.h5s_1);
              this.ic_1 = 3;
              suspendResult = updateQueueSize(this.g5w_1, this);
              if (suspendResult === get_COROUTINE_SUSPENDED()) {
                return suspendResult;
              }
              continue $sm;
            } else {
              var tmp_2 = this.i5w_1;
              if (tmp_2 instanceof PermanentFailure) {
                this.g5w_1.c58_1.z5r('Batch upload failed (permanent): ' + this.i5w_1.j5s_1);
                this.ic_1 = 2;
                suspendResult = updateQueueSize(this.g5w_1, this);
                if (suspendResult === get_COROUTINE_SUSPENDED()) {
                  return suspendResult;
                }
                continue $sm;
              } else {
                this.ic_1 = 5;
                continue $sm;
              }
            }
          }

        case 2:
          this.ic_1 = 5;
          continue $sm;
        case 3:
          var tmp0_safe_receiver = this.i5w_1.i5s_1;
          var tmp_3 = tmp0_safe_receiver;
          if ((tmp_3 == null ? null : new Duration(tmp_3)) == null)
            null;
          else {
            var tmp_4 = tmp0_safe_receiver;
            var delay = (tmp_4 == null ? null : new Duration(tmp_4)).tj_1;
            this.g5w_1.c58_1.n56('Scheduling retry after ' + _Duration___get_inWholeSeconds__impl__hpy7b3(delay).toString() + 's');
            launch(this.g5w_1.e58_1, VOID, VOID, EventQueue$uploadBatch$slambda_0(delay, this.g5w_1, null));
          }

          this.ic_1 = 5;
          continue $sm;
        case 4:
          this.ic_1 = 5;
          continue $sm;
        case 5:
          return Unit_instance;
        case 6:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 6) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $updateQueueSizeCOROUTINE$26(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.r5w_1 = _this__u8e3s4;
}
protoOf($updateQueueSizeCOROUTINE$26).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          this.jc_1 = 2;
          this.s5w_1 = this.r5w_1.g58_1;
          this.ic_1 = 1;
          suspendResult = this.r5w_1.a58_1.q5y(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var ARGUMENT = suspendResult;
          this.s5w_1.y15(ARGUMENT);
          this.jc_1 = 3;
          this.ic_1 = 4;
          continue $sm;
        case 2:
          this.jc_1 = 3;
          var tmp_0 = this.lc_1;
          if (tmp_0 instanceof Exception) {
            var e = this.lc_1;
            this.r5w_1.c58_1.z5r('Failed to update queue size: ' + e.message);
            this.ic_1 = 4;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 3:
          throw this.lc_1;
        case 4:
          this.jc_1 = 3;
          return Unit_instance;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 3) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
function EventQueue(storage, configuration, logger, uploader, scope) {
  this.a58_1 = storage;
  this.b58_1 = configuration;
  this.c58_1 = logger;
  this.d58_1 = uploader;
  this.e58_1 = scope;
  this.f58_1 = null;
  this.g58_1 = MutableStateFlow(new Long(0, 0));
  this.h58_1 = Mutex();
}
protoOf(EventQueue).o58 = function (event, $completion) {
  var tmp = new $enqueueCOROUTINE$22(this, event, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(EventQueue).j58 = function () {
  var tmp0_safe_receiver = this.f58_1;
  if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.vm()) === true) {
    this.c58_1.n56('Auto flush already running');
    return Unit_instance;
  }
  var tmp = this;
  tmp.f58_1 = launch(this.e58_1, VOID, VOID, EventQueue$startAutoFlush$slambda_0(this, null));
  this.c58_1.n56('Auto flush started with interval: ' + new Duration(this.b58_1.o57_1));
};
protoOf(EventQueue).k58 = function () {
  var tmp0_safe_receiver = this.f58_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    tmp0_safe_receiver.co();
  }
  this.f58_1 = null;
  this.c58_1.n56('Auto flush stopped');
};
protoOf(EventQueue).i58 = function ($completion) {
  var tmp = new $flushCOROUTINE$24(this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
function Companion_16() {
}
protoOf(Companion_16).u4i = function () {
  return $serializer_getInstance_13();
};
var Companion_instance_19;
function Companion_getInstance_22() {
  return Companion_instance_19;
}
function $serializer_13() {
  $serializer_instance_13 = this;
  var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('com.exacaster.analytics.storage.StoredEvent', this, 3);
  tmp0_serialDesc.w41('eventId', false);
  tmp0_serialDesc.w41('eventData', false);
  tmp0_serialDesc.w41('retryCount', false);
  this.r5y_1 = tmp0_serialDesc;
}
protoOf($serializer_13).z3q = function () {
  return this.r5y_1;
};
protoOf($serializer_13).l42 = function () {
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return [StringSerializer_getInstance(), StringSerializer_getInstance(), LongSerializer_getInstance()];
};
protoOf($serializer_13).n3r = function (decoder) {
  var tmp0_desc = this.r5y_1;
  var tmp1_flag = true;
  var tmp2_index = 0;
  var tmp3_bitMask0 = 0;
  var tmp4_local0 = null;
  var tmp5_local1 = null;
  var tmp6_local2 = new Long(0, 0);
  var tmp7_input = decoder.m3u(tmp0_desc);
  if (tmp7_input.b3v()) {
    tmp4_local0 = tmp7_input.w3u(tmp0_desc, 0);
    tmp3_bitMask0 = tmp3_bitMask0 | 1;
    tmp5_local1 = tmp7_input.w3u(tmp0_desc, 1);
    tmp3_bitMask0 = tmp3_bitMask0 | 2;
    tmp6_local2 = tmp7_input.s3u(tmp0_desc, 2);
    tmp3_bitMask0 = tmp3_bitMask0 | 4;
  } else
    while (tmp1_flag) {
      tmp2_index = tmp7_input.c3v(tmp0_desc);
      switch (tmp2_index) {
        case -1:
          tmp1_flag = false;
          break;
        case 0:
          tmp4_local0 = tmp7_input.w3u(tmp0_desc, 0);
          tmp3_bitMask0 = tmp3_bitMask0 | 1;
          break;
        case 1:
          tmp5_local1 = tmp7_input.w3u(tmp0_desc, 1);
          tmp3_bitMask0 = tmp3_bitMask0 | 2;
          break;
        case 2:
          tmp6_local2 = tmp7_input.s3u(tmp0_desc, 2);
          tmp3_bitMask0 = tmp3_bitMask0 | 4;
          break;
        default:
          throw UnknownFieldException_init_$Create$(tmp2_index);
      }
    }
  tmp7_input.n3u(tmp0_desc);
  return StoredEvent_init_$Create$(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
};
protoOf($serializer_13).s5y = function (encoder, value) {
  var tmp0_desc = this.r5y_1;
  var tmp1_output = encoder.m3u(tmp0_desc);
  tmp1_output.a3w(tmp0_desc, 0, value.s5p_1);
  tmp1_output.a3w(tmp0_desc, 1, value.t5p_1);
  tmp1_output.w3v(tmp0_desc, 2, value.u5p_1);
  tmp1_output.n3u(tmp0_desc);
};
protoOf($serializer_13).m3r = function (encoder, value) {
  return this.s5y(encoder, value instanceof StoredEvent ? value : THROW_CCE());
};
var $serializer_instance_13;
function $serializer_getInstance_13() {
  if ($serializer_instance_13 == null)
    new $serializer_13();
  return $serializer_instance_13;
}
function StoredEvent_init_$Init$(seen1, eventId, eventData, retryCount, serializationConstructorMarker, $this) {
  if (!(7 === (7 & seen1))) {
    throwMissingFieldException(seen1, 7, $serializer_getInstance_13().r5y_1);
  }
  $this.s5p_1 = eventId;
  $this.t5p_1 = eventData;
  $this.u5p_1 = retryCount;
  return $this;
}
function StoredEvent_init_$Create$(seen1, eventId, eventData, retryCount, serializationConstructorMarker) {
  return StoredEvent_init_$Init$(seen1, eventId, eventData, retryCount, serializationConstructorMarker, objectCreate(protoOf(StoredEvent)));
}
function StoredEvent(eventId, eventData, retryCount) {
  this.s5p_1 = eventId;
  this.t5p_1 = eventData;
  this.u5p_1 = retryCount;
}
protoOf(StoredEvent).t5y = function (eventId, eventData, retryCount) {
  return new StoredEvent(eventId, eventData, retryCount);
};
protoOf(StoredEvent).u5y = function (eventId, eventData, retryCount, $super) {
  eventId = eventId === VOID ? this.s5p_1 : eventId;
  eventData = eventData === VOID ? this.t5p_1 : eventData;
  retryCount = retryCount === VOID ? this.u5p_1 : retryCount;
  return $super === VOID ? this.t5y(eventId, eventData, retryCount) : $super.t5y.call(this, eventId, eventData, retryCount);
};
protoOf(StoredEvent).toString = function () {
  return 'StoredEvent(eventId=' + this.s5p_1 + ', eventData=' + this.t5p_1 + ', retryCount=' + this.u5p_1.toString() + ')';
};
protoOf(StoredEvent).hashCode = function () {
  var result = getStringHashCode(this.s5p_1);
  result = imul(result, 31) + getStringHashCode(this.t5p_1) | 0;
  result = imul(result, 31) + this.u5p_1.hashCode() | 0;
  return result;
};
protoOf(StoredEvent).equals = function (other) {
  if (this === other)
    return true;
  if (!(other instanceof StoredEvent))
    return false;
  var tmp0_other_with_cast = other instanceof StoredEvent ? other : THROW_CCE();
  if (!(this.s5p_1 === tmp0_other_with_cast.s5p_1))
    return false;
  if (!(this.t5p_1 === tmp0_other_with_cast.t5p_1))
    return false;
  if (!this.u5p_1.equals(tmp0_other_with_cast.u5p_1))
    return false;
  return true;
};
function getCachedEvents($this) {
  if ($this.a5z_1 == null) {
    $this.w5y_1.n56('Event cache is cold. Loading from settings.');
    var tmp = $this;
    var tmp_0;
    try {
      tmp_0 = toMutableList(decodeValue($this.v5y_1, $this.y5y_1, $this.x5y_1, emptyList()));
    } catch ($p) {
      var tmp_1;
      if ($p instanceof Exception) {
        var e = $p;
        $this.w5y_1.z57('Failed to decode events from settings, clearing corrupted data.', e);
        $this.v5y_1.x1x($this.x5y_1);
        // Inline function 'kotlin.collections.mutableListOf' call
        tmp_1 = ArrayList_init_$Create$();
      } else {
        throw $p;
      }
      tmp_0 = tmp_1;
    }
    tmp.a5z_1 = tmp_0;
  }
  return ensureNotNull($this.a5z_1);
}
function persist($this, $completion) {
  try {
    encodeValue($this.v5y_1, $this.y5y_1, $this.x5y_1, getCachedEvents($this));
  } catch ($p) {
    if ($p instanceof Exception) {
      var e = $p;
      $this.w5y_1.z57('Failed to persist events to settings.', e);
    } else {
      throw $p;
    }
  }
  return Unit_instance;
}
function SettingsEventStorage$deleteEvents$lambda($idSet) {
  return function (it) {
    return $idSet.z(it.s5p_1);
  };
}
function $insertEventCOROUTINE$27(_this__u8e3s4, event, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.j5z_1 = _this__u8e3s4;
  this.k5z_1 = event;
}
protoOf($insertEventCOROUTINE$27).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 6;
          var tmp_0 = this;
          tmp_0.l5z_1 = this.j5z_1.z5y_1;
          var tmp_1 = this;
          tmp_1.m5z_1 = null;
          this.ic_1 = 1;
          suspendResult = this.l5z_1.g1a(this.m5z_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.ic_1 = 2;
          continue $sm;
        case 2:
          this.jc_1 = 5;
          this.o5z_1 = new StoredEvent(this.k5z_1.n5i(), Default_getInstance_1().g3s(Companion_instance_5.u4i(), this.k5z_1), new Long(0, 0));
          getCachedEvents(this.j5z_1).r(this.o5z_1);
          this.ic_1 = 3;
          suspendResult = persist(this.j5z_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 3:
          this.n5z_1 = suspendResult;
          this.jc_1 = 6;
          this.ic_1 = 4;
          continue $sm;
        case 4:
          this.jc_1 = 6;
          this.l5z_1.r19(this.m5z_1);
          return Unit_instance;
        case 5:
          this.jc_1 = 6;
          var t = this.lc_1;
          this.l5z_1.r19(this.m5z_1);
          throw t;
        case 6:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 6) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $getPendingEventsCOROUTINE$28(_this__u8e3s4, limit, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.x5z_1 = _this__u8e3s4;
  this.y5z_1 = limit;
}
protoOf($getPendingEventsCOROUTINE$28).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          var tmp_0 = this;
          tmp_0.z5z_1 = this.x5z_1.z5y_1;
          var tmp_1 = this;
          tmp_1.a60_1 = null;
          this.ic_1 = 1;
          suspendResult = this.z5z_1.g1a(this.a60_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var tmp$ret$0;
          l$ret$1: do {
            var tmp_2;
            try {
              tmp$ret$0 = take(getCachedEvents(this.x5z_1), this.y5z_1);
              break l$ret$1;
            } catch ($p) {
              var tmp_3;
              var t = $p;
              this.z5z_1.r19(this.a60_1);
              throw t;
            }
          }
           while (false);
          var tmp_4 = tmp$ret$0;
          this.z5z_1.r19(this.a60_1);
          return tmp_4;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $getPendingEventsCountCOROUTINE$29(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.j60_1 = _this__u8e3s4;
}
protoOf($getPendingEventsCountCOROUTINE$29).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 2;
          var tmp_0 = this;
          tmp_0.k60_1 = this.j60_1.z5y_1;
          var tmp_1 = this;
          tmp_1.l60_1 = null;
          this.ic_1 = 1;
          suspendResult = this.k60_1.g1a(this.l60_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          var tmp$ret$0;
          l$ret$1: do {
            var tmp_2;
            try {
              var this_0 = getCachedEvents(this.j60_1);
              tmp$ret$0 = toLong_0(this_0.n());
              break l$ret$1;
            } catch ($p) {
              var tmp_3;
              var t = $p;
              this.k60_1.r19(this.l60_1);
              throw t;
            }
          }
           while (false);
          var tmp_4 = tmp$ret$0;
          this.k60_1.r19(this.l60_1);
          return tmp_4;
        case 2:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 2) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $incrementRetryCountCOROUTINE$30(_this__u8e3s4, eventId, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.u60_1 = _this__u8e3s4;
  this.v60_1 = eventId;
}
protoOf($incrementRetryCountCOROUTINE$30).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 6;
          var tmp_0 = this;
          tmp_0.w60_1 = this.u60_1.z5y_1;
          var tmp_1 = this;
          tmp_1.x60_1 = null;
          this.ic_1 = 1;
          suspendResult = this.w60_1.g1a(this.x60_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.ic_1 = 2;
          continue $sm;
        case 2:
          this.jc_1 = 5;
          var tmp_2 = this;
          var this_0 = getCachedEvents(this.u60_1);
          var tmp$ret$0;
          l$ret$1: do {
            var tmp0_iterator = this_0.u();
            while (tmp0_iterator.v()) {
              var element = tmp0_iterator.w();
              if (element.s5p_1 === this.v60_1) {
                tmp$ret$0 = element;
                break l$ret$1;
              }
            }
            tmp$ret$0 = null;
          }
           while (false);
          tmp_2.z60_1 = tmp$ret$0;
          if (!(this.z60_1 == null)) {
            var index = getCachedEvents(this.u60_1).t1(this.z60_1);
            if (!(index === -1)) {
              var tmp_3 = getCachedEvents(this.u60_1);
              var this_1 = this.z60_1.u5p_1;
              tmp_3.o(index, this.z60_1.u5y(VOID, VOID, this_1.lb(toLong_0(1))));
            }
          }

          this.ic_1 = 3;
          suspendResult = persist(this.u60_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 3:
          this.y60_1 = suspendResult;
          this.jc_1 = 6;
          this.ic_1 = 4;
          continue $sm;
        case 4:
          this.jc_1 = 6;
          this.w60_1.r19(this.x60_1);
          return Unit_instance;
        case 5:
          this.jc_1 = 6;
          var t = this.lc_1;
          this.w60_1.r19(this.x60_1);
          throw t;
        case 6:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 6) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $deleteEventsCOROUTINE$32(_this__u8e3s4, eventIds, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.i61_1 = _this__u8e3s4;
  this.j61_1 = eventIds;
}
protoOf($deleteEventsCOROUTINE$32).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 6;
          var tmp_0 = this;
          tmp_0.k61_1 = this.i61_1.z5y_1;
          var tmp_1 = this;
          tmp_1.l61_1 = null;
          this.ic_1 = 1;
          suspendResult = this.k61_1.g1a(this.l61_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.ic_1 = 2;
          continue $sm;
        case 2:
          this.jc_1 = 5;
          this.n61_1 = toSet(this.j61_1);
          var tmp_2 = getCachedEvents(this.i61_1);
          removeAll(tmp_2, SettingsEventStorage$deleteEvents$lambda(this.n61_1));
          this.ic_1 = 3;
          suspendResult = persist(this.i61_1, this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 3:
          this.m61_1 = suspendResult;
          this.jc_1 = 6;
          this.ic_1 = 4;
          continue $sm;
        case 4:
          this.jc_1 = 6;
          this.k61_1.r19(this.l61_1);
          return Unit_instance;
        case 5:
          this.jc_1 = 6;
          var t = this.lc_1;
          this.k61_1.r19(this.l61_1);
          throw t;
        case 6:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 6) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function SettingsEventStorage(settings, logger) {
  this.v5y_1 = settings;
  this.w5y_1 = logger;
  this.x5y_1 = 'exacaster_analytics_event_queue';
  this.y5y_1 = ListSerializer(Companion_instance_19.u4i());
  this.z5y_1 = Mutex();
  this.a5z_1 = null;
}
protoOf(SettingsEventStorage).y5x = function (event, $completion) {
  var tmp = new $insertEventCOROUTINE$27(this, event, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(SettingsEventStorage).z5x = function (limit, $completion) {
  var tmp = new $getPendingEventsCOROUTINE$28(this, limit, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(SettingsEventStorage).q5y = function ($completion) {
  var tmp = new $getPendingEventsCountCOROUTINE$29(this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(SettingsEventStorage).f5s = function (eventId, $completion) {
  var tmp = new $incrementRetryCountCOROUTINE$30(this, eventId, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(SettingsEventStorage).t5r = function (eventIds, $completion) {
  var tmp = new $deleteEventsCOROUTINE$32(this, eventIds, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
function SettingsPreferencesStorage(settings) {
  this.o61_1 = settings;
  this.p61_1 = 'user_id';
  this.q61_1 = 'anonymous_id';
  this.r61_1 = 'is_opted_out';
}
protoOf(SettingsPreferencesStorage).o56 = function () {
  return this.o61_1.k55(this.p61_1);
};
protoOf(SettingsPreferencesStorage).q58 = function (userId) {
  this.o61_1.j55(this.p61_1, userId);
};
protoOf(SettingsPreferencesStorage).p56 = function () {
  return this.o61_1.k55(this.q61_1);
};
protoOf(SettingsPreferencesStorage).q56 = function (anonymousId) {
  this.o61_1.j55(this.q61_1, anonymousId);
};
protoOf(SettingsPreferencesStorage).r56 = function () {
  return this.o61_1.q55(this.r61_1, false);
};
protoOf(SettingsPreferencesStorage).r58 = function (optOut) {
  this.o61_1.p55(this.r61_1, optOut);
};
protoOf(SettingsPreferencesStorage).x = function () {
  this.o61_1.x1x(this.p61_1);
  this.o61_1.x1x(this.q61_1);
  this.o61_1.x1x(this.r61_1);
};
function BatchIdGenerator$generate$lambda(byte) {
  return padStart(toString_1(byte & 255, 16), 2, _Char___init__impl__6a9atx(48));
}
function BatchIdGenerator() {
  this.u5r_1 = 16;
}
protoOf(BatchIdGenerator).v5r = function () {
  var bytes = Default_getInstance().yg(16);
  return joinToString(bytes, '', VOID, VOID, VOID, VOID, BatchIdGenerator$generate$lambda);
};
var BatchIdGenerator_instance;
function BatchIdGenerator_getInstance() {
  return BatchIdGenerator_instance;
}
function AnalyticsLogger() {
}
function DefaultLogger(enabled) {
  this.s61_1 = enabled;
  this.t61_1 = 'ExacasterAnalytics';
}
protoOf(DefaultLogger).n56 = function (message) {
  if (this.s61_1) {
    println('[' + this.t61_1 + '] DEBUG: ' + message);
  }
};
protoOf(DefaultLogger).n5d = function (message) {
  if (this.s61_1) {
    println('[' + this.t61_1 + '] INFO: ' + message);
  }
};
protoOf(DefaultLogger).m5d = function (message) {
  if (this.s61_1) {
    println('[' + this.t61_1 + '] WARN: ' + message);
  }
};
protoOf(DefaultLogger).z57 = function (message, throwable) {
  if (this.s61_1) {
    println('[' + this.t61_1 + '] ERROR: ' + message);
    if (throwable == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.contracts.contract' call
      println('[' + this.t61_1 + '] ERROR: ' + stackTraceToString(throwable));
    }
  }
};
function NoOpLogger() {
}
protoOf(NoOpLogger).n56 = function (message) {
};
protoOf(NoOpLogger).n5d = function (message) {
};
protoOf(NoOpLogger).m5d = function (message) {
};
protoOf(NoOpLogger).z57 = function (message, throwable) {
};
var NoOpLogger_instance;
function NoOpLogger_getInstance() {
  return NoOpLogger_instance;
}
function SystemTimeProvider() {
}
protoOf(SystemTimeProvider).t58 = function () {
  return System_instance.p4t().z4t();
};
function Analytics$track$lambda$lambda($properties) {
  return function ($this$properties) {
    $this$properties.j2($properties);
    return Unit_instance;
  };
}
function Analytics$track$lambda$lambda_0($context) {
  return function ($this$context) {
    $this$context.j2($context);
    return Unit_instance;
  };
}
function Analytics$track$lambda($properties, $context) {
  return function ($this$track) {
    $this$track.r5e(Analytics$track$lambda$lambda($properties));
    $this$track.s5e(Analytics$track$lambda$lambda_0($context));
    return Unit_instance;
  };
}
function Analytics$identify$lambda$lambda($properties) {
  return function ($this$properties) {
    $this$properties.j2($properties);
    return Unit_instance;
  };
}
function Analytics$identify$lambda$lambda_0($context) {
  return function ($this$context) {
    $this$context.j2($context);
    return Unit_instance;
  };
}
function Analytics$identify$lambda($properties, $context) {
  return function ($this$identify) {
    $this$identify.r5e(Analytics$identify$lambda$lambda($properties));
    $this$identify.s5e(Analytics$identify$lambda$lambda_0($context));
    return Unit_instance;
  };
}
function Analytics$screen$lambda$lambda($properties) {
  return function ($this$properties) {
    $this$properties.j2($properties);
    return Unit_instance;
  };
}
function Analytics$screen$lambda$lambda_0($context) {
  return function ($this$context) {
    $this$context.j2($context);
    return Unit_instance;
  };
}
function Analytics$screen$lambda($properties, $context) {
  return function ($this$screen) {
    $this$screen.r5e(Analytics$screen$lambda$lambda($properties));
    $this$screen.s5e(Analytics$screen$lambda$lambda_0($context));
    return Unit_instance;
  };
}
function Analytics$lifecycle$lambda$lambda($properties) {
  return function ($this$properties) {
    $this$properties.j2($properties);
    return Unit_instance;
  };
}
function Analytics$lifecycle$lambda$lambda_0($context) {
  return function ($this$context) {
    $this$context.j2($context);
    return Unit_instance;
  };
}
function Analytics$lifecycle$lambda($properties, $context) {
  return function ($this$lifecycle) {
    $this$lifecycle.r5e(Analytics$lifecycle$lambda$lambda($properties));
    $this$lifecycle.s5e(Analytics$lifecycle$lambda$lambda_0($context));
    return Unit_instance;
  };
}
function Analytics_0() {
}
protoOf(Analytics_0).initialize = function (configuration) {
  var tmp = configuration.writeKey;
  var tmp_0 = configuration.endpoint;
  var tmp0_safe_receiver = configuration.flushIntervalSeconds;
  var tmp_1;
  if (tmp0_safe_receiver == null) {
    tmp_1 = null;
  } else {
    // Inline function 'kotlin.time.Companion.seconds' call
    Companion_getInstance();
    tmp_1 = toDuration_1(tmp0_safe_receiver, DurationUnit_SECONDS_getInstance());
  }
  var tmp1_elvis_lhs = tmp_1;
  var tmp_2;
  var tmp_3 = tmp1_elvis_lhs;
  if ((tmp_3 == null ? null : new Duration(tmp_3)) == null) {
    // Inline function 'kotlin.time.Companion.seconds' call
    Companion_getInstance();
    tmp_2 = toDuration(30, DurationUnit_SECONDS_getInstance());
  } else {
    tmp_2 = tmp1_elvis_lhs;
  }
  var tmp_4 = tmp_2;
  var tmp2_elvis_lhs = configuration.flushQueueSize;
  var tmp_5 = tmp2_elvis_lhs == null ? 20 : tmp2_elvis_lhs;
  var tmp3_elvis_lhs = configuration.maxQueueSize;
  var tmp_6 = tmp3_elvis_lhs == null ? 1000 : tmp3_elvis_lhs;
  var tmp4_elvis_lhs = configuration.maxBatchSize;
  var tmp_7 = tmp4_elvis_lhs == null ? 500 : tmp4_elvis_lhs;
  var tmp5_elvis_lhs = configuration.enableDebugLogging;
  var tmp_8 = tmp5_elvis_lhs == null ? true : tmp5_elvis_lhs;
  var tmp6_elvis_lhs = configuration.trackApplicationLifecycle;
  var tmp_9 = tmp6_elvis_lhs == null ? true : tmp6_elvis_lhs;
  var tmp7_elvis_lhs = configuration.collectAdvertisingId;
  var tmp_10 = tmp7_elvis_lhs == null ? true : tmp7_elvis_lhs;
  var tmp8_elvis_lhs = configuration.collectLocation;
  var tmp_11 = tmp8_elvis_lhs == null ? true : tmp8_elvis_lhs;
  var tmp9_elvis_lhs = configuration.enableEncryption;
  var config = new AnalyticsConfiguration(tmp, tmp_0, tmp_4, tmp_5, tmp_6, tmp_7, tmp_8, tmp_9, tmp_10, tmp_11, tmp9_elvis_lhs == null ? false : tmp9_elvis_lhs);
  var settings = new StorageSettings();
  var tmp10_elvis_lhs = configuration.appName;
  var tmp_12 = tmp10_elvis_lhs == null ? 'Web Application' : tmp10_elvis_lhs;
  var tmp11_elvis_lhs = configuration.appVersion;
  var tmp_13 = tmp11_elvis_lhs == null ? '1.0.0' : tmp11_elvis_lhs;
  var tmp12_elvis_lhs = configuration.appBuild;
  var contextCollector = new JsContextCollector(tmp_12, tmp_13, tmp12_elvis_lhs == null ? '1' : tmp12_elvis_lhs, VOID, config.v57_1);
  var lifecycleTracker = new JsLifecycleTracker();
  ExacasterAnalytics_getInstance().l5d(config, settings, contextCollector, lifecycleTracker);
};
protoOf(Analytics_0).u61 = function (eventName, properties, context) {
  var tmp = ExacasterAnalytics_getInstance();
  tmp.q5d(eventName, Analytics$track$lambda(properties, context));
};
protoOf(Analytics_0).track = function (eventName, properties, context, $super) {
  properties = properties === VOID ? emptyMap() : properties;
  context = context === VOID ? emptyMap() : context;
  return this.u61(eventName, properties, context);
};
protoOf(Analytics_0).v61 = function (userId, properties, context) {
  var tmp = ExacasterAnalytics_getInstance();
  tmp.s5d(userId, Analytics$identify$lambda(properties, context));
};
protoOf(Analytics_0).identify = function (userId, properties, context, $super) {
  properties = properties === VOID ? emptyMap() : properties;
  context = context === VOID ? emptyMap() : context;
  return this.v61(userId, properties, context);
};
protoOf(Analytics_0).w61 = function (screenName, properties, context) {
  var tmp = ExacasterAnalytics_getInstance();
  tmp.r5d(screenName, Analytics$screen$lambda(properties, context));
};
protoOf(Analytics_0).screen = function (screenName, properties, context, $super) {
  properties = properties === VOID ? emptyMap() : properties;
  context = context === VOID ? emptyMap() : context;
  return this.w61(screenName, properties, context);
};
protoOf(Analytics_0).x61 = function (lifecycleState, properties, context) {
  try {
    // Inline function 'kotlin.enumValueOf' call
    var state = valueOf(lifecycleState);
    var tmp = ExacasterAnalytics_getInstance();
    tmp.p5d(state, Analytics$lifecycle$lambda(properties, context));
  } catch ($p) {
    if ($p instanceof IllegalArgumentException) {
      var e = $p;
      console.error('Unknown lifecycle state: ' + lifecycleState + '. Please use one of Analytics.LifecycleState values.');
    } else {
      throw $p;
    }
  }
};
protoOf(Analytics_0).lifecycle = function (lifecycleState, properties, context, $super) {
  properties = properties === VOID ? emptyMap() : properties;
  context = context === VOID ? emptyMap() : context;
  return this.x61(lifecycleState, properties, context);
};
protoOf(Analytics_0).flush = function () {
  ExacasterAnalytics_getInstance().f6();
};
protoOf(Analytics_0).optIn = function () {
  ExacasterAnalytics_getInstance().u5d();
};
protoOf(Analytics_0).optOut = function () {
  ExacasterAnalytics_getInstance().t5d();
};
protoOf(Analytics_0).reset = function () {
  ExacasterAnalytics_getInstance().x1m();
};
var Analytics_instance;
function Analytics_getInstance() {
  return Analytics_instance;
}
function JsAnalyticsConfiguration() {
}
function _get_locationCollector__muqubd($this) {
  // Inline function 'kotlin.getValue' call
  var this_0 = $this.r62_1;
  locationCollector$factory();
  return this_0.l2();
}
function collectLocationInfo($this, $completion) {
  var tmp = new $collectLocationInfoCOROUTINE$34($this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
}
function collectApplicationInfo($this) {
  return new ApplicationInfo($this.m62_1, $this.n62_1, $this.o62_1, $this.p62_1, $this.o62_1, 'production');
}
function collectDeviceInfo($this) {
  // Inline function 'kotlin.js.asDynamic' call
  var navigator = window.navigator;
  var deviceId = generateDeviceId($this);
  var isMobile = detectMobile($this);
  var isTablet = detectTablet($this);
  var tmp0_container = parseDeviceInfo($this);
  var manufacturer = tmp0_container.we();
  var model = tmp0_container.xe();
  var tmp = navigator.platform;
  var tmp1_elvis_lhs = (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : null;
  return new DeviceInfo(deviceId, manufacturer, model, tmp1_elvis_lhs == null ? 'Unknown' : tmp1_elvis_lhs, DeviceType_WEB_getInstance(), null, false, null, manufacturer, 'Browser', isTablet);
}
function collectNetworkInfo($this) {
  // Inline function 'kotlin.js.asDynamic' call
  var navigator = window.navigator;
  var tmp0_elvis_lhs = navigator.connection;
  var tmp1_elvis_lhs = tmp0_elvis_lhs == null ? navigator.mozConnection : tmp0_elvis_lhs;
  var tmp2_elvis_lhs = tmp1_elvis_lhs == null ? navigator.webkitConnection : tmp1_elvis_lhs;
  var tmp;
  if (tmp2_elvis_lhs == null) {
    return null;
  } else {
    tmp = tmp2_elvis_lhs;
  }
  var connection = tmp;
  var tmp_0;
  try {
    var tmp_1 = connection.type;
    var tmp3_safe_receiver = (!(tmp_1 == null) ? typeof tmp_1 === 'string' : false) ? tmp_1 : null;
    var tmp_2 = (tmp3_safe_receiver == null ? null : contains_0(tmp3_safe_receiver, 'cellular')) === true;
    var tmp_3 = connection.type;
    var tmp4_safe_receiver = (!(tmp_3 == null) ? typeof tmp_3 === 'string' : false) ? tmp_3 : null;
    var tmp_4 = (tmp4_safe_receiver == null ? null : contains_0(tmp4_safe_receiver, 'wifi')) === true;
    var tmp_5 = connection.effectiveType;
    var tmp_6 = (!(tmp_5 == null) ? typeof tmp_5 === 'string' : false) ? tmp_5 : null;
    var tmp_7 = connection.type;
    tmp_0 = new NetworkInfo(null, tmp_2, tmp_4, false, tmp_6, (!(tmp_7 == null) ? typeof tmp_7 === 'string' : false) ? tmp_7 : null);
  } catch ($p) {
    var tmp_8;
    if ($p instanceof Exception) {
      var e = $p;
      tmp_8 = null;
    } else {
      throw $p;
    }
    tmp_0 = tmp_8;
  }
  return tmp_0;
}
function collectScreenInfo($this) {
  var screen = window.screen;
  var devicePixelRatio = window.devicePixelRatio;
  return new ScreenInfo(screen.width, screen.height, devicePixelRatio);
}
function collectOSInfo($this) {
  var userAgent = window.navigator.userAgent;
  var tmp0_container = parseOSInfo($this, userAgent);
  var osName = tmp0_container.we();
  var osVersion = tmp0_container.xe();
  return new OSInfo(osName, osVersion);
}
function getLocale($this) {
  // Inline function 'kotlin.js.asDynamic' call
  var navigator = window.navigator;
  var tmp = navigator.language;
  var tmp0_elvis_lhs = (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : null;
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    var tmp_1 = navigator.userLanguage;
    tmp_0 = (!(tmp_1 == null) ? typeof tmp_1 === 'string' : false) ? tmp_1 : null;
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var tmp1_elvis_lhs = tmp_0;
  return tmp1_elvis_lhs == null ? 'en-US' : tmp1_elvis_lhs;
}
function getTimezone($this) {
  var tmp;
  try {
    var tmp_0 = Intl.DateTimeFormat().resolvedOptions().timeZone;
    tmp = (!(tmp_0 == null) ? typeof tmp_0 === 'string' : false) ? tmp_0 : THROW_CCE();
  } catch ($p) {
    var tmp_1;
    if ($p instanceof Exception) {
      var e = $p;
      tmp_1 = 'UTC';
    } else {
      throw $p;
    }
    tmp = tmp_1;
  }
  return tmp;
}
function generateDeviceId($this) {
  // Inline function 'kotlin.js.asDynamic' call
  var navigator = window.navigator;
  var screen = window.screen;
  var tmp = navigator.userAgent;
  var tmp0_elvis_lhs = (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : null;
  var tmp_0 = tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs;
  var tmp_1 = navigator.language;
  var tmp1_elvis_lhs = (!(tmp_1 == null) ? typeof tmp_1 === 'string' : false) ? tmp_1 : null;
  var components = listOf([tmp_0, tmp1_elvis_lhs == null ? '' : tmp1_elvis_lhs, screen.width.toString(), screen.height.toString(), screen.colorDepth.toString(), window.devicePixelRatio.toString()]);
  return getStringHashCode(joinToString_0(components, '|')).toString();
}
function detectMobile($this) {
  // Inline function 'kotlin.text.lowercase' call
  // Inline function 'kotlin.js.asDynamic' call
  var userAgent = window.navigator.userAgent.toLowerCase();
  var mobileKeywords = listOf(['mobile', 'android', 'iphone', 'ipod', 'blackberry', 'windows phone']);
  var tmp$ret$2;
  $l$block_0: {
    // Inline function 'kotlin.collections.any' call
    var tmp;
    if (isInterface(mobileKeywords, Collection)) {
      tmp = mobileKeywords.b1();
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$2 = false;
      break $l$block_0;
    }
    var tmp0_iterator = mobileKeywords.u();
    while (tmp0_iterator.v()) {
      var element = tmp0_iterator.w();
      // Inline function 'com.exacaster.analytics.collectors.JsContextCollector.detectMobile.<anonymous>' call
      if (contains_0(userAgent, element)) {
        tmp$ret$2 = true;
        break $l$block_0;
      }
    }
    tmp$ret$2 = false;
  }
  return tmp$ret$2;
}
function detectTablet($this) {
  // Inline function 'kotlin.text.lowercase' call
  // Inline function 'kotlin.js.asDynamic' call
  var userAgent = window.navigator.userAgent.toLowerCase();
  var tabletKeywords = listOf(['ipad', 'tablet', 'kindle', 'playbook', 'nexus 7', 'nexus 10']);
  // Inline function 'kotlin.js.asDynamic' call
  var tmp = window.navigator.maxTouchPoints;
  var tmp0_elvis_lhs = (!(tmp == null) ? typeof tmp === 'number' : false) ? tmp : null;
  var hasTouchSupport = (tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs) > 0;
  var hasLargeScreen = window.screen.width >= 768;
  var tmp_0;
  var tmp$ret$3;
  $l$block_0: {
    // Inline function 'kotlin.collections.any' call
    var tmp_1;
    if (isInterface(tabletKeywords, Collection)) {
      tmp_1 = tabletKeywords.b1();
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp$ret$3 = false;
      break $l$block_0;
    }
    var tmp0_iterator = tabletKeywords.u();
    while (tmp0_iterator.v()) {
      var element = tmp0_iterator.w();
      // Inline function 'com.exacaster.analytics.collectors.JsContextCollector.detectTablet.<anonymous>' call
      if (contains_0(userAgent, element)) {
        tmp$ret$3 = true;
        break $l$block_0;
      }
    }
    tmp$ret$3 = false;
  }
  if (tmp$ret$3) {
    tmp_0 = true;
  } else {
    tmp_0 = (hasTouchSupport ? hasLargeScreen : false) ? !detectMobile($this) : false;
  }
  return tmp_0;
}
function parseDeviceInfo($this) {
  var userAgent = window.navigator.userAgent;
  var tmp;
  if (contains_0(userAgent, 'iPhone') ? true : contains_0(userAgent, 'iPad')) {
    tmp = new Pair('Apple', contains_0(userAgent, 'iPad') ? 'iPad' : 'iPhone');
  } else if (contains_0(userAgent, 'Android')) {
    var androidRegex = Regex_init_$Create$('Android.*?;\\s*([^;)]+)');
    var match = androidRegex.z8(userAgent);
    var tmp1_safe_receiver = match == null ? null : match.o9();
    var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.f1(1);
    var tmp_0;
    if (tmp2_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.text.trim' call
      tmp_0 = toString(trim(isCharSequence(tmp2_safe_receiver) ? tmp2_safe_receiver : THROW_CCE()));
    }
    var tmp3_elvis_lhs = tmp_0;
    var deviceInfo = tmp3_elvis_lhs == null ? 'Android Device' : tmp3_elvis_lhs;
    tmp = new Pair('Android', deviceInfo);
  } else if (contains_0(userAgent, 'Windows')) {
    tmp = new Pair('Microsoft', 'Windows PC');
  } else if (contains_0(userAgent, 'Macintosh') ? true : contains_0(userAgent, 'Mac OS')) {
    tmp = new Pair('Apple', 'Mac');
  } else if (contains_0(userAgent, 'Linux')) {
    tmp = new Pair('Linux', 'Linux PC');
  } else {
    tmp = new Pair('Unknown', 'Unknown');
  }
  return tmp;
}
function parseOSInfo($this, userAgent) {
  var tmp;
  if (contains_0(userAgent, 'Windows NT 10.0')) {
    tmp = new Pair('Windows', '10');
  } else if (contains_0(userAgent, 'Windows NT 6.3')) {
    tmp = new Pair('Windows', '8.1');
  } else if (contains_0(userAgent, 'Windows NT 6.2')) {
    tmp = new Pair('Windows', '8');
  } else if (contains_0(userAgent, 'Windows NT 6.1')) {
    tmp = new Pair('Windows', '7');
  } else if (contains_0(userAgent, 'Windows')) {
    tmp = new Pair('Windows', 'Unknown');
  } else if (contains_0(userAgent, 'Mac OS X')) {
    var versionRegex = Regex_init_$Create$('Mac OS X ([0-9_]+)');
    var tmp0_safe_receiver = versionRegex.z8(userAgent);
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.o9();
    var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.f1(1);
    var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : replace(tmp2_safe_receiver, '_', '.');
    var version = tmp3_elvis_lhs == null ? 'Unknown' : tmp3_elvis_lhs;
    tmp = new Pair('macOS', version);
  } else if (contains_0(userAgent, 'Android')) {
    var versionRegex_0 = Regex_init_$Create$('Android ([0-9.]+)');
    var tmp4_safe_receiver = versionRegex_0.z8(userAgent);
    var tmp5_safe_receiver = tmp4_safe_receiver == null ? null : tmp4_safe_receiver.o9();
    var tmp6_elvis_lhs = tmp5_safe_receiver == null ? null : tmp5_safe_receiver.f1(1);
    var version_0 = tmp6_elvis_lhs == null ? 'Unknown' : tmp6_elvis_lhs;
    tmp = new Pair('Android', version_0);
  } else if (contains_0(userAgent, 'iPhone') ? true : contains_0(userAgent, 'iPad')) {
    var versionRegex_1 = Regex_init_$Create$('OS ([0-9_]+)');
    var tmp7_safe_receiver = versionRegex_1.z8(userAgent);
    var tmp8_safe_receiver = tmp7_safe_receiver == null ? null : tmp7_safe_receiver.o9();
    var tmp9_safe_receiver = tmp8_safe_receiver == null ? null : tmp8_safe_receiver.f1(1);
    var tmp10_elvis_lhs = tmp9_safe_receiver == null ? null : replace(tmp9_safe_receiver, '_', '.');
    var version_1 = tmp10_elvis_lhs == null ? 'Unknown' : tmp10_elvis_lhs;
    tmp = new Pair('iOS', version_1);
  } else if (contains_0(userAgent, 'Linux')) {
    tmp = new Pair('Linux', 'Unknown');
  } else {
    tmp = new Pair('Unknown', 'Unknown');
  }
  return tmp;
}
function JsContextCollector$locationCollector$delegate$lambda() {
  return new JsLocationCollector();
}
function $collectContextCOROUTINE$33(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.l63_1 = _this__u8e3s4;
}
protoOf($collectContextCOROUTINE$33).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          this.m63_1 = collectApplicationInfo(this.l63_1);
          this.n63_1 = collectDeviceInfo(this.l63_1);
          this.o63_1 = collectNetworkInfo(this.l63_1);
          if (this.l63_1.q62_1) {
            this.ic_1 = 1;
            suspendResult = collectLocationInfo(this.l63_1, this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            this.p63_1 = null;
            this.ic_1 = 2;
            continue $sm;
          }

        case 1:
          this.p63_1 = suspendResult;
          this.ic_1 = 2;
          continue $sm;
        case 2:
          var ARGUMENT = this.p63_1;
          var tmp_0 = collectScreenInfo(this.l63_1);
          var tmp_1 = collectOSInfo(this.l63_1);
          var tmp_2 = getLocale(this.l63_1);
          var tmp_3 = getTimezone(this.l63_1);
          var tmp_4 = window.navigator.userAgent;
          ExacasterAnalytics_getInstance();
          return new EventContext(this.m63_1, this.n63_1, this.o63_1, ARGUMENT, tmp_0, tmp_1, tmp_2, tmp_3, tmp_4, new LibraryInfo('exacaster-analytics', '1.0.0'));
        case 3:
          throw this.lc_1;
      }
    } catch ($p) {
      var e = $p;
      if (this.jc_1 === 3) {
        throw e;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e;
      }
    }
   while (true);
};
function $collectLocationInfoCOROUTINE$34(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.a63_1 = _this__u8e3s4;
}
protoOf($collectLocationInfoCOROUTINE$34).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 5;
          this.jc_1 = 4;
          this.ic_1 = 1;
          suspendResult = _get_locationCollector__muqubd(this.a63_1).q63(this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          if (suspendResult) {
            this.ic_1 = 2;
            suspendResult = _get_locationCollector__muqubd(this.a63_1).r63(this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            var tmp_0 = this;
            tmp_0.c63_1 = null;
            this.ic_1 = 3;
            continue $sm;
          }

        case 2:
          this.c63_1 = suspendResult;
          this.ic_1 = 3;
          continue $sm;
        case 3:
          this.b63_1 = this.c63_1;
          this.jc_1 = 5;
          this.ic_1 = 6;
          continue $sm;
        case 4:
          this.jc_1 = 5;
          var tmp_1 = this.lc_1;
          if (tmp_1 instanceof Exception) {
            var e = this.lc_1;
            var tmp_2 = this;
            tmp_2.b63_1 = null;
            this.ic_1 = 6;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 5:
          throw this.lc_1;
        case 6:
          this.jc_1 = 5;
          return this.b63_1;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 5) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
function JsContextCollector(appName, appVersion, appBuild, appNamespace, collectLocation) {
  appName = appName === VOID ? 'Web Application' : appName;
  appVersion = appVersion === VOID ? '1.0.0' : appVersion;
  appBuild = appBuild === VOID ? '1' : appBuild;
  appNamespace = appNamespace === VOID ? window.location.hostname : appNamespace;
  collectLocation = collectLocation === VOID ? false : collectLocation;
  this.m62_1 = appName;
  this.n62_1 = appVersion;
  this.o62_1 = appBuild;
  this.p62_1 = appNamespace;
  this.q62_1 = collectLocation;
  var tmp = this;
  tmp.r62_1 = lazy_0(JsContextCollector$locationCollector$delegate$lambda);
}
protoOf(JsContextCollector).p58 = function ($completion) {
  var tmp = new $collectContextCOROUTINE$33(this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
function locationCollector$factory() {
  return getPropertyCallableRef('locationCollector', 1, KProperty1, function (receiver) {
    return _get_locationCollector__muqubd(receiver);
  }, null);
}
function JsLocationCollector$hasLocationPermission$lambda($continuation) {
  return function (permissionStatus) {
    var tmp = permissionStatus.state;
    var state = (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : THROW_CCE();
    // Inline function 'kotlin.coroutines.resume' call
    var this_0 = $continuation;
    // Inline function 'kotlin.Companion.success' call
    var value = state === 'granted';
    var tmp$ret$0 = _Result___init__impl__xyqfz8(value);
    this_0.j6(tmp$ret$0);
    return Unit_instance;
  };
}
function JsLocationCollector$hasLocationPermission$lambda_0($continuation) {
  return function (_anonymous_parameter_0__qggqh8) {
    // Inline function 'kotlin.coroutines.resume' call
    var this_0 = $continuation;
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(false);
    this_0.j6(tmp$ret$0);
    return Unit_instance;
  };
}
function JsLocationCollector$getCurrentLocation$lambda($continuation) {
  return function (position) {
    var coords = position.coords;
    var tmp = coords.latitude;
    var tmp_0 = (!(tmp == null) ? typeof tmp === 'number' : false) ? tmp : THROW_CCE();
    var tmp_1 = coords.longitude;
    var tmp_2 = (!(tmp_1 == null) ? typeof tmp_1 === 'number' : false) ? tmp_1 : THROW_CCE();
    var tmp_3 = coords.accuracy;
    var tmp_4 = (!(tmp_3 == null) ? typeof tmp_3 === 'number' : false) ? tmp_3 : null;
    var tmp_5 = coords.altitude;
    var tmp_6 = (!(tmp_5 == null) ? typeof tmp_5 === 'number' : false) ? tmp_5 : null;
    var tmp_7 = coords.speed;
    var locationInfo = new LocationInfo(tmp_0, tmp_2, tmp_4, tmp_6, (!(tmp_7 == null) ? typeof tmp_7 === 'number' : false) ? tmp_7 : null, null, null, null);
    // Inline function 'kotlin.coroutines.resume' call
    var this_0 = $continuation;
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(locationInfo);
    this_0.j6(tmp$ret$0);
    return Unit_instance;
  };
}
function JsLocationCollector$getCurrentLocation$lambda_0($continuation) {
  return function (error) {
    // Inline function 'kotlin.coroutines.resume' call
    var this_0 = $continuation;
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(null);
    this_0.j6(tmp$ret$0);
    return Unit_instance;
  };
}
function $hasLocationPermissionCOROUTINE$35(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.a64_1 = _this__u8e3s4;
}
protoOf($hasLocationPermissionCOROUTINE$35).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 4;
          this.jc_1 = 3;
          var tmp_0 = this;
          tmp_0.c64_1 = window.navigator.permissions;
          if (this.c64_1 != null ? this.c64_1 != undefined : false) {
            this.ic_1 = 1;
            var cancellable = new CancellableContinuationImpl(intercepted(this), get_MODE_CANCELLABLE());
            cancellable.pq();
            this.c64_1.query({name: 'geolocation'}).then(JsLocationCollector$hasLocationPermission$lambda(cancellable)).catch(JsLocationCollector$hasLocationPermission$lambda_0(cancellable));
            suspendResult = returnIfSuspended(cancellable.rq(), this);
            if (suspendResult === get_COROUTINE_SUSPENDED()) {
              return suspendResult;
            }
            continue $sm;
          } else {
            var tmp_1 = this;
            tmp_1.d64_1 = false;
            this.ic_1 = 2;
            continue $sm;
          }

        case 1:
          this.d64_1 = suspendResult;
          this.ic_1 = 2;
          continue $sm;
        case 2:
          this.b64_1 = this.d64_1;
          this.jc_1 = 4;
          this.ic_1 = 5;
          continue $sm;
        case 3:
          this.jc_1 = 4;
          var tmp_2 = this.lc_1;
          if (tmp_2 instanceof Exception) {
            var e = this.lc_1;
            var tmp_3 = this;
            tmp_3.b64_1 = false;
            this.ic_1 = 5;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 4:
          throw this.lc_1;
        case 5:
          this.jc_1 = 4;
          return this.b64_1;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 4) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
function $getCurrentLocationCOROUTINE$36(_this__u8e3s4, resultContinuation) {
  CoroutineImpl.call(this, resultContinuation);
  this.m64_1 = _this__u8e3s4;
}
protoOf($getCurrentLocationCOROUTINE$36).uc = function () {
  var suspendResult = this.kc_1;
  $sm: do
    try {
      var tmp = this.ic_1;
      switch (tmp) {
        case 0:
          this.jc_1 = 3;
          var tmp_0 = this;
          tmp_0.n64_1 = window.navigator;
          this.o64_1 = this.n64_1.geolocation;
          if (this.o64_1 == null ? true : this.o64_1 == undefined) {
            return null;
          }

          this.jc_1 = 2;
          this.ic_1 = 1;
          var cancellable = new CancellableContinuationImpl(intercepted(this), get_MODE_CANCELLABLE());
          cancellable.pq();
          var tmp_1 = JsLocationCollector$getCurrentLocation$lambda(cancellable);
          this.o64_1.getCurrentPosition(tmp_1, JsLocationCollector$getCurrentLocation$lambda_0(cancellable), {enableHighAccuracy: true, timeout: 10000, maximumAge: 0});
          suspendResult = returnIfSuspended(cancellable.rq(), this);
          if (suspendResult === get_COROUTINE_SUSPENDED()) {
            return suspendResult;
          }

          continue $sm;
        case 1:
          this.p64_1 = suspendResult;
          this.jc_1 = 3;
          this.ic_1 = 4;
          continue $sm;
        case 2:
          this.jc_1 = 3;
          var tmp_2 = this.lc_1;
          if (tmp_2 instanceof Exception) {
            var e = this.lc_1;
            var tmp_3 = this;
            tmp_3.p64_1 = null;
            this.ic_1 = 4;
            continue $sm;
          } else {
            throw this.lc_1;
          }

        case 3:
          throw this.lc_1;
        case 4:
          this.jc_1 = 3;
          return this.p64_1;
      }
    } catch ($p) {
      var e_0 = $p;
      if (this.jc_1 === 3) {
        throw e_0;
      } else {
        this.ic_1 = this.jc_1;
        this.lc_1 = e_0;
      }
    }
   while (true);
};
function JsLocationCollector() {
}
protoOf(JsLocationCollector).q63 = function ($completion) {
  var tmp = new $hasLocationPermissionCOROUTINE$35(this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
protoOf(JsLocationCollector).r63 = function ($completion) {
  var tmp = new $getCurrentLocationCOROUTINE$36(this, $completion);
  tmp.kc_1 = Unit_instance;
  tmp.lc_1 = null;
  return tmp.uc();
};
function updateState($this, newState) {
  if (!$this.q64_1.l2().equals(newState)) {
    $this.q64_1.y15(newState);
    var tmp0_safe_receiver = $this.s64_1;
    if (tmp0_safe_receiver == null)
      null;
    else
      tmp0_safe_receiver(newState);
  }
}
function JsLifecycleTracker$startTracking$lambda(this$0) {
  return function (_anonymous_parameter_0__qggqh8) {
    // Inline function 'kotlin.js.asDynamic' call
    var tmp = document.hidden;
    var tmp0_elvis_lhs = (!(tmp == null) ? typeof tmp === 'boolean' : false) ? tmp : null;
    var isHidden = tmp0_elvis_lhs == null ? false : tmp0_elvis_lhs;
    var tmp_0;
    if (isHidden) {
      updateState(this$0, AppLifecycleState_BACKGROUND_getInstance());
      tmp_0 = Unit_instance;
    } else {
      updateState(this$0, AppLifecycleState_FOREGROUND_getInstance());
      tmp_0 = Unit_instance;
    }
    return Unit_instance;
  };
}
function JsLifecycleTracker$startTracking$lambda_0(this$0) {
  return function (_anonymous_parameter_0__qggqh8) {
    updateState(this$0, AppLifecycleState_TERMINATED_getInstance());
    return Unit_instance;
  };
}
function JsLifecycleTracker$startTracking$lambda_1(this$0) {
  return function (_anonymous_parameter_0__qggqh8) {
    updateState(this$0, AppLifecycleState_FOREGROUND_getInstance());
    return Unit_instance;
  };
}
function JsLifecycleTracker() {
  this.q64_1 = MutableStateFlow(AppLifecycleState_FOREGROUND_getInstance());
  this.r64_1 = asStateFlow(this.q64_1);
  this.s64_1 = null;
  this.t64_1 = null;
  this.u64_1 = null;
  this.v64_1 = null;
}
protoOf(JsLifecycleTracker).n58 = function () {
  updateState(this, AppLifecycleState_INITIALIZED_getInstance());
  var tmp = this;
  tmp.t64_1 = JsLifecycleTracker$startTracking$lambda(this);
  document.addEventListener('visibilitychange', this.t64_1);
  var tmp_0 = this;
  tmp_0.u64_1 = JsLifecycleTracker$startTracking$lambda_0(this);
  window.addEventListener('beforeunload', this.u64_1);
  var tmp_1 = this;
  tmp_1.v64_1 = JsLifecycleTracker$startTracking$lambda_1(this);
  window.addEventListener('load', this.v64_1);
  // Inline function 'kotlin.js.asDynamic' call
  var tmp_2 = document.hidden;
  var tmp0_elvis_lhs = (!(tmp_2 == null) ? typeof tmp_2 === 'boolean' : false) ? tmp_2 : null;
  var isHidden = tmp0_elvis_lhs == null ? false : tmp0_elvis_lhs;
  if (!isHidden) {
    updateState(this, AppLifecycleState_FOREGROUND_getInstance());
  }
};
protoOf(JsLifecycleTracker).l58 = function () {
  var tmp0_safe_receiver = this.t64_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    document.removeEventListener('visibilitychange', tmp0_safe_receiver);
  }
  var tmp1_safe_receiver = this.u64_1;
  if (tmp1_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    window.removeEventListener('beforeunload', tmp1_safe_receiver);
  }
  var tmp2_safe_receiver = this.v64_1;
  if (tmp2_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.contracts.contract' call
    window.removeEventListener('load', tmp2_safe_receiver);
  }
  this.t64_1 = null;
  this.u64_1 = null;
  this.v64_1 = null;
};
protoOf(JsLifecycleTracker).m58 = function (callback) {
  this.s64_1 = callback;
};
//region block: post-declaration
protoOf($serializer).m42 = typeParametersSerializers;
protoOf($serializer_0).m42 = typeParametersSerializers;
protoOf($serializer_1).m42 = typeParametersSerializers;
protoOf($serializer_2).m42 = typeParametersSerializers;
protoOf($serializer_3).m42 = typeParametersSerializers;
protoOf($serializer_4).m42 = typeParametersSerializers;
protoOf($serializer_5).m42 = typeParametersSerializers;
protoOf($serializer_6).m42 = typeParametersSerializers;
protoOf($serializer_7).m42 = typeParametersSerializers;
protoOf($serializer_8).m42 = typeParametersSerializers;
protoOf($serializer_9).m42 = typeParametersSerializers;
protoOf($serializer_10).m42 = typeParametersSerializers;
protoOf($serializer_11).m42 = typeParametersSerializers;
protoOf($serializer_12).m42 = typeParametersSerializers;
protoOf($serializer_13).m42 = typeParametersSerializers;
protoOf(DefaultLogger).z5r = error$default;
protoOf(NoOpLogger).z5r = error$default;
//endregion
//region block: init
Companion_instance_2 = new Companion();
Companion_instance_5 = new Companion_2();
Companion_instance_11 = new Companion_8();
Companion_instance_14 = new Companion_11();
Companion_instance_15 = new Companion_12();
Companion_instance_16 = new Companion_13();
Companion_instance_17 = new Companion_14();
Companion_instance_18 = new Companion_15();
NetworkClientFactory_instance = new NetworkClientFactory();
Companion_instance_19 = new Companion_16();
BatchIdGenerator_instance = new BatchIdGenerator();
NoOpLogger_instance = new NoOpLogger();
Analytics_instance = new Analytics_0();
//endregion
//region block: exports
var Analytics = {getInstance: Analytics_getInstance};
export {
  Analytics as Analytics,
};
//endregion

//# sourceMappingURL=exacaster-analytics-library.mjs.map
