import {
  Instant as Instant,
  Clock as Clock,
  OffsetDateTime as OffsetDateTime,
} from '@js-joda/core';
import {
  protoOf180f3jzyo7rfj as protoOf,
  objectMeta213120oau977m as objectMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  IllegalArgumentException_init_$Init$1elycfkdq8or6 as IllegalArgumentException_init_$Init$,
  objectCreate1ve4bgxiu4x98 as objectCreate,
  captureStack1fzi4aczwc4hg as captureStack,
  IllegalArgumentException_init_$Init$2smot2h1gg2y1 as IllegalArgumentException_init_$Init$_0,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  classMetawt99a3kyl3us as classMeta,
  VOID7hggqo3abtya as VOID,
  Long2qws0ah9gnpki as Long,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  indexOf1xbs558u7wr52 as indexOf,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  numberToLong1a4cndvg6c52s as numberToLong,
  numberToInt1ygmcfwhs2fkq as numberToInt,
  toLongw1zpgk99d84b as toLong,
  Comparable198qfk8pnblz0 as Comparable,
} from './kotlin-kotlin-stdlib.mjs';
import {
  STRING_getInstance2ou4lro9xn2qn as STRING_getInstance,
  PrimitiveSerialDescriptor3egfp53lutxj2 as PrimitiveSerialDescriptor,
  KSerializerzf77vz1967fq as KSerializer,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
//region block: imports
//endregion
//region block: pre-declaration
setMetadataFor(System, 'System', objectMeta);
setMetadataFor(DateTimeFormatException, 'DateTimeFormatException', classMeta, IllegalArgumentException, VOID, DateTimeFormatException_init_$Create$);
setMetadataFor(InstantIso8601Serializer, 'InstantIso8601Serializer', objectMeta, VOID, [KSerializer]);
setMetadataFor(Companion, 'Companion', objectMeta);
setMetadataFor(Instant_0, 'Instant', classMeta, VOID, [Comparable], VOID, VOID, {0: InstantIso8601Serializer_getInstance});
//endregion
function System() {
}
protoOf(System).p4t = function () {
  return Companion_getInstance().p4t();
};
var System_instance;
function System_getInstance() {
  return System_instance;
}
function DateTimeFormatException_init_$Init$($this) {
  IllegalArgumentException_init_$Init$($this);
  DateTimeFormatException.call($this);
  return $this;
}
function DateTimeFormatException_init_$Create$() {
  var tmp = DateTimeFormatException_init_$Init$(objectCreate(protoOf(DateTimeFormatException)));
  captureStack(tmp, DateTimeFormatException_init_$Create$);
  return tmp;
}
function DateTimeFormatException_init_$Init$_0(cause, $this) {
  IllegalArgumentException_init_$Init$_0(cause, $this);
  DateTimeFormatException.call($this);
  return $this;
}
function DateTimeFormatException_init_$Create$_0(cause) {
  var tmp = DateTimeFormatException_init_$Init$_0(cause, objectCreate(protoOf(DateTimeFormatException)));
  captureStack(tmp, DateTimeFormatException_init_$Create$_0);
  return tmp;
}
function DateTimeFormatException() {
  captureStack(this, DateTimeFormatException);
}
function get_DISTANT_PAST_SECONDS() {
  return DISTANT_PAST_SECONDS;
}
var DISTANT_PAST_SECONDS;
function get_DISTANT_FUTURE_SECONDS() {
  return DISTANT_FUTURE_SECONDS;
}
var DISTANT_FUTURE_SECONDS;
function get_NANOS_PER_MILLI() {
  return NANOS_PER_MILLI;
}
var NANOS_PER_MILLI;
function get_MILLIS_PER_ONE() {
  return MILLIS_PER_ONE;
}
var MILLIS_PER_ONE;
function InstantIso8601Serializer() {
  InstantIso8601Serializer_instance = this;
  this.u4t_1 = PrimitiveSerialDescriptor('Instant', STRING_getInstance());
}
protoOf(InstantIso8601Serializer).z3q = function () {
  return this.u4t_1;
};
protoOf(InstantIso8601Serializer).n3r = function (decoder) {
  return Companion_getInstance().l21(decoder.i3u());
};
protoOf(InstantIso8601Serializer).v4t = function (encoder, value) {
  encoder.p3v(value.toString());
};
protoOf(InstantIso8601Serializer).m3r = function (encoder, value) {
  return this.v4t(encoder, value instanceof Instant_0 ? value : THROW_CCE());
};
var InstantIso8601Serializer_instance;
function InstantIso8601Serializer_getInstance() {
  if (InstantIso8601Serializer_instance == null)
    new InstantIso8601Serializer();
  return InstantIso8601Serializer_instance;
}
function fixOffsetRepresentation($this, isoString) {
  var time = indexOf(isoString, _Char___init__impl__6a9atx(84), VOID, true);
  if (time === -1)
    return isoString;
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.text.indexOfLast' call
    var inductionVariable = charSequenceLength(isoString) - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        // Inline function 'kotlinx.datetime.Companion.fixOffsetRepresentation.<anonymous>' call
        var c = charSequenceGet(isoString, index);
        if (c === _Char___init__impl__6a9atx(43) ? true : c === _Char___init__impl__6a9atx(45)) {
          tmp$ret$1 = index;
          break $l$block;
        }
      }
       while (0 <= inductionVariable);
    tmp$ret$1 = -1;
  }
  var offset = tmp$ret$1;
  if (offset < time)
    return isoString;
  var separator = indexOf(isoString, _Char___init__impl__6a9atx(58), offset);
  return !(separator === -1) ? isoString : isoString + ':00';
}
function Companion() {
  Companion_instance = this;
  var tmp = this;
  // Inline function 'kotlinx.datetime.jsTry' call
  // Inline function 'kotlinx.datetime.Companion.DISTANT_PAST.<anonymous>' call
  var tmp$ret$1 = Instant.ofEpochSecond(get_DISTANT_PAST_SECONDS().p6(), 999999999);
  tmp.q4t_1 = new Instant_0(tmp$ret$1);
  var tmp_0 = this;
  // Inline function 'kotlinx.datetime.jsTry' call
  // Inline function 'kotlinx.datetime.Companion.DISTANT_FUTURE.<anonymous>' call
  var tmp$ret$3 = Instant.ofEpochSecond(get_DISTANT_FUTURE_SECONDS().p6(), 0);
  tmp_0.r4t_1 = new Instant_0(tmp$ret$3);
  this.s4t_1 = new Instant_0(Instant.MIN);
  this.t4t_1 = new Instant_0(Instant.MAX);
}
protoOf(Companion).p4t = function () {
  return new Instant_0(Clock.systemUTC().instant());
};
protoOf(Companion).l21 = function (isoString) {
  var tmp;
  try {
    // Inline function 'kotlinx.datetime.jsTry' call
    // Inline function 'kotlinx.datetime.Companion.parse.<anonymous>' call
    var tmp$ret$1 = OffsetDateTime.parse(fixOffsetRepresentation(Companion_getInstance(), isoString));
    tmp = new Instant_0(tmp$ret$1.toInstant());
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Error) {
      var e = $p;
      if (isJodaDateTimeParseException(e))
        throw DateTimeFormatException_init_$Create$_0(e);
      throw e;
    } else {
      throw $p;
    }
  }
  return tmp;
};
var Companion_instance;
function Companion_getInstance() {
  if (Companion_instance == null)
    new Companion();
  return Companion_instance;
}
function Instant_0(value) {
  Companion_getInstance();
  this.w4t_1 = value;
}
protoOf(Instant_0).x4t = function () {
  return numberToLong(this.w4t_1.epochSecond());
};
protoOf(Instant_0).y4t = function () {
  return numberToInt(this.w4t_1.nano());
};
protoOf(Instant_0).z4t = function () {
  // Inline function 'kotlin.Long.plus' call
  // Inline function 'kotlin.Long.times' call
  var this_0 = this.x4t();
  var other = get_MILLIS_PER_ONE();
  var this_1 = this_0.da(toLong(other));
  var other_0 = this.y4t() / get_NANOS_PER_MILLI() | 0;
  return this_1.lb(toLong(other_0));
};
protoOf(Instant_0).a4u = function (other) {
  return this.w4t_1.compareTo(other.w4t_1);
};
protoOf(Instant_0).d = function (other) {
  return this.a4u(other instanceof Instant_0 ? other : THROW_CCE());
};
protoOf(Instant_0).equals = function (other) {
  var tmp;
  if (this === other) {
    tmp = true;
  } else {
    var tmp_0;
    if (other instanceof Instant_0) {
      tmp_0 = this.w4t_1 === other.w4t_1 ? true : this.w4t_1.equals(other.w4t_1);
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  }
  return tmp;
};
protoOf(Instant_0).hashCode = function () {
  return this.w4t_1.hashCode();
};
protoOf(Instant_0).toString = function () {
  return this.w4t_1.toString();
};
function isJodaDateTimeParseException(_this__u8e3s4) {
  return hasJsExceptionName(_this__u8e3s4, 'DateTimeParseException');
}
function hasJsExceptionName(_this__u8e3s4, name) {
  // Inline function 'kotlin.js.asDynamic' call
  return _this__u8e3s4.name == name;
}
//region block: init
System_instance = new System();
DISTANT_PAST_SECONDS = new Long(-931914497, -750);
DISTANT_FUTURE_SECONDS = new Long(1151527680, 720);
NANOS_PER_MILLI = 1000000;
MILLIS_PER_ONE = 1000;
//endregion
//region block: exports
export {
  System_instance as System_instance3dr57gee6r420,
};
//endregion

//# sourceMappingURL=Kotlin-DateTime-library-kotlinx-datetime.mjs.map
