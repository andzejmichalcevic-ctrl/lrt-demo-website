import {
  encodeToByteArray1onwao0uakjfh as encodeToByteArray,
  protoOf180f3jzyo7rfj as protoOf,
  StringBuilder_init_$Create$2mwec1027v00x as StringBuilder_init_$Create$,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  Unit_instance1fbcbse1fwigr as Unit_instance,
  Default_getInstance5ktjwh40tq1j as Default_getInstance,
  chunked1r6ubl9km7ic5 as chunked,
  VOID7hggqo3abtya as VOID,
  joinTo3lkanfaxbzac2 as joinTo,
  decodeToString1x4faah2liw2p as decodeToString,
  split2bvyvnrlcifjv as split,
  startsWith26w8qjqapeeq6 as startsWith,
  toString1pkumu07cwy4m as toString,
  IllegalStateException_init_$Create$3ib9qa3pip8n4 as IllegalStateException_init_$Create$,
  substringAfter35b3qhto7hchb as substringAfter,
  substringBeforekje8w2lxhyb6 as substringBefore,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  trim11nh7r46at6sx as trim,
  isBlank1dvkhjjvox3p0 as isBlank,
  joinToString1cxrrlmo0chqs as joinToString,
  objectMeta213120oau977m as objectMeta,
  setMetadataForzkg9su7xd76l as setMetadataFor,
  classMetawt99a3kyl3us as classMeta,
  getStringHashCode26igk1bx568vk as getStringHashCode,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
//endregion
//region block: pre-declaration
setMetadataFor(PEM, 'PEM', objectMeta);
setMetadataFor(PemContent, 'PemContent', classMeta);
setMetadataFor(Companion, 'Companion', objectMeta);
setMetadataFor(PemLabel, 'PemLabel', classMeta);
//endregion
function PEM() {
  this.o4v_1 = '-----BEGIN ';
  this.p4v_1 = '-----END ';
  this.q4v_1 = '-----';
}
protoOf(PEM).r4v = function (content) {
  return encodeToByteArray(this.s4v(content));
};
protoOf(PEM).s4v = function (content) {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder_init_$Create$();
  // Inline function 'kotlin.contracts.contract' call
  // Inline function 'dev.whyoleg.cryptography.serialization.pem.PEM.encode.<anonymous>' call
  // Inline function 'kotlin.text.appendLine' call
  // Inline function 'kotlin.text.appendLine' call
  this_0.n5('-----BEGIN ').n5(_PemLabel___get_representation__impl__1gslev(content.t4v_1)).n5('-----').o5(_Char___init__impl__6a9atx(10));
  joinTo(chunked(Default_getInstance().kg(content.u4v_1), 64), this_0, '\n', VOID, '\n');
  // Inline function 'kotlin.text.appendLine' call
  // Inline function 'kotlin.text.appendLine' call
  this_0.n5('-----END ').n5(_PemLabel___get_representation__impl__1gslev(content.t4v_1)).n5('-----').o5(_Char___init__impl__6a9atx(10));
  return this_0.toString();
};
protoOf(PEM).v4v = function (bytes) {
  return this.w4v(decodeToString(bytes));
};
protoOf(PEM).w4v = function (string) {
  var lines = split(string, ['\n']);
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.collections.indexOfFirst' call
    var index = 0;
    var tmp0_iterator = lines.u();
    while (tmp0_iterator.v()) {
      var item = tmp0_iterator.w();
      // Inline function 'dev.whyoleg.cryptography.serialization.pem.PEM.decode.<anonymous>' call
      if (startsWith(item, '-----BEGIN ')) {
        tmp$ret$1 = index;
        break $l$block;
      }
      index = index + 1 | 0;
    }
    tmp$ret$1 = -1;
  }
  var beginLine = tmp$ret$1;
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!(beginLine === -1)) {
    // Inline function 'dev.whyoleg.cryptography.serialization.pem.PEM.decode.<anonymous>' call
    var message = 'Invalid PEM format: missing BEGIN label';
    throw IllegalStateException_init_$Create$(toString(message));
  }
  var tmp$ret$4;
  $l$block_0: {
    // Inline function 'kotlin.collections.indexOfFirst' call
    var index_0 = 0;
    var tmp0_iterator_0 = lines.u();
    while (tmp0_iterator_0.v()) {
      var item_0 = tmp0_iterator_0.w();
      // Inline function 'dev.whyoleg.cryptography.serialization.pem.PEM.decode.<anonymous>' call
      if (startsWith(item_0, '-----END ')) {
        tmp$ret$4 = index_0;
        break $l$block_0;
      }
      index_0 = index_0 + 1 | 0;
    }
    tmp$ret$4 = -1;
  }
  var endLine = tmp$ret$4;
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!(endLine === -1)) {
    // Inline function 'dev.whyoleg.cryptography.serialization.pem.PEM.decode.<anonymous>' call
    var message_0 = 'Invalid PEM format: missing END label';
    throw IllegalStateException_init_$Create$(toString(message_0));
  }
  // Inline function 'kotlin.text.trim' call
  var this_0 = substringBefore(substringAfter(lines.f1(beginLine), '-----BEGIN '), '-----');
  var beginLabel = toString(trim(isCharSequence(this_0) ? this_0 : THROW_CCE()));
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.text.isNotBlank' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!isBlank(beginLabel)) {
    // Inline function 'dev.whyoleg.cryptography.serialization.pem.PEM.decode.<anonymous>' call
    var message_1 = 'Invalid PEM format: BEGIN label is empty';
    throw IllegalStateException_init_$Create$(toString(message_1));
  }
  // Inline function 'kotlin.text.trim' call
  var this_1 = substringBefore(substringAfter(lines.f1(endLine), '-----END '), '-----');
  var endLabel = toString(trim(isCharSequence(this_1) ? this_1 : THROW_CCE()));
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.text.isNotBlank' call
  // Inline function 'kotlin.contracts.contract' call
  if (!!isBlank(endLabel)) {
    // Inline function 'dev.whyoleg.cryptography.serialization.pem.PEM.decode.<anonymous>' call
    var message_2 = 'Invalid PEM format: BEGIN label is empty';
    throw IllegalStateException_init_$Create$(toString(message_2));
  }
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(beginLabel === endLabel)) {
    // Inline function 'dev.whyoleg.cryptography.serialization.pem.PEM.decode.<anonymous>' call
    var message_3 = 'Invalid PEM format: BEGIN=`' + beginLabel + '`, END=`' + endLabel + '`';
    throw IllegalStateException_init_$Create$(toString(message_3));
  }
  var contentText = joinToString(lines.v1(beginLine + 1 | 0, endLine), '');
  return new PemContent(_PemLabel___init__impl__xifhtx(beginLabel), Default_getInstance().og(contentText));
};
var PEM_instance;
function PEM_getInstance() {
  return PEM_instance;
}
function PemContent(label, bytes) {
  this.t4v_1 = label;
  this.u4v_1 = bytes;
}
function ensurePemLabel(_this__u8e3s4, label) {
  // Inline function 'kotlin.check' call
  // Inline function 'kotlin.contracts.contract' call
  if (!(_this__u8e3s4.t4v_1 === label)) {
    // Inline function 'dev.whyoleg.cryptography.serialization.pem.ensurePemLabel.<anonymous>' call
    var message = 'Wrong PEM label, expected ' + new PemLabel(label) + ', actual ' + new PemLabel(_this__u8e3s4.t4v_1);
    throw IllegalStateException_init_$Create$(toString(message));
  }
  return _this__u8e3s4;
}
function _PemLabel___init__impl__xifhtx(representation) {
  return representation;
}
function _PemLabel___get_representation__impl__1gslev($this) {
  return $this;
}
function Companion() {
  Companion_instance = this;
  this.x4v_1 = _PemLabel___init__impl__xifhtx('PUBLIC KEY');
  this.y4v_1 = _PemLabel___init__impl__xifhtx('PRIVATE KEY');
  this.z4v_1 = _PemLabel___init__impl__xifhtx('RSA PUBLIC KEY');
  this.a4w_1 = _PemLabel___init__impl__xifhtx('RSA PRIVATE KEY');
}
var Companion_instance;
function Companion_getInstance() {
  if (Companion_instance == null)
    new Companion();
  return Companion_instance;
}
function PemLabel__toString_impl_auwpt1($this) {
  return 'PemLabel(representation=' + $this + ')';
}
function PemLabel__hashCode_impl_aw96zu($this) {
  return getStringHashCode($this);
}
function PemLabel__equals_impl_42ic6q($this, other) {
  if (!(other instanceof PemLabel))
    return false;
  if (!($this === (other instanceof PemLabel ? other.b4w_1 : THROW_CCE())))
    return false;
  return true;
}
function PemLabel(representation) {
  Companion_getInstance();
  this.b4w_1 = representation;
}
protoOf(PemLabel).toString = function () {
  return PemLabel__toString_impl_auwpt1(this.b4w_1);
};
protoOf(PemLabel).hashCode = function () {
  return PemLabel__hashCode_impl_aw96zu(this.b4w_1);
};
protoOf(PemLabel).equals = function (other) {
  return PemLabel__equals_impl_42ic6q(this.b4w_1, other);
};
//region block: init
PEM_instance = new PEM();
//endregion
//region block: exports
export {
  PemContent as PemContent61i58fspvc2p,
  ensurePemLabel as ensurePemLabel270qhcv8ps8sl,
  PEM_instance as PEM_instance1x9y0i69w08s3,
  Companion_getInstance as Companion_getInstance189lo0154tya6,
};
//endregion

//# sourceMappingURL=cryptography-kotlin-cryptography-serialization-pem.mjs.map
